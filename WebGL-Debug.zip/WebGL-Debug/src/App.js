App = $CreateClass(
    function() {
        Uno.Application.call(this);
        this._musicPlayer = null;
        this._fftProvider = null;
        this.Draw_SingleBatch_fe7860e_5_0_26 = null;
        this._draw_fe7860e = new Uno.Runtime.Implementation.ShaderBackends.OpenGL.GLDrawCall;
    },
    function(S) {
        var I = S.prototype = new Uno.Application;

        I.GetType = function()
        {
            return 300;
        };

        I.Update = function()
        {
            this._musicPlayer.Update();
        };

        I.Draw = function()
        {
            if (this._fftProvider.FftData() == null)
            {
                return;
            }

            for (var i = 0; i < this._fftProvider.FftData().length; i++)
            {
                var WorldSrtMatrix_fe7860e_2_46_5 = Uno.Matrix.Mul_11(Uno.Matrix.Scaling(Uno.Float3.New_2(2.0, Uno.Math.Max_1(2.0, this._fftProvider.FftData()[i] / 10.0), 2.0)), Uno.Matrix.Translation(Uno.Float3.New_2((i * 7.5) - 100.0, 0.0, 0.0)));
                {
                    this._draw_fe7860e.Use();
                    this._draw_fe7860e.Attrib_1(0, this.Draw_SingleBatch_fe7860e_5_0_26.Positions().DataType(), this.Draw_SingleBatch_fe7860e_5_0_26.Positions().VertexBuffer(), this.Draw_SingleBatch_fe7860e_5_0_26.Positions().StrideInBytes(), 0);
                    this._draw_fe7860e.Attrib_1(1, this.Draw_SingleBatch_fe7860e_5_0_26.Normals().DataType(), this.Draw_SingleBatch_fe7860e_5_0_26.Normals().VertexBuffer(), this.Draw_SingleBatch_fe7860e_5_0_26.Normals().StrideInBytes(), 0);
                    this._draw_fe7860e.Uniform_10(2, ($AsOp(Fuse.DrawContext.Current().Camera(), 250) != null) ? $AsOp(Fuse.DrawContext.Current().Camera(), 250).AbsolutePosition() : Uno.Float3.New_2(100.0, 100.0, 100.0));
                    this._draw_fe7860e.Uniform_14(3, Uno.Matrix.Mul_11(WorldSrtMatrix_fe7860e_2_46_5, Uno.Matrix.Mul_11(Uno.Matrix.LookAtRH(($AsOp(Fuse.DrawContext.Current().Camera(), 250) != null) ? $AsOp(Fuse.DrawContext.Current().Camera(), 250).AbsolutePosition() : Uno.Float3.New_2(100.0, 100.0, 100.0), ($AsOp(Fuse.DrawContext.Current().Camera(), 250) != null) ? Uno.Float3.op_Addition($AsOp(Fuse.DrawContext.Current().Camera(), 250).AbsolutePosition(), $AsOp(Fuse.DrawContext.Current().Camera(), 250).AbsoluteForward()) : Uno.Float3.New_2(0.0, 0.0, 0.0), ($AsOp(Fuse.DrawContext.Current().Camera(), 250) != null) ? $AsOp(Fuse.DrawContext.Current().Camera(), 250).AbsoluteUp() : Uno.Float3.New_2(0.0, 0.0, 1.0)), Uno.Matrix.PerspectiveRH(($AsOp(Fuse.DrawContext.Current().Camera(), 250) != null) ? $AsOp(Fuse.DrawContext.Current().Camera(), 250).Frustum().FovRadians() : 0.7853982, Fuse.DrawContext.Current().Aspect(), ($AsOp(Fuse.DrawContext.Current().Camera(), 250) != null) ? $AsOp(Fuse.DrawContext.Current().Camera(), 250).Frustum().ZNear() : 1.0, ($AsOp(Fuse.DrawContext.Current().Camera(), 250) != null) ? $AsOp(Fuse.DrawContext.Current().Camera(), 250).Frustum().ZFar() : 10000.0))));
                    this._draw_fe7860e.Uniform_14(4, WorldSrtMatrix_fe7860e_2_46_5);
                    this._draw_fe7860e.Uniform_14(5, Uno.Matrix.Transpose_2(Uno.Matrix.Invert(WorldSrtMatrix_fe7860e_2_46_5)));
                    this._draw_fe7860e.Draw(this.Draw_SingleBatch_fe7860e_5_0_26.VertexCount(), this.Draw_SingleBatch_fe7860e_5_0_26.IndexType(), this.Draw_SingleBatch_fe7860e_5_0_26.IndexBuffer());
                }
            }
        };

        I.init_DrawCalls = function()
        {
            this.Draw_SingleBatch_fe7860e_5_0_26 = Fuse.Drawing.Batching.BatchHelpers.CreateSingleBatch(Fuse.Drawing.Meshes.MeshGenerator.CreateCube(Uno.Float3.New_1(0.0), 0.5));
            this._draw_fe7860e = Uno.Runtime.Implementation.ShaderBackends.OpenGL.GLDrawCall.New_1($DownCast(Uno.Runtime.Implementation.Internal.BundleRegistry.Get(46), 137));
        };

        App._InitTypes = function()
        {
            Outracks.UIThemes.MobileBlue.MobileBlueStyle._TypeInit();
            Uno.Diagnostics.Debug._TypeInit();
            Uno.Runtime.Implementation.Internal.NumericFormatter._TypeInit();
            Uno.String._TypeInit();
            Uno.Color._TypeInit();
            Uno.EventArgs._TypeInit();
            Experimental.ApiBindings.WebAudio.AudioContext._TypeInit();
            Experimental.Net.Http.HttpMessageHandler._TypeInit();
            Experimental.Net.Http.HttpMethodStringConverter._TypeInit();
            Fuse.Profiling.Context._TypeInit();
            Fuse.Resources.Resources._TypeInit();
            Fuse.Resources.BundleFileImageSourceCache._TypeInit();
            Fuse.Resources.DisposalManager._TypeInit();
            Fuse.Resources.HttpImageSourceCache._TypeInit();
            Fuse.Animations.BlenderMap._TypeInit();
            Fuse.Animations.Mixer._TypeInit();
            Fuse.Animations.MasterTransform._TypeInit();
            Fuse.Drawing.BlendModeHelpers._TypeInit();
            Fuse.Drawing.Colors._TypeInit();
            Fuse.Drawing.Brushes._TypeInit();
            Fuse.Triggers.Tapped._TypeInit();
            Fuse.Internal.TextPosition._TypeInit();
            Fuse.Entities.Designer.PreloadedResources._TypeInit();
            Fuse.Controls.Canvas._TypeInit_2();
            Fuse.Controls.DefaultScrollViewerBehavior._TypeInit();
            Fuse.Layouts.DockLayout._TypeInit();
            Fuse.Layouts.GridLayout._TypeInit();
            Fuse.Layouts.Layouts._TypeInit();
            Fuse.DrawContext._TypeInit();
            Fuse.Environment._TypeInit();
            Fuse.Input._TypeInit();
            Fuse.UpdateManager._TypeInit();
            Fuse.Keyboard._TypeInit();
            Fuse.Node._TypeInit();
            Fuse.Cache._TypeInit();
            Fuse.Element._TypeInit_1();
        };

        I._ObjInit_1 = function()
        {
            App._InitTypes();
            Uno.Application.prototype._ObjInit.call(this);
            this._musicPlayer = FuseGame.Audio.MusicPlayer.New_1($DownCast(Uno.Runtime.Implementation.Internal.BundleRegistry.Get(1), 171));
            this._fftProvider = FuseGame.Audio.FftProvider.New_1(this._musicPlayer, 0.3);
            this.init_DrawCalls();
        };

        App.New_1 = function()
        {
            var inst = new App;
            inst._ObjInit_1();
            return inst;
        };

    });
