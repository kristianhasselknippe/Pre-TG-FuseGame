Player = $CreateClass(
    function() {
        GameObject.call(this);
        this.RateOfFire = 0;
        this.RapidFireRate = 0;
        this._powerups = null;
        this._wDown = false;
        this._aDown = false;
        this._sDown = false;
        this._dDown = false;
        this._spaceDown = false;
        this._shootTimer = 0;
    },
    function(S) {
        var I = S.prototype = new GameObject;

        I.GetType = function()
        {
            return 1034;
        };

        I.Up = function()
        {
            return (this._wDown ? 1 : 0);
        };

        I.Left = function()
        {
            return (this._aDown ? -1 : 0);
        };

        I.Down = function()
        {
            return (this._sDown ? -1 : 0);
        };

        I.Right = function()
        {
            return (this._dDown ? 1 : 0);
        };

        I.IsShooting = function()
        {
            return this._spaceDown;
        };

        I.OnCollision = function(other)
        {
            if ($IsOp(other, 1039))
            {
                this._powerups.Add($DownCast(other, 1039));
                GameObject.Destroy(other);

                if ($IsOp(other, 1041))
                {
                    this.Children()["Uno.Collections.ICollection__Fuse_Element.Add"]($DownCast(other, 1041).GetAppearance());
                }
            }
            else if ($IsOp(other, 1036))
            {
                GameObject.Game().Score(0);
            }
        };

        I.OnUpdate = function(dt)
        {
            var screenSize_124 = new Uno.Float2;
            this.ProcessInput(dt);
            screenSize_124.op_Assign(GameObject.ScreenSize());

            if ((this.Position().X > (screenSize_124.X * 0.5)) || (this.Position().X < (screenSize_124.X * -0.5)))
            {
                this.Position(Uno.Float2.New_2(-this.Position().X, this.Position().Y));
            }

            if ((this.Position().Y > (screenSize_124.Y * 0.5)) || (this.Position().Y < (screenSize_124.Y * -0.5)))
            {
                this.Position(Uno.Float2.New_2(this.Position().X, -this.Position().Y));
            }

            this.ProcessPowerups(dt);
            this._shootTimer = this._shootTimer + dt;

            if (this.IsShooting() && (this._shootTimer > (1.0 / this.RateOfFire)))
            {
                this.Shoot();
                this._shootTimer = 0.0;
            }
        };

        I.ProcessPowerups = function(dt)
        {
            var hasRapidFire = false;
            var hasShield = false;
            var hasBoom = false;

            for (var i = 0; i < this._powerups.Count(); i++)
            {
                this._powerups.Item(i).Duration = this._powerups.Item(i).Duration - dt;

                if (this._powerups.Item(i).Duration < 0.0)
                {
                    if (this.Children()["Uno.Collections.ICollection__Fuse_Element.Contains"](this._powerups.Item(i)))
                    {
                        this.Children()["Uno.Collections.ICollection__Fuse_Element.Remove"](this._powerups.Item(i));
                    }

                    this._powerups.RemoveAt(i);
                    continue;
                }

                if ($IsOp(this._powerups.Item(i), 1040))
                {
                    hasRapidFire = true;
                }
                else if ($IsOp(this._powerups.Item(i), 1041))
                {
                    hasShield = true;
                }
                else if ($IsOp(this._powerups.Item(i), 1042))
                {
                    hasBoom = true;
                }
            }

            this.RateOfFire = hasRapidFire ? this.RapidFireRate : 3.0;
        };

        I.ProcessInput = function(dt)
        {
            var rotation = Uno.Math.DegreesToRadians_1(this.Rotation());
            var input = this.Up() + this.Down();
            var velDelta = input * dt;
            var rot = this.Left() + this.Right();
            var rotDelta = (rot * dt) * this.RotationSpeed;
            this.Rotation(this.Rotation() + Uno.Math.RadiansToDegrees_1(rotDelta));
            var x = Uno.Math.Cos_1(rotation);
            var y = Uno.Math.Sin_1(rotation);
            var dir = Uno.Float2.op_Multiply(Uno.Vector.Normalize(Uno.Float2.New_2(x, y)), this.Acceleration);
            this.Velocity(Uno.Float2.op_Addition(this.Velocity(), Uno.Float2.op_Multiply_2(velDelta, dir)));
        };

        I.KeyPressed = function(sender, args)
        {
            switch (args.Key())
            {
                case 87:
                {
                    this._wDown = true;
                    break;
                }
                case 65:
                {
                    this._aDown = true;
                    break;
                }
                case 83:
                {
                    this._sDown = true;
                    break;
                }
                case 68:
                {
                    this._dDown = true;
                    break;
                }
                case 32:
                {
                    this._spaceDown = true;
                    break;
                }
            }
        };

        I.Shoot = function()
        {
            GameObject.Instantiate(Bullet.New_4(this.Position(), this.Rotation()));
        };

        I.KeyReleased = function(sender, args)
        {
            switch (args.Key())
            {
                case 87:
                {
                    this._wDown = false;
                    break;
                }
                case 65:
                {
                    this._aDown = false;
                    break;
                }
                case 83:
                {
                    this._sDown = false;
                    break;
                }
                case 68:
                {
                    this._dDown = false;
                    break;
                }
                case 32:
                {
                    this._spaceDown = false;
                    break;
                }
            }
        };

        I._ObjInit_5 = function()
        {
            var collection_123;
            this.RateOfFire = 3.0;
            this.RapidFireRate = 15.0;
            this._powerups = Uno.Collections.List__Powerup.New_1();
            GameObject.prototype._ObjInit_4.call(this);
            var image = Fuse.Image.New_1();
            image.Texture($DownCast(Uno.Runtime.Implementation.Internal.BundleRegistry.Get(2), 324));
            image.Transforms()["Uno.Collections.ICollection__Fuse_Transform.Add"]((collection_123 = Fuse.Rotation.New_1(), collection_123.Degrees(90.0), 90.0, collection_123));
            this.Appearance(image);
            this.Effects()["Uno.Collections.ICollection__Fuse_Effects_Effect.Add"](FuseGame.PlayerEffect.New_1());
            this.Width(50.0);
            this.Height(50.0);
            Uno.Application.Current().Window().add_KeyPressed($CreateDelegate(this, Player.prototype.KeyPressed, 493));
            Uno.Application.Current().Window().add_KeyReleased($CreateDelegate(this, Player.prototype.KeyReleased, 493));
            GameObject.Game().RegisterCollisionCallback(this, $CreateDelegate(this, Player.prototype.OnCollision, 481));
        };

        Player.New_4 = function()
        {
            var inst = new Player;
            inst._ObjInit_5();
            return inst;
        };

    });
