Collider = $CreateClass(
    function() {
        this.GameObject = null;
        this.OnCollision = null;
    },
    function(S) {
        var I = S.prototype;

        I.GetType = function()
        {
            return 1038;
        };

        I.AreColliding = function(other)
        {
            return !((((other.BoundingBox().Left > this.GameObject.BoundingBox().Right) || (other.BoundingBox().Right < this.GameObject.BoundingBox().Left)) || (other.BoundingBox().Top > this.GameObject.BoundingBox().Bottom)) || (other.BoundingBox().Bottom < this.GameObject.BoundingBox().Top));
        };

        I._ObjInit = function(go, onCollision)
        {
            this.GameObject = go;
            this.OnCollision = onCollision;
        };

        Collider.New_1 = function(go, onCollision)
        {
            var inst = new Collider;
            inst._ObjInit(go, onCollision);
            return inst;
        };

    });
