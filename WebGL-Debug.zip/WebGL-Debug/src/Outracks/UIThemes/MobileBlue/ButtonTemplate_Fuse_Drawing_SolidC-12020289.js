Outracks.UIThemes.MobileBlue.ButtonTemplate_Fuse_Drawing_SolidColor_Color_Property = $CreateClass(
    function() {
        Uno.UX.Property__float4.call(this);
        this._obj = null;
    },
    function(S) {
        var I = S.prototype = new Uno.UX.Property__float4;

        I.GetType = function()
        {
            return 49;
        };

        I.OnGet = function()
        {
            return this._obj.Color();
        };

        I.OnSet = function(v)
        {
            this._obj.Color(v);
        };

        I._ObjInit_2 = function(obj)
        {
            Uno.UX.Property__float4.prototype._ObjInit_1.call(this, 0);
            this._obj = obj;
        };

        Outracks.UIThemes.MobileBlue.ButtonTemplate_Fuse_Drawing_SolidColor_Color_Property.New_1 = function(obj)
        {
            var inst = new Outracks.UIThemes.MobileBlue.ButtonTemplate_Fuse_Drawing_SolidColor_Color_Property;
            inst._ObjInit_2(obj);
            return inst;
        };

    });
