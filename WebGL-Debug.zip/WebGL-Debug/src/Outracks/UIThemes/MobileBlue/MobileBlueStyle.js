Outracks.UIThemes.MobileBlue.MobileBlueStyle = $CreateClass(
    function() {
        Fuse.Style.call(this);
    },
    function(S) {
        var I = S.prototype = new Fuse.Style;

        Outracks.UIThemes.MobileBlue.MobileBlueStyle.LatoRegular = null;

        I.GetType = function()
        {
            return 41;
        };

        I.InitializeUX = function()
        {
            var temp1 = Outracks.UIThemes.MobileBlue.ButtonTemplate.New_1();
            var temp2 = Outracks.UIThemes.MobileBlue.SliderTemplate.New_1();
            var temp3 = Outracks.UIThemes.MobileBlue.TextInputTemplate.New_1();
            var temp4 = Outracks.UIThemes.MobileBlue.BackButtonTemplate.New_1();
            var temp5 = Outracks.UIThemes.MobileBlue.SwitchTemplate.New_1();
            var temp6 = Outracks.UIThemes.MobileBlue.NavigationBarTemplate.New_1();
            var temp7 = Outracks.UIThemes.MobileBlue.PageTemplate.New_1();
            this.Templates()["Uno.Collections.ICollection__Uno_UX_ITemplate.Add"]($DownCast(temp1, 33161));
            this.Templates()["Uno.Collections.ICollection__Uno_UX_ITemplate.Add"]($DownCast(temp2, 33161));
            this.Templates()["Uno.Collections.ICollection__Uno_UX_ITemplate.Add"]($DownCast(temp3, 33161));
            this.Templates()["Uno.Collections.ICollection__Uno_UX_ITemplate.Add"]($DownCast(temp4, 33161));
            this.Templates()["Uno.Collections.ICollection__Uno_UX_ITemplate.Add"]($DownCast(temp5, 33161));
            this.Templates()["Uno.Collections.ICollection__Uno_UX_ITemplate.Add"]($DownCast(temp6, 33161));
            this.Templates()["Uno.Collections.ICollection__Uno_UX_ITemplate.Add"]($DownCast(temp7, 33161));
        };

        Outracks.UIThemes.MobileBlue.MobileBlueStyle._TypeInit = function()
        {
            Outracks.UIThemes.MobileBlue.MobileBlueStyle.LatoRegular = Fuse.Font.New_2();
            Outracks.UIThemes.MobileBlue.MobileBlueStyle.LatoRegular.IsDefault(true);
            var temp = $DownCast(Uno.Runtime.Implementation.Internal.BundleRegistry.Get(0), 316);
            Outracks.UIThemes.MobileBlue.MobileBlueStyle.LatoRegular.FontFace(temp);
        };

        I._ObjInit_1 = function()
        {
            Fuse.Style.prototype._ObjInit.call(this);
            this.InitializeUX();
        };

        Outracks.UIThemes.MobileBlue.MobileBlueStyle.New_2 = function()
        {
            var inst = new Outracks.UIThemes.MobileBlue.MobileBlueStyle;
            inst._ObjInit_1();
            return inst;
        };

    });
