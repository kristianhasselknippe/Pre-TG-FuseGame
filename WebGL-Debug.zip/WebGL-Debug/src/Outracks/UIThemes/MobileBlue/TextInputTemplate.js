Outracks.UIThemes.MobileBlue.TextInputTemplate = $CreateClass(
    function() {
        Uno.UX.Template__Fuse_Controls_TextInput.call(this);
        this.SolidColor1_Color_inst = null;
        this.DropShadow1_Color_inst = null;
    },
    function(S) {
        var I = S.prototype = new Uno.UX.Template__Fuse_Controls_TextInput;

        I.GetType = function()
        {
            return 46;
        };

        I.OnApply = function(self)
        {
            var Focus1 = Fuse.Triggers.FocusWithin.New_1();
            var SetFloat1 = Fuse.Animations.ChangeFloat4.New_1();
            SetFloat1.Value(Uno.Float4.New_2(0.6, 0.6, 0.6, 0.0));
            SetFloat1.Easing(17);
            SetFloat1.Duration(0.4);
            var SetFloat2 = Fuse.Animations.ChangeFloat4.New_1();
            SetFloat2.Value(Uno.Float4.New_2(0.4156863, 0.7294118, 1.0, 1.0));
            SetFloat2.Easing(17);
            SetFloat2.Duration(0.4);
            var DropShadow1 = Fuse.Effects.DropShadow.New_1();
            DropShadow1.Softness(0.5317994);
            DropShadow1.Color(Uno.Float4.New_2(0.4156863, 0.7294118, 1.0, 0.0));
            var Background = Fuse.Shapes.Rectangle.New_1();
            Background.CornerRadius(2.0);
            var SolidColor3 = Fuse.Drawing.SolidColor.New_1();
            var Stroke2 = Fuse.Drawing.Stroke.New_1();
            Stroke2.Width(2.0);
            var SolidColor1 = Fuse.Drawing.SolidColor.New_1();
            SolidColor1.Color(Uno.Float4.New_2(0.6, 0.6, 0.6, 1.0));
            self.SetStyleMargin(Uno.Float4.New_2(5.0, 5.0, 5.0, 5.0));
            self.SetStylePadding(Uno.Float4.New_2(20.0, 25.0, 20.0, 25.0));
            self.IsFocusable(true);
            this.SolidColor1_Color_inst = Outracks.UIThemes.MobileBlue.TextInputTemplate_Fuse_Drawing_SolidColor_Color_Property.New_1(SolidColor1);
            this.DropShadow1_Color_inst = Outracks.UIThemes.MobileBlue.TextInputTemplate_Fuse_Effects_DropShadow_Color_Property.New_1(DropShadow1);
            Focus1.Animators()["Uno.Collections.ICollection__Fuse_Animations_Animator.Add"](SetFloat1);
            Focus1.Animators()["Uno.Collections.ICollection__Fuse_Animations_Animator.Add"](SetFloat2);
            SetFloat1.Target(this.SolidColor1_Color_inst);
            SetFloat2.Target(this.DropShadow1_Color_inst);
            Background.Fills()["Uno.Collections.ICollection__Fuse_Drawing_Brush.Add"](SolidColor3);
            Background.Strokes()["Uno.Collections.ICollection__Fuse_Drawing_Stroke.Add"](Stroke2);
            Stroke2.Brush(SolidColor1);
            self.SetStyleAppearance(Background);
            self.AddStyleEffect(DropShadow1);
            self.AddStyleBehavior(Focus1);
        };

        I._ObjInit_1 = function()
        {
            Uno.UX.Template__Fuse_Controls_TextInput.prototype._ObjInit.call(this);
        };

        Outracks.UIThemes.MobileBlue.TextInputTemplate.New_1 = function()
        {
            var inst = new Outracks.UIThemes.MobileBlue.TextInputTemplate;
            inst._ObjInit_1();
            return inst;
        };

    });
