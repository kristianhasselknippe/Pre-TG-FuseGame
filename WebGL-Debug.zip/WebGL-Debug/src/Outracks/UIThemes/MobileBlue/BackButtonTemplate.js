Outracks.UIThemes.MobileBlue.BackButtonTemplate = $CreateClass(
    function() {
        Uno.UX.Template__Fuse_Controls_BackButton.call(this);
        this.ArrowColor_Color_inst = null;
        this.TextBlock1_TextColor_inst = null;
    },
    function(S) {
        var I = S.prototype = new Uno.UX.Template__Fuse_Controls_BackButton;

        I.GetType = function()
        {
            return 39;
        };

        I.OnApply = function(self)
        {
            var DockPanel1 = Fuse.Controls.DockPanel.New_3();
            DockPanel1.Alignment(9);
            Fuse.Controls.DockPanel.SetDock(DockPanel1, 0);
            var temp = Fuse.Shapes.Path.New_1();
            temp.Data("m 0 10 l 10 10 m 0 -20 l -10 10");
            temp.FillRule(0);
            temp.Width(10.0);
            temp.Height(20.0);
            temp.Margin(Uno.Float4.New_2(5.0, 0.0, 2.0, 0.0));
            Fuse.Controls.DockPanel.SetDock(temp, 0);
            var temp1 = Fuse.Drawing.Stroke.New_1();
            temp1.Width(1.0);
            var ArrowColor = Fuse.Drawing.SolidColor.New_1();
            ArrowColor.Color(Uno.Float4.New_2(0.1294118, 0.5882353, 0.9529412, 1.0));
            var TextBlock1 = Fuse.Elements.TextBlock.New_2();
            TextBlock1.Text("Back");
            TextBlock1.Alignment(9);
            TextBlock1.Margin(Uno.Float4.New_2(5.0, 0.0, 5.0, 0.0));
            TextBlock1.TextColor(Uno.Float4.New_2(0.2588235, 0.427451, 0.8470588, 1.0));
            TextBlock1.FontSize(18.0);
            TextBlock1.TextAlignment(1);
            var temp2 = Fuse.Shapes.Rectangle.New_1();
            var temp3 = Fuse.Triggers.Disabled.New_1();
            var temp4 = Fuse.Animations.ChangeColor.New_1();
            temp4.Color(Uno.Float4.New_2(0.6, 0.6, 0.6, 0.0));
            var temp5 = Fuse.Animations.ChangeColor.New_1();
            temp5.Color(Uno.Float4.New_2(0.6, 0.6, 0.6, 0.0));
            var temp6 = Fuse.Animations.Move.New_1();
            temp6.RelativeTo(1);
            temp6.X(-0.3);
            self.IsFocusable(true);
            this.ArrowColor_Color_inst = Outracks.UIThemes.MobileBlue.BackButtonTemplate_Fuse_Drawing_SolidColor_Color_Property.New_1(ArrowColor);
            this.TextBlock1_TextColor_inst = Outracks.UIThemes.MobileBlue.BackButtonTemplate_Fuse_Element_TextColor_Property.New_1(TextBlock1);
            DockPanel1.Children()["Uno.Collections.ICollection__Fuse_Element.Add"](temp);
            DockPanel1.Children()["Uno.Collections.ICollection__Fuse_Element.Add"](TextBlock1);
            temp.Strokes()["Uno.Collections.ICollection__Fuse_Drawing_Stroke.Add"](temp1);
            temp1.Brush(ArrowColor);
            temp3.Animators()["Uno.Collections.ICollection__Fuse_Animations_Animator.Add"](temp4);
            temp3.Animators()["Uno.Collections.ICollection__Fuse_Animations_Animator.Add"](temp5);
            temp3.Animators()["Uno.Collections.ICollection__Fuse_Animations_Animator.Add"](temp6);
            temp4.Target(this.ArrowColor_Color_inst);
            temp5.Target(this.TextBlock1_TextColor_inst);
            self.SetStyleAppearance(temp2);
            self.AddStyleChild(DockPanel1);
            self.AddStyleBehavior(temp3);
        };

        I._ObjInit_1 = function()
        {
            Uno.UX.Template__Fuse_Controls_BackButton.prototype._ObjInit.call(this);
        };

        Outracks.UIThemes.MobileBlue.BackButtonTemplate.New_1 = function()
        {
            var inst = new Outracks.UIThemes.MobileBlue.BackButtonTemplate;
            inst._ObjInit_1();
            return inst;
        };

    });
