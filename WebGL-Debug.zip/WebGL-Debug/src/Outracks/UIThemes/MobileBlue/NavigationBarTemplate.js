Outracks.UIThemes.MobileBlue.NavigationBarTemplate = $CreateClass(
    function() {
        Uno.UX.Template__Fuse_Controls_NavigationBar.call(this);
    },
    function(S) {
        var I = S.prototype = new Uno.UX.Template__Fuse_Controls_NavigationBar;

        I.GetType = function()
        {
            return 42;
        };

        I.OnApply = function(self)
        {
            var Background = Fuse.Shapes.Rectangle.New_1();
            Background.Height(45.0);
            var SolidColor1 = Fuse.Drawing.SolidColor.New_1();
            SolidColor1.Color(Uno.Float4.New_2(0.9411765, 0.9372549, 0.9372549, 1.0));
            self.SetStyleHeight(45.0);
            Background.Fills()["Uno.Collections.ICollection__Fuse_Drawing_Brush.Add"](SolidColor1);
            self.SetStyleAppearance(Background);
        };

        I._ObjInit_1 = function()
        {
            Uno.UX.Template__Fuse_Controls_NavigationBar.prototype._ObjInit.call(this);
        };

        Outracks.UIThemes.MobileBlue.NavigationBarTemplate.New_1 = function()
        {
            var inst = new Outracks.UIThemes.MobileBlue.NavigationBarTemplate;
            inst._ObjInit_1();
            return inst;
        };

    });
