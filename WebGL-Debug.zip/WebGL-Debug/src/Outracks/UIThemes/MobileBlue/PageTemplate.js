Outracks.UIThemes.MobileBlue.PageTemplate = $CreateClass(
    function() {
        Uno.UX.Template__Fuse_Controls_Page.call(this);
    },
    function(S) {
        var I = S.prototype = new Uno.UX.Template__Fuse_Controls_Page;

        I.GetType = function()
        {
            return 43;
        };

        I.OnApply = function(self)
        {
            var temp = Fuse.Triggers.Enter.New_1();
            var temp1 = Fuse.Animations.Move.New_1();
            temp1.RelativeTo(1);
            temp1.X(1.0);
            temp1.Easing(0);
            temp1.Duration(1.0);
            var temp2 = Fuse.Triggers.Exit.New_1();
            var temp3 = Fuse.Animations.Move.New_1();
            temp3.RelativeTo(1);
            temp3.X(-1.0);
            temp3.Easing(0);
            temp3.Duration(1.0);
            temp.Animators()["Uno.Collections.ICollection__Fuse_Animations_Animator.Add"](temp1);
            temp2.Animators()["Uno.Collections.ICollection__Fuse_Animations_Animator.Add"](temp3);
            self.AddStyleBehavior(temp);
            self.AddStyleBehavior(temp2);
        };

        I._ObjInit_1 = function()
        {
            Uno.UX.Template__Fuse_Controls_Page.prototype._ObjInit.call(this);
        };

        Outracks.UIThemes.MobileBlue.PageTemplate.New_1 = function()
        {
            var inst = new Outracks.UIThemes.MobileBlue.PageTemplate;
            inst._ObjInit_1();
            return inst;
        };

    });
