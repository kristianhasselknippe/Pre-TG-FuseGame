Outracks.UIThemes.MobileBlue.GutterBrush = $CreateClass(
    function() {
        Fuse.Drawing.DynamicBrush.call(this);
        this._left = new Uno.Float4;
        this._right = new Uno.Float4;
        this._split = 0;
    },
    function(S) {
        var I = S.prototype = new Fuse.Drawing.DynamicBrush;

        I.GetType = function()
        {
            return 38;
        };

        I.Left = function(value)
        {
            if (value !== undefined)
            {
                this._left.op_Assign(value);
                this.OnShadingChanged();
            }
            else
            {
                return this._left;
            }
        };

        I.Right = function(value)
        {
            if (value !== undefined)
            {
                this._right.op_Assign(value);
                this.OnShadingChanged();
            }
            else
            {
                return this._right;
            }
        };

        I.Split = function(value)
        {
            if (value !== undefined)
            {
                this._split = value;
                this.OnShadingChanged();
            }
            else
            {
                return this._split;
            }
        };

        I._ObjInit_2 = function()
        {
            this._left = Uno.Float4.New_1(1.0);
            this._right = Uno.Float4.New_1(1.0);
            Fuse.Drawing.DynamicBrush.prototype._ObjInit_1.call(this);
        };

        Outracks.UIThemes.MobileBlue.GutterBrush.New_1 = function()
        {
            var inst = new Outracks.UIThemes.MobileBlue.GutterBrush;
            inst._ObjInit_2();
            return inst;
        };

    });
