Outracks.UIThemes.MobileBlue.ButtonTemplate = $CreateClass(
    function() {
        Uno.UX.Template__Fuse_Controls_Button.call(this);
        this.fill_Color_inst = null;
    },
    function(S) {
        var I = S.prototype = new Uno.UX.Template__Fuse_Controls_Button;

        I.GetType = function()
        {
            return 40;
        };

        I.OnApply = function(self)
        {
            var temp = Fuse.Shapes.Rectangle.New_1();
            temp.CornerRadius(2.0);
            var fill = Fuse.Drawing.SolidColor.New_1();
            fill.Color(Uno.Float4.New_2(0.1294118, 0.5882353, 0.9529412, 1.0));
            var temp1 = Fuse.Triggers.Pressed.New_1();
            var temp2 = Fuse.Animations.ChangeColor.New_1();
            temp2.Color(Uno.Float4.New_2(0.09803922, 0.4627451, 0.8235294, 1.0));
            temp2.Easing(17);
            temp2.Duration(0.05);
            temp2.EasingBack(4);
            temp2.DurationBack(0.25);
            var temp3 = Fuse.Triggers.Hovered.New_1();
            var temp4 = Fuse.Animations.ChangeColor.New_1();
            temp4.Color(Uno.Float4.New_2(0.1176471, 0.5333334, 0.8980392, 1.0));
            temp4.Easing(17);
            temp4.Duration(0.05);
            temp4.EasingBack(4);
            temp4.DurationBack(0.15);
            self.SetStyleText("BUTTON");
            self.SetStyleMargin(Uno.Float4.New_2(5.0, 5.0, 5.0, 5.0));
            self.SetStylePadding(Uno.Float4.New_2(10.0, 10.0, 10.0, 10.0));
            self.SetStyleTextColor(Uno.Float4.New_2(1.0, 1.0, 1.0, 1.0));
            self.SetStyleTextAlignment(1);
            self.IsFocusable(true);
            this.fill_Color_inst = Outracks.UIThemes.MobileBlue.ButtonTemplate_Fuse_Drawing_SolidColor_Color_Property.New_1(fill);
            temp.Fills()["Uno.Collections.ICollection__Fuse_Drawing_Brush.Add"](fill);
            temp1.Animators()["Uno.Collections.ICollection__Fuse_Animations_Animator.Add"](temp2);
            temp2.Target(this.fill_Color_inst);
            temp3.Animators()["Uno.Collections.ICollection__Fuse_Animations_Animator.Add"](temp4);
            temp4.Target(this.fill_Color_inst);
            self.SetStyleAppearance(temp);
            self.AddStyleBehavior(temp1);
            self.AddStyleBehavior(temp3);
        };

        I._ObjInit_1 = function()
        {
            Uno.UX.Template__Fuse_Controls_Button.prototype._ObjInit.call(this);
        };

        Outracks.UIThemes.MobileBlue.ButtonTemplate.New_1 = function()
        {
            var inst = new Outracks.UIThemes.MobileBlue.ButtonTemplate;
            inst._ObjInit_1();
            return inst;
        };

    });
