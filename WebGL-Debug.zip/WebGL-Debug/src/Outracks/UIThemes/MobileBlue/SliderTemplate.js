Outracks.UIThemes.MobileBlue.SliderTemplate = $CreateClass(
    function() {
        Uno.UX.Template__Fuse_Controls_Slider.call(this);
    },
    function(S) {
        var I = S.prototype = new Uno.UX.Template__Fuse_Controls_Slider;

        I.GetType = function()
        {
            return 44;
        };

        I.OnApply = function(self)
        {
            var Thumb = Fuse.Controls.Panel.New_2();
            Thumb.Width(36.0);
            Thumb.Height(36.0);
            Thumb.Alignment(1);
            var Rectangle1 = Fuse.Shapes.Circle.New_1();
            Rectangle1.Width(16.0);
            Rectangle1.Height(16.0);
            Rectangle1.Alignment(10);
            var SolidColor1 = Fuse.Drawing.SolidColor.New_1();
            SolidColor1.Color(Uno.Float4.New_2(0.1294118, 0.5882353, 0.9529412, 1.0));
            var Rectangle2 = Fuse.Shapes.Circle.New_1();
            var SolidColor2 = Fuse.Drawing.SolidColor.New_1();
            SolidColor2.Color(Uno.Float4.New_2(0.4196078, 0.7333333, 1.0, 0.8235294));
            var temp = Fuse.Controls.Panel.New_2();
            var Gutter = Fuse.Shapes.Rectangle.New_1();
            Gutter.CornerRadius(3.0);
            Gutter.Height(4.0);
            Gutter.Alignment(8);
            Gutter.Margin(Uno.Float4.New_2(22.0, 0.0, 22.0, 0.0));
            var GutterBrush1 = Outracks.UIThemes.MobileBlue.GutterBrush.New_1();
            GutterBrush1.Left(Uno.Float4.New_2(0.4196078, 0.7333333, 1.0, 1.0));
            GutterBrush1.Right(Uno.Float4.New_2(0.8705882, 0.8705882, 0.8705882, 1.0));
            var temp1 = Fuse.Shapes.Rectangle.New_1();
            self.SetStyleMargin(Uno.Float4.New_2(5.0, 5.0, 5.0, 5.0));
            self.IsFocusable(true);
            Thumb.Children()["Uno.Collections.ICollection__Fuse_Element.Add"](Rectangle1);
            Thumb.Children()["Uno.Collections.ICollection__Fuse_Element.Add"](Rectangle2);
            Rectangle1.Fills()["Uno.Collections.ICollection__Fuse_Drawing_Brush.Add"](SolidColor1);
            Rectangle2.Fills()["Uno.Collections.ICollection__Fuse_Drawing_Brush.Add"](SolidColor2);
            temp.Appearance(temp1);
            temp.Children()["Uno.Collections.ICollection__Fuse_Element.Add"](Gutter);
            Gutter.Fill(GutterBrush1);
            self.Thumb(Thumb);
            self.SetStyleAppearance(temp);
        };

        I._ObjInit_1 = function()
        {
            Uno.UX.Template__Fuse_Controls_Slider.prototype._ObjInit.call(this);
        };

        Outracks.UIThemes.MobileBlue.SliderTemplate.New_1 = function()
        {
            var inst = new Outracks.UIThemes.MobileBlue.SliderTemplate;
            inst._ObjInit_1();
            return inst;
        };

    });
