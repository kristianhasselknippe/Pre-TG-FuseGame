Outracks.UIThemes.MobileBlue.SwitchTemplate = $CreateClass(
    function() {
        Uno.UX.Template__Fuse_Controls_Switch.call(this);
        this.SolidColor31_Color_inst = null;
        this.SolidColor3_Color_inst = null;
        this.SolidColor2_Color_inst = null;
    },
    function(S) {
        var I = S.prototype = new Uno.UX.Template__Fuse_Controls_Switch;

        I.GetType = function()
        {
            return 45;
        };

        I.OnApply = function(self)
        {
            var Panel = Fuse.Controls.Panel.New_2();
            Panel.Width(100.0);
            Panel.Height(42.0);
            var ThumbPanel = Fuse.Controls.Panel.New_2();
            ThumbPanel.Width(38.0);
            ThumbPanel.Height(38.0);
            ThumbPanel.Alignment(1);
            ThumbPanel.Margin(Uno.Float4.New_2(2.0, 2.0, 2.0, 2.0));
            var X = Fuse.Shapes.Path.New_1();
            X.Data("m 0 0 l 14 14 m 0 -14 l -14 14");
            X.Alignment(5);
            X.Margin(Uno.Float4.New_2(12.0, 12.0, 0.0, 0.0));
            var Stroke1 = Fuse.Drawing.Stroke.New_1();
            Stroke1.Width(2.0);
            var SolidColor3 = Fuse.Drawing.SolidColor.New_1();
            SolidColor3.Color(Uno.Float4.New_2(0.8705882, 0.8705882, 0.8705882, 1.0));
            var Check = Fuse.Shapes.Path.New_1();
            Check.Data("m 0 0 l 5 5 l 12 -12");
            Check.Alignment(5);
            Check.Margin(Uno.Float4.New_2(10.0, 13.0, 0.0, 0.0));
            var Stroke11 = Fuse.Drawing.Stroke.New_1();
            Stroke11.Width(2.0);
            var SolidColor31 = Fuse.Drawing.SolidColor.New_1();
            SolidColor31.Color(Uno.Float4.New_2(1.0, 1.0, 1.0, 0.0));
            var ThumbBackground = Fuse.Shapes.Circle.New_1();
            ThumbBackground.Width(38.0);
            ThumbBackground.Height(38.0);
            ThumbBackground.Alignment(1);
            var SolidColor2 = Fuse.Drawing.SolidColor.New_1();
            SolidColor2.Color(Uno.Float4.New_2(1.0, 1.0, 1.0, 1.0));
            var DropShadow1 = Fuse.Effects.DropShadow.New_1();
            DropShadow1.Softness(0.2171554);
            DropShadow1.Offset(Uno.Float2.New_2(2.0, 2.0));
            DropShadow1.Color(Uno.Float4.New_2(0.0, 0.0, 0.0, 0.1568628));
            var Background = Fuse.Shapes.Rectangle.New_1();
            Background.CornerRadius(21.0);
            Background.Antialiasing(1);
            Background.Width(100.0);
            Background.Height(42.0);
            var SolidColor1 = Fuse.Drawing.SolidColor.New_1();
            SolidColor1.Color(Uno.Float4.New_2(0.8705882, 0.8705882, 0.8705882, 1.0));
            var Stroke2 = Fuse.Drawing.Stroke.New_1();
            Stroke2.Width(0.5);
            var SolidColor4 = Fuse.Drawing.SolidColor.New_1();
            SolidColor4.Color(Uno.Float4.New_2(0.8235294, 0.8235294, 0.8235294, 1.0));
            var temp = Fuse.Controls.DefaultSwitchBehavior.New_1();
            var temp1 = Fuse.Animations.ChangeFloat4.New_1();
            temp1.Value(Uno.Float4.New_2(1.0, 1.0, 1.0, 1.5));
            temp1.Easing(3);
            temp1.Duration(0.45);
            var temp2 = Fuse.Animations.ChangeFloat4.New_1();
            temp2.Value(Uno.Float4.New_2(0.8705882, 0.8705882, 0.8705882, -0.5));
            temp2.Easing(3);
            temp2.Duration(0.45);
            var temp3 = Fuse.Animations.ChangeColor.New_1();
            temp3.Color(Uno.Float4.New_2(0.1294118, 0.5882353, 0.9529412, 1.0));
            temp3.Easing(3);
            temp3.Duration(0.45);
            var temp4 = Fuse.Animations.Move.New_1();
            temp4.X(58.0);
            temp4.Easing(3);
            temp4.Duration(0.45);
            self.SetStyleWidth(104.0);
            self.SetStyleHeight(42.0);
            this.SolidColor31_Color_inst = Outracks.UIThemes.MobileBlue.SwitchTemplate_Fuse_Drawing_SolidColor_Color_Property.New_1(SolidColor31);
            this.SolidColor3_Color_inst = Outracks.UIThemes.MobileBlue.SwitchTemplate_Fuse_Drawing_SolidColor_Color_Property.New_1(SolidColor3);
            this.SolidColor2_Color_inst = Outracks.UIThemes.MobileBlue.SwitchTemplate_Fuse_Drawing_SolidColor_Color_Property.New_1(SolidColor2);
            Panel.Appearance(Background);
            Panel.Children()["Uno.Collections.ICollection__Fuse_Element.Add"](ThumbPanel);
            ThumbPanel.Children()["Uno.Collections.ICollection__Fuse_Element.Add"](X);
            ThumbPanel.Children()["Uno.Collections.ICollection__Fuse_Element.Add"](Check);
            ThumbPanel.Children()["Uno.Collections.ICollection__Fuse_Element.Add"](ThumbBackground);
            ThumbPanel.Effects()["Uno.Collections.ICollection__Fuse_Effects_Effect.Add"](DropShadow1);
            X.Strokes()["Uno.Collections.ICollection__Fuse_Drawing_Stroke.Add"](Stroke1);
            Stroke1.Brush(SolidColor3);
            Check.Strokes()["Uno.Collections.ICollection__Fuse_Drawing_Stroke.Add"](Stroke11);
            Stroke11.Brush(SolidColor31);
            ThumbBackground.Fills()["Uno.Collections.ICollection__Fuse_Drawing_Brush.Add"](SolidColor2);
            Background.Fills()["Uno.Collections.ICollection__Fuse_Drawing_Brush.Add"](SolidColor1);
            Background.Strokes()["Uno.Collections.ICollection__Fuse_Drawing_Stroke.Add"](Stroke2);
            Stroke2.Brush(SolidColor4);
            temp.Animators()["Uno.Collections.ICollection__Fuse_Animations_Animator.Add"](temp1);
            temp.Animators()["Uno.Collections.ICollection__Fuse_Animations_Animator.Add"](temp2);
            temp.Animators()["Uno.Collections.ICollection__Fuse_Animations_Animator.Add"](temp3);
            temp.Animators()["Uno.Collections.ICollection__Fuse_Animations_Animator.Add"](temp4);
            temp1.Target(this.SolidColor31_Color_inst);
            temp2.Target(this.SolidColor3_Color_inst);
            temp3.Target(this.SolidColor2_Color_inst);
            temp4.Target(ThumbPanel);
            self.SetStyleAppearance(Panel);
            self.AddStyleBehavior(temp);
        };

        I._ObjInit_1 = function()
        {
            Uno.UX.Template__Fuse_Controls_Switch.prototype._ObjInit.call(this);
        };

        Outracks.UIThemes.MobileBlue.SwitchTemplate.New_1 = function()
        {
            var inst = new Outracks.UIThemes.MobileBlue.SwitchTemplate;
            inst._ObjInit_1();
            return inst;
        };

    });
