Boom = $CreateClass(
    function() {
        Powerup.call(this);
    },
    function(S) {
        var I = S.prototype = new Powerup;

        I.GetType = function()
        {
            return 1042;
        };

    });
