MainView = $CreateClass(
    function() {
        Fuse.App.call(this);
        this.bloom = null;
        this.background = null;
    },
    function(S) {
        var I = S.prototype = new Fuse.App;

        MainView._musicPlayer = null;

        I.GetType = function()
        {
            return 1032;
        };

        I.InitializeUX = function()
        {
            this.bloom = FuseGame.BloomEffect.New_3();
            this.bloom.Softness(20.0);
            this.bloom.Multiplier(2.0);
            this.bloom.CachingMode(2);
            var temp = Outracks.UIThemes.MobileBlue.MobileBlueStyle.New_2();
            var temp1 = Game.New_4();
            this.background = Background.New_3();
            var temp2 = Fuse.Translation.New_1();
            temp2.X(-240.0);
            this.ClearColor(Uno.Float4.New_2(1.0, 1.0, 1.0, 1.0));
            this.bloom.Style(temp);
            this.bloom.Children()["Uno.Collections.ICollection__Fuse_Element.Add"](temp1);
            temp1.Appearance(this.background);
            this.background.Transforms()["Uno.Collections.ICollection__Fuse_Transform.Add"](temp2);
            this.RootNode($DownCast(this.bloom, 33719));
        };

        MainView._InitTypes = function()
        {
            Outracks.UIThemes.MobileBlue.MobileBlueStyle._TypeInit();
            Uno.Diagnostics.Debug._TypeInit();
            Uno.Runtime.Implementation.Internal.NumericFormatter._TypeInit();
            Uno.String._TypeInit();
            Uno.Color._TypeInit();
            Uno.EventArgs._TypeInit();
            Experimental.ApiBindings.WebAudio.AudioContext._TypeInit();
            Experimental.Net.Http.HttpMessageHandler._TypeInit();
            Experimental.Net.Http.HttpMethodStringConverter._TypeInit();
            Fuse.Profiling.Context._TypeInit();
            Fuse.Resources.Resources._TypeInit();
            Fuse.Resources.BundleFileImageSourceCache._TypeInit();
            Fuse.Resources.DisposalManager._TypeInit();
            Fuse.Resources.HttpImageSourceCache._TypeInit();
            Fuse.Animations.BlenderMap._TypeInit();
            Fuse.Animations.Mixer._TypeInit();
            Fuse.Animations.MasterTransform._TypeInit();
            Fuse.Drawing.BlendModeHelpers._TypeInit();
            Fuse.Drawing.Colors._TypeInit();
            Fuse.Drawing.Brushes._TypeInit();
            Fuse.Triggers.Tapped._TypeInit();
            Fuse.Internal.TextPosition._TypeInit();
            Fuse.Entities.Designer.PreloadedResources._TypeInit();
            Fuse.Controls.Canvas._TypeInit_2();
            Fuse.Controls.DefaultScrollViewerBehavior._TypeInit();
            Fuse.Layouts.DockLayout._TypeInit();
            Fuse.Layouts.GridLayout._TypeInit();
            Fuse.Layouts.Layouts._TypeInit();
            Fuse.DrawContext._TypeInit();
            Fuse.Environment._TypeInit();
            Fuse.Input._TypeInit();
            Fuse.UpdateManager._TypeInit();
            Fuse.Keyboard._TypeInit();
            Fuse.Node._TypeInit();
            Fuse.Cache._TypeInit();
            Fuse.Element._TypeInit_1();
        };

        I._ObjInit_2 = function()
        {
            MainView._InitTypes();
            Fuse.App.prototype._ObjInit_1.call(this);
            MainView._musicPlayer = FuseGame.Audio.MusicPlayer.New_1($DownCast(Uno.Runtime.Implementation.Internal.BundleRegistry.Get(1), 441));
            this.InitializeUX();
            this.bloom.FftProvider(FuseGame.Audio.FftProvider.New_1(MainView._musicPlayer, 0.0));
            this.background.FftProvider(FuseGame.Audio.FftProvider.New_1(MainView._musicPlayer, 0.0));
        };

        MainView.New_2 = function()
        {
            var inst = new MainView;
            inst._ObjInit_2();
            return inst;
        };

    });
