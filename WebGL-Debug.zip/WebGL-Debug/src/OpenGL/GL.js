OpenGL.GL = $CreateClass(
    function() {
    },
    function(S) {

        OpenGL.GL.GetInteger = function(__pname)
        {
            return gl.getParameter(__pname) | 0;
        };

        OpenGL.GL.Disable = function(__cap)
        {
            gl.disable(__cap);
        };

        OpenGL.GL.Enable = function(__cap)
        {
            gl.enable(__cap);
        };

        OpenGL.GL.GetError = function()
        {
            return gl.getError();
        };

        OpenGL.GL.Clear = function(__mask)
        {
            gl.clear(__mask);
        };

        OpenGL.GL.ClearColor = function(__red, __green, __blue, __alpha)
        {
            gl.clearColor(__red, __green, __blue, __alpha);
        };

        OpenGL.GL.ClearDepth = function(__depth)
        {
            gl.clearDepth(__depth);
        };

        OpenGL.GL.ColorMask = function(__red, __green, __blue, __alpha)
        {
            gl.colorMask(__red, __green, __blue, __alpha);
        };

        OpenGL.GL.DepthMask = function(__flag)
        {
            gl.depthMask(__flag);
        };

        OpenGL.GL.BlendFuncSeparate = function(__srcRGB, __dstRGB, __srcAlpha, __dstAlpha)
        {
            gl.blendFuncSeparate(__srcRGB, __dstRGB, __srcAlpha, __dstAlpha);
        };

        OpenGL.GL.DepthFunc = function(__func)
        {
            gl.depthFunc(__func);
        };

        OpenGL.GL.CullFace = function(__mode)
        {
            gl.cullFace(__mode);
        };

        OpenGL.GL.FrontFace = function(__mode)
        {
            gl.frontFace(__mode);
        };

        OpenGL.GL.LineWidth = function(__width)
        {
            gl.lineWidth(__width);
        };

        OpenGL.GL.Scissor = function(__x, __y, __width, __height)
        {
            gl.scissor(__x, __y, __width, __height);
        };

        OpenGL.GL.Viewport = function(__x, __y, __width, __height)
        {
            gl.viewport(__x, __y, __width, __height);
        };

        OpenGL.GL.BindBuffer = function(__target, __buffer)
        {
            gl.bindBuffer(__target, __buffer);
        };

        OpenGL.GL.BufferDatai = function(__target, __sizeInBytes, __usage)
        {
            gl.bufferData(__target, __sizeInBytes, __usage);
        };

        OpenGL.GL.BufferData_1 = function(__target, __data, __usage)
        {
            gl.bufferData(__target, Uno.Marshalling.JavaScript.TypedArrays.CreateUint8Array(__data), __usage);
        };

        OpenGL.GL.BufferSubData = function(__target, __offset, __data)
        {
            gl.bufferSubData(__target, __offset, Uno.Marshalling.JavaScript.TypedArrays.CreateUint8Array(__data));
        };

        OpenGL.GL.CreateBuffer = function()
        {
            return gl.createBuffer();
        };

        OpenGL.GL.DeleteBuffer = function(__buffer)
        {
            gl.deleteBuffer(__buffer);
        };

        OpenGL.GL.BindFramebuffer = function(__target, __fb)
        {
            gl.bindFramebuffer(__target, __fb);
        };

        OpenGL.GL.CheckFramebufferStatus = function(__target)
        {
            return gl.checkFramebufferStatus(__target);
        };

        OpenGL.GL.CreateFramebuffer = function()
        {
            return gl.createFramebuffer();
        };

        OpenGL.GL.DeleteFramebuffer = function(__fb)
        {
            gl.deleteFramebuffer(__fb);
        };

        OpenGL.GL.FramebufferTexture2D = function(__target, __attachment, __textarget, __texture, __level)
        {
            gl.framebufferTexture2D(__target, __attachment, __textarget, __texture, __level);
        };

        OpenGL.GL.FramebufferRenderbuffer = function(__target, __attachment, __renderbuffertarget, __renderbuffer)
        {
            gl.framebufferRenderbuffer(__target, __attachment, __renderbuffertarget, __renderbuffer);
        };

        OpenGL.GL.GetFramebufferBinding = function()
        {
            return gl.getParameter(gl.FRAMEBUFFER_BINDING);
        };

        OpenGL.GL.BindRenderbuffer = function(__target, __renderbuffer)
        {
            gl.bindRenderbuffer(__target, __renderbuffer);
        };

        OpenGL.GL.CreateRenderbuffer = function()
        {
            return gl.createRenderbuffer();
        };

        OpenGL.GL.DeleteRenderbuffer = function(__renderbuffer)
        {
            gl.deleteRenderbuffer(__renderbuffer);
        };

        OpenGL.GL.RenderbufferStorage = function(__target, __internalFormat, __width, __height)
        {
            gl.renderbufferStorage(__target, __internalFormat, __width, __height);
        };

        OpenGL.GL.GetRenderbufferBinding = function()
        {
            return gl.getParameter(gl.RENDERBUFFER_BINDING);
        };

        OpenGL.GL.ActiveTexture = function(__texture)
        {
            gl.activeTexture(__texture);
        };

        OpenGL.GL.BindTexture = function(__target, __texture)
        {
            gl.bindTexture(__target, __texture);
        };

        OpenGL.GL.CreateTexture = function()
        {
            return gl.createTexture();
        };

        OpenGL.GL.DeleteTexture = function(__texture)
        {
            gl.deleteTexture(__texture);
        };

        OpenGL.GL.TexImage2D = function(__target, __level, __internalFormat, __width, __height, __border, __format, __type, __data)
        {
            gl.texImage2D(__target,__level,__internalFormat,__width,__height,__border,__format,__type,Uno.Marshalling.JavaScript.TypedArrays.CreateUint8Array(__data));
        };

        OpenGL.GL.TexParameteri = function(__target, __pname, __param)
        {
            gl.texParameteri(__target, __pname, __param);
        };

        OpenGL.GL.AttachShader = function(__program, __shader)
        {
            gl.attachShader(__program, __shader);
        };

        OpenGL.GL.CompileShader = function(__shader)
        {
            gl.compileShader(__shader);
        };

        OpenGL.GL.CreateProgram = function()
        {
            return gl.createProgram();
        };

        OpenGL.GL.CreateShader = function(__type)
        {
            return gl.createShader(__type);
        };

        OpenGL.GL.DeleteProgram = function(__program)
        {
            gl.deleteProgram(__program);
        };

        OpenGL.GL.DeleteShader = function(__shader)
        {
            gl.deleteShader(__shader);
        };

        OpenGL.GL.DetachShader = function(__program, __shader)
        {
            gl.detachShader(__program, __shader);
        };

        OpenGL.GL.GetProgramParameter = function(__program, __pname)
        {
            return gl.getProgramParameter(__program, __pname);
        };

        OpenGL.GL.GetProgramInfoLog = function(__program)
        {
            return gl.getProgramInfoLog(__program);
        };

        OpenGL.GL.GetShaderParameter = function(__shader, __pname)
        {
            return gl.getShaderParameter(__shader, __pname);
        };

        OpenGL.GL.GetShaderInfoLog = function(__shader)
        {
            return gl.getShaderInfoLog(__shader);
        };

        OpenGL.GL.LinkProgram = function(__program)
        {
            gl.linkProgram(__program);
        };

        OpenGL.GL.ShaderSource = function(__shader, __source)
        {
            gl.shaderSource(__shader, __source);
        };

        OpenGL.GL.UseProgram = function(__program)
        {
            gl.useProgram(__program);
        };

        OpenGL.GL.DisableVertexAttribArray = function(__index)
        {
            gl.disableVertexAttribArray(__index);
        };

        OpenGL.GL.EnableVertexAttribArray = function(__index)
        {
            gl.enableVertexAttribArray(__index);
        };

        OpenGL.GL.GetAttribLocation = function(__program, __name)
        {
            return gl.getAttribLocation(__program, __name);
        };

        OpenGL.GL.GetUniformLocation = function(__program, __name)
        {
            return gl.getUniformLocation(__program, __name);
        };

        OpenGL.GL.Uniform1i = function(__location, __value)
        {
            gl.uniform1i(__location, __value);
        };

        OpenGL.GL.Uniform1f = function(__location, __value)
        {
            gl.uniform1f(__location, __value);
        };

        OpenGL.GL.Uniform2f = function(__location, __value)
        {
            gl.uniform2f(__location, __value.X, __value.Y);
        };

        OpenGL.GL.Uniform3f = function(__location, __value)
        {
            gl.uniform3f(__location, __value.X, __value.Y, __value.Z);
        };

        OpenGL.GL.Uniform4f = function(__location, __value)
        {
            gl.uniform4f(__location, __value.X, __value.Y, __value.Z, __value.W);
        };

        OpenGL.GL.UniformMatrix4f = function(__location, __transpose, __value)
        {
            gl.uniformMatrix4fv(__location, __transpose, Uno.Marshalling.JavaScript.TypedArrays.CreateFloat32Array_2(__value));
        };

        OpenGL.GL.Uniform1fv = function(__location, __value)
        {
            gl.uniform1fv(__location, Uno.Marshalling.JavaScript.TypedArrays.CreateFloat32Array_3(__value));
        };

        OpenGL.GL.Uniform4fv = function(__location, __value)
        {
            gl.uniform4fv(__location, Uno.Marshalling.JavaScript.TypedArrays.CreateFloat32Array_6(__value));
        };

        OpenGL.GL.VertexAttribPointer = function(__index, __size, __type, __normalized, __stride, __offset)
        {
            gl.vertexAttribPointer(__index, __size, __type, __normalized, __stride, __offset);
        };

        OpenGL.GL.DrawArrays = function(__mode, __first, __count)
        {
            gl.drawArrays(__mode, __first, __count);
        };

        OpenGL.GL.DrawElements = function(__mode, __count, __type, __offset)
        {
            gl.drawElements(__mode, __count, __type, __offset);
        };

    });
