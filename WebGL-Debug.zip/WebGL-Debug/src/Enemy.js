Enemy = $CreateClass(
    function() {
        GameObject.call(this);
        this.EnemySpeed = 0;
    },
    function(S) {
        var I = S.prototype = new GameObject;

        I.GetType = function()
        {
            return 1036;
        };

        I.OnUpdate = function(dt)
        {
            var dir_123 = new Uno.Float2;
            dir_123.op_Assign(Uno.Vector.Normalize(Uno.Float2.op_UnaryNegation(this.Position())));
            this.Velocity(Uno.Float2.op_Multiply(dir_123, this.EnemySpeed));
        };

        I._ObjInit_5 = function()
        {
            this.EnemySpeed = 1.0;
            GameObject.prototype._ObjInit_4.call(this);
            this.Width(50.0);
            this.Height(50.0);
            var pb = FuseGame.ParticleBatcher.New_3(25.0, 70);
            this.Appearance(pb);
        };

        I._ObjInit_6 = function(pos)
        {
            this.EnemySpeed = 1.0;
            this._ObjInit_5();
            this.Position(pos);
        };

        Enemy.New_5 = function(pos)
        {
            var inst = new Enemy;
            inst._ObjInit_6(pos);
            return inst;
        };

    });
