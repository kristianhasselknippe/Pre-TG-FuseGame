Game = $CreateClass(
    function() {
        GameObject.call(this);
        this.SpawnEnemyRate = 0;
        this.SpawnPowerupRate = 0;
        this.ScoreTextBlock = null;
        this._score = 0;
        this._gameObjects = null;
        this._colliders = null;
        this._spawnEnemiesTimer = 0;
        this._spawnPowerupTimer = 0;
        this._rand = null;
    },
    function(S) {
        var I = S.prototype = new GameObject;

        I.GetType = function()
        {
            return 1037;
        };

        I.Score = function(value)
        {
            if (value !== undefined)
            {
                this._score = value;
                this.ScoreTextBlock.Text(Uno.String.op_Addition_2($CreateBox(value, 425), ""));
            }
            else
            {
                return this._score;
            }
        };

        I.RegisterCollisionCallback = function(go, onCollision)
        {
            this._colliders.Add(Collider.New_1(go, onCollision));
        };

        I.HandlerSpawning = function(dt)
        {
            this._spawnEnemiesTimer = this._spawnEnemiesTimer + dt;

            if (this._spawnEnemiesTimer > (1.0 / this.SpawnEnemyRate))
            {
                this.SpawnEnemy();
                this._spawnEnemiesTimer = 0.0;
            }

            this._spawnPowerupTimer = this._spawnPowerupTimer + dt;

            if (this._spawnPowerupTimer > (1.0 / this.SpawnPowerupRate))
            {
                this.SpawnPowerup();
                this._spawnPowerupTimer = 0.0;
            }
        };

        I.SpawnEnemy = function()
        {
            var ang = this._rand.NextFloat_1(0.0, 6.28318548);
            var x = Uno.Math.Cos_1(ang);
            var y = Uno.Math.Sin_1(ang);
            var pos = Uno.Float2.op_Multiply_1(Uno.Float2.New_2(x, y), GameObject.ScreenSize());
            GameObject.Instantiate(Enemy.New_5(pos));
        };

        I.SpawnPowerup = function()
        {
            var screenX = GameObject.ScreenSize().X * 0.5;
            var screenY = GameObject.ScreenSize().Y * 0.5;
            var x = this._rand.NextFloat_1(-screenX, screenX);
            var y = this._rand.NextFloat_1(-screenY, screenY);
            GameObject.Instantiate(RapidFire.New_5(Uno.Float2.New_2(x, y)));
        };

        I.OnUpdate = function(dt)
        {
            this.HandlerSpawning(dt);

            for (var i = 0; i < this._colliders.Count(); i++)
            {
                var collider = this._colliders.Item(i);

                for (var j = 0; j < this._gameObjects.Count(); j++)
                {
                    var go = this._gameObjects.Item(j);

                    if (!go.IsCollidable() || (go == collider.GameObject))
                    {
                        continue;
                    }

                    if (collider.AreColliding(go))
                    {
                        collider.OnCollision.Invoke(go);
                    }
                }
            }
        };

        I.Add = function(go)
        {
            this._gameObjects.Add(go);
            this.Children()["Uno.Collections.ICollection__Fuse_Element.Add"](go);
        };

        I.Remove = function(go)
        {
            if (this._gameObjects.Contains(go))
            {
                this._gameObjects.Remove(go);
            }

            if (this.Children()["Uno.Collections.ICollection__Fuse_Element.Contains"](go))
            {
                this.Children()["Uno.Collections.ICollection__Fuse_Element.Remove"](go);
            }

            for (var i = 0; i < this._colliders.Count(); i++)
            {
                var col = this._colliders.Item(i);

                if (col.GameObject == go)
                {
                    this._colliders.Remove(col);
                    return;
                }
            }
        };

        I._ObjInit_5 = function()
        {
            this.SpawnEnemyRate = 1.0;
            this.SpawnPowerupRate = 0.1;
            this.ScoreTextBlock = Fuse.Elements.TextBlock.New_2();
            this._gameObjects = Uno.Collections.List__GameObject.New_1();
            this._colliders = Uno.Collections.List__Collider.New_1();
            this._rand = Uno.Random.New_1(934232);
            GameObject.prototype._ObjInit_4.call(this);
            this.ScoreTextBlock.FontSize(50.0);
            this.ScoreTextBlock.Alignment(6);
            this.ScoreTextBlock.Text("0");
            this.ScoreTextBlock.TextColor(Uno.Float4.New_2(0.0, 0.0, 1.0, 1.0));
            this.Children()["Uno.Collections.ICollection__Fuse_Element.Add"](this.ScoreTextBlock);
            GameObject.SetGame(this);
            this.Add(RapidFire.New_5(Uno.Float2.New_2(200.0, 200.0)));
            this.Add(Player.New_4());
        };

        Game.New_4 = function()
        {
            var inst = new Game;
            inst._ObjInit_5();
            return inst;
        };

    });
