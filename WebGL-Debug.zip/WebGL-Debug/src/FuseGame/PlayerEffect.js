FuseGame.PlayerEffect = $CreateClass(
    function() {
        Fuse.Effects.Effect.call(this);
        this._fftProvider = null;
        this.numFoos = 0;
        this.Render_VertexData_91a5c636_7_2_1 = null;
        this.Render_WorldTransform_91a5c636_4_8_2 = new Uno.Float4x4;
        this.Render_WorldTransform_91a5c636_4_8_3 = new Uno.Float4x4;
        this._draw_91a5c636 = new Uno.Runtime.Implementation.ShaderBackends.OpenGL.GLDrawCall;
    },
    function(S) {
        var I = S.prototype = new Fuse.Effects.Effect;

        I.GetType = function()
        {
            return 1030;
        };

        I.RenderBounds = function()
        {
            return Uno.Rect.New_1(0.0, 0.0, this.Element().ActualSize().X, this.Element().ActualSize().Y);
        };

        I.Sound = function(sender, array)
        {
            this.numFoos = ((array[100] / 200.0) * 5.0) | 0;
            this.OnRenderingChanged();
        };

        I.Render = function(dc)
        {
            var compositMatrix_123 = new Uno.Float4x4;
            var elementRect_124 = new Uno.Recti;
            compositMatrix_123.op_Assign(this.GetCompositMatrix(dc));
            elementRect_124.op_Assign(this.GetLocalElementRect());

            if ((elementRect_124.Size().X > Uno.Graphics.Texture2D.MaxSize()) || (elementRect_124.Size().Y > Uno.Graphics.Texture2D.MaxSize()))
            {
                Uno.Diagnostics.Debug.Log(Uno.String.op_Addition_1(Uno.String.op_Addition(Uno.String.op_Addition_1("Player-effect bigger than maximum texture size, dropping rendering (size: ", $CopyStruct(elementRect_124.Size())), ", max-size: "), $CreateBox(Uno.Graphics.Texture2D.MaxSize(), 425)), 1, "/Users/vegard/Pre-TG-FuseGame/Effects/PlayerEffect.uno", 36);
                return;
            }

            var original = this.Element().CaptureRegion(dc, elementRect_124, Uno.Int2.New_1(0), Uno.Matrix.Invert(compositMatrix_123));
            var step = 0.2;

            for (var i = 0; i < this.numFoos; ++i)
            {
                {
                    this._draw_91a5c636.BlendEnabled(true);
                    this._draw_91a5c636.BlendSrcRgb(2);
                    this._draw_91a5c636.BlendDstRgb(3);
                    this._draw_91a5c636.BlendDstAlpha(3);
                    this._draw_91a5c636.DepthTestEnabled(false);
                    this._draw_91a5c636.Use();
                    this._draw_91a5c636.Attrib_1(0, 2, this.Render_VertexData_91a5c636_7_2_1, 8, 0);
                    this._draw_91a5c636.Uniform_8(1, dc.VirtualResolution().X);
                    this._draw_91a5c636.Uniform_8(2, dc.VirtualResolution().Y);
                    this._draw_91a5c636.Uniform_8(3, this.Element().Opacity());
                    this._draw_91a5c636.Uniform_14(4, Uno.Matrix.Mul_11(Uno.Matrix.Mul_7(this.Render_WorldTransform_91a5c636_4_8_2, Uno.Matrix.Scaling_1(Uno.Float2.op_Implicit(Uno.Int2.op_Explicit(Uno.Float2.op_Multiply(Uno.Float2.op_Implicit(elementRect_124.Size()), 1.0 - (step * i)))).X, Uno.Float2.op_Implicit(Uno.Int2.op_Explicit(Uno.Float2.op_Multiply(Uno.Float2.op_Implicit(elementRect_124.Size()), 1.0 - (step * i)))).Y, 1.0), this.Render_WorldTransform_91a5c636_4_8_3, Uno.Matrix.Translation_1(Uno.Float2.op_Addition(Uno.Float2.op_Implicit(elementRect_124.Position()), Uno.Float2.op_Multiply(Uno.Float2.op_Subtraction(Uno.Float2.op_Implicit(elementRect_124.Size()), Uno.Float2.op_Implicit(Uno.Int2.op_Explicit(Uno.Float2.op_Multiply(Uno.Float2.op_Implicit(elementRect_124.Size()), 1.0 - (step * i))))), 0.5)).X, Uno.Float2.op_Addition(Uno.Float2.op_Implicit(elementRect_124.Position()), Uno.Float2.op_Multiply(Uno.Float2.op_Subtraction(Uno.Float2.op_Implicit(elementRect_124.Size()), Uno.Float2.op_Implicit(Uno.Int2.op_Explicit(Uno.Float2.op_Multiply(Uno.Float2.op_Implicit(elementRect_124.Size()), 1.0 - (step * i))))), 0.5)).Y, 0.0)), compositMatrix_123));
                    this._draw_91a5c636.Sampler_2(5, original.ColorBuffer());
                    this._draw_91a5c636.DrawArrays(6);
                }
            }
        };

        I.init_DrawCalls = function()
        {
            this.Render_VertexData_91a5c636_7_2_1 = Uno.Graphics.VertexBuffer.New_3(Uno.Runtime.Implementation.Internal.BufferConverters.ToBuffer_1(Array.Init([Uno.Float2.New_2(0.0, 0.0), Uno.Float2.New_2(0.0, 1.0), Uno.Float2.New_2(1.0, 1.0), Uno.Float2.New_2(0.0, 0.0), Uno.Float2.New_2(1.0, 1.0), Uno.Float2.New_2(1.0, 0.0)], 430)), 0);
            this.Render_WorldTransform_91a5c636_4_8_2 = Uno.Matrix.Translation_1(-Uno.Float2.New_1(0.0).X, -Uno.Float2.New_1(0.0).Y, 0.0);
            this.Render_WorldTransform_91a5c636_4_8_3.op_Assign(Uno.Matrix.RotationZ(0.0));
            this._draw_91a5c636 = Uno.Runtime.Implementation.ShaderBackends.OpenGL.GLDrawCall.New_1($DownCast(Uno.Runtime.Implementation.Internal.BundleRegistry.Get(49), 383));
        };

        I._ObjInit_1 = function()
        {
            Fuse.Effects.Effect.prototype._ObjInit.call(this, 2);
            this._fftProvider = FuseGame.Audio.FftProvider.New_1(MainView._musicPlayer, 0.0);
            this._fftProvider.add_FftAvailable($CreateDelegate(this, FuseGame.PlayerEffect.prototype.Sound, 497));
            this.init_DrawCalls();
        };

        FuseGame.PlayerEffect.New_1 = function()
        {
            var inst = new FuseGame.PlayerEffect;
            inst._ObjInit_1();
            return inst;
        };

    });
