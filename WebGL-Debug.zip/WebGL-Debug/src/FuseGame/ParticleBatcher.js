FuseGame.ParticleBatcher = $CreateClass(
    function() {
        Fuse.Controls.Panel.call(this);
        this._batch = null;
        this.ParticleSize = 0;
        this.ParticleCount = 0;
        this.Radius = 0;
        this.Color = new Uno.Float4;
        this._draw_5f89302a = new Uno.Runtime.Implementation.ShaderBackends.OpenGL.GLDrawCall;
    },
    function(S) {
        var I = S.prototype = new Fuse.Controls.Panel;

        I.GetType = function()
        {
            return 1029;
        };

        I.Initialize = function()
        {
            var v_123 = new Uno.Float3;
            var maxVertices = 65535;
            var quadVertices = Array.Init([Uno.Float3.New_2(0.0, 0.0, 0.0), Uno.Float3.New_2(1.0, 0.0, 0.0), Uno.Float3.New_2(1.0, 1.0, 0.0), Uno.Float3.New_2(0.0, 1.0, 0.0)], 431);
            var quadIndices = Array.Init([0, 1, 2, 2, 3, 0], 424);
            var particleCount = this.ParticleCount;
            var verticeCount = particleCount * quadVertices.length;
            var indicesCount = particleCount * quadIndices.length;
            this._batch = Fuse.Drawing.Batching.Batch.New_1(verticeCount, indicesCount, true);
            var rand = Uno.Random.New_1(1338);
            var indexAdd = 0;

            for (var i = 0; i < particleCount; i++)
            {
                var pos = Uno.Float3.op_Multiply(Uno.Float3.New_2((rand.NextFloat() - 0.5) * 2.0, (rand.NextFloat() - 0.5) * 2.0, 0.0), this.Radius);

                for (var j = 0; j < quadVertices.length; j++)
                {
                    v_123.op_Assign(quadVertices[j]);
                    this._batch.Positions().Write_1(v_123);
                    this._batch.TexCoord0s().Write(Uno.Float2.New_2(v_123.X, 1.0 - v_123.Y));
                    this._batch.Attrib1Buffer().Write_2(Uno.Float4.New_7(pos, i));
                }

                for (var j = 0; j < quadIndices.length; j++)
                {
                    this._batch.Indices().Write_1((quadIndices[j] + indexAdd));
                }

                indexAdd = indexAdd + quadVertices.length;
            }
        };

        I.OnDraw = function(dc)
        {
            var compositMatrix_124 = new Uno.Float4x4;
            this.InvalidateVisual();
            compositMatrix_124.op_Assign(this.GetDrawMatrix(dc));
            {
                this._draw_5f89302a.DepthTestEnabled(false);
                this._draw_5f89302a.CullFace(0);
                this._draw_5f89302a.Use();
                this._draw_5f89302a.Attrib_1(0, this._batch.Attrib1Buffer().DataType(), this._batch.Attrib1Buffer().VertexBuffer(), this._batch.Attrib1Buffer().StrideInBytes(), 0);
                this._draw_5f89302a.Attrib_1(1, this._batch.Positions().DataType(), this._batch.Positions().VertexBuffer(), this._batch.Positions().StrideInBytes(), 0);
                this._draw_5f89302a.Uniform_8(2, Fuse.Time.FrameTime());
                this._draw_5f89302a.Uniform_8(3, this.Radius);
                this._draw_5f89302a.Uniform_9(4, Uno.Float2.New_2(this.ParticleSize, this.ParticleSize));
                this._draw_5f89302a.Uniform_14(5, compositMatrix_124);
                this._draw_5f89302a.Uniform_9(6, dc.VirtualResolution());
                this._draw_5f89302a.Uniform_8(7, (Fuse.Time.FrameTime() * 2.0) + 1.0);
                this._draw_5f89302a.Uniform_8(8, this.Color.X);
                this._draw_5f89302a.Uniform_8(9, Fuse.Time.FrameTime() * 2.0);
                this._draw_5f89302a.Uniform_8(10, this.Color.Z);
                this._draw_5f89302a.Uniform_8(11, this.Color.Y);
                this._draw_5f89302a.Uniform_8(12, this.Color.W);
                this._draw_5f89302a.Draw(this._batch.VertexCount(), this._batch.IndexType(), this._batch.IndexBuffer());
            }
        };

        I.init_DrawCalls = function()
        {
            this._draw_5f89302a = Uno.Runtime.Implementation.ShaderBackends.OpenGL.GLDrawCall.New_1($DownCast(Uno.Runtime.Implementation.Internal.BundleRegistry.Get(48), 383));
        };

        I._ObjInit_4 = function(radius, particleCount)
        {
            this.ParticleSize = 5.0;
            this.ParticleCount = 70;
            this.Radius = 50.0;
            this.Color = Uno.Float4.New_2(0.9, 0.0, 0.9, 1.0);
            Fuse.Controls.Panel.prototype._ObjInit_3.call(this);
            this.ParticleCount = particleCount;
            this.Radius = radius;
            this.Initialize();
            this.init_DrawCalls();
        };

        FuseGame.ParticleBatcher.New_3 = function(radius, particleCount)
        {
            var inst = new FuseGame.ParticleBatcher;
            inst._ObjInit_4(radius, particleCount);
            return inst;
        };

    });
