FuseGame.Audio.ScaleNode = $CreateClass(
    function() {
        this._velocity = 0;
        this._attractionForce = 0;
        this._attractionCurve = 0;
        this._damping = 0;
        this._energyEps = 0;
        this._simTime = 0;
        this.timeStep = 0;
        this.PositionChanged = null;
        this._IsLocked = false;
        this._Position = 0;
        this._AttractionDestinatoin = 0;
    },
    function(S) {
        var I = S.prototype;

        I.GetType = function()
        {
            return 1026;
        };

        I.IsLocked = function(value)
        {
            if (value !== undefined)
            {
                this._IsLocked = value;
            }
            else
            {
                return this._IsLocked;
            }
        };

        I.Position = function(value)
        {
            if (value !== undefined)
            {
                this._Position = value;
            }
            else
            {
                return this._Position;
            }
        };

        I.Velocity = function(value)
        {
            if (value !== undefined)
            {
                if (this._velocity != value)
                {
                    this._velocity = value;
                }
            }
            else
            {
                return this._velocity;
            }
        };

        I.AttractionDestinatoin = function(value)
        {
            if (value !== undefined)
            {
                this._AttractionDestinatoin = value;
            }
            else
            {
                return this._AttractionDestinatoin;
            }
        };

        I.AttractionForce = function(value)
        {
            if (value !== undefined)
            {
                this._attractionForce = value;
            }
            else
            {
                return this._attractionForce;
            }
        };

        I.AttractionCurve = function(value)
        {
            if (value !== undefined)
            {
                this._attractionCurve = value;
            }
            else
            {
                return this._attractionCurve;
            }
        };

        I.Damping = function(value)
        {
            if (value !== undefined)
            {
                this._damping = value;
            }
            else
            {
                return this._damping;
            }
        };

        I.Attraction = function()
        {
            var v = this.AttractionDestinatoin() - this.Position();
            return Uno.Math.Pow_1(Uno.Math.Abs_1(v), this.AttractionCurve()) * ((v < 0.0) ? -1 : 1);
        };

        I.GetTime = function()
        {
            return Fuse.Time.FrameTime();
        };

        I.Update = function()
        {
            var p = this.Position();

            while (this._simTime < this.GetTime())
            {
                this.Iterate();
                this._simTime = this._simTime + this.timeStep;
            }

            if ((this.Position() != p) && Uno.Delegate.op_Inequality(this.PositionChanged, null))
            {
                this.PositionChanged.Invoke(this.Position());
            }
        };

        I.Iterate = function()
        {
            this.Velocity(this.Velocity() + ((this.Attraction() * this.AttractionForce()) * this.timeStep));
            this.Velocity(this.Velocity() * this.Damping());

            if (!this.IsLocked())
            {
                this.Position(this.Position() + (this.Velocity() * this.timeStep));
            }
        };

        I._ObjInit = function()
        {
            this._attractionForce = 4000.0;
            this._attractionCurve = 0.65;
            this._damping = 0.985;
            this._energyEps = 1.0;
            this.timeStep = 0.001;
        };

        FuseGame.Audio.ScaleNode.New_1 = function()
        {
            var inst = new FuseGame.Audio.ScaleNode;
            inst._ObjInit();
            return inst;
        };

    });
