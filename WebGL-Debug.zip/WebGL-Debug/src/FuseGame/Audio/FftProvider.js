FuseGame.Audio.FftProvider = $CreateClass(
    function() {
        this._player = null;
        this._pushDelay = 0;
        this._lastPushTime = 0;
        this.FftAvailable = null;
    },
    function(S) {
        var I = S.prototype;

        I.GetType = function()
        {
            return 1024;
        };

        I.OnFftAvailable = function(sender, fft)
        {
            var elapsed = Fuse.Time.FrameTime() - this._lastPushTime;

            if (elapsed >= this._pushDelay)
            {
                this._lastPushTime = Fuse.Time.FrameTime();

                if (Uno.Delegate.op_Inequality(this.FftAvailable, null))
                {
                    this.FftAvailable.Invoke(this, fft);
                }
            }
        };

        I._ObjInit = function(player, pushDelay)
        {
            this._player = player;
            this._player.add_FftAvailable($CreateDelegate(this, FuseGame.Audio.FftProvider.prototype.OnFftAvailable, 497));
            this._pushDelay = pushDelay;
        };

        FuseGame.Audio.FftProvider.New_1 = function(player, pushDelay)
        {
            var inst = new FuseGame.Audio.FftProvider;
            inst._ObjInit(player, pushDelay);
            return inst;
        };

        I.add_FftAvailable = function(value)
        {
            this.FftAvailable = $DownCast(Uno.Delegate.Combine(this.FftAvailable, value), 497);
        };

        I.remove_FftAvailable = function(value)
        {
            this.FftAvailable = $DownCast(Uno.Delegate.Remove(this.FftAvailable, value), 497);
        };

    });
