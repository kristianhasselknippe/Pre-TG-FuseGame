FuseGame.Audio.MusicPlayer = $CreateClass(
    function() {
        this._context = null;
        this._analyser = null;
        this._sourceNode = null;
        this._sourceBuffer = null;
        this._fftData = null;
        this._scaleNodes = null;
        this.FftAvailable = null;
    },
    function(S) {
        var I = S.prototype;

        I.GetType = function()
        {
            return 1025;
        };

        I.OnBufferLoaded = function(audioBuffer)
        {
            this._sourceBuffer = audioBuffer;
            this._sourceNode.Buffer(audioBuffer);
            this._sourceNode.Connect(this._analyser);
            this._analyser.Connect(this._context.Destination());
            this._sourceNode.Start();
            Fuse.UpdateManager.AddAction($CreateDelegate(this, FuseGame.Audio.MusicPlayer.prototype.Update, 436), 0);
        };

        I.Update = function()
        {
            var fftData = Array.Zeros(this._analyser.FrequencyBinCount(), 421);
            this._analyser.GetByteFrequencyData(fftData);

            for (var i = 0; i < this._scaleNodes.length; i++)
            {
                this._scaleNodes[i].AttractionDestinatoin(fftData[i] * 2.0);
                this._scaleNodes[i].Update();
                this._fftData[i] = this._scaleNodes[i].Position();
            }

            this.OnFftAvailable(this._fftData);
        };

        I.OnFftAvailable = function(fft)
        {
            if (Uno.Delegate.op_Inequality(this.FftAvailable, null))
            {
                this.FftAvailable.Invoke(this, fft);
            }
        };

        I._ObjInit = function(musicFile)
        {
            this._context = Experimental.ApiBindings.WebAudio.AudioContext.New_1();
            this._sourceNode = this._context.CreateAudioBufferSourceNode();
            this._analyser = this._context.CreateAnalyserNode();
            this._analyser.FftSize(256);
            this._analyser.SmoothingTimeConstat(0.0);
            this._scaleNodes = Array.Sized(this._analyser.FrequencyBinCount(), 1026);
            this._fftData = Array.Zeros(this._analyser.FrequencyBinCount(), 429);

            for (var i = 0; i < this._scaleNodes.length; i++)
            {
                this._scaleNodes[i] = FuseGame.Audio.ScaleNode.New_1();
            }

            this._context.CreateAudioBuffer(musicFile, $CreateDelegate(this, FuseGame.Audio.MusicPlayer.prototype.OnBufferLoaded, 469));
        };

        FuseGame.Audio.MusicPlayer.New_1 = function(musicFile)
        {
            var inst = new FuseGame.Audio.MusicPlayer;
            inst._ObjInit(musicFile);
            return inst;
        };

        I.add_FftAvailable = function(value)
        {
            this.FftAvailable = $DownCast(Uno.Delegate.Combine(this.FftAvailable, value), 497);
        };

    });
