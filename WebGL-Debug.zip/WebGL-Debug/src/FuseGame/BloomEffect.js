FuseGame.BloomEffect = $CreateClass(
    function() {
        Fuse.Controls.Panel.call(this);
        this._fftProvider = null;
        this._softness = 0;
        this._offset = new Uno.Float2;
        this._helpers = null;
        this._Multiplier = 0;
    },
    function(S) {
        var I = S.prototype = new Fuse.Controls.Panel;

        I.GetType = function()
        {
            return 1027;
        };

        I.FftProvider = function(value)
        {
            if (value !== undefined)
            {
                if (this._fftProvider != null)
                {
                    this._fftProvider.remove_FftAvailable($CreateDelegate(this, FuseGame.BloomEffect.prototype.OnFftAvailable, 497));
                }

                this._fftProvider = value;

                if (this._fftProvider != null)
                {
                    this._fftProvider.add_FftAvailable($CreateDelegate(this, FuseGame.BloomEffect.prototype.OnFftAvailable, 497));
                }
            }
            else
            {
                return this._fftProvider;
            }
        };

        I.Softness = function(value)
        {
            if (value !== undefined)
            {
                if (this._softness != value)
                {
                    this._softness = value;
                }
            }
            else
            {
                return this._softness;
            }
        };

        I.Multiplier = function(value)
        {
            if (value !== undefined)
            {
                this._Multiplier = value;
            }
            else
            {
                return this._Multiplier;
            }
        };

        I.Offset = function(value)
        {
            if (value !== undefined)
            {
                if (Uno.Float2.op_Inequality(this._offset, value))
                {
                    this._offset.op_Assign(value);
                }
            }
            else
            {
                return this._offset;
            }
        };

        I.OnFftAvailable = function(sender, fftData)
        {
            this.Multiplier(fftData[1] / 128.0);
            this.Offset(Uno.Float2.New_2(fftData[2] / 128.0, fftData[3] / 128.0));
        };

        I.OnDraw = function(dc)
        {
            var clientSize_123 = new Uno.Int2;
            var compositMatrix_124 = new Uno.Float4x4;
            var softness = Uno.Math.Sqrt_1(this.Softness()) * 10.0;
            clientSize_123.op_Assign(Uno.Application.Current().Window().ClientSize());
            var temp = Fuse.FramebufferPool.Lock(clientSize_123, 3, true);
            dc.PushRenderTarget(temp, true);
            dc.Clear(Uno.Float4.New_1(0.0), 1.0);
            Fuse.Controls.Panel.prototype.OnDraw.call(this, dc);
            dc.PopRenderTarget();
            compositMatrix_124.op_Assign(this.GetDrawMatrix(dc));
            var blur = this._helpers.Blur(temp.ColorBuffer(), dc, this.AbsoluteZoom(), softness * 0.016);
            this._helpers.BlitAdd(dc, blur.ColorBuffer(), temp.ColorBuffer(), Uno.Float2.op_Implicit(Uno.Int2.op_Explicit(Uno.Float2.op_Division_1(Uno.Float2.op_Implicit(temp.Size()), this.AbsoluteZoom()))), Uno.Float2.New_2(0.0, 0.0), compositMatrix_124, this.Multiplier());
            Fuse.FramebufferPool.Release(blur);
            Fuse.FramebufferPool.Release(temp);
        };

        I._ObjInit_4 = function()
        {
            this._helpers = FuseGame.EffectHelpers.New_1();
            Fuse.Controls.Panel.prototype._ObjInit_3.call(this);
            this.Softness(2.0);
        };

        FuseGame.BloomEffect.New_3 = function()
        {
            var inst = new FuseGame.BloomEffect;
            inst._ObjInit_4();
            return inst;
        };

    });
