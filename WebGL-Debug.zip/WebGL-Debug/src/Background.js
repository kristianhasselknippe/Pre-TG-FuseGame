Background = $CreateClass(
    function() {
        Fuse.Controls.Panel.call(this);
        this._cubeCount = new Uno.Int2;
        this._cubeOffset = new Uno.Float2;
        this._cubeHalfExtent = 0;
        this._batchIsInvalid = false;
        this._batch = null;
        this._mesh = null;
        this._fftProvider = null;
        this._draw_5787bce2 = new Uno.Runtime.Implementation.ShaderBackends.OpenGL.GLDrawCall;
    },
    function(S) {
        var I = S.prototype = new Fuse.Controls.Panel;

        I.GetType = function()
        {
            return 1031;
        };

        I.CubeCount = function(value)
        {
            if (value !== undefined)
            {
                if (Uno.Int2.op_Inequality(this._cubeCount, value))
                {
                    this._cubeCount.op_Assign(value);
                    this._batchIsInvalid = true;
                }
            }
            else
            {
                return this._cubeCount;
            }
        };

        I.CubeOffset = function(value)
        {
            if (value !== undefined)
            {
                if (Uno.Float2.op_Inequality(this._cubeOffset, value))
                {
                    this._cubeOffset.op_Assign(value);
                    this._batchIsInvalid = true;
                }
            }
            else
            {
                return this._cubeOffset;
            }
        };

        I.CubeHalfExtent = function(value)
        {
            if (value !== undefined)
            {
                if (this._cubeHalfExtent != value)
                {
                    this._cubeHalfExtent = value;
                    this._batchIsInvalid = true;
                }
            }
            else
            {
                return this._cubeHalfExtent;
            }
        };

        I.FftProvider = function(value)
        {
            if (value !== undefined)
            {
                if (this._fftProvider != null)
                {
                    this._fftProvider.remove_FftAvailable($CreateDelegate(this, Background.prototype.OnFftAvailable, 497));
                }

                this._fftProvider = value;

                if (this._fftProvider != null)
                {
                    this._fftProvider.add_FftAvailable($CreateDelegate(this, Background.prototype.OnFftAvailable, 497));
                }
            }
            else
            {
                return this._fftProvider;
            }
        };

        I.OnFftAvailable = function(sender, fftData)
        {
            var scaleBuffer = this._batch.Attrib1Buffer();
            scaleBuffer.Position(0);
            var counter = 0;

            for (var x = 0; x < this.CubeCount().X; x++)
            {
                for (var y = 0; y < this.CubeCount().Y; y++)
                {
                    for (var i = 0; i < this._mesh.VertexCount(); i++)
                    {
                        scaleBuffer.Write_2(Uno.Float4.New_2(1.0, 1.0, fftData[counter] / 10.0, 1.0));
                    }

                    counter++;
                }
            }

            scaleBuffer.Invalidate();
        };

        I.CreateBatch = function()
        {
            var ind_126;
            var ind_127;
            var ind_128;
            this._mesh = Fuse.Drawing.Meshes.MeshGenerator.CreateCube(Uno.Float3.New_1(0.0), this.CubeHalfExtent());
            var cubeCount = this.CubeCount().X * this.CubeCount().Y;
            var verticeCount = cubeCount * this._mesh.VertexCount();
            var indiceCount = cubeCount * this._mesh.IndexCount();
            var positions = Array.Structs(cubeCount, Uno.Float3, 431);
            var posCounter = 0;

            for (var x = 0; x < this.CubeCount().X; x++)
            {
                for (var y = 0; y < this.CubeCount().Y; y++)
                {
                    positions[posCounter] = Uno.Float3.New_2(x * this.CubeOffset().X, y * this.CubeOffset().Y, 0.0);
                    posCounter++;
                }
            }

            this._batch = Fuse.Drawing.Batching.Batch.New_1(verticeCount, indiceCount, true);
            var indexCounter = 0;

            for (var i = 0; i < cubeCount; i++)
            {
                for (var j = 0; j < this._mesh.VertexCount(); j++)
                {
                    this._batch.Positions().Write_1(Uno.Float3.op_Addition((ind_126 = this._mesh.Positions().GetFloat4(j), Uno.Float3.New_2(ind_126.X, ind_126.Y, ind_126.Z)), positions[i]));
                    this._batch.Normals().Write_1((ind_127 = this._mesh.Normals().GetFloat4(j), Uno.Float3.New_2(ind_127.X, ind_127.Y, ind_127.Z)));
                    this._batch.TexCoord0s().Write((ind_128 = this._mesh.TexCoords().GetFloat4(j), Uno.Float2.New_2(ind_128.X, ind_128.Y)));
                    this._batch.Attrib0Buffer().Write_2(Uno.Float4.New_2(0.7, 0.3, 0.0, 1.0));
                    this._batch.Attrib1Buffer().Write_2(Uno.Float4.New_2(1.0, 1.0, 1.0, 1.0));
                }

                for (var j = 0; j < this._mesh.IndexCount(); j++)
                {
                    this._batch.Indices().Write_1((this._mesh.Indices().GetInt(j) + indexCounter));
                }

                indexCounter = indexCounter + this._mesh.VertexCount();
            }

            this._batchIsInvalid = false;
        };

        I.UpdateScaling = function()
        {
        };

        I.OnRooted = function()
        {
            this.add_Update($CreateDelegate(this, Background.prototype.OnUpdate, 445));
            Fuse.Controls.Panel.prototype.OnRooted.call(this);
        };

        I.OnUnrooted = function()
        {
            this.remove_Update($CreateDelegate(this, Background.prototype.OnUpdate, 445));
            Fuse.Controls.Panel.prototype.OnUnrooted.call(this);
        };

        I.OnDraw = function(dc)
        {
            var m_123 = new Uno.Float4x4;
            Fuse.Controls.Panel.prototype.OnDraw.call(this, dc);

            if (this._batchIsInvalid)
            {
                return;
            }

            m_123.op_Assign(this.GetDrawMatrix(dc));
            var scale = Uno.Float3.New_1(0.0);
            var rotation = Uno.Float4.New_1(0.0);
            var translation = Uno.Float3.New_1(0.0);
            Uno.Matrix.Decompose(m_123, $CreateRef(function(){return scale}, function($){scale=$}, this), $CreateRef(function(){return rotation}, function($){rotation=$}, this), $CreateRef(function(){return translation}, function($){translation=$}, this));
            {
                this._draw_5787bce2.Use();
                this._draw_5787bce2.Attrib_1(0, this._batch.Positions().DataType(), this._batch.Positions().VertexBuffer(), this._batch.Positions().StrideInBytes(), 0);
                this._draw_5787bce2.Attrib_1(1, this._batch.Attrib1Buffer().DataType(), this._batch.Attrib1Buffer().VertexBuffer(), this._batch.Attrib1Buffer().StrideInBytes(), 0);
                this._draw_5787bce2.Attrib_1(2, this._batch.Attrib0Buffer().DataType(), this._batch.Attrib0Buffer().VertexBuffer(), this._batch.Attrib0Buffer().StrideInBytes(), 0);
                this._draw_5787bce2.Attrib_1(3, this._batch.Normals().DataType(), this._batch.Normals().VertexBuffer(), this._batch.Normals().StrideInBytes(), 0);
                this._draw_5787bce2.Uniform_14(4, Uno.Matrix.RotationQuaternion(rotation));
                this._draw_5787bce2.Uniform_14(5, Uno.Matrix.Translation(translation));
                this._draw_5787bce2.Uniform_14(6, Uno.Matrix.Mul_11(Uno.Matrix.LookAtRH(Uno.Float3.New_2(0.0, 300.0, 0.0), ($AsOp(Fuse.DrawContext.Current().Camera(), 843) != null) ? Uno.Float3.op_Addition($AsOp(Fuse.DrawContext.Current().Camera(), 843).AbsolutePosition(), $AsOp(Fuse.DrawContext.Current().Camera(), 843).AbsoluteForward()) : Uno.Float3.New_2(0.0, 0.0, 0.0), ($AsOp(Fuse.DrawContext.Current().Camera(), 843) != null) ? $AsOp(Fuse.DrawContext.Current().Camera(), 843).AbsoluteUp() : Uno.Float3.New_2(0.0, 0.0, 1.0)), Uno.Matrix.PerspectiveRH(($AsOp(Fuse.DrawContext.Current().Camera(), 843) != null) ? $AsOp(Fuse.DrawContext.Current().Camera(), 843).Frustum().FovRadians() : 0.7853982, Fuse.DrawContext.Current().Aspect(), ($AsOp(Fuse.DrawContext.Current().Camera(), 843) != null) ? $AsOp(Fuse.DrawContext.Current().Camera(), 843).Frustum().ZNear() : 1.0, ($AsOp(Fuse.DrawContext.Current().Camera(), 843) != null) ? $AsOp(Fuse.DrawContext.Current().Camera(), 843).Frustum().ZFar() : 10000.0)));
                this._draw_5787bce2.Draw(this._batch.VertexCount(), this._batch.IndexType(), this._batch.IndexBuffer());
            }
        };

        I.OnUpdate = function(sender, args)
        {
            this.InvalidateVisual();

            if (this._batchIsInvalid)
            {
                this.CreateBatch();
            }

            this.UpdateScaling();
        };

        I.init_DrawCalls = function()
        {
            this._draw_5787bce2 = Uno.Runtime.Implementation.ShaderBackends.OpenGL.GLDrawCall.New_1($DownCast(Uno.Runtime.Implementation.Internal.BundleRegistry.Get(50), 383));
        };

        I._ObjInit_4 = function()
        {
            this._cubeCount = Uno.Int2.New_2(128, 1);
            this._cubeOffset = Uno.Float2.New_2(4.0, 4.0);
            this._cubeHalfExtent = 1.0;
            this._batchIsInvalid = true;
            Fuse.Controls.Panel.prototype._ObjInit_3.call(this);
            this.CachingMode(2);
            this.init_DrawCalls();
        };

        Background.New_3 = function()
        {
            var inst = new Background;
            inst._ObjInit_4();
            return inst;
        };

    });
