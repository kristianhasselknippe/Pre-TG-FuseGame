Powerup = $CreateClass(
    function() {
        GameObject.call(this);
        this.Duration = 0;
    },
    function(S) {
        var I = S.prototype = new GameObject;

        I.GetType = function()
        {
            return 1039;
        };

        I.GetAppearance = function()
        {
            return Fuse.Controls.Panel.New_2();
        };

        I._ObjInit_5 = function(pos)
        {
            GameObject.prototype._ObjInit_4.call(this);
            this.Position(pos);
            this.Appearance(this.GetAppearance());
        };

    });
