Bullet = $CreateClass(
    function() {
        GameObject.call(this);
        this.BulletSpeed = 0;
    },
    function(S) {
        var I = S.prototype = new GameObject;

        I.GetType = function()
        {
            return 1035;
        };

        I.OnCollision = function(other)
        {
            if ($IsOp(other, 1036))
            {
                GameObject.Destroy(other);
                GameObject.Destroy(this);
                GameObject.Game().Score(GameObject.Game().Score() + 1);
            }
        };

        I.OnUpdate = function(dt)
        {
            if (Uno.Vector.Distance(this.Position(), Uno.Float2.New_2(0.0, 0.0)) > 2000.0)
            {
                GameObject.Destroy(this);
            }
        };

        I._ObjInit_5 = function(position, rotation)
        {
            var ind_126;
            var dir_125 = new Uno.Float2;
            var collection_123;
            this.BulletSpeed = 10.0;
            GameObject.prototype._ObjInit_4.call(this);
            this.Width(15.0);
            this.Height(5.0);
            this.Appearance((collection_123 = Fuse.Shapes.Rectangle.New_1(), ind_126 = Fuse.Drawing.SolidColor.New_2(Uno.Float4.New_2(1.0, 0.0, 0.0, 1.0)), collection_123.Fill(ind_126), ind_126, collection_123));
            this.Position(position);
            this.Rotation(rotation);
            var rot = Uno.Math.DegreesToRadians_1(this.Rotation());
            var x = Uno.Math.Cos_1(rot);
            var y = Uno.Math.Sin_1(rot);
            dir_125.op_Assign(Uno.Vector.Normalize(Uno.Float2.New_2(x, y)));
            this.Velocity(Uno.Float2.op_Multiply(dir_125, this.BulletSpeed));
            GameObject.Game().RegisterCollisionCallback(this, $CreateDelegate(this, Bullet.prototype.OnCollision, 481));
        };

        Bullet.New_4 = function(position, rotation)
        {
            var inst = new Bullet;
            inst._ObjInit_5(position, rotation);
            return inst;
        };

    });
