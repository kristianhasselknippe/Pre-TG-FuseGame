Uno.Char = $CreateClass(
    function() {
        this.$struct = true;
    },
    function(S) {
        var I = S.prototype;

        I.GetType = function()
        {
            return 420;
        };

        Uno.Char.IsWhiteSpace = function(c)
        {
            var whitespace = "  ᠎             　\u2028\u2029\t\n\v\f\r ";
            return whitespace.IndexOf(c, 0) != -1;
        };

    });
