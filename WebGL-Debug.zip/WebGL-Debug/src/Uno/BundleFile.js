Uno.BundleFile = $CreateClass(
    function() {
        this._Name = null;
    },
    function(S) {
        var I = S.prototype;

        I.GetType = function()
        {
            return 441;
        };

        I.Name = function(value)
        {
            if (value !== undefined)
            {
                this._Name = value;
            }
            else
            {
                return this._Name;
            }
        };

        I.ReadAllBytes = function()
        {
            return $BundleBuffers[this._Name];
        };

        I._ObjInit = function(filename)
        {
            this.Name(filename);
        };

        Uno.BundleFile.New_1 = function(filename)
        {
            var inst = new Uno.BundleFile;
            inst._ObjInit(filename);
            return inst;
        };

    });
