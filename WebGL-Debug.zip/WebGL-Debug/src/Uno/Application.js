Uno.Application = $CreateClass(
    function() {
        this._Window = null;
        this._GraphicsContext = null;
        this._ClearColor = new Uno.Float4;
        this._ClearDepth = 0;
        this._DrawNextFrame = false;
        this._FrameTime = 0;
        this._FrameInterval = 0;
    },
    function(S) {
        var I = S.prototype;

        Uno.Application._Current = null;

        I.GetType = function()
        {
            return 417;
        };

        Uno.Application.Current = function(value)
        {
            if (value !== undefined)
            {
                Uno.Application._Current = value;
            }
            else
            {
                return Uno.Application._Current;
            }
        };

        I.Window = function(value)
        {
            if (value !== undefined)
            {
                this._Window = value;
            }
            else
            {
                return this._Window;
            }
        };

        I.GraphicsContext = function(value)
        {
            if (value !== undefined)
            {
                this._GraphicsContext = value;
            }
            else
            {
                return this._GraphicsContext;
            }
        };

        I.ClearColor = function(value)
        {
            if (value !== undefined)
            {
                this._ClearColor.op_Assign(value);
            }
            else
            {
                return this._ClearColor;
            }
        };

        I.ClearDepth = function(value)
        {
            if (value !== undefined)
            {
                this._ClearDepth = value;
            }
            else
            {
                return this._ClearDepth;
            }
        };

        I.DrawNextFrame = function(value)
        {
            if (value !== undefined)
            {
                this._DrawNextFrame = value;
            }
            else
            {
                return this._DrawNextFrame;
            }
        };

        I.FrameTime = function(value)
        {
            if (value !== undefined)
            {
                this._FrameTime = value;
            }
            else
            {
                return this._FrameTime;
            }
        };

        I.FrameInterval = function(value)
        {
            if (value !== undefined)
            {
                this._FrameInterval = value;
            }
            else
            {
                return this._FrameInterval;
            }
        };

        I.Load = function()
        {
        };

        I.Update = function()
        {
        };

        I.Draw = function()
        {
        };

        I._ObjInit = function()
        {
            if (Uno.Application.Current() == null)
            {
                Uno.Application.Current(this);
            }

            this.Window(Uno.Platform.Window.New_1());
            this.GraphicsContext(Uno.Graphics.GraphicsContext.New_1());
            this.ClearColor(Uno.Float4.New_2(0.0, 0.0, 0.0, 1.0));
            this.ClearDepth(1.0);
            this.DrawNextFrame(true);
        };

    });
