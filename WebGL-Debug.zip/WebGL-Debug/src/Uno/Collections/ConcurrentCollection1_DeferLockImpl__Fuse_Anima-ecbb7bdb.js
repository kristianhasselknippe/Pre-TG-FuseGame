Uno.Collections.ConcurrentCollection1_DeferLockImpl__Fuse_Animations_IMixerMaster = $CreateClass(
    function() {
        this._collection = null;
    },
    function(S) {
        var I = S.prototype;

        I.GetType = function()
        {
            return 281;
        };

        I.$II = function(id)
        {
            return [418].indexOf(id) != -1;
        };

        I.Dispose = function()
        {
            this._collection.EndDefer();
        };

        I._ObjInit = function(c)
        {
            this._collection = c;
        };

        Uno.Collections.ConcurrentCollection1_DeferLockImpl__Fuse_Animations_IMixerMaster.New_1 = function(c)
        {
            var inst = new Uno.Collections.ConcurrentCollection1_DeferLockImpl__Fuse_Animations_IMixerMaster;
            inst._ObjInit(c);
            return inst;
        };

        I["Uno.IDisposable.Dispose"] = I.Dispose;

    });
