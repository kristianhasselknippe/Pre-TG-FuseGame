Uno.Collections.ConcurrentCollection__Fuse_Animations_IMixerMaster = $CreateClass(
    function() {
        this._back = null;
        this._add = null;
        this._remove = null;
        this._defer = false;
        this._lockImpl = null;
    },
    function(S) {
        var I = S.prototype;

        I.GetType = function()
        {
            return 228;
        };

        I.Count = function()
        {
            return (this._back.Count() + this._add.Count()) - this._remove.Count();
        };

        I.DeferChanges = function()
        {
            this._defer = true;
        };

        I.EndDefer = function()
        {
            this._defer = false;

            for (var enum_123 = this._remove.GetEnumerator(); enum_123.MoveNext(); )
            {
                var r = enum_123.Current();
                this._back.Remove(r);
            }

            for (var enum_124 = this._add.GetEnumerator(); enum_124.MoveNext(); )
            {
                var a = enum_124.Current();
                this._back.Add(a);
            }

            this._remove.Clear();
            this._add.Clear();
        };

        I.Add = function(item)
        {
            if (this._defer)
            {
                this._add.Add(item);
            }
            else
            {
                this._back.Add(item);
            }
        };

        I.Remove = function(item)
        {
            if (this._defer)
            {
                if (this._add.Remove(item))
                {
                    return true;
                }

                if (this._back.Contains(item))
                {
                    this._remove.Add(item);
                    return true;
                }

                return false;
            }

            return this._back.Remove(item);
        };

        I.GetEnumerator = function()
        {
            return $CopyStruct(this._back.GetEnumerator());
        };

        I.DeferLock = function()
        {
            if (this._lockImpl == null)
            {
                this._lockImpl = Uno.Collections.ConcurrentCollection1_DeferLockImpl__Fuse_Animations_IMixerMaster.New_1(this);
            }

            this.DeferChanges();
            return $DownCast(this._lockImpl, 33186);
        };

        I._ObjInit = function()
        {
            this._back = Uno.Collections.List__Fuse_Animations_IMixerMaster.New_1();
            this._add = Uno.Collections.List__Fuse_Animations_IMixerMaster.New_1();
            this._remove = Uno.Collections.List__Fuse_Animations_IMixerMaster.New_1();
        };

        Uno.Collections.ConcurrentCollection__Fuse_Animations_IMixerMaster.New_1 = function()
        {
            var inst = new Uno.Collections.ConcurrentCollection__Fuse_Animations_IMixerMaster;
            inst._ObjInit();
            return inst;
        };

    });
