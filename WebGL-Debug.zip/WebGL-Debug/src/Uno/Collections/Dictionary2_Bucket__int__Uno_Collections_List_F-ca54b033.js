Uno.Collections.Dictionary2_Bucket__int__Uno_Collections_List_Fuse_INode_ = $CreateClass(
    function() {
        this.$struct = true;
        this.Key = 0;
        this.Value = null;
        this.State = 0;
    },
    function(S) {
        var I = S.prototype;

        I.GetType = function()
        {
            return 254;
        };

    });
