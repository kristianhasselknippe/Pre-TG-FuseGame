Uno.Collections.Dictionary2_Bucket__string__Fuse_Resources_Resource = $CreateClass(
    function() {
        this.$struct = true;
        this.Key = null;
        this.Value = null;
        this.State = 0;
    },
    function(S) {
        var I = S.prototype;

        I.GetType = function()
        {
            return 238;
        };

    });
