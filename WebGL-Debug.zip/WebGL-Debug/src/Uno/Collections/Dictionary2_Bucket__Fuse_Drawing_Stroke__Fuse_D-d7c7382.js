Uno.Collections.Dictionary2_Bucket__Fuse_Drawing_Stroke__Fuse_Drawing_PolygonFiller = $CreateClass(
    function() {
        this.$struct = true;
        this.Key = null;
        this.Value = null;
        this.State = 0;
    },
    function(S) {
        var I = S.prototype;

        I.GetType = function()
        {
            return 245;
        };

    });
