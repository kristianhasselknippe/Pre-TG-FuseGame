Uno.Collections.Dictionary2_Bucket__int__int = $CreateClass(
    function() {
        this.$struct = true;
        this.Key = 0;
        this.Value = 0;
        this.State = 0;
    },
    function(S) {
        var I = S.prototype;

        I.GetType = function()
        {
            return 256;
        };

    });
