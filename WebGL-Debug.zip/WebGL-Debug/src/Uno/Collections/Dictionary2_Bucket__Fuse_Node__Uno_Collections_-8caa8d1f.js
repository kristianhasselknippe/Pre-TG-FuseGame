Uno.Collections.Dictionary2_Bucket__Fuse_Node__Uno_Collections_List_Fuse_Triggers_Tapped_ = $CreateClass(
    function() {
        this.$struct = true;
        this.Key = null;
        this.Value = null;
        this.State = 0;
    },
    function(S) {
        var I = S.prototype;

        I.GetType = function()
        {
            return 246;
        };

    });
