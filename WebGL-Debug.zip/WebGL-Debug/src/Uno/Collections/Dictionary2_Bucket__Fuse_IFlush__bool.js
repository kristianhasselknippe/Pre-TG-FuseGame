Uno.Collections.Dictionary2_Bucket__Fuse_IFlush__bool = $CreateClass(
    function() {
        this.$struct = true;
        this.Key = null;
        this.Value = false;
        this.State = 0;
    },
    function(S) {
        var I = S.prototype;

        I.GetType = function()
        {
            return 255;
        };

    });
