Uno.ArgumentNullException = $CreateClass(
    function() {
        Uno.ArgumentException.call(this);
    },
    function(S) {
        var I = S.prototype = new Uno.ArgumentException;

        I.GetType = function()
        {
            return 438;
        };

        I._ObjInit_4 = function(paramName)
        {
            Uno.ArgumentException.prototype._ObjInit_3.call(this, "value was null", paramName);
        };

        Uno.ArgumentNullException.New_5 = function(paramName)
        {
            var inst = new Uno.ArgumentNullException;
            inst._ObjInit_4(paramName);
            return inst;
        };

    });
