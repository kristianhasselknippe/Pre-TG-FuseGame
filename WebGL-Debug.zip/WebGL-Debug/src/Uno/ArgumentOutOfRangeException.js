Uno.ArgumentOutOfRangeException = $CreateClass(
    function() {
        Uno.ArgumentException.call(this);
    },
    function(S) {
        var I = S.prototype = new Uno.ArgumentException;

        I.GetType = function()
        {
            return 439;
        };

        I._ObjInit_5 = function(paramName)
        {
            Uno.ArgumentException.prototype._ObjInit_3.call(this, "value out of range", paramName);
        };

        Uno.ArgumentOutOfRangeException.New_6 = function(paramName)
        {
            var inst = new Uno.ArgumentOutOfRangeException;
            inst._ObjInit_5(paramName);
            return inst;
        };

    });
