Uno.Buffer = $CreateClass(
    function() {
        this._offset = 0;
        this._sizeInBytes = 0;
        this._isReadOnly = false;
        this._data = null;
    },
    function(S) {
        var I = S.prototype;

        I.GetType = function()
        {
            return 440;
        };

        I.SizeInBytes = function()
        {
            return this._sizeInBytes;
        };

        I.GetHandle = function()
        {
            return this._data;
        };

        I.SetHandle = function()
        {
            if (this._isReadOnly)
            {
                throw new $Error(Uno.InvalidOperationException.New_4("Buffer is read only"));
            }

            return this._data;
        };

        I.GetSByte = function(offset)
        {
            return this.GetHandle()[this._offset + offset].ByteToSByte();
        };

        I.GetSByte4 = function(offset)
        {
            return Uno.SByte4.New_2(this.GetSByte(offset), this.GetSByte(offset + 1), this.GetSByte(offset + 2), this.GetSByte(offset + 3));
        };

        I.GetByte = function(offset)
        {
            return this.GetHandle()[this._offset + offset];
        };

        I.GetByte4 = function(offset)
        {
            return Uno.Byte4.New_1(this.GetByte(offset), this.GetByte(offset + 1), this.GetByte(offset + 2), this.GetByte(offset + 3));
        };

        I.GetShort = function(offset, littleEndian)
        {
            return Uno.Runtime.Implementation.BufferImpl.GetShort(this.GetHandle(), this._offset + offset, littleEndian);
        };

        I.GetShort2 = function(offset, littleEndian)
        {
            return Uno.Short2.New_2(this.GetShort(offset, littleEndian), this.GetShort(offset + 2, littleEndian));
        };

        I.GetShort4 = function(offset, littleEndian)
        {
            return Uno.Short4.New_2(this.GetShort(offset, littleEndian), this.GetShort(offset + 2, littleEndian), this.GetShort(offset + 4, littleEndian), this.GetShort(offset + 6, littleEndian));
        };

        I.GetUShort = function(offset, littleEndian)
        {
            return Uno.Runtime.Implementation.BufferImpl.GetUShort(this.GetHandle(), this._offset + offset, littleEndian);
        };

        I.SetUShort = function(offset, value, littleEndian)
        {
            Uno.Runtime.Implementation.BufferImpl.SetUShort(this.SetHandle(), this._offset + offset, value, littleEndian);
        };

        I.GetUShort2 = function(offset, littleEndian)
        {
            return Uno.UShort2.New_2(this.GetUShort(offset, littleEndian), this.GetUShort(offset + 2, littleEndian));
        };

        I.GetUShort4 = function(offset, littleEndian)
        {
            return Uno.UShort4.New_2(this.GetUShort(offset, littleEndian), this.GetUShort(offset + 2, littleEndian), this.GetUShort(offset + 4, littleEndian), this.GetUShort(offset + 6, littleEndian));
        };

        I.GetUInt = function(offset, littleEndian)
        {
            return Uno.Runtime.Implementation.BufferImpl.GetUInt(this.GetHandle(), this._offset + offset, littleEndian);
        };

        I.GetFloat = function(offset, littleEndian)
        {
            return Uno.Runtime.Implementation.BufferImpl.GetFloat(this.GetHandle(), this._offset + offset, littleEndian);
        };

        I.SetFloat = function(offset, value, littleEndian)
        {
            Uno.Runtime.Implementation.BufferImpl.SetFloat(this.SetHandle(), this._offset + offset, value, littleEndian);
        };

        I.GetFloat2 = function(offset, littleEndian)
        {
            return Uno.Float2.New_2(this.GetFloat(offset, littleEndian), this.GetFloat(offset + 4, littleEndian));
        };

        I.SetFloat2 = function(offset, value, littleEndian)
        {
            var value_134 = new Uno.Float2;
            value_134.op_Assign(value);
            this.SetFloat(offset, value_134.X, littleEndian);
            this.SetFloat(offset + 4, value_134.Y, littleEndian);
        };

        I.GetFloat3 = function(offset, littleEndian)
        {
            return Uno.Float3.New_2(this.GetFloat(offset, littleEndian), this.GetFloat(offset + 4, littleEndian), this.GetFloat(offset + 8, littleEndian));
        };

        I.SetFloat3 = function(offset, value, littleEndian)
        {
            var value_135 = new Uno.Float3;
            value_135.op_Assign(value);
            this.SetFloat(offset, value_135.X, littleEndian);
            this.SetFloat(offset + 4, value_135.Y, littleEndian);
            this.SetFloat(offset + 8, value_135.Z, littleEndian);
        };

        I.GetFloat4 = function(offset, littleEndian)
        {
            return Uno.Float4.New_2(this.GetFloat(offset, littleEndian), this.GetFloat(offset + 4, littleEndian), this.GetFloat(offset + 8, littleEndian), this.GetFloat(offset + 12, littleEndian));
        };

        I.SetFloat4 = function(offset, value, littleEndian)
        {
            var value_136 = new Uno.Float4;
            value_136.op_Assign(value);
            this.SetFloat(offset, value_136.X, littleEndian);
            this.SetFloat(offset + 4, value_136.Y, littleEndian);
            this.SetFloat(offset + 8, value_136.Z, littleEndian);
            this.SetFloat(offset + 12, value_136.W, littleEndian);
        };

        I._ObjInit = function(data, offset, sizeInBytes, isReadOnly)
        {
            this._data = data;
            this._offset = offset;
            this._sizeInBytes = sizeInBytes;
            this._isReadOnly = isReadOnly;
        };

        I._ObjInit_1 = function(data)
        {
            this._ObjInit(data, 0, data.length, true);
        };

        Uno.Buffer.New_2 = function(data)
        {
            var inst = new Uno.Buffer;
            inst._ObjInit_1(data);
            return inst;
        };

        I._ObjInit_2 = function(sizeInBytes)
        {
            this._ObjInit(Array.Zeros(sizeInBytes, 421), 0, sizeInBytes, false);
        };

        Uno.Buffer.New_3 = function(sizeInBytes)
        {
            var inst = new Uno.Buffer;
            inst._ObjInit_2(sizeInBytes);
            return inst;
        };

    });
