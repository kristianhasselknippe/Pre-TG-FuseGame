Uno.Bool = $CreateClass(
    function() {
        this.$struct = true;
    },
    function(S) {
        var I = S.prototype;

        I.GetType = function()
        {
            return 419;
        };

    });
