Uno.Byte4 = $CreateClass(
    function() {
        this.$struct = true;
        this.X = 0;
        this.Y = 0;
        this.Z = 0;
        this.W = 0;
    },
    function(S) {
        var I = S.prototype;

        I.GetType = function()
        {
            return 442;
        };

        I.Equals = function(o)
        {
            return Uno.Object.prototype.Equals.call(this, o);
        };

        I.GetHashCode = function()
        {
            return Uno.Object.prototype.GetHashCode.call(this);
        };

        I.ToString = function()
        {
            return Uno.String.op_Addition(Uno.String.op_Addition(Uno.String.op_Addition(Uno.String.op_Addition(Uno.String.op_Addition(Uno.String.op_Addition(this.X.ToString(), ", "), this.Y.ToString()), ", "), this.Z.ToString()), ", "), this.W.ToString());
        };

        I._ObjInit = function(x, y, z, w)
        {
            this.X = x;
            this.Y = y;
            this.Z = z;
            this.W = w;
        };

        Uno.Byte4.New_1 = function(x, y, z, w)
        {
            var inst = new Uno.Byte4;
            inst._ObjInit(x, y, z, w);
            return inst;
        };

    });
