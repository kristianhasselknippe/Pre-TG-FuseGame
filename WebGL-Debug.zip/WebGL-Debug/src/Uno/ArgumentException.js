Uno.ArgumentException = $CreateClass(
    function() {
        Uno.Exception.call(this);
    },
    function(S) {
        var I = S.prototype = new Uno.Exception;

        I.GetType = function()
        {
            return 437;
        };

        I._ObjInit_3 = function(message, paramName)
        {
            Uno.Exception.prototype._ObjInit.call(this, Uno.String.op_Addition(Uno.String.op_Addition(paramName, ": "), message));
        };

        Uno.ArgumentException.New_4 = function(message, paramName)
        {
            var inst = new Uno.ArgumentException;
            inst._ObjInit_3(message, paramName);
            return inst;
        };

    });
