HTML5 = {};
OpenGL = {};
Outracks = {};
Outracks.UnoCore = {};
Outracks.UnoCore.Utilities = {};
Outracks.UIThemes = {};
Outracks.UIThemes.MobileBlue = {};
System = {};
System.IO = {};
Uno = {};
Uno.Collections = {};
Uno.Compiler = {};
Uno.Compiler.Ast = {};
Uno.Compiler.ExportTargetInterop = {};
Uno.Compiler.ImportServices = {};
Uno.Compiler.ShaderGenerator = {};
Uno.Content = {};
Uno.Content.Fonts = {};
Uno.Content.Images = {};
Uno.Content.Models = {};
Uno.Content.Splines = {};
Uno.Diagnostics = {};
Uno.Graphics = {};
Uno.IO = {};
Uno.Marshalling = {};
Uno.Marshalling.JavaScript = {};
Uno.Platform = {};
Uno.Runtime = {};
Uno.Runtime.Implementation = {};
Uno.Runtime.Implementation.Internal = {};
Uno.Runtime.Implementation.ShaderBackends = {};
Uno.Runtime.Implementation.ShaderBackends.OpenGL = {};
Uno.Text = {};
Uno.UX = {};
Uno.UX.Internal = {};
Uno.Geometry = {};
Experimental = {};
Experimental.ApiBindings = {};
Experimental.ApiBindings.WebAudio = {};
Experimental.Net = {};
Experimental.Net.Http = {};
Experimental.Net.Http.Implementation = {};
Experimental.TextureLoader = {};
Fuse = {};
Fuse.Designer = {};
Fuse.Profiling = {};
Fuse.Resources = {};
Fuse.Animations = {};
Fuse.Drawing = {};
Fuse.Drawing.Batching = {};
Fuse.Drawing.Meshes = {};
Fuse.Drawing.Primitives = {};
Fuse.Drawing.Tesselation = {};
Fuse.Drawing.Tesselation.Collections = {};
Fuse.Drawing.Planar = {};
Fuse.Physics = {};
Fuse.Triggers = {};
Fuse.Triggers.Actions = {};
Fuse.Internal = {};
Fuse.Internal.Drawing = {};
Fuse.Effects = {};
Fuse.Elements = {};
Fuse.Elements.Implementations = {};
Fuse.Entities = {};
Fuse.Entities.Designer = {};
Fuse.Entities.Filters = {};
Fuse.Entities.Internal = {};
Fuse.Entities.Primitives = {};
Fuse.Entities.Processing = {};
Fuse.Shapes = {};
Fuse.Controls = {};
Fuse.Controls.Internal = {};
Fuse.Controls.Primitives = {};
Fuse.Layouts = {};
FuseGame = {};
FuseGame.Audio = {};


$AsyncCount = 0;
$BundleBuffers = {};
$BundleImages = {};
$BundleAudios = {};
$PressedKeys = [];
$PressedButtons = [];

function $PreloadBundle(files) {
    for (var i = 0; i < files.length; i++) {
        $AsyncCount++;

        (function(name) {
            var url = "data/" + name;

            switch (/(?:\.([^.]+))?$/.exec(name)[1]) {
                case "jpg":
                case "png":
                    var img = new Image();
                    img.onload = function () { 
                        $BundleImages[name] = img;
                        $AsyncCount--;
                    };
                    img.crossOrigin = '';
                    img.src = url;
                    break;

                case "mp3":
                case "ogg":
                    var audio = new Audio();
                    audio.controls = false;
                    audio.autoplay = false;
                    audio.src = url;
                    $BundleAudios[name] = audio;
                    $AsyncCount--;
                    break;

                case "woff":
                case "otf":
                case "ttf":
                    if(document.fonts && (typeof FontFace != "undefined")) {
                        function success(fontFace) {
                            document.fonts.add(fontFace);
                            $AsyncCount--;
                        }
                        function error(e) {
                            console.log("Could not load fontface " + name);
                        }
                        function loadFont() {
                            var face = new FontFace(name, 'url(' + url + ')', {});
                            face.loaded.then(success, error);
                            face.load();
                        }
                        setTimeout(loadFont, 4); // NOTE: I have no clue why I need to do this async, but it randomly doesn't work if I don't
                    } else {
                        var d = document,
                            s = d.createElement('style'),
                            n = d.createElement('span'),
                            f = "'" + name + "'";

                        n.innerHTML = 'giItT1WQy@!-/#';
                        n.style.position      = 'absolute';
                        n.style.left          = '-10000px';
                        n.style.top           = '-10000px';
                        n.style.fontSize      = '300px';
                        n.style.fontFamily    = f;
                        n.style.fontVariant   = 'normal';
                        n.style.fontStyle     = 'normal';
                        n.style.fontWeight    = 'normal';
                        n.style.letterSpacing = '0';
                        d.body.appendChild(n);

                        var startWidth = n.offsetWidth,
                            interval = 0;

                        function checkFont() {
                            if (n.offsetWidth != startWidth) {
                                n.parentNode.removeChild(n);

                                if (interval)
                                    clearInterval(interval);

                                $AsyncCount--;

                                //return true;
                            }
                        };

                        s.appendChild(d.createTextNode("@font-face{font-family:" + f + ";src:url('" + url + "')}"));
                        d.head.appendChild(s);

                        //if (!checkFont())
                            interval = setInterval(checkFont, 50);
                    }
                    break;

                default:
                    var req = new XMLHttpRequest();
                    req.onload = function () {
                        $BundleBuffers[name] = new Uint8Array(req.response);
                        $AsyncCount--;
                    };
                    req.open("GET", url, true);
                    req.responseType = "arraybuffer";
                    req.send(null);
                    break;
            }
        })(files[i]);
    }
}

function $ParseStringToNumeric(str, typeName, minValue, maxValue)
{
    if (str === null)
    {
        throw Uno.ArgumentNullException.New_5("String");
    }
    if (!isFinite(str))
    {
        throw Uno.FormatException.New_3("Unable to convert string to " + typeName);
    }

    var parsedValue;
    if (typeName == 'float' || typeName == 'double')
    {
        parsedValue = parseFloat(str);
    }
    if (typeName == 'int' || typeName == 'long' || typeName == 'ulong')
    {
        parsedValue = parseInt(str);
    }
    if (isNaN(parsedValue))
    {
        throw Uno.FormatException.New_3("Unable to convert string to " + typeName);
    }

    if (minValue > parsedValue || parsedValue > maxValue)
    {
        throw Uno.OverflowException.New_3("Value was either too large or too small for " + typeName);
    }
    return parsedValue;
}

function $ParseStringToBool(str)
{
    if (str === null)
    {
        throw Uno.ArgumentNullException.New_5("String");
    }
    if (str.trim().toLowerCase() === "true") {
        return true;
    }
    if (str.trim().toLowerCase() === "false") {
        return false;
    }
    throw Uno.FormatException.New_3("Unable to convert string to bool");
}

function $Vendor(obj, mn)
{
    var m = obj[mn];
    if (m) return m;
    for(var p in {ms:0, moz:0, webkit:0, o:0})
    {
        m = obj[p + mn.charAt(0).toUpperCase() + mn.slice(1)];
        if (m !== undefined) return m;
    }
    return undefined;
}

function $GetFullscreen()
{
    return $Vendor(document, "isFullScreen");
}

function $SetFullscreen(b)
{
    if (b)
        $Vendor(document.body, "requestFullscreen").call(document.body);
    else
        $Vendor(document, "cancelFullScreen").call(document);
}

// the following is used in utf8 encode / decode!

String.FromArray = function (arr) {
        // TODO: make this work without "invalid argument type"
        //return String.fromCharCode.apply(null, arr);
        //return arr.map(function(code) { return String.fromCharCode(code);}).join("");
        var str = [];
        for (var i = 0, l = arr.length; i < l; i++) str.push(String.fromCharCode(arr[i]));
        return str.join("");
};

String.ToArray = function(str) {
        var arr = new Array(str.length);
        for (var i = 0, l = arr.length; i < l; i++) arr[i] = str.charCodeAt(i);
        return arr;
};

Number.prototype.ByteToSByte = function() {
    return this > 127 ? 127 - this : this;
}

Number.prototype.SByteToByte = function() {
    return this < 0 ? 127 - this : this;
}

function $Error(ex) {
    this.exception = ex;
    arguments[0] = ex.Message()
    var tmp = Error.apply(this, arguments);

    tmp.name = this.name = 'Uno.Exception'
    this.message = tmp.message
    
    Object.defineProperty(this, 'stack', {
        get: function() {
            return tmp.stack
        }
    })

    return this
}

var IntermediateInheritor = function() {}
IntermediateInheritor.prototype = Error.prototype;
$Error.prototype = new IntermediateInheritor()

$ConvertNativeException = function(ex)
{
    if (ex instanceof TypeError)
        return Uno.NullReferenceException.New_3();

    if (ex && ex.exception)
        return ex.exception;

    return ex;
};

$SetupWebGL = function(rootDomElement)
{
    var success = true;

    rootDomElement.appendChild((function() {
        canvas = document.createElement("canvas");
        canvas.style.position = "absolute";
        canvas.style.outline = 'none';
        canvas.setAttribute("tabindex", "0");

        var message = document.createElement("div");
        message.style.padding = "10px";

        if (!window.WebGLRenderingContext) {
            success = false;
            message.innerHTML = "Hum, your browser does not support WebGL.<br /><a href='http://get.webgl.org'>Get a new one</a>, it's easy!";
            //document.location = "http://get.webgl.org/";
            return message;
        }

        var glAttrs = {
            alpha: false
        };

        gl = canvas.getContext("webgl", glAttrs) || canvas.getContext("experimental-webgl", glAttrs);

        if (!gl)
        {
            success = false;
            message.innerHTML = "Could not initialize WebGL.<br />Don't worry, <a href='http://get.webgl.org/troubleshooting'>help is on the way</a>!";
            //document.location = "http://get.webgl.org/troubleshooting";
            return message;
        }

        // TODO: Implement way to see if this extension is used
        gl.getExtension('OES_standard_derivatives');

        return canvas;
    })());

    return success;
};


(function()
{
    var constructors = [];
    var populizers = [];

    $CreateClass = function(constructor, populizer)
    {
        constructors.push(constructor);
        populizers.push(populizer);
        return constructor;
    };

    $PopulateClasses = function()
    {
        for (i = 0; i < constructors.length; i++)
            populizers[i](constructors[i]);
    };
})();

Array.CreateId = function(id) {
    return id + (1 << 16);
};

Array.Init = function (array, elmId) {
    if (elmId == 421)
        array = new Uint8Array(array);

    array.GetType = function() {
        return Array.CreateId(elmId);
    }

    return array;
};

Array.Sized = function (size, elmId) {
    return Array.Init(new Array(size), elmId);
};

Array.Fill = function (size, cb, elmId) {
    var array = new Array(size);
    for (var i = 0; i < size; i++)
        array[i] = cb();
    return Array.Init(array, elmId);
};

Array.Structs = function (size, ctor, elmId, elmArgIds) {
    return Array.Fill(size, function(){return new ctor(elmArgIds);}, elmId);
};

Array.Zeros = function (s, elmId) {
    for (var i = 0, a = new Array(s); i < s;) a[i++] = 0;
    return Array.Init(a, elmId);
};


Uno.Object = Object;



I = Object.prototype;

I.GetType = function() {
    return 413;
};

I.$II = function() {
    return false;
};


Uno.Object.New = function () {
    return new Object();
};



//$globalHashCounter = 0;

I.GetHashCode = function () {

    if (this instanceof Number)
        return this | 0;

    return 0;

/*
    if (this.$hashCode != undefined)
        return this.$hashCode;

    this.$hashCode = $globalHashCounter++;
    return this.$hashCode;
*/
};




I.Equals = function (obj) {
    if (obj === undefined || obj === null)
        return false;

    if (obj.$box)
        return this.Equals(obj.$);

    if (this.$struct) {
        for (p in this)
            if (!$EqOp(this[p], obj[p]))
                return false;

        return true;
    }

    return this == obj;
};




I.ToString = function (id) {
    return id == 420
        ? String.fromCharCode(this)
        : (this instanceof Boolean)
            ? (this==true)
                ? "True"
                : "False"
            : this.toString();
};



function $CreateRef(getFunc, setFunc, objInst, $) {
    $ = {
        G: getFunc,
        S: setFunc,
        $: objInst
    };
    return function (v) {
        return v !== undefined ? $.S(v) : $.G();
    }
}

function $CopyStruct(obj) {
    var copy = {};
    copy.prototype = obj.prototype;

    for (p in obj) {
        copy[p] = obj[p] && obj[p].$struct ?
            $CopyStruct(obj[p]) :
            obj[p];
    }

    return copy;
}

function $CreateBox(obj, id) {
    return obj === undefined || obj === null ? null :
            obj.constructor == Number || obj.constructor == Boolean ? {

                Equals: function(obj) {
                    return this.$.Equals(obj);
                },


                GetHashCode: function() {
                    return this.$.GetHashCode();
                },


                ToString: function() {
                    return this.$.ToString(this.id);
                },

                GetType: function() {
                    return this.id;
                },
                $box: true,
                $: obj,
                id: id
            } :
            obj.$struct ?
                $CopyStruct(obj) :
                obj;
}

function $CreateDelegate(inst, func, id) {
    return {
        $: inst,
        F: func,
        P: null,
        GetType: function () {
            return id;
        },
        Equals: function(obj) {
            return obj && this.GetType() == obj.GetType() && this.$ == obj.$ && this.F == obj.F;
        },
        Invoke: function () {
            var t = this, p = t.P, a = arguments;
            if (p) p.Invoke.apply(p, a);
            return t.F.apply(t.$, a);
        }
    };
};

function $EqOp(left, right) {
    return left == right || left && left.Equals(right);
}

var $BaseTypeIds = [0, 0, 0, 425, 425, 425, 425, 425, 425, 425, 425, 425, 425, 425, 425, 425, 425, 425, 425, 425, 425, 425, 425, 425, 425, 425, 425, 425, 425, 425, 425, 0, 0, 0, 0, 0, 0, 0, 722, 400, 401, 960, 402, 403, 404, 405, 406, 394, 394, 394, 394, 394, 394, 0, 413, 0, 425, 413, 413, 413, 413, 413, 413, 413, 413, 413, 413, 413, 413, 413, 413, 413, 413, 413, 413, 413, 413, 413, 413, 413, 413, 413, 413, 413, 413, 413, 413, 413, 413, 413, 413, 413, 413, 413, 413, 413, 413, 413, 413, 413, 413, 413, 413, 413, 413, 413, 413, 413, 413, 413, 413, 413, 413, 413, 413, 413, 413, 413, 413, 413, 413, 413, 413, 413, 413, 413, 413, 413, 413, 413, 413, 413, 413, 413, 413, 413, 413, 413, 413, 413, 413, 413, 413, 413, 413, 413, 413, 413, 413, 413, 413, 413, 413, 413, 413, 413, 413, 413, 413, 413, 413, 413, 413, 413, 413, 413, 413, 413, 413, 413, 413, 413, 413, 413, 413, 413, 413, 413, 413, 413, 413, 413, 413, 413, 413, 413, 413, 413, 413, 413, 413, 413, 413, 413, 413, 413, 413, 413, 413, 413, 413, 413, 413, 413, 413, 413, 413, 413, 413, 413, 413, 413, 413, 413, 413, 413, 413, 413, 413, 413, 413, 413, 413, 413, 413, 413, 413, 413, 413, 413, 413, 413, 413, 413, 413, 413, 413, 413, 413, 413, 413, 413, 413, 413, 413, 413, 413, 413, 413, 413, 413, 413, 413, 413, 413, 413, 413, 413, 413, 413, 413, 413, 413, 413, 413, 413, 413, 413, 413, 413, 413, 413, 413, 413, 413, 413, 413, 413, 413, 413, 413, 413, 413, 413, 413, 413, 413, 413, 413, 413, 413, 413, 413, 413, 413, 413, 413, 413, 413, 413, 413, 413, 413, 413, 413, 413, 413, 413, 413, 413, 413, 413, 413, 413, 413, 316, 413, 413, 413, 413, 413, 0, 425, 0, 413, 413, 425, 425, 330, 330, 413, 425, 425, 425, 425, 425, 425, 425, 425, 425, 413, 413, 0, 0, 0, 0, 413, 425, 425, 0, 425, 425, 425, 425, 425, 444, 444, 444, 425, 444, 413, 0, 0, 0, 0, 0, 413, 413, 413, 413, 413, 413, 413, 413, 413, 413, 413, 413, 413, 416, 0, 0, 413, 413, 0, 0, 0, 0, 0, 0, 0, 0, 413, 413, 392, 392, 392, 392, 392, 392, 413, 413, 413, 413, 413, 413, 413, 0, 413, 413, 413, 413, 413, 0, 413, 413, 413, 413, 413, 413, 413, 413, 413, 413, 413, 413, 413, 413, 413, 413, 413, 413, 413, 0, 0, 0, 415, 416, 437, 437, 413, 413, 413, 0, 413, 415, 416, 416, 416, 416, 416, 416, 413, 413, 413, 0, 413, 416, 416, 416, 0, 413, 413, 413, 413, 413, 413, 413, 413, 415, 415, 415, 415, 415, 415, 415, 415, 415, 415, 415, 415, 415, 415, 415, 415, 415, 415, 415, 415, 415, 415, 415, 415, 415, 415, 415, 415, 415, 415, 415, 415, 415, 415, 415, 415, 415, 415, 413, 413, 413, 413, 413, 413, 413, 413, 413, 413, 515, 516, 516, 515, 516, 415, 0, 0, 0, 0, 413, 0, 540, 413, 413, 413, 532, 532, 413, 413, 416, 416, 416, 413, 425, 0, 413, 413, 544, 544, 425, 425, 413, 413, 413, 416, 0, 0, 425, 413, 0, 413, 413, 413, 413, 0, 575, 576, 0, 413, 566, 575, 0, 576, 413, 413, 444, 415, 413, 575, 413, 575, 572, 971, 971, 971, 415, 425, 0, 413, 425, 413, 588, 588, 604, 605, 413, 413, 413, 413, 413, 626, 604, 605, 413, 413, 413, 413, 624, 413, 413, 413, 626, 586, 590, 604, 605, 632, 633, 634, 425, 413, 413, 413, 413, 413, 413, 413, 413, 586, 586, 586, 586, 586, 586, 586, 586, 586, 413, 413, 413, 413, 413, 413, 589, 589, 589, 589, 589, 589, 589, 589, 589, 413, 413, 413, 413, 413, 413, 413, 413, 413, 413, 413, 413, 676, 677, 678, 679, 680, 681, 413, 413, 676, 677, 678, 679, 680, 681, 650, 651, 652, 653, 654, 655, 676, 677, 678, 679, 680, 681, 413, 413, 413, 0, 696, 701, 413, 700, 413, 413, 413, 413, 413, 413, 413, 413, 413, 697, 413, 413, 413, 698, 699, 697, 413, 697, 413, 413, 0, 413, 425, 0, 413, 720, 720, 413, 722, 722, 721, 425, 722, 0, 0, 425, 425, 425, 425, 425, 425, 413, 0, 0, 413, 413, 413, 413, 743, 743, 413, 413, 413, 413, 413, 413, 413, 0, 413, 0, 413, 413, 413, 754, 759, 759, 754, 762, 754, 764, 764, 0, 0, 0, 413, 413, 413, 413, 413, 773, 413, 773, 413, 773, 788, 788, 788, 788, 922, 415, 788, 413, 971, 413, 413, 425, 793, 788, 425, 793, 793, 793, 793, 793, 413, 425, 413, 425, 971, 0, 0, 0, 413, 413, 413, 413, 413, 413, 413, 413, 413, 0, 413, 413, 413, 991, 413, 413, 0, 413, 413, 413, 425, 413, 829, 829, 413, 829, 425, 839, 425, 840, 835, 991, 839, 0, 413, 978, 842, 978, 912, 413, 858, 858, 425, 425, 413, 413, 425, 858, 858, 858, 991, 413, 413, 413, 413, 413, 0, 0, 413, 413, 413, 413, 880, 870, 773, 425, 971, 413, 920, 415, 882, 882, 991, 882, 880, 444, 415, 444, 415, 413, 882, 878, 413, 882, 425, 880, 971, 871, 793, 880, 880, 425, 908, 425, 908, 413, 425, 903, 903, 908, 413, 0, 425, 908, 413, 417, 413, 413, 413, 967, 0, 413, 444, 920, 921, 921, 415, 921, 415, 921, 415, 921, 415, 921, 415, 921, 415, 920, 415, 444, 444, 415, 444, 413, 0, 425, 415, 444, 0, 413, 415, 413, 967, 413, 444, 415, 444, 415, 413, 0, 413, 0, 413, 0, 413, 413, 413, 413, 965, 965, 425, 413, 0, 413, 920, 972, 415, 972, 415, 0, 413, 413, 413, 416, 413, 425, 912, 912, 912, 912, 413, 413, 413, 978, 413, 415, 425, 444, 415, 444, 415, 444, 415, 0, 425, 425, 425, 425, 0, 425, 425, 425, 413, 425, 425, 991, 0, 0, 413, 425, 425, 413, 425, 425, 413, 425, 413, 413, 413, 882, 413, 882, 829, 882, 913, 882, 1033, 1033, 1033, 1033, 413, 1033, 1039, 1039, 1039];

function $IsOp(obj, id, objId) {
    if (obj) {

        ti = objId || obj.GetType();

        // Interface bit
        if (id & (1 << 15))
            return obj.$II(id ^ (1 << 15));

        do {
            if (ti == id) return true;
            ti = ti < $BaseTypeIds.length ? $BaseTypeIds[ti] : 413;
        } while (ti);
    }

    return false;
}

function $AsOp(obj, id, objId) {
    return $IsOp(obj, id, objId) ? obj : null;
}

function $DownCast(obj, id) {
    if (!obj)
        return obj;

    if ($IsOp(obj, id))
        return obj.$box ? obj.$ : obj;

    throw Uno.InvalidCastException.New_3();
}

function $Initialize(main) {

    if (!window.cancelAnimationFrame)
        window.cancelAnimationFrame = $Vendor(window, "cancelAnimationFrame");

    if (!window.requestAnimationFrame)
        window.requestAnimationFrame = $Vendor(window, "requestAnimationFrame");

    if (!window.requestAnimationFrame)
        window.requestAnimationFrame = function (callback) {
            var currTime = new Date().getTime();
            var timeToCall = Math.max(0, 16 - (currTime - lastTime));
            var id = window.setTimeout(function () { callback(timeToCall); },
              timeToCall);
            lastTime = currTime + timeToCall;
            return id;
        };

    window.oncontextmenu = function () {
        return false;
    }

    getMouseButton = function(e) {
        return e.which == 1
                ? 1
                : e.which == 2
                    ? 2
                    : e.which == 3
                        ? 3
                        : 0;
    }

    addEvent = window.addEventListener ? function (elem, type, method) {
            elem.addEventListener(type, method, false);
        } : function (elem, type, method) {
            elem.attachEvent('on' + type, method);
        };

/*
    Note: Methods below does not seem to be used

    removeEvent = window.removeEventListener ? function (elem, type, method) {
            elem.removeEventListener(type, method, false);
        } : function (elem, type, method) {
            elem.detachEvent('on' + type, method);
        };

    addWindowEvent = function (type, method) {
            window.addEventListener(type, method, false);
        };

    removeWindowEvent = function (type, method) {
            window.removeEventListener(type, method, false);
        };
*/

    var started = false;

    // start rendering
    function tick() {
        if (!started) {
            if ($AsyncCount > 0) { // Wait until everything in the app bundle is loaded
                window.requestAnimationFrame(tick);
                return;
            }

            started = true;
            canvas.width = window.innerWidth;
            canvas.height = window.innerHeight;

            main();

            var stopPropagationIfHandled = function(e, isHandled) {
                if (isHandled)
                    e.preventDefault();
            };

            addEvent(canvas, "touchstart", function(e) {
                var touch = e.changedTouches[0];
                Uno.Runtime.Implementation.Internal.Bootstrapper.OnTouchDown(canvas, touch.clientX, touch.clientY, touch.identifier);
            });

            addEvent(canvas, "touchmove", function(e) {
                var touch = e.changedTouches[0];
                Uno.Runtime.Implementation.Internal.Bootstrapper.OnTouchMove(canvas, touch.clientX, touch.clientY, touch.identifier);
            });

            addEvent(canvas, "touchend", function(e) {
                var touch = e.changedTouches[0];
                Uno.Runtime.Implementation.Internal.Bootstrapper.OnTouchUp(canvas, touch.clientX, touch.clientY, touch.identifier);
            });



            addEvent(canvas, "mousedown", function(e) {
                var button = getMouseButton(e);
                $PressedButtons[button] = true;
                Uno.Runtime.Implementation.Internal.Bootstrapper.OnMouseDown(canvas, e.clientX, e.clientY, button);
            });

            addEvent(canvas, "mousemove", function(e) {
                Uno.Runtime.Implementation.Internal.Bootstrapper.OnMouseMove(canvas, e.clientX, e.clientY);
            });

            addEvent(canvas, "mouseout", function(e) {
                e = e ? e : window.event;
                var from = e.relatedTarget || e.toElement;
                if (!from || from.nodeName == "HTML") {
                    Uno.Runtime.Implementation.Internal.Bootstrapper.OnMouseOut(canvas);
                }
            });

            addEvent(canvas, "mouseup", function(e) {
                var button = getMouseButton(e);
                $PressedButtons[button] = false;
                Uno.Runtime.Implementation.Internal.Bootstrapper.OnMouseUp(canvas, e.clientX, e.clientY, button);
            });



            addEvent(canvas, "wheel", function(e) {
                var deltaX = e.deltaX;
                var deltaY = e.deltaY;

                // e.deltaMode as of 16.01.2015 is the same as our WheelDeltaMode enum.
                Uno.Runtime.Implementation.Internal.Bootstrapper.OnMouseWheel(canvas, deltaX, deltaY, e.deltaMode);
            });

            addEvent(canvas, "keydown", function(e) {
                $PressedKeys[e.keyCode] = true;

                stopPropagationIfHandled(e,
                    Uno.Runtime.Implementation.Internal.Bootstrapper.OnKeyDown(canvas, e.keyCode));
            });

            addEvent(canvas, "keyup", function(e) {
                $PressedKeys[e.keyCode] = false;
                stopPropagationIfHandled(e,
                    Uno.Runtime.Implementation.Internal.Bootstrapper.OnKeyUp(canvas, e.keyCode));
            });

            addEvent(canvas, "keypress", function(e) {
                stopPropagationIfHandled(e,
                    Uno.Runtime.Implementation.Internal.Bootstrapper.OnTextInput(canvas, String.fromCharCode(e.keyCode || e.charCode)));
                // TODO: Probably needs an invisible input text box to recieve input string and also to handle onscreen keyboard on mobile
            });

            addEvent(window, "beforeunload", function(e) {
                var cancel = Uno.Runtime.Implementation.Internal.Bootstrapper.OnWindowClosing(canvas);
                if (cancel) {
                    var m = "Are you sure you want to leave this page? Data you have entered may not be saved.";
                    (e || window.event).returnValue = m;
                    return m;
                }
            });

            addEvent(window, "unload", function(e) {
                Uno.Runtime.Implementation.Internal.Bootstrapper.OnWindowClosed(canvas);
            });

            addEvent(window, "resize", function(e) {
                canvas.width = window.innerWidth;
                canvas.height = window.innerHeight;
                Uno.Runtime.Implementation.Internal.Bootstrapper.OnWindowSizeChanged(canvas);
            });

            addEvent(window, "focus", function(e) {
                Uno.Runtime.Implementation.Internal.Bootstrapper.OnGotFocus(canvas);
            });
            
            addEvent(window, "blur", function(e) {
                Uno.Runtime.Implementation.Internal.Bootstrapper.OnLostFocus(canvas);
            });

            Uno.Runtime.Implementation.Internal.Bootstrapper.OnLoad();
        }

        Uno.Runtime.Implementation.Internal.Bootstrapper.OnUpdate();

        if (Uno.Application.Current().DrawNextFrame())
            Uno.Runtime.Implementation.Internal.Bootstrapper.OnDraw();

        window.requestAnimationFrame(tick);
    }


    Uno.String.New_1 = function(arr) {
        return String.fromCharCode.apply(window, arr);
    }



    Uno.Object.Equals_1 = function (left, right) {
        return left == right || left && left.Equals(right);
    }


    tick();
}
