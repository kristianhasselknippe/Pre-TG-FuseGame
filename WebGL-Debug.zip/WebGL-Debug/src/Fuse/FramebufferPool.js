Fuse.FramebufferPool = $CreateClass(
    function() {
    },
    function(S) {
        Fuse.FramebufferPool.framebufferPool = null;

        Fuse.FramebufferPool.Frame = function()
        {
            Fuse.FramebufferPool.EnsurePool();
            return Fuse.FramebufferPool.framebufferPool.frame;
        };

        Fuse.FramebufferPool.EnsurePool = function()
        {
            if (Fuse.FramebufferPool.framebufferPool == null)
            {
                Fuse.FramebufferPool.framebufferPool = Fuse.FramebufferPoolImpl.New_1();
            }
        };

        Fuse.FramebufferPool.Register = function(cfb)
        {
            Fuse.FramebufferPool.EnsurePool();
            Fuse.FramebufferPool.framebufferPool.Register(cfb);
        };

        Fuse.FramebufferPool.UnRegister = function(cfb)
        {
            Fuse.FramebufferPool.EnsurePool();
            Fuse.FramebufferPool.framebufferPool.UnRegister(cfb);
        };

        Fuse.FramebufferPool.Lock = function(size, format, depth)
        {
            var size_123 = new Uno.Int2;
            size_123.op_Assign(size);
            return Fuse.FramebufferPool.Lock_1(size_123.X, size_123.Y, format, depth);
        };

        Fuse.FramebufferPool.Lock_1 = function(width, height, format, depth)
        {
            Fuse.FramebufferPool.EnsurePool();
            return Fuse.FramebufferPool.framebufferPool.Lock(width, height, format, depth);
        };

        Fuse.FramebufferPool.Release = function(fb)
        {
            Fuse.FramebufferPool.EnsurePool();
            Fuse.FramebufferPool.framebufferPool.Release(fb);
        };

    });
