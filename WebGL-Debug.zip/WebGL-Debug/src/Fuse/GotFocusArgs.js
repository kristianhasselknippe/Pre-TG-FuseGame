Fuse.GotFocusArgs = $CreateClass(
    function() {
        Uno.EventArgs.call(this);
    },
    function(S) {
        var I = S.prototype = new Uno.EventArgs;

        I.GetType = function()
        {
            return 937;
        };

        I._ObjInit_1 = function()
        {
            Uno.EventArgs.prototype._ObjInit.call(this);
        };

        Fuse.GotFocusArgs.New_2 = function()
        {
            var inst = new Fuse.GotFocusArgs;
            inst._ObjInit_1();
            return inst;
        };

    });
