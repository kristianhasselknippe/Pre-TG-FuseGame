Fuse.Physics.PointBody1D = $CreateClass(
    function() {
        this._velocity = 0;
        this._attractionForce = 0;
        this._attractionCurve = 0;
        this._damping = 0;
        this._energyEps = 0;
        this._isStatic = false;
        this._isSimulating = false;
        this._isUpdating = false;
        this._simTime = 0;
        this.timeStep = 0;
        this.PositionChanged = null;
        this._IsLocked = false;
        this._Position = 0;
        this._AttractionDestinatoin = 0;
    },
    function(S) {
        var I = S.prototype;

        I.GetType = function()
        {
            return 772;
        };

        I.IsLocked = function(value)
        {
            if (value !== undefined)
            {
                this._IsLocked = value;
            }
            else
            {
                return this._IsLocked;
            }
        };

        I.Position = function(value)
        {
            if (value !== undefined)
            {
                this._Position = value;
            }
            else
            {
                return this._Position;
            }
        };

        I.Velocity = function(value)
        {
            if (value !== undefined)
            {
                if (this._velocity != value)
                {
                    this._velocity = value;
                    this._isStatic = false;
                    this.HookUpdate();
                }
            }
            else
            {
                return this._velocity;
            }
        };

        I.AttractionDestinatoin = function(value)
        {
            if (value !== undefined)
            {
                this._AttractionDestinatoin = value;
            }
            else
            {
                return this._AttractionDestinatoin;
            }
        };

        I.AttractionForce = function(value)
        {
            if (value !== undefined)
            {
                this._attractionForce = value;
            }
            else
            {
                return this._attractionForce;
            }
        };

        I.AttractionCurve = function(value)
        {
            if (value !== undefined)
            {
                this._attractionCurve = value;
            }
            else
            {
                return this._attractionCurve;
            }
        };

        I.Damping = function(value)
        {
            if (value !== undefined)
            {
                this._damping = value;
            }
            else
            {
                return this._damping;
            }
        };

        I.EnergyEps = function(value)
        {
            if (value !== undefined)
            {
                this._energyEps = value;
            }
            else
            {
                return this._energyEps;
            }
        };

        I.IsStatic = function(value)
        {
            if (value !== undefined)
            {
                if (this._isStatic != value)
                {
                    this._isStatic = value;
                    this.HookUpdate();
                }
            }
            else
            {
                return this._isStatic;
            }
        };

        I.Attraction = function()
        {
            var v = this.AttractionDestinatoin() - this.Position();
            return Uno.Math.Pow_1(Uno.Math.Abs_1(v), this.AttractionCurve()) * ((v < 0.0) ? -1 : 1);
        };

        I.Energy = function()
        {
            return Uno.Math.Abs_1(this.Attraction()) + Uno.Math.Abs_1(this.Velocity());
        };

        I.HookUpdate = function()
        {
            if ((this._isSimulating && !this._isStatic) && !this._isUpdating)
            {
                Fuse.UpdateManager.AddAction($CreateDelegate(this, Fuse.Physics.PointBody1D.prototype.Update, 436), 0);
                this._isUpdating = true;
                this._simTime = this.GetTime();
                return;
            }

            if (this._isUpdating && (this._isStatic || !this._isSimulating))
            {
                Fuse.UpdateManager.RemoveAction($CreateDelegate(this, Fuse.Physics.PointBody1D.prototype.Update, 436), 0);
                this._isUpdating = false;
                return;
            }
        };

        I.GetTime = function()
        {
            return Fuse.Time.FrameTime();
        };

        I.StartSimulation = function()
        {
            if (!this._isSimulating)
            {
                this._isSimulating = true;
                this.HookUpdate();
            }
        };

        I.StopSimulation = function()
        {
            this._isSimulating = false;
            this.HookUpdate();
        };

        I.Update = function()
        {
            var p = this.Position();

            while (this._simTime < this.GetTime())
            {
                this.Iterate();
                this._simTime = this._simTime + this.timeStep;
            }

            if ((this.Position() != p) && Uno.Delegate.op_Inequality(this.PositionChanged, null))
            {
                this.PositionChanged.Invoke(this.Position());
            }
        };

        I.Iterate = function()
        {
            this.Velocity(this.Velocity() + ((this.Attraction() * this.AttractionForce()) * this.timeStep));
            this.Velocity(this.Velocity() * this.Damping());

            if (!this.IsLocked())
            {
                this.Position(this.Position() + (this.Velocity() * this.timeStep));

                if (this.Energy() < this.EnergyEps())
                {
                    this.IsStatic(true);
                }
            }
        };

    });
