Fuse.Image = $CreateClass(
    function() {
        Fuse.Element.call(this);
        this._sizing = null;
        this._sourcePinned = false;
        this._source = null;
        this._hasColor = false;
        this._color = new Uno.Float4;
        this._resampleMode = 0;
        this._hasResampleMode = false;
        this._scale9Margin = new Uno.Float4;
        this._hasScale9Margin = false;
        this._origin = new Uno.Float2;
        this._scale = new Uno.Float2;
        this._drawOrigin = new Uno.Float2;
        this._drawSize = new Uno.Float2;
        this._uvClip = new Uno.Float4;
        this.lockedTexture = false;
        this.SourceChanged = null;
        this.LoadingChanged = null;
        this.FailedChanged = null;
    },
    function(S) {
        var I = S.prototype = new Fuse.Element;

        I.GetType = function()
        {
            return 1013;
        };

        I.Source = function(value)
        {
            if (value !== undefined)
            {
                if (this._source != value)
                {
                    this.ReleaseSource();
                    this._source = value;

                    if (this._source != null)
                    {
                        this._source.add_Changed($CreateDelegate(this, Fuse.Image.prototype.OnSourceChanged, 445));
                    }

                    this.OnSourceChanged(null, null);
                }
            }
            else
            {
                return this._source;
            }
        };

        I.Texture = function(value)
        {
            if (value !== undefined)
            {
                var ts = $AsOp(this._source, 578);

                if (ts != null)
                {
                    ts.Texture(value);
                    return;
                }

                ts = Fuse.Resources.TextureImageSource.New_1();
                ts.Texture(value);
                this.Source(ts);
            }
            else
            {
                var ts = $AsOp(this._source, 578);

                if (ts != null)
                {
                    return ts.Texture();
                }

                return null;
            }
        };

        I.Color = function(value)
        {
            if (value !== undefined)
            {
                if (!this._hasColor || Uno.Float4.op_Inequality(this._color, value))
                {
                    this._color.op_Assign(value);
                    this._hasColor = true;
                    this.OnColorChanged();
                }
            }
            else
            {
                return this._color;
            }
        };

        I.ResampleMode = function(value)
        {
            if (value !== undefined)
            {
                if (!this._hasResampleMode || (this._resampleMode != value))
                {
                    this._resampleMode = value;
                    this._hasResampleMode = true;
                    this.OnResampleModeChanged();
                }
            }
            else
            {
                return this._resampleMode;
            }
        };

        I.StretchMode = function(value)
        {
            if (value !== undefined)
            {
                if (this._sizing.SetStretchMode(value))
                {
                    this.OnSizingChanged();
                }
            }
            else
            {
                return this._sizing.stretchMode;
            }
        };

        I.Scale9Margin = function(value)
        {
            if (value !== undefined)
            {
                if (!this._hasScale9Margin || Uno.Float4.op_Inequality(this._scale9Margin, value))
                {
                    this._scale9Margin.op_Assign(value);
                    this._hasScale9Margin = true;
                    this.OnScale9MarginChanged();
                }
            }
            else
            {
                return this._scale9Margin;
            }
        };

        I.ReleaseSource = function()
        {
            if (this._source == null)
            {
                return;
            }

            this._source.remove_Changed($CreateDelegate(this, Fuse.Image.prototype.OnSourceChanged, 445));

            if (this._sourcePinned)
            {
                this._source.Unpin();
                this._sourcePinned = false;
            }

            this._source = null;
        };

        I.OnRooted = function()
        {
            Fuse.Element.prototype.OnRooted.call(this);
            this.CheckPinning();
        };

        I.OnUnrooted = function()
        {
            Fuse.Element.prototype.OnUnrooted.call(this);
            this.CheckPinning();
        };

        I.CheckPinning = function()
        {
            if (this._source == null)
            {
                return;
            }

            var on = this.IsRooted();

            if (on != this._sourcePinned)
            {
                if (on)
                {
                    this._source.Pin();
                }
                else
                {
                    this._source.Unpin();
                }

                this._sourcePinned = on;
            }
        };

        I.OnSourceChanged = function(sender, args)
        {
            this.CheckPinning();
            this.InvalidateLayout();
            this.InvalidateVisual();

            if (Uno.Delegate.op_Inequality(this.SourceChanged, null))
            {
                this.SourceChanged.Invoke(this, Uno.EventArgs.Empty);
            }

            if (Uno.Delegate.op_Inequality(this.LoadingChanged, null))
            {
                this.LoadingChanged.Invoke(this, Uno.EventArgs.Empty);
            }

            if (Uno.Delegate.op_Inequality(this.FailedChanged, null))
            {
                this.FailedChanged.Invoke(this, Uno.EventArgs.Empty);
            }
        };

        I.OnColorChanged = function()
        {
            this.InvalidateVisual();
        };

        I.OnResampleModeChanged = function()
        {
            this.InvalidateVisual();
        };

        I.OnSizingChanged = function()
        {
            this.InvalidateVisual();
            this.InvalidateLayout();
        };

        I.OnScale9MarginChanged = function()
        {
            this.InvalidateLayout();
            this.InvalidateVisual();
        };

        I.GetSize = function()
        {
            if (this.Source() != null)
            {
                return this.Source().Size();
            }

            return Uno.Float2.New_1(0.0);
        };

        I.GetContentSize = function(fillSize, fillSet)
        {
            this._sizing.padding = Uno.Float4.New_1(0.0);
            return this._sizing.ExpandFillSize(this.GetSize(), fillSize, fillSet);
        };

        I.ArrangePaddingBox = function(size)
        {
            var contentDesiredSize_126 = new Uno.Float2;
            this._sizing.padding.op_Assign(this.Padding());
            contentDesiredSize_126.op_Assign(this.GetSize());
            this._scale.op_Assign(this._sizing.CalcScale(size, contentDesiredSize_126));
            this._origin = this._sizing.CalcOrigin(size, Uno.Float2.op_Multiply_1(contentDesiredSize_126, this._scale));
            this._drawOrigin.op_Assign(this._origin);
            this._drawSize = Uno.Float2.op_Multiply_1(contentDesiredSize_126, this._scale);
            this._uvClip = this._sizing.CalcClip(size, $CreateRef(function(){return this.$._drawOrigin}, function($){this.$._drawOrigin=$}, this), $CreateRef(function(){return this.$._drawSize}, function($){this.$._drawSize=$}, this));
        };

        I.GetTexture = function()
        {
            if (this.Source() != null)
            {
                return this.Source().GetTexture();
            }

            return null;
        };

        I.OnDraw = function(dc)
        {
            var ind_131;
            var ind_132;
            var ind_133;
            var collection_123;
            var tex = this.GetTexture();

            if (tex == null)
            {
                return;
            }

            collection_123 = Fuse.Drawing.TextureFill.New_1();
            collection_123.Texture(tex);
            collection_123.Color(this.Color());
            collection_123.ResampleMode(this.ResampleMode());
            var tf = collection_123;

            if (this.StretchMode() == 2)
            {
                Fuse.Internal.Drawing.Scale9Rectangle.Draw(dc, this.GetDrawMatrix(dc), this.ActualSize(), this.GetSize(), tf, this.Scale9Margin());
            }
            else
            {
                Fuse.Internal.Drawing.ImageRectangle.Draw(dc, this.GetDrawMatrix(dc), this._drawOrigin, this._drawSize, (ind_131 = this._uvClip, Uno.Float2.New_2(ind_131.X, ind_131.Y)), Uno.Float2.op_Subtraction((ind_132 = this._uvClip, Uno.Float2.New_2(ind_132.Z, ind_132.W)), (ind_133 = this._uvClip, Uno.Float2.New_2(ind_133.X, ind_133.Y))), tf);
            }
        };

        I.OnHitTestVisual = function(htc)
        {
            if (this.IsPointInside(htc.LocalPoint()))
            {
                htc.Hit($DownCast(this, 33719));
            }
        };

        I._ObjInit_2 = function()
        {
            this._sizing = Fuse.Internal.SizingContainer.New_1();
            this._color = Uno.Float4.New_1(1.0);
            this._resampleMode = 2;
            this._scale9Margin = Uno.Float4.New_1(10.0);
            this.lockedTexture = true;
            Fuse.Element.prototype._ObjInit_1.call(this);
        };

        Fuse.Image.New_1 = function()
        {
            var inst = new Fuse.Image;
            inst._ObjInit_2();
            return inst;
        };

    });
