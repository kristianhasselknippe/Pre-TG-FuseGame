Fuse.CanvasTextRendererImpl = $CreateClass(
    function() {
    },
    function(S) {

        Fuse.CanvasTextRendererImpl.Create = function(__fontName)
        {
            var ret = {};
            ret.fontFace = __fontName;
            ret.fontFaceQuoted = "'" + __fontName + "'"
            ret.canvas = document.createElement('canvas');
            ret.context = ret.canvas.getContext("2d");
            return ret;
        };

        Fuse.CanvasTextRendererImpl.MeasureStringVirtual = function(__handle, __s)
        {
            return __handle.context.measureText(__s).width;
        };

        Fuse.CanvasTextRendererImpl.BeginRendering = function(__handle, __width, __height, __fontSize)
        {
            var canvas = __handle.canvas;
            canvas.width = __width;
            canvas.height = __height;
            
            // Setting width and height on the canvas might clear/reset its values, so we make sure to reset the font afterwards.
            Fuse.CanvasTextRendererImpl.UpdateFontSize(__handle, __fontSize);
            
            var context = __handle.context;
            // Because setting width/height on a canvas might clear it, this fillRect may not be necessary, but I'm not sure how that works on all browsers.
            context.fillStyle = "#000";
            context.fillRect(0, 0, __width, __height);
            context.fillStyle = "#fff";
            context.textBaseline = "middle";
        };

        Fuse.CanvasTextRendererImpl.DrawText = function(__handle, __x, __y, __s)
        {
            __handle.context.fillText(__s, __x, __y);
        };

        Fuse.CanvasTextRendererImpl.EndRendering = function(__handle, __width, __height)
        {
            var image = __handle.context.getImageData(0, 0, __width, __height);
            return Uno.Content.Images.Bitmap.New_1(Uno.Int2.New_2(image.width, image.height), 3, Uno.Buffer.New_2(new Uint8Array(image.data.buffer)));
        };

        Fuse.CanvasTextRendererImpl.UpdateFontSize = function(__handle, __fontSize)
        {
            if (__fontSize + "px " + __handle.fontFace != __handle.context.font)
            	__handle.context.font = __fontSize + "px" + __handle.fontFaceQuoted;
        };

    });
