Fuse.Translation = $CreateClass(
    function() {
        Fuse.Transform.call(this);
        this._added = null;
        this._x = 0;
        this._y = 0;
        this._z = 0;
        this._RelativeTo = 0;
        this._RelativeNode = null;
    },
    function(S) {
        var I = S.prototype = new Fuse.Transform;

        I.GetType = function()
        {
            return 984;
        };

        I.RelativeTo = function(value)
        {
            if (value !== undefined)
            {
                this._RelativeTo = value;
            }
            else
            {
                return this._RelativeTo;
            }
        };

        I.RelativeNode = function(value)
        {
            if (value !== undefined)
            {
                this._RelativeNode = value;
            }
            else
            {
                return this._RelativeNode;
            }
        };

        I.X = function(value)
        {
            if (value !== undefined)
            {
                if (this._x != value)
                {
                    this._x = value;
                    this.OnMatrixChanged();
                }
            }
            else
            {
                return this._x;
            }
        };

        I.Y = function(value)
        {
            if (value !== undefined)
            {
                if (this._y != value)
                {
                    this._y = value;
                    this.OnMatrixChanged();
                }
            }
            else
            {
                return this._y;
            }
        };

        I.Z = function(value)
        {
            if (value !== undefined)
            {
                if (this._z != value)
                {
                    this._z = value;
                    this.OnMatrixChanged();
                }
            }
            else
            {
                return this._z;
            }
        };

        I.Vector = function(value)
        {
            if (value !== undefined)
            {
                var value_124 = new Uno.Float3;
                value_124.op_Assign(value);

                if (((this._x != value_124.X) || (this._y != value_124.Y)) || (this._z != value_124.Z))
                {
                    this._x = value_124.X;
                    this._y = value_124.Y;
                    this._z = value_124.Z;
                    this.OnMatrixChanged();
                }
            }
            else
            {
                return Uno.Float3.New_2(this.X(), this.Y(), this.Z());
            }
        };

        I.AbsVector = function()
        {
            var v = this.Vector();
            var ind_125 = this.RelativeNode();
            var node = (ind_125 != null) ? ind_125 : this._added;

            if ((this.RelativeTo() == 2) && (node != null))
            {
                v.op_Assign(this.RelativeToSize(v, node.Parent()));
            }
            else if (this.RelativeTo() == 1)
            {
                v.op_Assign(this.RelativeToSize(v, $DownCast(node, 33719)));
            }

            return v;
        };

        I.OnAdded = function(n)
        {
            this._added = n;
        };

        I.OnRemoved = function(n)
        {
            this._added = null;
        };

        I.RelativeToSize = function(v, node)
        {
            var isz = $AsOp(node, 33750);

            if (isz == null)
            {
                return v;
            }

            return Uno.Float3.op_Multiply_1(v, isz["Fuse.IActualSize.ActualSize"]());
        };

        I.AppendTo = function(m, weight)
        {
            var v = Uno.Float3.op_Multiply(this.AbsVector(), weight);
            m.AppendTranslation(v.X, v.Y, v.Z);
        };

        I.PrependTo = function(m)
        {
            var v = this.AbsVector();
            m.PrependTranslation(v.X, v.Y, v.Z);
        };

        I._ObjInit_1 = function()
        {
            Fuse.Transform.prototype._ObjInit.call(this);
        };

        Fuse.Translation.New_1 = function()
        {
            var inst = new Fuse.Translation;
            inst._ObjInit_1();
            return inst;
        };

    });
