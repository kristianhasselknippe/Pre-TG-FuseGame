Fuse.SelectionQuery = $CreateClass(
    function() {
        this._results = null;
    },
    function(S) {
        var I = S.prototype;

        I.GetType = function()
        {
            return 956;
        };

        I.Select = function(root, point, camera)
        {
            this._results = Uno.Collections.List__Fuse_HitTestResult.New_1();
            var args = Fuse.HitTestContext.New_1(point, $CreateDelegate(this, Fuse.SelectionQuery.prototype.Select_1, 948));

            if (camera != null)
            {
                args.PushCamera(camera);
            }

            root["Fuse.INode.HitTest"](args);

            if (camera != null)
            {
                args.PopCamera();
            }

            args.Dispose();
            return this._results.ToArray();
        };

        I.Select_1 = function(result)
        {
            this._results.Add(result);
        };

        I._ObjInit = function()
        {
        };

        Fuse.SelectionQuery.New_1 = function()
        {
            var inst = new Fuse.SelectionQuery;
            inst._ObjInit();
            return inst;
        };

    });
