Fuse.PointerLeaveArgs = $CreateClass(
    function() {
        Fuse.PointerEventArgs.call(this);
    },
    function(S) {
        var I = S.prototype = new Fuse.PointerEventArgs;

        I.GetType = function()
        {
            return 933;
        };

        I._ObjInit_3 = function(data)
        {
            Fuse.PointerEventArgs.prototype._ObjInit_2.call(this, data);
        };

        Fuse.PointerLeaveArgs.New_2 = function(data)
        {
            var inst = new Fuse.PointerLeaveArgs;
            inst._ObjInit_3(data);
            return inst;
        };

    });
