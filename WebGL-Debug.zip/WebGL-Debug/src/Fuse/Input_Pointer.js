Fuse.Input_Pointer = $CreateClass(
    function() {
        this.PointCoord = new Uno.Float2;
        this.WasHandled = false;
        this.DistanceMoved = 0;
        this.TimeAppeared = 0;
    },
    function(S) {
        var I = S.prototype;

        I.GetType = function()
        {
            return 1019;
        };

        I._ObjInit = function()
        {
            this.TimeAppeared = Uno.Diagnostics.Clock.GetSeconds();
        };

        Fuse.Input_Pointer.New_1 = function()
        {
            var inst = new Fuse.Input_Pointer;
            inst._ObjInit();
            return inst;
        };

    });
