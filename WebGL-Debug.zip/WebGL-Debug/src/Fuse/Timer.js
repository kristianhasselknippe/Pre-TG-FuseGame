Fuse.Timer = $CreateClass(
    function() {
        this._callback = null;
        this._startTime = 0;
        this._interval = 0;
        this._running = false;
        this._once = false;
    },
    function(S) {
        var I = S.prototype;

        I.GetType = function()
        {
            return 963;
        };

        I.Start = function()
        {
            this._startTime = Uno.Diagnostics.Clock.GetSeconds();
            Fuse.UpdateManager.AddAction($CreateDelegate(this, Fuse.Timer.prototype.Update, 436), 0);
            this._running = true;
        };

        I.Stop = function()
        {
            this._running = false;
            Fuse.UpdateManager.RemoveAction($CreateDelegate(this, Fuse.Timer.prototype.Update, 436), 0);
        };

        I.Update = function()
        {
            var now = Uno.Diagnostics.Clock.GetSeconds();
            var time = now - this._startTime;

            if (time > this._interval)
            {
                this._callback.Invoke();

                if (this._once)
                {
                    this.Stop();
                }
                else
                {
                    this._startTime = now;
                }
            }
        };

        Fuse.Timer.Wait = function(duration, callback)
        {
            var t = Fuse.Timer.New_1(duration, callback);
            t.Start();
        };

        I._ObjInit = function(interval, callback)
        {
            this._callback = callback;
            this._startTime = Uno.Diagnostics.Clock.GetSeconds();
            this._interval = interval;
            this._once = true;
        };

        Fuse.Timer.New_1 = function(interval, callback)
        {
            var inst = new Fuse.Timer;
            inst._ObjInit(interval, callback);
            return inst;
        };

    });
