Fuse.Drawing.WindingRules = $CreateClass(
    function() {
    },
    function(S) {

        Fuse.Drawing.WindingRules.Odd = function(n)
        {
            return (n & 1) != 0;
        };

        Fuse.Drawing.WindingRules.NonZero = function(n)
        {
            return n != 0;
        };

    });
