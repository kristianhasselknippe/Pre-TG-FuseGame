Fuse.Drawing.HorizontalLineTo = $CreateClass(
    function() {
        Fuse.Drawing.LineTo.call(this);
        this._x = 0;
    },
    function(S) {
        var I = S.prototype = new Fuse.Drawing.LineTo;

        I.GetType = function()
        {
            return 765;
        };

        I.Serialize = function()
        {
            return Uno.String.op_Addition_1("H ", $CreateBox(this._x, 429));
        };

        I._ObjInit_3 = function(prev, lastPosition, x)
        {
            var lastPosition_123 = new Uno.Float2;
            lastPosition_123.op_Assign(lastPosition);
            Fuse.Drawing.LineTo.prototype._ObjInit_2.call(this);
            this.LineToCtor(prev, lastPosition_123, Uno.Float2.New_2(x, lastPosition_123.Y));
            this._x = x;
        };

        Fuse.Drawing.HorizontalLineTo.New_4 = function(prev, lastPosition, x)
        {
            var inst = new Fuse.Drawing.HorizontalLineTo;
            inst._ObjInit_3(prev, lastPosition, x);
            return inst;
        };

    });
