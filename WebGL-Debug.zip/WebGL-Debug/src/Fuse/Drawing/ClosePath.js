Fuse.Drawing.ClosePath = $CreateClass(
    function() {
        Fuse.Drawing.ContourTerminator.call(this);
        this._lastPosition = new Uno.Float2;
    },
    function(S) {
        var I = S.prototype = new Fuse.Drawing.ContourTerminator;

        I.GetType = function()
        {
            return 761;
        };

        I.Serialize = function()
        {
            return "Z";
        };

        I._ObjInit_3 = function(prev, lastPosition)
        {
            Fuse.Drawing.ContourTerminator.prototype._ObjInit_2.call(this);
            this.ContourTerminatorCtor(prev, prev.FindStartOfLastContour());
            this._lastPosition.op_Assign(lastPosition);
        };

        Fuse.Drawing.ClosePath.New_2 = function(prev, lastPosition)
        {
            var inst = new Fuse.Drawing.ClosePath;
            inst._ObjInit_3(prev, lastPosition);
            return inst;
        };

    });
