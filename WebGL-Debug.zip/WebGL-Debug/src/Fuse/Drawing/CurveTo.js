Fuse.Drawing.CurveTo = $CreateClass(
    function() {
        Fuse.Drawing.PathGeometry.call(this);
        this._lastPosition = new Uno.Float2;
        this._controlPointStart = new Uno.Float2;
        this._controlPointEnd = new Uno.Float2;
    },
    function(S) {
        var I = S.prototype = new Fuse.Drawing.PathGeometry;

        I.GetType = function()
        {
            return 762;
        };

        I.EndTangent = function()
        {
            return Uno.Float2.op_Subtraction(this.EndPosition(), this.ControlPointEnd());
        };

        I.HasLastBounds = function()
        {
            return true;
        };

        I.LastBounds = function()
        {
            return Fuse.Drawing.BezierOp.GetRect(this._lastPosition, this._controlPointStart, this._controlPointEnd, this.EndPosition());
        };

        I.ControlPointEnd = function()
        {
            return this._controlPointEnd;
        };

        I.CurveToCtor = function(prev, lastPosition, controlPointStart, controlPointEnd, position)
        {
            this.PathGeometryCtor(prev, position);
            this._lastPosition.op_Assign(lastPosition);
            this._controlPointStart.op_Assign(controlPointStart);
            this._controlPointEnd.op_Assign(controlPointEnd);
        };

        I.EvaluateLast = function()
        {
            return Uno.Geometry.CubicBezier.Subdivide(this._lastPosition, this._controlPointStart, this._controlPointEnd, this.EndPosition());
        };

        I.Serialize = function()
        {
            return Uno.String.op_Addition_1(Uno.String.op_Addition(Uno.String.op_Addition_1(Uno.String.op_Addition(Uno.String.op_Addition_1(Uno.String.op_Addition(Uno.String.op_Addition_1(Uno.String.op_Addition(Uno.String.op_Addition_1(Uno.String.op_Addition(Uno.String.op_Addition_1("C ", $CreateBox(this._controlPointStart.X, 429)), " "), $CreateBox(this._controlPointStart.Y, 429)), " "), $CreateBox(this._controlPointEnd.X, 429)), " "), $CreateBox(this._controlPointEnd.Y, 429)), " "), $CreateBox(this.EndPosition().X, 429)), " "), $CreateBox(this.EndPosition().Y, 429));
        };

        I._ObjInit_1 = function(prev, lastPosition, controlPointStart, controlPointEnd, position)
        {
            Fuse.Drawing.PathGeometry.prototype._ObjInit.call(this);
            this.CurveToCtor(prev, lastPosition, controlPointStart, controlPointEnd, position);
        };

        Fuse.Drawing.CurveTo.New_2 = function(prev, lastPosition, controlPointStart, controlPointEnd, position)
        {
            var inst = new Fuse.Drawing.CurveTo;
            inst._ObjInit_1(prev, lastPosition, controlPointStart, controlPointEnd, position);
            return inst;
        };

        I._ObjInit_2 = function()
        {
            Fuse.Drawing.PathGeometry.prototype._ObjInit.call(this);
        };

    });
