Fuse.Drawing.TextureFill = $CreateClass(
    function() {
        Fuse.Drawing.DynamicBrush.call(this);
        this._texture = null;
        this._resampleMode = 0;
        this._color = new Uno.Float4;
        this._repeatHorizontally = false;
        this._repeatVertically = false;
        this._align = 0;
        this._sizeMode = 0;
    },
    function(S) {
        var I = S.prototype = new Fuse.Drawing.DynamicBrush;

        I.GetType = function()
        {
            return 728;
        };

        I.Texture = function(value)
        {
            if (value !== undefined)
            {
                if (value == this._texture)
                {
                    return;
                }

                this._texture = value;
                this.OnShadingChanged();
            }
            else
            {
                return this._texture;
            }
        };

        I.ResampleMode = function(value)
        {
            if (value !== undefined)
            {
                if (value == this._resampleMode)
                {
                    return;
                }

                this._resampleMode = value;
                this.OnShadingChanged();
            }
            else
            {
                return this._resampleMode;
            }
        };

        I.Color = function(value)
        {
            if (value !== undefined)
            {
                if (Uno.Float4.op_Equality(value, this._color))
                {
                    return;
                }

                this._color.op_Assign(value);
                this.OnShadingChanged();
            }
            else
            {
                return this._color;
            }
        };

        I.Alignment = function(value)
        {
            if (value !== undefined)
            {
                if (value == this._align)
                {
                    return;
                }

                this._align = value;
                this.OnShadingChanged();
            }
            else
            {
                return this._align;
            }
        };

        I.HorizontalAlignment = function()
        {
            return this.Alignment() & 3;
        };

        I.VerticalAlignment = function()
        {
            return this.Alignment() & 12;
        };

        I.SizeMode = function(value)
        {
            if (value !== undefined)
            {
                if (value == this._sizeMode)
                {
                    return;
                }

                this._sizeMode = value;
                this.OnShadingChanged();
            }
            else
            {
                return this._sizeMode;
            }
        };

        I.MinFilter = function()
        {
            switch (this.ResampleMode())
            {
                case 1:
                default:
                {
                    return 9729;
                }
                case 0:
                {
                    return 9728;
                }
                case 2:
                {
                    return 9987;
                }
            }
        };

        I.MagFilter = function()
        {
            switch (this.ResampleMode())
            {
                case 1:
                default:
                {
                    return 9729;
                }
                case 0:
                {
                    return 9728;
                }
                case 2:
                {
                    return 9729;
                }
            }
        };

        I._ObjInit_2 = function()
        {
            this._resampleMode = 1;
            this._color = Uno.Float4.New_1(1.0);
            this._repeatHorizontally = true;
            this._repeatVertically = true;
            Fuse.Drawing.DynamicBrush.prototype._ObjInit_1.call(this);
        };

        Fuse.Drawing.TextureFill.New_1 = function()
        {
            var inst = new Fuse.Drawing.TextureFill;
            inst._ObjInit_2();
            return inst;
        };

    });
