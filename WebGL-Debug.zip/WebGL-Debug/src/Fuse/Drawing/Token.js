Fuse.Drawing.Token = $CreateClass(
    function() {
        this.First = 0;
        this.Last = 0;
        this.Next = null;
        this.HasAction = false;
    },
    function(S) {
        var I = S.prototype;

        I.GetType = function()
        {
            return 757;
        };

        I._ObjInit = function(first, hasAction)
        {
            this.First = first;
            this.HasAction = hasAction;
        };

        Fuse.Drawing.Token.New_1 = function(first, hasAction)
        {
            var inst = new Fuse.Drawing.Token;
            inst._ObjInit(first, hasAction);
            return inst;
        };

    });
