Fuse.Drawing.PathGeometry = $CreateClass(
    function() {
        this._previous = null;
        this._position = new Uno.Float2;
        this._boundsCache = new Uno.Rect;
        this._hasBoundsCache = false;
    },
    function(S) {
        var I = S.prototype;

        I.GetType = function()
        {
            return 754;
        };

        I.Bounds = function()
        {
            if (!this._hasBoundsCache)
            {
                this._hasBoundsCache = true;
                this._boundsCache = this.CalculateBounds();
            }

            return this._boundsCache;
        };

        I.HasLastBounds = function()
        {
            return false;
        };

        I.LastBounds = function()
        {
            throw new $Error(Uno.InvalidOperationException.New_3());
        };

        I.EndsContour = function()
        {
            return false;
        };

        I.EndPosition = function()
        {
            return this._position;
        };

        I.EndTangent = function()
        {
            return Uno.Float2.New_1(0.0);
        };

        Fuse.Drawing.PathGeometry.Parse = function(pathDescription)
        {
            return Fuse.Drawing.PathGeometryParser.Deserialize(pathDescription);
        };

        I.PathGeometryCtor = function(previous, position)
        {
            this._previous = previous;
            this._position.op_Assign(position);
        };

        I.MoveTo = function(x, y)
        {
            return Fuse.Drawing.MoveTo.New_2(this, Uno.Float2.New_2(x, y));
        };

        I.MoveTo_1 = function(position)
        {
            return Fuse.Drawing.MoveTo.New_2(this, position);
        };

        I.LineTo = function(x, y)
        {
            return Fuse.Drawing.LineTo.New_2(this, this.EndPosition(), Uno.Float2.New_2(x, y));
        };

        I.LineTo_1 = function(position)
        {
            return Fuse.Drawing.LineTo.New_2(this, this.EndPosition(), position);
        };

        I.HorizontalLineTo = function(x)
        {
            return Fuse.Drawing.HorizontalLineTo.New_4(this, this.EndPosition(), x);
        };

        I.VerticalLineTo = function(y)
        {
            return Fuse.Drawing.VerticalLineTo.New_4(this, this.EndPosition(), y);
        };

        I.CurveTo = function(controlPointStart, controlPointEnd, position)
        {
            return Fuse.Drawing.CurveTo.New_2(this, this.EndPosition(), controlPointStart, controlPointEnd, position);
        };

        I.SmoothCurveTo = function(controlPointEnd, position)
        {
            return Fuse.Drawing.SmoothCurveTo.New_4(this, this.EndPosition(), this.EndTangent(), controlPointEnd, position);
        };

        I.ClosePath = function()
        {
            return Fuse.Drawing.ClosePath.New_2(this, this.EndPosition());
        };

        I.ToPolygon = function(WindingRule, scale)
        {
            return Fuse.Drawing.Polygon.New_2(WindingRule, $DownCast(Fuse.Drawing.ContourEnumerable.New_1(this, scale), 32828));
        };

        I.RemoveLast = function()
        {
            return this._previous;
        };

        I.CalculateBounds = function()
        {
            var pg = this;

            while ((pg != null) && !pg.HasLastBounds())
            {
                pg = pg._previous;
            }

            if (pg == null)
            {
                return Uno.Rect.New_1(0.0, 0.0, 0.0, 0.0);
            }

            var rectUnion = pg.LastBounds();
            pg = pg._previous;

            while (pg != null)
            {
                if (pg.HasLastBounds())
                {
                    rectUnion = Uno.Rect.Union(rectUnion, pg.LastBounds());
                }

                pg = pg._previous;
            }

            return rectUnion;
        };

        I.EvaluateLast = function()
        {
            return $DownCast(Uno.Collections.EmptyEnumerable__float2.New_1(), 32826);
        };

        I.FindStartOfLastContour = function()
        {
            return (this._previous != null) ? this._previous.FindStartOfLastContour() : Uno.Float2.New_2(0.0, 0.0);
        };

        I.ToString = function()
        {
            return Uno.String.op_Addition(Uno.String.op_Addition((this._previous == null) ? "" : this._previous.ToString(), " "), this.Serialize());
        };

        I.Serialize = function()
        {
            return "";
        };

        I._ObjInit = function()
        {
            this._previous = null;
            this._position = Uno.Float2.New_2(0.0, 0.0);
        };

        Fuse.Drawing.PathGeometry.New_1 = function()
        {
            var inst = new Fuse.Drawing.PathGeometry;
            inst._ObjInit();
            return inst;
        };

    });
