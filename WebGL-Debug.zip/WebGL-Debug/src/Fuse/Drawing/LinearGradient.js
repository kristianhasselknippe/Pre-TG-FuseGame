Fuse.Drawing.LinearGradient = $CreateClass(
    function() {
        Fuse.Drawing.DynamicBrush.call(this);
        this._sortedStops = null;
        this._startPoint = new Uno.Float2;
        this._endPoint = new Uno.Float2;
    },
    function(S) {
        var I = S.prototype = new Fuse.Drawing.DynamicBrush;

        I.GetType = function()
        {
            return 724;
        };

        I.SortedStops = function()
        {
            return this._sortedStops;
        };

        I.StartPoint = function(value)
        {
            if (value !== undefined)
            {
                if (Uno.Float2.op_Inequality(this._startPoint, value))
                {
                    this._startPoint.op_Assign(value);
                    this.OnShadingChanged();
                }
            }
            else
            {
                return this._startPoint;
            }
        };

        I.EndPoint = function(value)
        {
            if (value !== undefined)
            {
                if (Uno.Float2.op_Inequality(this._endPoint, value))
                {
                    this._endPoint.op_Assign(value);
                    this.OnShadingChanged();
                }
            }
            else
            {
                return this._endPoint;
            }
        };

    });
