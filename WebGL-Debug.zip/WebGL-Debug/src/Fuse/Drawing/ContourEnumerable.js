Fuse.Drawing.ContourEnumerable = $CreateClass(
    function() {
        this._head = null;
        this._scale = new Uno.Float2;
    },
    function(S) {
        var I = S.prototype;

        I.GetType = function()
        {
            return 751;
        };

        I.$II = function(id)
        {
            return [60].indexOf(id) != -1;
        };

        I.GetEnumerator = function()
        {
            return $DownCast(Fuse.Drawing.ContourEnumerator.New_1(this._head, this._scale), 32874);
        };

        I._ObjInit = function(head, scale)
        {
            this._head = head;
            this._scale.op_Assign(scale);
        };

        Fuse.Drawing.ContourEnumerable.New_1 = function(head, scale)
        {
            var inst = new Fuse.Drawing.ContourEnumerable;
            inst._ObjInit(head, scale);
            return inst;
        };

        I["Uno.Collections.IEnumerable__Fuse_Drawing_Contour.GetEnumerator"] = I.GetEnumerator;

    });
