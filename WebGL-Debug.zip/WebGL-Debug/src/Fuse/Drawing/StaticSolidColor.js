Fuse.Drawing.StaticSolidColor = $CreateClass(
    function() {
        Fuse.Drawing.StaticBrush.call(this);
        this._color = new Uno.Float4;
    },
    function(S) {
        var I = S.prototype = new Fuse.Drawing.StaticBrush;

        I.GetType = function()
        {
            return 726;
        };

        I.Color = function()
        {
            return this._color;
        };

        I._ObjInit_2 = function(color)
        {
            Fuse.Drawing.StaticBrush.prototype._ObjInit_1.call(this);
            this._color.op_Assign(color);
        };

        Fuse.Drawing.StaticSolidColor.New_1 = function(color)
        {
            var inst = new Fuse.Drawing.StaticSolidColor;
            inst._ObjInit_2(color);
            return inst;
        };

    });
