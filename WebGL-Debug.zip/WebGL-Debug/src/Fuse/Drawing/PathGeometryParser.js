Fuse.Drawing.PathGeometryParser = $CreateClass(
    function() {
        this._data = null;
        this._headToken = null;
        this._prevToken = null;
        this._token = null;
        this._head = null;
        this._x = 0;
        this._y = 0;
    },
    function(S) {
        var I = S.prototype;

        I.GetType = function()
        {
            return 756;
        };

        Fuse.Drawing.PathGeometryParser.Deserialize = function(data)
        {
            if (Uno.String.op_Equality(data, null) || (data.length == 0))
            {
                return Fuse.Drawing.PathGeometry.New_1();
            }

            return Fuse.Drawing.PathGeometryParser.New_1(data)._head;
        };

        I.Execute = function(c)
        {
            switch (c)
            {
                case 77:
                {
                    this.MoveTo(0.0, 0.0);
                    break;
                }
                case 67:
                {
                    this.CurveTo(0.0, 0.0);
                    break;
                }
                case 83:
                {
                    this.SmoothCurveTo(0.0, 0.0);
                    break;
                }
                case 90:
                {
                    this.ClosePath();
                    break;
                }
                case 76:
                {
                    this.LineTo(0.0, 0.0);
                    break;
                }
                case 72:
                {
                    this.HLineTo(0.0, 0.0);
                    break;
                }
                case 86:
                {
                    this.VLineTo(0.0, 0.0);
                    break;
                }
                case 109:
                {
                    this.MoveTo(this._x, this._y);
                    break;
                }
                case 99:
                {
                    this.CurveTo(this._x, this._y);
                    break;
                }
                case 115:
                {
                    this.SmoothCurveTo(this._x, this._y);
                    break;
                }
                case 122:
                {
                    this.ClosePath();
                    break;
                }
                case 108:
                {
                    this.LineTo(this._x, this._y);
                    break;
                }
                case 104:
                {
                    this.HLineTo(this._x, this._y);
                    break;
                }
                case 118:
                {
                    this.VLineTo(this._x, this._y);
                    break;
                }
            }
        };

        I.StartNewToken = function(prevLastChar, nextFirstChar, hasAction)
        {
            this._prevToken.Last = prevLastChar;
            this._prevToken = this._prevToken.Next = Fuse.Drawing.Token.New_1(nextFirstChar, hasAction);
        };

        I.CurveTo = function(offsetX, offsetY)
        {
            var x1 = offsetX + this.ReadFloat();
            var y1 = offsetY + this.ReadFloat();
            var x2 = offsetX + this.ReadFloat();
            var y2 = offsetY + this.ReadFloat();
            var x = this._x = offsetX + this.ReadFloat();
            var y = this._y = offsetY + this.ReadFloat();
            this._head = this._head.CurveTo(Uno.Float2.New_2(x1, y1), Uno.Float2.New_2(x2, y2), Uno.Float2.New_2(x, y));
        };

        I.SmoothCurveTo = function(offsetX, offsetY)
        {
            var x2 = offsetX + this.ReadFloat();
            var y2 = offsetY + this.ReadFloat();
            var x = this._x = offsetX + this.ReadFloat();
            var y = this._y = offsetY + this.ReadFloat();
            this._head = this._head.SmoothCurveTo(Uno.Float2.New_2(x2, y2), Uno.Float2.New_2(x, y));
        };

        I.MoveTo = function(offsetX, offsetY)
        {
            var x = this._x = offsetX + this.ReadFloat();
            var y = this._y = offsetY + this.ReadFloat();
            this._head = this._head.MoveTo(x, y);
        };

        I.LineTo = function(offsetX, offsetY)
        {
            var x = this._x = offsetX + this.ReadFloat();
            var y = this._y = offsetY + this.ReadFloat();
            this._head = this._head.LineTo(x, y);
        };

        I.HLineTo = function(offsetX, offsetY)
        {
            var x = this._x = offsetX + this.ReadFloat();
            this._head = this._head.HorizontalLineTo(x);
        };

        I.VLineTo = function(offsetX, offsetY)
        {
            var y = this._y = offsetY + this.ReadFloat();
            this._head = this._head.VerticalLineTo(y);
        };

        I.ClosePath = function()
        {
            this._head = this._head.ClosePath();
        };

        I.ReadFloat = function()
        {
            var str = this._data.Substring(this._token.First, (this._token.Last - this._token.First) + 1);
            var res = Uno.Float.Parse(str);
            this._token = this._token.Next;
            return res;
        };

        I._ObjInit = function(data)
        {
            this._data = data;
            this._headToken = Fuse.Drawing.Token.New_1(-1, false);
            this._prevToken = this._headToken.Next = Fuse.Drawing.Token.New_1(0, false);
            var wasExponent = false;

            for (var i = 0; i < data.length; i++)
            {
                var c = data.charCodeAt(i);

                switch (c)
                {
                    case 0:
                    case 32:
                    case 44:
                    {
                        this.StartNewToken(i - 1, i + 1, false);
                        break;
                    }
                    case 45:
                    {
                        if (!wasExponent)
                        {
                            this.StartNewToken(i - 1, i, false);
                        }

                        break;
                    }
                    case 77:
                    case 67:
                    case 83:
                    case 90:
                    case 76:
                    case 72:
                    case 86:
                    case 109:
                    case 99:
                    case 115:
                    case 122:
                    case 108:
                    case 104:
                    case 118:
                    {
                        this.StartNewToken(i - 1, i, true);
                        this.StartNewToken(i, i + 1, false);
                        break;
                    }
                }

                wasExponent = (c == 101) || (c == 69);
            }

            this._prevToken.Last = data.length - 1;

            for (var token = this._headToken.Next; token != null; )
            {
                var next = token.Next;

                while ((next != null) && ((next.Last - next.First) < 0))
                {
                    next = next.Next;
                }

                token = token.Next = next;
            }

            this._head = Fuse.Drawing.PathGeometry.New_1();
            this._token = this._headToken.Next;

            while (this._token != null)
            {
                if (!this._token.HasAction)
                {
                    this._token = this._token.Next;
                    continue;
                }

                var currentCommand = this._data.charCodeAt(this._token.First);
                this._token = this._token.Next;

                do
                {
                    this.Execute(currentCommand);
                }
                while ((this._token != null) && !this._token.HasAction);
            }
        };

        Fuse.Drawing.PathGeometryParser.New_1 = function(data)
        {
            var inst = new Fuse.Drawing.PathGeometryParser;
            inst._ObjInit(data);
            return inst;
        };

    });
