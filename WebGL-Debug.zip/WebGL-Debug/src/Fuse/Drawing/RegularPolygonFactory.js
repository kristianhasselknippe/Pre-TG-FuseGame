Fuse.Drawing.RegularPolygonFactory = $CreateClass(
    function() {
    },
    function(S) {

        Fuse.Drawing.RegularPolygonFactory.AppendTo = function(self, Sides, Radius, Invert)
        {
            var c_123 = new Uno.Float2;
            var t = ((Invert ? 2 : -2) * 3.14159274) / Sides;
            c_123.op_Assign(self.EndPosition());
            var g = self.MoveTo(c_123.X, c_123.Y - Radius);

            for (var i = 1; i < Sides; i++)
            {
                g = g.LineTo(c_123.X + (Uno.Math.Sin_1(t * i) * Radius), c_123.Y - (Uno.Math.Cos_1(t * i) * Radius));
            }

            g = g.ClosePath();
            return g;
        };

    });
