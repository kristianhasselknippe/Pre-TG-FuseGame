Fuse.Drawing.Tesselation.ActiveRegion = $CreateClass(
    function() {
        this._mesh = null;
        this._upperEdge = null;
        this._upperEdgeDictNode = null;
        this._Sentinel = false;
        this._WindingNumber = 0;
        this._IsInside = false;
        this._IsDirty = false;
        this._fixUpperEdge = false;
    },
    function(S) {
        var I = S.prototype;

        I.GetType = function()
        {
            return 715;
        };

        I.UpperEdge = function(value)
        {
            if (value !== undefined)
            {
                this._upperEdge = value;
            }
            else
            {
                return this._upperEdge;
            }
        };

        I.Sentinel = function(value)
        {
            if (value !== undefined)
            {
                this._Sentinel = value;
            }
            else
            {
                return this._Sentinel;
            }
        };

        I.UpperEdgeDictNode = function(value)
        {
            if (value !== undefined)
            {
                this._upperEdgeDictNode = value;
            }
            else
            {
                return this._upperEdgeDictNode;
            }
        };

        I.WindingNumber = function(value)
        {
            if (value !== undefined)
            {
                this._WindingNumber = value;
            }
            else
            {
                return this._WindingNumber;
            }
        };

        I.IsInside = function(value)
        {
            if (value !== undefined)
            {
                this._IsInside = value;
            }
            else
            {
                return this._IsInside;
            }
        };

        I.IsDirty = function(value)
        {
            if (value !== undefined)
            {
                this._IsDirty = value;
            }
            else
            {
                return this._IsDirty;
            }
        };

        I.fixUpperEdge = function(value)
        {
            if (value !== undefined)
            {
                this._fixUpperEdge = value;
            }
            else
            {
                return this._fixUpperEdge;
            }
        };

        I.TopLeft = function()
        {
            var org = this.UpperEdge().Origin();
            var reg = this;

            do
            {
                reg = reg.Above();
            }
            while (reg.UpperEdge().Origin() == org);

            if (reg.fixUpperEdge())
            {
                var e = this._mesh.Connect(reg.Below().UpperEdge().Sym(), reg.UpperEdge().LeftNext());
                reg.FixUpperEdge(e);
                reg = reg.Above();
            }

            return reg;
        };

        I.TopRight = function()
        {
            var dst = this.UpperEdge().Destination();
            var reg = this;

            do
            {
                reg = reg.Above();
            }
            while (reg.UpperEdge().Destination() == dst);

            return reg;
        };

        I.Below = function()
        {
            return this.UpperEdgeDictNode().Prev().Key();
        };

        I.Above = function()
        {
            return this.UpperEdgeDictNode().Next().Key();
        };

        I.FixUpperEdge = function(newEdge)
        {
            this._mesh.DeleteEdge(this.UpperEdge());
            this.fixUpperEdge(false);
            this.UpperEdge(newEdge);
            newEdge.ActiveRegion(this);
        };

        I.ToString = function()
        {
            return Uno.String.op_Addition(Uno.String.op_Addition_1("Region of ", this.UpperEdge()), this.fixUpperEdge() ? " NEEDS FIX" : "");
        };

        I._ObjInit = function(mesh, upperEdge, sentinel)
        {
            this._mesh = mesh;
            this.UpperEdge(upperEdge);
            this.Sentinel(sentinel);
        };

        Fuse.Drawing.Tesselation.ActiveRegion.New_1 = function(mesh, upperEdge, sentinel)
        {
            var inst = new Fuse.Drawing.Tesselation.ActiveRegion;
            inst._ObjInit(mesh, upperEdge, sentinel);
            return inst;
        };

    });
