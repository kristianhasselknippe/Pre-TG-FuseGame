Fuse.Drawing.Tesselation.HalfEdge = $CreateClass(
    function() {
        this._isFirst = false;
        this._ActiveRegion = null;
        this._Next = null;
        this._Winding = 0;
        this._Sym = null;
        this._Origin = null;
        this._OriginNext = null;
        this._Left = null;
        this._LeftNext = null;
    },
    function(S) {
        var I = S.prototype;

        I.GetType = function()
        {
            return 707;
        };

        I.ActiveRegion = function(value)
        {
            if (value !== undefined)
            {
                this._ActiveRegion = value;
            }
            else
            {
                return this._ActiveRegion;
            }
        };

        I.Next = function(value)
        {
            if (value !== undefined)
            {
                this._Next = value;
            }
            else
            {
                return this._Next;
            }
        };

        I.Winding = function(value)
        {
            if (value !== undefined)
            {
                this._Winding = value;
            }
            else
            {
                return this._Winding;
            }
        };

        I.Sym = function(value)
        {
            if (value !== undefined)
            {
                this._Sym = value;
            }
            else
            {
                return this._Sym;
            }
        };

        I.Origin = function(value)
        {
            if (value !== undefined)
            {
                this._Origin = value;
            }
            else
            {
                return this._Origin;
            }
        };

        I.OriginNext = function(value)
        {
            if (value !== undefined)
            {
                this._OriginNext = value;
            }
            else
            {
                return this._OriginNext;
            }
        };

        I.OriginPrev = function()
        {
            return this.Sym().LeftNext();
        };

        I.Left = function(value)
        {
            if (value !== undefined)
            {
                this._Left = value;
            }
            else
            {
                return this._Left;
            }
        };

        I.LeftNext = function(value)
        {
            if (value !== undefined)
            {
                this._LeftNext = value;
            }
            else
            {
                return this._LeftNext;
            }
        };

        I.LeftPrev = function()
        {
            return this.OriginNext().Sym();
        };

        I.Right = function(value)
        {
            if (value !== undefined)
            {
                this.Sym().Left(value);
            }
            else
            {
                return this.Sym().Left();
            }
        };

        I.RightPrev = function()
        {
            return this.Sym().OriginNext();
        };

        I.Destination = function(value)
        {
            if (value !== undefined)
            {
                this.Sym().Origin(value);
            }
            else
            {
                return this.Sym().Origin();
            }
        };

        I.DestinationNext = function()
        {
            return this.RightPrev().Sym();
        };

        I.GoesLeft = function()
        {
            return this.Destination().VertLeq(this.Origin());
        };

        I.GoesRight = function()
        {
            return this.Origin().VertLeq(this.Destination());
        };

        I.IsBoundaryEdge = function()
        {
            return this.Right().IsInside() != this.Left().IsInside();
        };

        I.Split = function()
        {
            var tempHalfEdge = this.AddEdgeVertex();
            var newEdge = tempHalfEdge.Sym();
            Fuse.Drawing.Tesselation.HalfEdge.ExchangeOriginNextAkaSplice(this.Sym(), this.Sym().OriginPrev());
            Fuse.Drawing.Tesselation.HalfEdge.ExchangeOriginNextAkaSplice(this.Sym(), newEdge);
            this.Destination(newEdge.Origin());
            newEdge.Destination().AnEdge(newEdge.Sym());
            newEdge.Right(this.Right());
            newEdge.Winding(this.Winding());
            newEdge.Sym().Winding(this.Sym().Winding());
            return newEdge;
        };

        I.AddEdgeVertex = function()
        {
            var ind_123;
            var newEdge = Fuse.Drawing.Tesselation.HalfEdge.MakeEdge(this);
            var eNewSym = newEdge.Sym();
            Fuse.Drawing.Tesselation.HalfEdge.ExchangeOriginNextAkaSplice(newEdge, this.LeftNext());
            newEdge.Origin(this.Destination());
            Fuse.Drawing.Tesselation.Vertex.MakeVertex(eNewSym, newEdge.Origin());
            newEdge.Left((ind_123 = this.Left(), eNewSym.Left(ind_123), ind_123));
            return newEdge;
        };

        Fuse.Drawing.Tesselation.HalfEdge.AddWinding = function(eDst, eSrc)
        {
            eDst.Winding(eDst.Winding() + eSrc.Winding());
            eDst.Sym().Winding(eDst.Sym().Winding() + eSrc.Sym().Winding());
        };

        Fuse.Drawing.Tesselation.HalfEdge.MakeEdge = function(eNext)
        {
            var e = Fuse.Drawing.Tesselation.HalfEdge.New_1(true);
            var eSym = Fuse.Drawing.Tesselation.HalfEdge.New_1(false);

            if (eNext.Sym()._isFirst)
            {
                eNext = eNext.Sym();
            }

            var ePrev = eNext.Sym().Next();
            eSym.Next(ePrev);
            ePrev.Sym().Next(e);
            e.Next(eNext);
            eNext.Sym().Next(eSym);
            e.Sym(eSym);
            e.OriginNext(e);
            e.LeftNext(eSym);
            e.Origin(null);
            e.Left(null);
            e.Winding(0);
            e.ActiveRegion(null);
            eSym.Sym(e);
            eSym.OriginNext(eSym);
            eSym.LeftNext(e);
            eSym.Origin(null);
            eSym.Left(null);
            eSym.Winding(0);
            eSym.ActiveRegion(null);
            return e;
        };

        Fuse.Drawing.Tesselation.HalfEdge.ExchangeOriginNextAkaSplice = function(a, b)
        {
            var aOnext = a.OriginNext();
            var bOnext = b.OriginNext();
            aOnext.Sym().LeftNext(b);
            bOnext.Sym().LeftNext(a);
            a.OriginNext(bOnext);
            b.OriginNext(aOnext);
        };

        Fuse.Drawing.Tesselation.HalfEdge.KillEdge = function(eDel)
        {
            if (eDel.Sym()._isFirst)
            {
                eDel = eDel.Sym();
            }

            var eNext = eDel.Next();
            var ePrev = eDel.Sym().Next();
            eNext.Sym().Next(ePrev);
            ePrev.Sym().Next(eNext);
            eDel.Sym().Sym(null);
            eDel.Sym().Next(null);
            eDel.Sym().Origin(null);
            eDel.Sym().OriginNext(null);
            eDel.Sym().Left(null);
            eDel.Sym().LeftNext(null);
            eDel.Sym(null);
            eDel.Next(null);
            eDel.Origin(null);
            eDel.OriginNext(null);
            eDel.Left(null);
            eDel.LeftNext(null);
        };

        I.ToString = function()
        {
            return this.GoesLeft() ? Uno.String.op_Addition_1(Uno.String.op_Addition(Uno.String.op_Addition_1("Left edge ", this.Destination()), " <= "), this.Origin()) : Uno.String.op_Addition_1(Uno.String.op_Addition(Uno.String.op_Addition_1("Right edge ", this.Origin()), " => "), this.Destination());
        };

        I._ObjInit = function(isFirst)
        {
            this._isFirst = isFirst;
        };

        Fuse.Drawing.Tesselation.HalfEdge.New_1 = function(isFirst)
        {
            var inst = new Fuse.Drawing.Tesselation.HalfEdge;
            inst._ObjInit(isFirst);
            return inst;
        };

    });
