Fuse.Drawing.Tesselation.EdgesEnumerable = $CreateClass(
    function() {
        Fuse.Drawing.Tesselation.Collections.LinkedListEnumerable__Fuse_Drawing_Tesselation_HalfEdge.call(this);
        this._head = null;
    },
    function(S) {
        var I = S.prototype = new Fuse.Drawing.Tesselation.Collections.LinkedListEnumerable__Fuse_Drawing_Tesselation_HalfEdge;

        I.GetType = function()
        {
            return 711;
        };

        I.GetNext = function(v)
        {
            return (v.Next() == this._head) ? null : v.Next();
        };

        I._ObjInit_1 = function(head)
        {
            Fuse.Drawing.Tesselation.Collections.LinkedListEnumerable__Fuse_Drawing_Tesselation_HalfEdge.prototype._ObjInit.call(this, (head.Next() == head) ? null : head.Next());
            this._head = head;
        };

        Fuse.Drawing.Tesselation.EdgesEnumerable.New_1 = function(head)
        {
            var inst = new Fuse.Drawing.Tesselation.EdgesEnumerable;
            inst._ObjInit_1(head);
            return inst;
        };

    });
