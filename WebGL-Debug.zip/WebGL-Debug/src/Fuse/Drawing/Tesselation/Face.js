Fuse.Drawing.Tesselation.Face = $CreateClass(
    function() {
        this._prev = null;
        this._anEdge = null;
        this._Next = null;
        this._IsInside = false;
    },
    function(S) {
        var I = S.prototype;

        I.GetType = function()
        {
            return 706;
        };

        I.Next = function(value)
        {
            if (value !== undefined)
            {
                this._Next = value;
            }
            else
            {
                return this._Next;
            }
        };

        I.Prev = function(value)
        {
            if (value !== undefined)
            {
                this._prev = value;
            }
            else
            {
                return this._prev;
            }
        };

        I.AnEdge = function(value)
        {
            if (value !== undefined)
            {
                this._anEdge = value;
            }
            else
            {
                return this._anEdge;
            }
        };

        I.EdgeLoop = function()
        {
            return $DownCast(Fuse.Drawing.Tesselation.EdgeLoopEnumerable.New_1(this.AnEdge()), 32831);
        };

        I.IsInside = function(value)
        {
            if (value !== undefined)
            {
                this._IsInside = value;
            }
            else
            {
                return this._IsInside;
            }
        };

        I.ToContour = function()
        {
            return Fuse.Drawing.Contour.New_2(true, Uno.Collections.EnumerableExtensions.Select__Fuse_Drawing_Tesselation_HalfEdge__float2(this.EdgeLoop(), $CreateDelegate(null, Fuse.Drawing.Tesselation.Face.Coords, 499)));
        };

        Fuse.Drawing.Tesselation.Face.Coords = function(edge)
        {
            return edge.Origin().Coords();
        };

        Fuse.Drawing.Tesselation.Face.MakeFace = function(eOrig, fNext)
        {
            var fNew = Fuse.Drawing.Tesselation.Face.New_1();
            var fPrev = fNext.Prev();
            fNew.Prev(fPrev);
            fPrev.Next(fNew);
            fNew.Next(fNext);
            fNext.Prev(fNew);
            fNew.AnEdge(eOrig);
            fNew.IsInside(fNext.IsInside());
            var e = eOrig;

            do
            {
                e.Left(fNew);
                e = e.LeftNext();
            }
            while (e != eOrig);

            return fNew;
        };

        Fuse.Drawing.Tesselation.Face.KillFace = function(fDel, newLface)
        {
            var eStart = fDel.AnEdge();
            var e = eStart;

            do
            {
                e.Left(newLface);
                e = e.LeftNext();
            }
            while (e != eStart);

            var fPrev = fDel.Prev();
            var fNext = fDel.Next();
            fNext.Prev(fPrev);
            fPrev.Next(fNext);
        };

        I._ObjInit = function()
        {
        };

        Fuse.Drawing.Tesselation.Face.New_1 = function()
        {
            var inst = new Fuse.Drawing.Tesselation.Face;
            inst._ObjInit();
            return inst;
        };

    });
