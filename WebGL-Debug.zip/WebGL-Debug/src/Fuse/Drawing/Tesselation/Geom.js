Fuse.Drawing.Tesselation.Geom = $CreateClass(
    function() {
    },
    function(S) {

        Fuse.Drawing.Tesselation.Geom.EdgeEval = function(u, v, w)
        {
            var gapL = v.S - u.S;
            var gapR = w.S - v.S;
            var gap = gapL + gapR;

            if (gap > 9.9999997473787516e-06)
            {
                if (gapL < gapR)
                {
                    return ((v.T - u.T) + ((u.T - w.T) * (gapL / (gapL + gapR))));
                }
                else
                {
                    return ((v.T - w.T) + ((w.T - u.T) * (gapR / (gapL + gapR))));
                }
            }

            return 0.0;
        };

        Fuse.Drawing.Tesselation.Geom.EdgeSign = function(u, v, w)
        {
            var gapL = v.S - u.S;
            var gapR = w.S - v.S;
            var gap = gapL + gapR;

            if (gap > 9.9999997473787516e-06)
            {
                return (((v.T - w.T) * gapL) + ((v.T - u.T) * gapR));
            }

            return 0.0;
        };

        Fuse.Drawing.Tesselation.Geom.TransLeq = function(u, v)
        {
            return (u.T < v.T) || ((u.T == v.T) && (u.S <= v.S));
        };

        Fuse.Drawing.Tesselation.Geom.TransEval = function(u, v, w)
        {
            var gapL = v.T - u.T;
            var gapR = w.T - v.T;

            if ((gapL + gapR) > 9.9999997473787516e-06)
            {
                if (gapL < gapR)
                {
                    return ((v.S - u.S) + ((u.S - w.S) * (gapL / (gapL + gapR))));
                }
                else
                {
                    return ((v.S - w.S) + ((w.S - u.S) * (gapR / (gapL + gapR))));
                }
            }

            return 0.0;
        };

        Fuse.Drawing.Tesselation.Geom.TransSign = function(u, v, w)
        {
            var gapL = v.T - u.T;
            var gapR = w.T - v.T;

            if ((gapL + gapR) > 9.9999997473787516e-06)
            {
                return (((v.S - w.S) * gapL) + ((v.S - u.S) * gapR));
            }

            return 0.0;
        };

        Fuse.Drawing.Tesselation.Geom.Interpolate = function(ai, x, bi, y)
        {
            var a = Uno.Math.Max(0.0, ai);
            var b = Uno.Math.Max(0.0, bi);
            return (a <= b) ? ((Uno.Math.Abs(b) <= 9.9999997473787516e-06) ? ((x + y) / 2.0) : (x + ((y - x) * (a / (a + b))))) : (y + ((x - y) * (b / (a + b))));
        };

        Fuse.Drawing.Tesselation.Geom.Swap = function(a, b)
        {
            var tmp = a();
            a(b());
            b(tmp);
        };

        Fuse.Drawing.Tesselation.Geom.Intersect = function(o1p, d1p, o2p, d2p)
        {
            var o1 = o1p;
            var d1 = d1p;
            var o2 = o2p;
            var d2 = d2p;
            var v = Fuse.Drawing.Tesselation.Vertex.New_1();
            var z1;
            var z2;

            if (!o1.VertLeq(d1))
            {
                Fuse.Drawing.Tesselation.Geom.Swap($CreateRef(function(){return o1}, function($){o1=$}, this), $CreateRef(function(){return d1}, function($){d1=$}, this));
            }

            if (!o2.VertLeq(d2))
            {
                Fuse.Drawing.Tesselation.Geom.Swap($CreateRef(function(){return o2}, function($){o2=$}, this), $CreateRef(function(){return d2}, function($){d2=$}, this));
            }

            if (!o1.VertLeq(o2))
            {
                Fuse.Drawing.Tesselation.Geom.Swap($CreateRef(function(){return o1}, function($){o1=$}, this), $CreateRef(function(){return o2}, function($){o2=$}, this));
                Fuse.Drawing.Tesselation.Geom.Swap($CreateRef(function(){return d1}, function($){d1=$}, this), $CreateRef(function(){return d2}, function($){d2=$}, this));
            }

            if (!o2.VertLeq(d1))
            {
                v.S = (o2.S + d1.S) / 2.0;
            }
            else if (d1.VertLeq(d2))
            {
                z1 = Fuse.Drawing.Tesselation.Geom.EdgeEval(o1, o2, d1);
                z2 = Fuse.Drawing.Tesselation.Geom.EdgeEval(o2, d1, d2);

                if ((z1 + z2) < 0.0)
                {
                    z1 = -z1;
                    z2 = -z2;
                }

                v.S = Fuse.Drawing.Tesselation.Geom.Interpolate(z1, o2.S, z2, d1.S);
            }
            else
            {
                z1 = Fuse.Drawing.Tesselation.Geom.EdgeSign(o1, o2, d1);
                z2 = -Fuse.Drawing.Tesselation.Geom.EdgeSign(o1, d2, d1);

                if ((z1 + z2) < 0.0)
                {
                    z1 = -z1;
                    z2 = -z2;
                }

                v.S = Fuse.Drawing.Tesselation.Geom.Interpolate(z1, o2.S, z2, d2.S);
            }

            if (!Fuse.Drawing.Tesselation.Geom.TransLeq(o1, d1))
            {
                Fuse.Drawing.Tesselation.Geom.Swap($CreateRef(function(){return o1}, function($){o1=$}, this), $CreateRef(function(){return d1}, function($){d1=$}, this));
            }

            if (!Fuse.Drawing.Tesselation.Geom.TransLeq(o2, d2))
            {
                Fuse.Drawing.Tesselation.Geom.Swap($CreateRef(function(){return o2}, function($){o2=$}, this), $CreateRef(function(){return d2}, function($){d2=$}, this));
            }

            if (!Fuse.Drawing.Tesselation.Geom.TransLeq(o1, o2))
            {
                Fuse.Drawing.Tesselation.Geom.Swap($CreateRef(function(){return o1}, function($){o1=$}, this), $CreateRef(function(){return o2}, function($){o2=$}, this));
                Fuse.Drawing.Tesselation.Geom.Swap($CreateRef(function(){return d1}, function($){d1=$}, this), $CreateRef(function(){return d2}, function($){d2=$}, this));
            }

            if (!Fuse.Drawing.Tesselation.Geom.TransLeq(o2, d1))
            {
                v.T = (o2.T + d1.T) / 2.0;
            }
            else if (Fuse.Drawing.Tesselation.Geom.TransLeq(d1, d2))
            {
                z1 = Fuse.Drawing.Tesselation.Geom.TransEval(o1, o2, d1);
                z2 = Fuse.Drawing.Tesselation.Geom.TransEval(o2, d1, d2);

                if ((z1 + z2) < 0.0)
                {
                    z1 = -z1;
                    z2 = -z2;
                }

                v.T = Fuse.Drawing.Tesselation.Geom.Interpolate(z1, o2.T, z2, d1.T);
            }
            else
            {
                z1 = Fuse.Drawing.Tesselation.Geom.TransSign(o1, o2, d1);
                z2 = -Fuse.Drawing.Tesselation.Geom.TransSign(o1, d2, d1);

                if ((z1 + z2) < 0.0)
                {
                    z1 = -z1;
                    z2 = -z2;
                }

                v.T = Fuse.Drawing.Tesselation.Geom.Interpolate(z1, o2.T, z2, d2.T);
            }

            return v;
        };

    });
