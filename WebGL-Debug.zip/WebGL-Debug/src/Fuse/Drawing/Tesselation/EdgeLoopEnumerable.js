Fuse.Drawing.Tesselation.EdgeLoopEnumerable = $CreateClass(
    function() {
        Fuse.Drawing.Tesselation.Collections.LinkedListEnumerable__Fuse_Drawing_Tesselation_HalfEdge.call(this);
    },
    function(S) {
        var I = S.prototype = new Fuse.Drawing.Tesselation.Collections.LinkedListEnumerable__Fuse_Drawing_Tesselation_HalfEdge;

        I.GetType = function()
        {
            return 705;
        };

        I.GetNext = function(e)
        {
            return (e.LeftNext() == this._first) ? null : e.LeftNext();
        };

        I._ObjInit_1 = function(anEdge)
        {
            Fuse.Drawing.Tesselation.Collections.LinkedListEnumerable__Fuse_Drawing_Tesselation_HalfEdge.prototype._ObjInit.call(this, anEdge);
        };

        Fuse.Drawing.Tesselation.EdgeLoopEnumerable.New_1 = function(anEdge)
        {
            var inst = new Fuse.Drawing.Tesselation.EdgeLoopEnumerable;
            inst._ObjInit_1(anEdge);
            return inst;
        };

    });
