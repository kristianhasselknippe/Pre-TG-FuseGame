Fuse.Drawing.Tesselation.MeshBuilder = $CreateClass(
    function() {
        this._mesh = null;
        this._lastEdge = null;
    },
    function(S) {
        var I = S.prototype;

        I.GetType = function()
        {
            return 712;
        };

        Fuse.Drawing.Tesselation.MeshBuilder.CreateFromContours = function(contours)
        {
            var v_125 = new Uno.Float2;
            var b = Fuse.Drawing.Tesselation.MeshBuilder.New_1();

            for (var enum_123 = contours["Uno.Collections.IEnumerable__Fuse_Drawing_Contour.GetEnumerator"](); enum_123["Uno.Collections.IEnumerator.MoveNext"](); )
            {
                var contour = enum_123["Uno.Collections.IEnumerator__Fuse_Drawing_Contour.Current"]();
                b.NewContour();

                for (var enum_124 = contour.Vertices()["Uno.Collections.IEnumerable__float2.GetEnumerator"](); enum_124["Uno.Collections.IEnumerator.MoveNext"](); )
                {
                    v_125.op_Assign(enum_124["Uno.Collections.IEnumerator__float2.Current"]());
                    b.AddVertex(v_125.X, v_125.Y);
                }
            }

            return b.Complete();
        };

        I.NewContour = function()
        {
            this._lastEdge = null;
        };

        I.AddVertex = function(x, y)
        {
            if ((x != x) || (y != y))
            {
                throw new $Error(Uno.Exception.New_1("Vertex was NaN"));
            }

            var e = (this._lastEdge != null) ? this._lastEdge.Split() : this.CreateSelfLoop();
            e.Origin().S = x;
            e.Origin().T = y;
            e.Winding(1);
            e.Sym().Winding(-1);
            this._lastEdge = e;
        };

        I.CreateSelfLoop = function()
        {
            var e = this._mesh.MakeEdge();
            this._mesh.Splice(e, e.Sym());
            return e;
        };

        I.Complete = function()
        {
            return this._mesh;
        };

        I._ObjInit = function()
        {
            this._mesh = Fuse.Drawing.Tesselation.Mesh.New_1();
        };

        Fuse.Drawing.Tesselation.MeshBuilder.New_1 = function()
        {
            var inst = new Fuse.Drawing.Tesselation.MeshBuilder;
            inst._ObjInit();
            return inst;
        };

    });
