Fuse.Drawing.Tesselation.Vertex = $CreateClass(
    function() {
        this._prev = null;
        this._anEdge = null;
        this.S = 0;
        this.T = 0;
        this._Next = null;
    },
    function(S) {
        var I = S.prototype;

        I.GetType = function()
        {
            return 714;
        };

        I.Next = function(value)
        {
            if (value !== undefined)
            {
                this._Next = value;
            }
            else
            {
                return this._Next;
            }
        };

        I.Prev = function(value)
        {
            if (value !== undefined)
            {
                this._prev = value;
            }
            else
            {
                return this._prev;
            }
        };

        I.AnEdge = function(value)
        {
            if (value !== undefined)
            {
                this._anEdge = value;
            }
            else
            {
                return this._anEdge;
            }
        };

        I.OutgoingEdges = function()
        {
            return $DownCast(Fuse.Drawing.Tesselation.OriginEnumerable.New_1(this.AnEdge()), 32831);
        };

        I.Coords = function()
        {
            return Uno.Float2.New_2(this.S, this.T);
        };

        I.QueueHandle = function()
        {
            return this;
        };

        I.VertEq = function(v)
        {
            return (this.S == v.S) && (this.T == v.T);
        };

        I.VertLeq = function(v)
        {
            return (this.S < v.S) || ((this.S == v.S) && (this.T <= v.T));
        };

        Fuse.Drawing.Tesselation.Vertex.MakeVertex = function(eOrig, vNext)
        {
            var vNew = Fuse.Drawing.Tesselation.Vertex.New_1();
            var vPrev = vNext.Prev();
            vNew.Prev(vPrev);
            vPrev.Next(vNew);
            vNew.Next(vNext);
            vNext.Prev(vNew);
            vNew.AnEdge(eOrig);
            var e = eOrig;

            do
            {
                e.Origin(vNew);
                e = e.OriginNext();
            }
            while (e != eOrig);

            return vNew;
        };

        Fuse.Drawing.Tesselation.Vertex.KillVertex = function(vDel, newOrg)
        {
            var eStart = vDel.AnEdge();
            var e = eStart;

            do
            {
                e.Origin(newOrg);
                e = e.OriginNext();
            }
            while (e != eStart);

            var vPrev = vDel.Prev();
            var vNext = vDel.Next();
            vNext.Prev(vPrev);
            vPrev.Next(vNext);
        };

        I.ToString = function()
        {
            return Uno.String.op_Addition(Uno.String.op_Addition_1(Uno.String.op_Addition(Uno.String.op_Addition_1("[", $CreateBox(this.S, 428)), ", "), $CreateBox(this.T, 428)), "]");
        };

        I._ObjInit = function()
        {
        };

        Fuse.Drawing.Tesselation.Vertex.New_1 = function()
        {
            var inst = new Fuse.Drawing.Tesselation.Vertex;
            inst._ObjInit();
            return inst;
        };

    });
