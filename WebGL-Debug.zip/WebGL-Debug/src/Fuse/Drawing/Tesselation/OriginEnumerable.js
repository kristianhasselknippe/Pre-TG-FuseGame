Fuse.Drawing.Tesselation.OriginEnumerable = $CreateClass(
    function() {
        Fuse.Drawing.Tesselation.Collections.LinkedListEnumerable__Fuse_Drawing_Tesselation_HalfEdge.call(this);
    },
    function(S) {
        var I = S.prototype = new Fuse.Drawing.Tesselation.Collections.LinkedListEnumerable__Fuse_Drawing_Tesselation_HalfEdge;

        I.GetType = function()
        {
            return 713;
        };

        I.GetNext = function(edge)
        {
            return (edge.OriginNext() == this._first) ? null : edge.OriginNext();
        };

        I._ObjInit_1 = function(anEdge)
        {
            Fuse.Drawing.Tesselation.Collections.LinkedListEnumerable__Fuse_Drawing_Tesselation_HalfEdge.prototype._ObjInit.call(this, anEdge);
        };

        Fuse.Drawing.Tesselation.OriginEnumerable.New_1 = function(anEdge)
        {
            var inst = new Fuse.Drawing.Tesselation.OriginEnumerable;
            inst._ObjInit_1(anEdge);
            return inst;
        };

    });
