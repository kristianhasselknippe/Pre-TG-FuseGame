Fuse.Drawing.Tesselation.Sweep = $CreateClass(
    function() {
        this._mesh = null;
        this._isWindingInside = null;
        this._dict = null;
        this._pq = null;
        this._event = null;
    },
    function(S) {
        var I = S.prototype;

        I.GetType = function()
        {
            return 717;
        };

        I.Event = function()
        {
            return this._event;
        };

        I.ComputeInterior = function()
        {
            this.RemoveDegenerateEdges();
            this.InitPriorityQ();
            this.InitEdgeDict();
            var v;

            while ((v = this._pq.Dequeue()) != null)
            {
                for (; ; )
                {
                    var vNext = this._pq.Peek();

                    if ((vNext == null) || !vNext.VertEq(v))
                    {
                        break;
                    }

                    vNext = this._pq.Dequeue();
                    this.SpliceMergeVertices(v.AnEdge(), vNext.AnEdge());
                }

                this.SweepEvent(v);
            }

            this._event = this._dict.Min().Key().UpperEdge().Origin();
            this._dict.CheckInvariants();
            this._mesh.CheckConsistency();
            this.DoneEdgeDict();
            this.RemoveDegenerateFaces();
        };

        I.RemoveDegenerateEdges = function()
        {
            var e;
            var eNext;
            var eHead = this._mesh.EdgesHead;

            for (e = eHead.Next(); e != eHead; e = eNext)
            {
                eNext = e.Next();
                var eLnext = e.LeftNext();

                if (e.Origin().VertEq(e.Destination()) && (e.LeftNext().LeftNext() != e))
                {
                    this.SpliceMergeVertices(eLnext, e);
                    this._mesh.DeleteEdge(e);
                    e = eLnext;
                    eLnext = e.LeftNext();
                }

                if (eLnext.LeftNext() == e)
                {
                    if (eLnext != e)
                    {
                        if ((eLnext == eNext) || (eLnext == eNext.Sym()))
                        {
                            eNext = eNext.Next();
                        }

                        this._mesh.DeleteEdge(eLnext);
                    }

                    if ((e == eNext) || (e == eNext.Sym()))
                    {
                        eNext = eNext.Next();
                    }

                    this._mesh.DeleteEdge(e);
                }
            }

            this._mesh.CheckConsistency();
        };

        I.RemoveDegenerateFaces = function()
        {
            for (var enum_123 = this._mesh.Faces()["Uno.Collections.IEnumerable__Fuse_Drawing_Tesselation_Face.GetEnumerator"](); enum_123["Uno.Collections.IEnumerator.MoveNext"](); )
            {
                var f = enum_123["Uno.Collections.IEnumerator__Fuse_Drawing_Tesselation_Face.Current"]();
                var e = f.AnEdge();

                if (e.LeftNext().LeftNext() == e)
                {
                    Fuse.Drawing.Tesselation.HalfEdge.AddWinding(e.OriginNext(), e);
                    this._mesh.DeleteEdge(e);
                }
            }

            this._mesh.CheckConsistency();
        };

        I.InitPriorityQ = function()
        {
            for (var enum_124 = this._mesh.Vertices()["Uno.Collections.IEnumerable__Fuse_Drawing_Tesselation_Vertex.GetEnumerator"](); enum_124["Uno.Collections.IEnumerator.MoveNext"](); )
            {
                var v = enum_124["Uno.Collections.IEnumerator__Fuse_Drawing_Tesselation_Vertex.Current"]();
                this._pq.Enqueue(v);
            }
        };

        I.InitEdgeDict = function()
        {
            this.AddSentinel(-1000000.0);
            this.AddSentinel(1000000.0);
        };

        I.AddSentinel = function(t)
        {
            var e = this._mesh.MakeEdge();
            e.Origin().S = 1000000.0;
            e.Origin().T = t;
            e.Destination().S = -1000000.0;
            e.Destination().T = t;
            this._event = e.Destination();
            var reg = Fuse.Drawing.Tesselation.ActiveRegion.New_1(this._mesh, e, true);
            reg.UpperEdgeDictNode(this._dict.Insert(reg));
        };

        I.SweepEvent = function(vEvent)
        {
            this._event = vEvent;
            this._dict.CheckInvariants();
            this._mesh.CheckConsistency();
            var e = Uno.Collections.EnumerableExtensions.FirstOrDefault__Fuse_Drawing_Tesselation_HalfEdge(vEvent.OutgoingEdges(), $CreateDelegate(null, Fuse.Drawing.Tesselation.Sweep.HasActiveRegion, 506));

            if (e == null)
            {
                this.ConnectLeftVertex(vEvent);
                return;
            }

            var regUp = e.ActiveRegion().TopLeft();

            if (regUp == null)
            {
                throw new $Error(Uno.Exception.New_1("longjmp(tess.env, 1);"));
            }

            var reg = regUp.Below();
            var eTopLeft = reg.UpperEdge();
            var eBottomLeft = this.FinishLeftRegions(reg, null);

            if (eBottomLeft.OriginNext() == eTopLeft)
            {
                this.ConnectRightVertex(regUp, eBottomLeft);
                this._dict.CheckInvariants();
            }
            else
            {
                this.AddRightEdges(regUp, eBottomLeft.OriginNext(), eTopLeft, eTopLeft, true);
                this._dict.CheckInvariants();
            }
        };

        Fuse.Drawing.Tesselation.Sweep.HasActiveRegion = function(e)
        {
            return e.ActiveRegion() != null;
        };

        I.ConnectLeftVertex = function(vEvent)
        {
            var regUp = this._dict.GetRegionContaining(vEvent);
            var regLo = regUp.Below();
            var eUp = regUp.UpperEdge();
            var eLo = regLo.UpperEdge();

            if (Fuse.Drawing.Tesselation.Geom.EdgeSign(eUp.Destination(), vEvent, eUp.Origin()) == 0.0)
            {
                this.ConnectLeftDegenerate(regUp, vEvent);
                return;
            }

            var reg = eLo.Destination().VertLeq(eUp.Destination()) ? regUp : regLo;

            if (regUp.IsInside() || reg.fixUpperEdge())
            {
                var eNew;

                if (reg == regUp)
                {
                    eNew = this._mesh.Connect(vEvent.AnEdge().Sym(), eUp.LeftNext());
                }
                else
                {
                    var tempHalfEdge = this._mesh.Connect(eLo.DestinationNext(), vEvent.AnEdge());
                    eNew = tempHalfEdge.Sym();
                }

                if (reg.fixUpperEdge())
                {
                    reg.FixUpperEdge(eNew);
                }
                else
                {
                    this.ComputeWinding(this._dict.AddRegionBelow(regUp, eNew));
                }

                this.SweepEvent(vEvent);
            }
            else
            {
                this.AddRightEdges(regUp, vEvent.AnEdge(), vEvent.AnEdge(), null, true);
            }
        };

        I.ConnectLeftDegenerate = function(regUp, vEvent)
        {
            var e = regUp.UpperEdge();

            if (e.Origin().VertEq(vEvent))
            {
                this.SpliceMergeVertices(e, vEvent.AnEdge());
                return;
            }

            if (!e.Destination().VertEq(vEvent))
            {
                this._mesh.SplitEdge(e.Sym());

                if (regUp.fixUpperEdge())
                {
                    this._mesh.DeleteEdge(e.OriginNext());
                    regUp.fixUpperEdge(false);
                }

                this._mesh.Splice(vEvent.AnEdge(), e);
                this.SweepEvent(vEvent);
                return;
            }

            regUp = regUp.TopRight();
            var reg = regUp.Below();
            var eTopRight = reg.UpperEdge().Sym();
            var eTopLeft = eTopRight.OriginNext();
            var eLast = eTopLeft;

            if (reg.fixUpperEdge())
            {
                this.DeleteRegion(reg);
                this._mesh.DeleteEdge(eTopRight);
                eTopRight = eTopLeft.OriginPrev();
            }

            this._mesh.Splice(vEvent.AnEdge(), eTopRight);

            if (!eTopLeft.GoesLeft())
            {
                eTopLeft = null;
            }

            this.AddRightEdges(regUp, eTopRight.OriginNext(), eLast, eTopLeft, true);
        };

        I.SpliceMergeVertices = function(e1, e2)
        {
            this._mesh.Splice(e1, e2);
        };

        I.ConnectRightVertex = function(regUp, eBottomLeft)
        {
            var eTopLeft = eBottomLeft.OriginNext();
            var regLo = regUp.Below();
            var eUp = regUp.UpperEdge();
            var eLo = regLo.UpperEdge();
            var degenerate = false;

            if (eUp.Destination() != eLo.Destination())
            {
                this.CheckForIntersect(regUp);
            }

            if (eUp.Origin().VertEq(this._event))
            {
                this._mesh.Splice(eTopLeft.OriginPrev(), eUp);
                regUp = regUp.TopLeft();

                if (regUp == null)
                {
                    throw new $Error(Uno.Exception.New_1("longjmp(tess.env, 1);"));
                }

                eTopLeft = regUp.Below().UpperEdge();
                this.FinishLeftRegions(regUp.Below(), regLo);
                degenerate = true;
            }

            if (eLo.Origin().VertEq(this._event))
            {
                this._mesh.Splice(eBottomLeft, eLo.OriginPrev());
                eBottomLeft = this.FinishLeftRegions(regLo, null);
                degenerate = true;
            }

            if (degenerate)
            {
                this.AddRightEdges(regUp, eBottomLeft.OriginNext(), eTopLeft, eTopLeft, true);
                return;
            }

            var tmp = eLo.Origin().VertLeq(eUp.Origin()) ? eLo.OriginPrev() : eUp;
            var eNew = this._mesh.Connect(eBottomLeft.LeftPrev(), tmp);
            this.AddRightEdges(regUp, eNew, eNew.OriginNext(), eNew.OriginNext(), false);
            eNew.Sym().ActiveRegion().fixUpperEdge(true);
            this.WalkDirtyRegions(regUp);
        };

        I.WalkDirtyRegions = function(regUp)
        {
            var regLo = regUp.Below();

            while (true)
            {
                while (regLo.IsDirty())
                {
                    regUp = regLo;
                    regLo = regLo.Below();
                }

                if (!regUp.IsDirty())
                {
                    regLo = regUp;
                    regUp = regUp.Above();

                    if ((regUp == null) || !regUp.IsDirty())
                    {
                        return;
                    }
                }

                regUp.IsDirty(false);
                var eUp = regUp.UpperEdge();
                var eLo = regLo.UpperEdge();

                if (eUp.Destination() != eLo.Destination())
                {
                    if (this.CheckForLeftSplice(regUp))
                    {
                        if (regLo.fixUpperEdge())
                        {
                            this.DeleteRegion(regLo);
                            this._mesh.DeleteEdge(eLo);
                            regLo = regUp.Below();
                            eLo = regLo.UpperEdge();
                        }
                        else if (regUp.fixUpperEdge())
                        {
                            this.DeleteRegion(regUp);
                            this._mesh.DeleteEdge(eUp);
                            regUp = regLo.Above();
                            eUp = regUp.UpperEdge();
                        }
                    }
                }

                if (eUp.Origin() != eLo.Origin())
                {
                    if ((((eUp.Destination() != eLo.Destination()) && !regUp.fixUpperEdge()) && !regLo.fixUpperEdge()) && ((eUp.Destination() == this._event) || (eLo.Destination() == this._event)))
                    {
                        if (this.CheckForIntersect(regUp))
                        {
                            return;
                        }
                    }
                    else
                    {
                        this.CheckForRightSplice(regUp);
                    }
                }

                if ((eUp.Origin() == eLo.Origin()) && (eUp.Destination() == eLo.Destination()))
                {
                    Fuse.Drawing.Tesselation.HalfEdge.AddWinding(eLo, eUp);
                    this.DeleteRegion(regUp);
                    this._mesh.DeleteEdge(eUp);
                    regUp = regLo.Above();
                }
            }
        };

        I.CheckForIntersect = function(regUp)
        {
            var ind_125;
            var regLo = regUp.Below();
            var eUp = regUp.UpperEdge();
            var eLo = regLo.UpperEdge();
            var orgUp = eUp.Origin();
            var orgLo = eLo.Origin();
            var dstUp = eUp.Destination();
            var dstLo = eLo.Destination();

            if (orgUp == orgLo)
            {
                return false;
            }

            var tMinUp = Uno.Math.Min(orgUp.T, dstUp.T);
            var tMaxLo = Uno.Math.Max(orgLo.T, dstLo.T);

            if (tMinUp > tMaxLo)
            {
                return false;
            }

            if (orgUp.VertLeq(orgLo))
            {
                if (Fuse.Drawing.Tesselation.Geom.EdgeSign(dstLo, orgUp, orgLo) > 0.0)
                {
                    return false;
                }
            }
            else
            {
                if (Fuse.Drawing.Tesselation.Geom.EdgeSign(dstUp, orgLo, orgUp) < 0.0)
                {
                    return false;
                }
            }

            var isect = Fuse.Drawing.Tesselation.Geom.Intersect(dstUp, orgUp, dstLo, orgLo);

            if (isect.VertLeq(this._event))
            {
                isect.S = this._event.S;
                isect.T = this._event.T;
            }

            var orgMin = orgUp.VertLeq(orgLo) ? orgUp : orgLo;

            if (orgMin.VertLeq(isect))
            {
                isect.S = orgMin.S;
                isect.T = orgMin.T;
            }

            if (isect.VertEq(orgUp) || isect.VertEq(orgLo))
            {
                this.CheckForRightSplice(regUp);
                return false;
            }

            if ((!dstUp.VertEq(this._event) && (Fuse.Drawing.Tesselation.Geom.EdgeSign(dstUp, this._event, isect) >= 0.0)) || (!dstLo.VertEq(this._event) && (Fuse.Drawing.Tesselation.Geom.EdgeSign(dstLo, this._event, isect) <= 0.0)))
            {
                if (dstLo == this._event)
                {
                    this._mesh.SplitEdge(eUp.Sym());
                    this._mesh.Splice(eLo.Sym(), eUp);
                    regUp = regUp.TopLeft();

                    if (regUp == null)
                    {
                        throw new $Error(Uno.Exception.New_1("longjmp(tess.env, 1);"));
                    }

                    eUp = regUp.Below().UpperEdge();
                    this.FinishLeftRegions(regUp.Below(), regLo);
                    this.AddRightEdges(regUp, eUp.OriginPrev(), eUp, eUp, true);
                    return true;
                }

                if (dstUp == this._event)
                {
                    this._mesh.SplitEdge(eLo.Sym());
                    this._mesh.Splice(eUp.LeftNext(), eLo.OriginPrev());
                    regLo = regUp;
                    regUp = regUp.TopRight();
                    var e = regUp.Below().UpperEdge().RightPrev();
                    regLo.UpperEdge(eLo.OriginPrev());
                    eLo = this.FinishLeftRegions(regLo, null);
                    this.AddRightEdges(regUp, eLo.OriginNext(), eUp.RightPrev(), e, true);
                    return true;
                }

                if (Fuse.Drawing.Tesselation.Geom.EdgeSign(dstUp, this._event, isect) >= 0.0)
                {
                    regUp.Above().IsDirty((regUp.IsDirty(true), true));
                    this._mesh.SplitEdge(eUp.Sym());
                    eUp.Origin().S = this._event.S;
                    eUp.Origin().T = this._event.T;
                }

                if (Fuse.Drawing.Tesselation.Geom.EdgeSign(dstLo, this._event, isect) <= 0.0)
                {
                    regUp.IsDirty((regLo.IsDirty(true), true));
                    this._mesh.SplitEdge(eLo.Sym());
                    eLo.Origin().S = this._event.S;
                    eLo.Origin().T = this._event.T;
                }

                return false;
            }

            this._mesh.SplitEdge(eUp.Sym());
            this._mesh.SplitEdge(eLo.Sym());
            this._mesh.Splice(eLo.OriginPrev(), eUp);
            eUp.Origin().S = isect.S;
            eUp.Origin().T = isect.T;
            this._pq.Enqueue(eUp.Origin());
            regUp.Above().IsDirty((ind_125 = (regLo.IsDirty(true), true), regUp.IsDirty(ind_125), ind_125));
            return false;
        };

        I.AddRightEdges = function(regUp, eFirst, eLast, eTopLeft, cleanUp)
        {
            var firstTime = true;
            var re = eFirst;

            do
            {
                this._dict.AddRegionBelow(regUp, re.Sym());
                re = re.OriginNext();
            }
            while (re != eLast);

            if (eTopLeft == null)
            {
                eTopLeft = regUp.Below().UpperEdge().RightPrev();
            }

            var reg = null;
            var e = null;
            var regPrev = regUp;
            var ePrev = eTopLeft;

            for (; ; )
            {
                reg = regPrev.Below();
                e = reg.UpperEdge().Sym();

                if (e.Origin() != ePrev.Origin())
                {
                    break;
                }

                if (e.OriginNext() != ePrev)
                {
                    this._mesh.Splice(e.OriginPrev(), e);
                    this._mesh.Splice(ePrev.OriginPrev(), e);
                }

                reg.WindingNumber(regPrev.WindingNumber() - e.Winding());
                reg.IsInside(this._isWindingInside.Invoke(reg.WindingNumber()));
                regPrev.IsDirty(true);

                if (!firstTime && this.CheckForRightSplice(regPrev))
                {
                    Fuse.Drawing.Tesselation.HalfEdge.AddWinding(e, ePrev);
                    this.DeleteRegion(regPrev);
                    this._mesh.DeleteEdge(ePrev);
                }

                firstTime = false;
                regPrev = reg;
                ePrev = e;
            }

            regPrev.IsDirty(true);

            if (cleanUp)
            {
                this.WalkDirtyRegions(regPrev);
            }
        };

        I.CheckForRightSplice = function(regUp)
        {
            var regLo = regUp.Below();
            var eUp = regUp.UpperEdge();
            var eLo = regLo.UpperEdge();

            if (eUp.Origin().VertLeq(eLo.Origin()))
            {
                if (Fuse.Drawing.Tesselation.Geom.EdgeSign(eLo.Destination(), eUp.Origin(), eLo.Origin()) > 0.0)
                {
                    return false;
                }

                if (!eUp.Origin().VertEq(eLo.Origin()))
                {
                    this._mesh.SplitEdge(eLo.Sym());
                    this._mesh.Splice(eUp, eLo.OriginPrev());
                    regUp.IsDirty((regLo.IsDirty(true), true));
                }
                else if (eUp.Origin() != eLo.Origin())
                {
                    this._pq.Remove(eUp.Origin().QueueHandle());
                    this.SpliceMergeVertices(eLo.OriginPrev(), eUp);
                }
            }
            else
            {
                if (Fuse.Drawing.Tesselation.Geom.EdgeSign(eUp.Destination(), eLo.Origin(), eUp.Origin()) < 0.0)
                {
                    return false;
                }

                regUp.Above().IsDirty((regUp.IsDirty(true), true));
                this._mesh.SplitEdge(eUp.Sym());
                this._mesh.Splice(eLo.OriginPrev(), eUp);
            }

            return true;
        };

        I.CheckForLeftSplice = function(regUp)
        {
            var regLo = regUp.Below();
            var eUp = regUp.UpperEdge();
            var eLo = regLo.UpperEdge();

            if (eUp.Destination().VertLeq(eLo.Destination()))
            {
                if (Fuse.Drawing.Tesselation.Geom.EdgeSign(eUp.Destination(), eLo.Destination(), eUp.Origin()) < 0.0)
                {
                    return false;
                }

                regUp.Above().IsDirty((regUp.IsDirty(true), true));
                var e = eUp.Split();
                this._mesh.Splice(eLo.Sym(), e);
                e.Left().IsInside(regUp.IsInside());
            }
            else
            {
                if (Fuse.Drawing.Tesselation.Geom.EdgeSign(eLo.Destination(), eUp.Destination(), eLo.Origin()) > 0.0)
                {
                    return false;
                }

                regUp.IsDirty((regLo.IsDirty(true), true));
                var e = eLo.Split();
                this._mesh.Splice(eUp.LeftNext(), eLo.Sym());
                e.Right().IsInside(regUp.IsInside());
            }

            return true;
        };

        I.ComputeWinding = function(reg)
        {
            reg.WindingNumber(reg.Above().WindingNumber() + reg.UpperEdge().Winding());
            reg.IsInside(this._isWindingInside.Invoke(reg.WindingNumber()));
        };

        I.FinishLeftRegions = function(regFirst, regLast)
        {
            var regPrev = regFirst;
            var ePrev = regFirst.UpperEdge();

            while (regPrev != regLast)
            {
                regPrev.fixUpperEdge(false);
                var reg = regPrev.Below();
                var e = reg.UpperEdge();

                if (e.Origin() != ePrev.Origin())
                {
                    if (!reg.fixUpperEdge())
                    {
                        this.FinishRegion(regPrev);
                        break;
                    }

                    e = this._mesh.Connect(ePrev.LeftPrev(), e.Sym());
                    reg.FixUpperEdge(e);
                }

                if (ePrev.OriginNext() != e)
                {
                    this._mesh.Splice(e.OriginPrev(), e);
                    this._mesh.Splice(ePrev, e);
                }

                this.FinishRegion(regPrev);
                ePrev = reg.UpperEdge();
                regPrev = reg;
            }

            return ePrev;
        };

        I.FinishRegion = function(reg)
        {
            var e = reg.UpperEdge();
            var f = e.Left();
            f.IsInside(reg.IsInside());
            f.AnEdge(e);
            this.DeleteRegion(reg);
        };

        I.DoneEdgeDict = function()
        {
            var reg;

            while ((reg = this._dict.Min().Key()) != null)
            {
                if (!reg.Sentinel())
                {
                }

                this.DeleteRegion(reg);
            }
        };

        I.DeleteRegion = function(reg)
        {
            if (reg.fixUpperEdge())
            {
            }

            reg.UpperEdge().ActiveRegion(null);
            this._dict.Delete(reg.UpperEdgeDictNode());
        };

        I._ObjInit = function(mesh, windingRule)
        {
            this._mesh = mesh;
            this._isWindingInside = windingRule;
            this._dict = Fuse.Drawing.Tesselation.Collections.ActiveRegionDict.New_1(this, this._mesh);
            this._pq = Fuse.Drawing.Tesselation.Collections.VertexQueue.New_1();
        };

        Fuse.Drawing.Tesselation.Sweep.New_1 = function(mesh, windingRule)
        {
            var inst = new Fuse.Drawing.Tesselation.Sweep;
            inst._ObjInit(mesh, windingRule);
            return inst;
        };

    });
