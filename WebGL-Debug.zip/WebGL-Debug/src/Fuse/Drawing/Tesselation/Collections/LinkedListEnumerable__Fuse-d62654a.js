Fuse.Drawing.Tesselation.Collections.LinkedListEnumerable__Fuse_Drawing_Tesselation_Collections_DictNode_Fuse_Drawing_Tesselation_ActiveRegion_ = $CreateClass(
    function() {
        this._first = null;
    },
    function(S) {
        var I = S.prototype;

        I.GetType = function()
        {
            return 700;
        };

        I._ObjInit = function(first)
        {
            this._first = first;
        };

    });
