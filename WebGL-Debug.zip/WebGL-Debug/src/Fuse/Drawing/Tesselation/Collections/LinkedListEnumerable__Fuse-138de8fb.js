Fuse.Drawing.Tesselation.Collections.LinkedListEnumerable__Fuse_Drawing_Tesselation_Vertex = $CreateClass(
    function() {
        this._first = null;
    },
    function(S) {
        var I = S.prototype;

        I.GetType = function()
        {
            return 698;
        };

        I.$II = function(id)
        {
            return [64].indexOf(id) != -1;
        };

        I.GetEnumerator = function()
        {
            return $DownCast(Fuse.Drawing.Tesselation.Collections.LinkedListEnumerator__Fuse_Drawing_Tesselation_Vertex.New_1(this._first, this), 32877);
        };

        I._ObjInit = function(first)
        {
            this._first = first;
        };

        I["Uno.Collections.IEnumerable__Fuse_Drawing_Tesselation_Vertex.GetEnumerator"] = I.GetEnumerator;

    });
