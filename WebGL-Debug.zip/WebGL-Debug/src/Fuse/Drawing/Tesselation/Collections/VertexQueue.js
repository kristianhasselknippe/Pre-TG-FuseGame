Fuse.Drawing.Tesselation.Collections.VertexQueue = $CreateClass(
    function() {
        Fuse.Drawing.Tesselation.Collections.PriorityQueue__Fuse_Drawing_Tesselation_Vertex.call(this);
    },
    function(S) {
        var I = S.prototype = new Fuse.Drawing.Tesselation.Collections.PriorityQueue__Fuse_Drawing_Tesselation_Vertex;

        I.GetType = function()
        {
            return 693;
        };

        I.Leq_1 = function(a, b)
        {
            return !a.VertLeq(b);
        };

        I._ObjInit_1 = function()
        {
            var collection_123;
            Fuse.Drawing.Tesselation.Collections.PriorityQueue__Fuse_Drawing_Tesselation_Vertex.prototype._ObjInit.call(this, (collection_123 = Fuse.Drawing.Tesselation.Vertex.New_1(), collection_123.S = 3.4028230607370965e+38, collection_123));
        };

        Fuse.Drawing.Tesselation.Collections.VertexQueue.New_1 = function()
        {
            var inst = new Fuse.Drawing.Tesselation.Collections.VertexQueue;
            inst._ObjInit_1();
            return inst;
        };

    });
