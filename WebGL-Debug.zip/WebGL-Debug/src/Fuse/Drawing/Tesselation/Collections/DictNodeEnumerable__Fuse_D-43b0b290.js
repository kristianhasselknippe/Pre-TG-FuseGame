Fuse.Drawing.Tesselation.Collections.DictNodeEnumerable__Fuse_Drawing_Tesselation_ActiveRegion = $CreateClass(
    function() {
        Fuse.Drawing.Tesselation.Collections.LinkedListEnumerable__Fuse_Drawing_Tesselation_Collections_DictNode_Fuse_Drawing_Tesselation_ActiveRegion_.call(this);
        this._head = null;
    },
    function(S) {
        var I = S.prototype = new Fuse.Drawing.Tesselation.Collections.LinkedListEnumerable__Fuse_Drawing_Tesselation_Collections_DictNode_Fuse_Drawing_Tesselation_ActiveRegion_;

        I.GetType = function()
        {
            return 695;
        };

        I._ObjInit_1 = function(head)
        {
            Fuse.Drawing.Tesselation.Collections.LinkedListEnumerable__Fuse_Drawing_Tesselation_Collections_DictNode_Fuse_Drawing_Tesselation_ActiveRegion_.prototype._ObjInit.call(this, head.Next());
            this._head = head;
        };

        Fuse.Drawing.Tesselation.Collections.DictNodeEnumerable__Fuse_Drawing_Tesselation_ActiveRegion.New_1 = function(head)
        {
            var inst = new Fuse.Drawing.Tesselation.Collections.DictNodeEnumerable__Fuse_Drawing_Tesselation_ActiveRegion;
            inst._ObjInit_1(head);
            return inst;
        };

    });
