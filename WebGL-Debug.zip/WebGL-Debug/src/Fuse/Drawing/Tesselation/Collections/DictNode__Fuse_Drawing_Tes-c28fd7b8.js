Fuse.Drawing.Tesselation.Collections.DictNode__Fuse_Drawing_Tesselation_ActiveRegion = $CreateClass(
    function() {
        this._key = null;
        this._prev = null;
        this._Next = null;
    },
    function(S) {
        var I = S.prototype;

        I.GetType = function()
        {
            return 694;
        };

        I.Key = function(value)
        {
            if (value !== undefined)
            {
                this._key = value;
            }
            else
            {
                return this._key;
            }
        };

        I.Next = function(value)
        {
            if (value !== undefined)
            {
                this._Next = value;
            }
            else
            {
                return this._Next;
            }
        };

        I.Prev = function(value)
        {
            if (value !== undefined)
            {
                this._prev = value;
            }
            else
            {
                return this._prev;
            }
        };

        I.InsertBefore = function(key)
        {
            var collection_123;
            collection_123 = Fuse.Drawing.Tesselation.Collections.DictNode__Fuse_Drawing_Tesselation_ActiveRegion.New_1();
            collection_123.Key(key);
            var newNode = collection_123;
            var node = this;
            newNode.Next(node.Next());
            node.Next().Prev(newNode);
            newNode.Prev(node);
            node.Next(newNode);
            return newNode;
        };

        I.Unlink = function()
        {
            this.Prev().Next(this.Next());
            this.Next().Prev(this.Prev());
            this.Next(null);
            this.Prev(null);
        };

        I._ObjInit = function()
        {
            this.Key(null);
            this.Next(this);
            this.Prev(this);
        };

        Fuse.Drawing.Tesselation.Collections.DictNode__Fuse_Drawing_Tesselation_ActiveRegion.New_1 = function()
        {
            var inst = new Fuse.Drawing.Tesselation.Collections.DictNode__Fuse_Drawing_Tesselation_ActiveRegion;
            inst._ObjInit();
            return inst;
        };

    });
