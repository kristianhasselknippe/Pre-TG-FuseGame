Fuse.Drawing.Tesselation.Collections.ActiveRegionDict = $CreateClass(
    function() {
        Fuse.Drawing.Tesselation.Collections.Dict__Fuse_Drawing_Tesselation_ActiveRegion.call(this);
        this._mesh = null;
        this._sweep = null;
    },
    function(S) {
        var I = S.prototype = new Fuse.Drawing.Tesselation.Collections.Dict__Fuse_Drawing_Tesselation_ActiveRegion;

        I.GetType = function()
        {
            return 692;
        };

        I.CheckInvariants = function()
        {
        };

        I.Leq = function(reg1, reg2)
        {
            var e1 = reg1.UpperEdge();
            var e2 = reg2.UpperEdge();
            return this.EdgeLeq(e1, e2);
        };

        I.EdgeLeq = function(e1, e2)
        {
            if (e1.Destination() == this._sweep.Event())
            {
                if (e2.Destination() == this._sweep.Event())
                {
                    if (e1.Origin().VertLeq(e2.Origin()))
                    {
                        return Fuse.Drawing.Tesselation.Geom.EdgeSign(e2.Destination(), e1.Origin(), e2.Origin()) <= 0.0;
                    }
                    else
                    {
                        return Fuse.Drawing.Tesselation.Geom.EdgeSign(e1.Destination(), e2.Origin(), e1.Origin()) >= 0.0;
                    }
                }
                else
                {
                    return Fuse.Drawing.Tesselation.Geom.EdgeSign(e2.Destination(), this._sweep.Event(), e2.Origin()) <= 0.0;
                }
            }

            if (e2.Destination() == this._sweep.Event())
            {
                return Fuse.Drawing.Tesselation.Geom.EdgeSign(e1.Destination(), this._sweep.Event(), e1.Origin()) >= 0.0;
            }

            var t1 = Fuse.Drawing.Tesselation.Geom.EdgeEval(e1.Destination(), this._sweep.Event(), e1.Origin());
            var t2 = Fuse.Drawing.Tesselation.Geom.EdgeEval(e2.Destination(), this._sweep.Event(), e2.Origin());
            return t1 >= t2;
        };

        I.AddRegionBelow = function(regAbove, eNewUp)
        {
            var regNew = Fuse.Drawing.Tesselation.ActiveRegion.New_1(this._mesh, eNewUp, false);
            regNew.UpperEdgeDictNode(this.InsertBefore(regAbove.UpperEdgeDictNode(), regNew));
            eNewUp.ActiveRegion(regNew);
            return regNew;
        };

        I.GetRegionContaining = function(vEvent)
        {
            return this.Search(Fuse.Drawing.Tesselation.ActiveRegion.New_1(this._mesh, vEvent.AnEdge().Sym(), false)).Key();
        };

        I._ObjInit_1 = function(sweep, mesh)
        {
            Fuse.Drawing.Tesselation.Collections.Dict__Fuse_Drawing_Tesselation_ActiveRegion.prototype._ObjInit.call(this);
            this._mesh = mesh;
            this._sweep = sweep;
        };

        Fuse.Drawing.Tesselation.Collections.ActiveRegionDict.New_1 = function(sweep, mesh)
        {
            var inst = new Fuse.Drawing.Tesselation.Collections.ActiveRegionDict;
            inst._ObjInit_1(sweep, mesh);
            return inst;
        };

    });
