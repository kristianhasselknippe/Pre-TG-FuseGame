Fuse.Drawing.Tesselation.Collections.Dict__Fuse_Drawing_Tesselation_ActiveRegion = $CreateClass(
    function() {
        this._head = null;
        this._nodes = null;
    },
    function(S) {
        var I = S.prototype;

        I.GetType = function()
        {
            return 696;
        };

        I.Min = function()
        {
            return this._head.Next();
        };

        I.Search = function(key)
        {
            var node = this._head;

            do
            {
                node = node.Next();
            }
            while ((node.Key() != null) && !this.Leq(key, node.Key()));

            return node;
        };

        I.Insert = function(key)
        {
            return this.InsertBefore(this._head, key);
        };

        I.InsertBefore = function(node, key)
        {
            do
            {
                node = node.Prev();
            }
            while ((node.Key() != null) && !this.Leq(node.Key(), key));

            return node.InsertBefore(key);
        };

        I.Delete = function(node)
        {
            node.Unlink();
        };

        I._ObjInit = function()
        {
            this._head = Fuse.Drawing.Tesselation.Collections.DictNode__Fuse_Drawing_Tesselation_ActiveRegion.New_1();
            this._nodes = Fuse.Drawing.Tesselation.Collections.DictNodeEnumerable__Fuse_Drawing_Tesselation_ActiveRegion.New_1(this._head);
        };

    });
