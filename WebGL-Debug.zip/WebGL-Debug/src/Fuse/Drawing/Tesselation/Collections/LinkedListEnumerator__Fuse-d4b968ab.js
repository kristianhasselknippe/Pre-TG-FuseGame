Fuse.Drawing.Tesselation.Collections.LinkedListEnumerator__Fuse_Drawing_Tesselation_HalfEdge = $CreateClass(
    function() {
        this._enumerable = null;
        this._next = null;
        this._current = null;
    },
    function(S) {
        var I = S.prototype;

        I.GetType = function()
        {
            return 702;
        };

        I.$II = function(id)
        {
            return [108, 418, 54].indexOf(id) != -1;
        };

        I.Current = function()
        {
            return this._current;
        };

        I.Dispose = function()
        {
        };

        I.MoveNext = function()
        {
            if (this._next == null)
            {
                return false;
            }

            this._current = this._next;
            this._next = this._enumerable.GetNext(this._current);
            return true;
        };

        I._ObjInit = function(first, enumerable)
        {
            this._enumerable = enumerable;
            this._current = null;
            this._next = first;
        };

        Fuse.Drawing.Tesselation.Collections.LinkedListEnumerator__Fuse_Drawing_Tesselation_HalfEdge.New_1 = function(first, enumerable)
        {
            var inst = new Fuse.Drawing.Tesselation.Collections.LinkedListEnumerator__Fuse_Drawing_Tesselation_HalfEdge;
            inst._ObjInit(first, enumerable);
            return inst;
        };

        I["Uno.Collections.IEnumerator__Fuse_Drawing_Tesselation_HalfEdge.Current"] = I.Current;
        I["Uno.IDisposable.Dispose"] = I.Dispose;
        I["Uno.Collections.IEnumerator.MoveNext"] = I.MoveNext;

    });
