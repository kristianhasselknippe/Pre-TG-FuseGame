Fuse.Drawing.Tesselation.Collections.LinkedListEnumerable__Fuse_Drawing_Tesselation_Face = $CreateClass(
    function() {
        this._first = null;
    },
    function(S) {
        var I = S.prototype;

        I.GetType = function()
        {
            return 699;
        };

        I.$II = function(id)
        {
            return [65].indexOf(id) != -1;
        };

        I.GetEnumerator = function()
        {
            return $DownCast(Fuse.Drawing.Tesselation.Collections.LinkedListEnumerator__Fuse_Drawing_Tesselation_Face.New_1(this._first, this), 32878);
        };

        I._ObjInit = function(first)
        {
            this._first = first;
        };

        I["Uno.Collections.IEnumerable__Fuse_Drawing_Tesselation_Face.GetEnumerator"] = I.GetEnumerator;

    });
