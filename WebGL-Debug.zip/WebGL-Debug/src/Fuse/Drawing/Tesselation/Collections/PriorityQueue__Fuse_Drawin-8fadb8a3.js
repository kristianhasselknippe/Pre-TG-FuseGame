Fuse.Drawing.Tesselation.Collections.PriorityQueue__Fuse_Drawing_Tesselation_Vertex = $CreateClass(
    function() {
        this._elements = null;
        this._used = 0;
        this._maxValue = null;
    },
    function(S) {
        var I = S.prototype;

        I.GetType = function()
        {
            return 701;
        };

        I.Peek = function()
        {
            return this.IsEmpty() ? null : this._elements[0];
        };

        I.IsEmpty = function()
        {
            return this._used < 1;
        };

        I.Leq = function(ai, bi)
        {
            return this.Leq_1(this._elements[ai], this._elements[bi]);
        };

        I.Enqueue = function(newKey)
        {
            this.EnsureCapacity();
            this._used = this._used + 1;
            this._elements[this._used - 1] = this._maxValue;
            this.HeapIncreaseKey(this._used - 1, newKey);
        };

        I.EnsureCapacity = function()
        {
            if (this._elements.length == this._used)
            {
                var oldElements = this._elements;
                this._elements = Array.Sized(this._elements.length * 2, 714);

                for (var i = 0; i < this._used; i++)
                {
                    this._elements[i] = oldElements[i];
                }
            }
        };

        I.HeapIncreaseKey = function(i, key)
        {
            this._elements[i] = key;

            while ((i > 0) && this.Leq(this.Parent(i), i))
            {
                this.Swap(i, this.Parent(i));
                i = this.Parent(i);
            }
        };

        I.Dequeue = function()
        {
            if (this.IsEmpty())
            {
                return null;
            }

            var max = this._elements[0];
            this.RemoveAt(0);
            return max;
        };

        I.Remove = function(item)
        {
            for (var index = 0; index < this._used; ++index)
            {
                if (item.Equals(this._elements[index]))
                {
                    this.RemoveAt(index);
                    return;
                }
            }

            throw new $Error(Uno.ArgumentException.New_4(Uno.String.op_Addition(Uno.String.op_Addition_1("item ", item), " not found in queue"), "item"));
        };

        I.RemoveAt = function(index)
        {
            this._used--;
            this._elements[index] = this._elements[this._used];
            this._elements[this._used] = null;
            this.MaxHeapify(index);
        };

        I.MaxHeapify = function(i)
        {
            var l = this.Left(i);
            var r = this.Right(i);
            var largest = -1;

            if ((l < this._used) && !this.Leq_1(this._elements[l], this._elements[i]))
            {
                largest = l;
            }
            else
            {
                largest = i;
            }

            if ((r < this._used) && !this.Leq_1(this._elements[r], this._elements[largest]))
            {
                largest = r;
            }

            if (largest != i)
            {
                this.Swap(i, largest);
                this.MaxHeapify(largest);
            }
        };

        I.Swap = function(a, b)
        {
            var tmp = this._elements[a];
            this._elements[a] = this._elements[b];
            this._elements[b] = tmp;
        };

        I.Parent = function(i)
        {
            return (i / 2) | 0;
        };

        I.Left = function(i)
        {
            return 2 * i;
        };

        I.Right = function(i)
        {
            return (2 * i) + 1;
        };

        I._ObjInit = function(maxValue)
        {
            this._maxValue = maxValue;
            this._elements = Array.Sized(256, 714);
            this._used = 0;
        };

    });
