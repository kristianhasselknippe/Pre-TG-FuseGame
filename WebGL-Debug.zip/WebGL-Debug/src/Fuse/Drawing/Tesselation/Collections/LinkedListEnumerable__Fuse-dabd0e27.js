Fuse.Drawing.Tesselation.Collections.LinkedListEnumerable__Fuse_Drawing_Tesselation_HalfEdge = $CreateClass(
    function() {
        this._first = null;
    },
    function(S) {
        var I = S.prototype;

        I.GetType = function()
        {
            return 697;
        };

        I.$II = function(id)
        {
            return [63].indexOf(id) != -1;
        };

        I.GetEnumerator = function()
        {
            return $DownCast(Fuse.Drawing.Tesselation.Collections.LinkedListEnumerator__Fuse_Drawing_Tesselation_HalfEdge.New_1(this._first, this), 32876);
        };

        I._ObjInit = function(first)
        {
            this._first = first;
        };

        I["Uno.Collections.IEnumerable__Fuse_Drawing_Tesselation_HalfEdge.GetEnumerator"] = I.GetEnumerator;

    });
