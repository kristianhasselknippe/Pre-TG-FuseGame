Fuse.Drawing.Tesselation.VerticesEnumerable = $CreateClass(
    function() {
        Fuse.Drawing.Tesselation.Collections.LinkedListEnumerable__Fuse_Drawing_Tesselation_Vertex.call(this);
        this._head = null;
    },
    function(S) {
        var I = S.prototype = new Fuse.Drawing.Tesselation.Collections.LinkedListEnumerable__Fuse_Drawing_Tesselation_Vertex;

        I.GetType = function()
        {
            return 709;
        };

        I.GetNext = function(v)
        {
            return (v.Next() == this._head) ? null : v.Next();
        };

        I._ObjInit_1 = function(head)
        {
            Fuse.Drawing.Tesselation.Collections.LinkedListEnumerable__Fuse_Drawing_Tesselation_Vertex.prototype._ObjInit.call(this, (head.Next() == head) ? null : head.Next());
            this._head = head;
        };

        Fuse.Drawing.Tesselation.VerticesEnumerable.New_1 = function(head)
        {
            var inst = new Fuse.Drawing.Tesselation.VerticesEnumerable;
            inst._ObjInit_1(head);
            return inst;
        };

    });
