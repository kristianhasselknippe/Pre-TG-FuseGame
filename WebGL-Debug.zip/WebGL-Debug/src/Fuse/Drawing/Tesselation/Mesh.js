Fuse.Drawing.Tesselation.Mesh = $CreateClass(
    function() {
        this.VerticesHead = null;
        this.FacesHead = null;
        this.EdgesHead = null;
        this._edgesHeadSym = null;
    },
    function(S) {
        var I = S.prototype;

        I.GetType = function()
        {
            return 708;
        };

        I.Vertices = function()
        {
            return $DownCast(Fuse.Drawing.Tesselation.VerticesEnumerable.New_1(this.VerticesHead), 32832);
        };

        I.Faces = function()
        {
            return $DownCast(Fuse.Drawing.Tesselation.FacesEnumerable.New_1(this.FacesHead), 32833);
        };

        I.InteriorFaces = function()
        {
            return Uno.Collections.EnumerableExtensions.Where__Fuse_Drawing_Tesselation_Face(this.Faces(), $CreateDelegate(this, Fuse.Drawing.Tesselation.Mesh.prototype.IsInside, 505));
        };

        I.Edges = function()
        {
            return $DownCast(Fuse.Drawing.Tesselation.EdgesEnumerable.New_1(this.EdgesHead), 32831);
        };

        I.ComputeInterior = function(windingRule)
        {
            Fuse.Drawing.Tesselation.Sweep.New_1(this, windingRule).ComputeInterior();
        };

        I.TessellateInterior = function()
        {
            for (var enum_123 = this.Faces()["Uno.Collections.IEnumerable__Fuse_Drawing_Tesselation_Face.GetEnumerator"](); enum_123["Uno.Collections.IEnumerator.MoveNext"](); )
            {
                var f = enum_123["Uno.Collections.IEnumerator__Fuse_Drawing_Tesselation_Face.Current"]();

                if (f.IsInside())
                {
                    this.TessellateMonoRegion(f);
                }
            }
        };

        I.TessellateMonoRegion = function(face)
        {
            var up = face.AnEdge();

            while (up.Destination().VertLeq(up.Origin()))
            {
                up = up.LeftPrev();
            }

            while (up.Origin().VertLeq(up.Destination()))
            {
                up = up.LeftNext();
            }

            var lo = up.LeftPrev();

            while (up.LeftNext() != lo)
            {
                if (up.Destination().VertLeq(lo.Origin()))
                {
                    while ((lo.LeftNext() != up) && (lo.LeftNext().GoesLeft() || (Fuse.Drawing.Tesselation.Geom.EdgeSign(lo.Origin(), lo.Destination(), lo.LeftNext().Destination()) <= 0.0)))
                    {
                        lo = this.Connect(lo.LeftNext(), lo).Sym();
                    }

                    lo = lo.LeftPrev();
                }
                else
                {
                    while ((lo.LeftNext() != up) && (up.LeftPrev().GoesRight() || (Fuse.Drawing.Tesselation.Geom.EdgeSign(up.Destination(), up.Origin(), up.LeftPrev().Origin()) >= 0.0)))
                    {
                        up = this.Connect(up, up.LeftPrev()).Sym();
                    }

                    up = up.LeftNext();
                }
            }

            while (lo.LeftNext().LeftNext() != up)
            {
                lo = this.Connect(lo.LeftNext(), lo).Sym();
            }
        };

        I.SetWindingNumber = function(value)
        {
            for (var enum_125 = this.Edges()["Uno.Collections.IEnumerable__Fuse_Drawing_Tesselation_HalfEdge.GetEnumerator"](); enum_125["Uno.Collections.IEnumerator.MoveNext"](); )
            {
                var e = enum_125["Uno.Collections.IEnumerator__Fuse_Drawing_Tesselation_HalfEdge.Current"]();
                e.Winding(e.IsBoundaryEdge() ? (e.Left().IsInside() ? value : -value) : 0);
            }
        };

        I.DeleteInternalEdges = function()
        {
            for (var enum_126 = this.Edges()["Uno.Collections.IEnumerable__Fuse_Drawing_Tesselation_HalfEdge.GetEnumerator"](); enum_126["Uno.Collections.IEnumerator.MoveNext"](); )
            {
                var e = enum_126["Uno.Collections.IEnumerator__Fuse_Drawing_Tesselation_HalfEdge.Current"]();

                if (!e.IsBoundaryEdge())
                {
                    this.DeleteEdge(e);
                }
            }
        };

        I.IsInside = function(face)
        {
            return face.IsInside();
        };

        I.Dispose = function()
        {
            for (var enum_127 = this.Edges()["Uno.Collections.IEnumerable__Fuse_Drawing_Tesselation_HalfEdge.GetEnumerator"](); enum_127["Uno.Collections.IEnumerator.MoveNext"](); )
            {
                var edge = enum_127["Uno.Collections.IEnumerator__Fuse_Drawing_Tesselation_HalfEdge.Current"]();
                Fuse.Drawing.Tesselation.HalfEdge.KillEdge(edge);
            }

            Fuse.Drawing.Tesselation.HalfEdge.KillEdge(this.EdgesHead);
            this.VerticesHead.Next(null);
            this.FacesHead.Next(null);
        };

        I.GetContours = function()
        {
            return Uno.Collections.EnumerableExtensions.Select__Fuse_Drawing_Tesselation_Face__Fuse_Drawing_Contour(this.InteriorFaces(), $CreateDelegate(this, Fuse.Drawing.Tesselation.Mesh.prototype.CreateContour, 500));
        };

        I.CreateContour = function(f)
        {
            return f.ToContour();
        };

        I.MakeEdge = function()
        {
            var e = Fuse.Drawing.Tesselation.HalfEdge.MakeEdge(this.EdgesHead);
            Fuse.Drawing.Tesselation.Vertex.MakeVertex(e, this.VerticesHead);
            Fuse.Drawing.Tesselation.Vertex.MakeVertex(e.Sym(), this.VerticesHead);
            Fuse.Drawing.Tesselation.Face.MakeFace(e, this.FacesHead);
            return e;
        };

        I.CheckConsistency = function()
        {
        };

        I.DeleteEdge = function(eDel)
        {
            if (eDel.Origin() == null)
            {
                throw new $Error(Uno.Exception.New_1(Uno.String.op_Addition_1("eDel.Origin was null", $CopyStruct(eDel.Destination().Coords()))));
            }

            if (eDel.Destination() == null)
            {
                throw new $Error(Uno.Exception.New_1(Uno.String.op_Addition_1("eDel.Destination was null ", $CopyStruct(eDel.Origin().Coords()))));
            }

            var eDelSym = eDel.Sym();
            var joiningLoops = false;

            if (eDel.Left() != eDel.Right())
            {
                joiningLoops = true;
                Fuse.Drawing.Tesselation.Face.KillFace(eDel.Left(), eDel.Right());
            }

            if (eDel.OriginNext() == eDel)
            {
                Fuse.Drawing.Tesselation.Vertex.KillVertex(eDel.Origin(), null);
            }
            else
            {
                eDel.Right().AnEdge(eDel.OriginPrev());
                eDel.Origin().AnEdge(eDel.OriginNext());
                Fuse.Drawing.Tesselation.HalfEdge.ExchangeOriginNextAkaSplice(eDel, eDel.OriginPrev());

                if (!joiningLoops)
                {
                    Fuse.Drawing.Tesselation.Face.MakeFace(eDel, eDel.Left());
                }
            }

            if (eDelSym.OriginNext() == eDelSym)
            {
                Fuse.Drawing.Tesselation.Vertex.KillVertex(eDelSym.Origin(), null);
                Fuse.Drawing.Tesselation.Face.KillFace(eDelSym.Left(), null);
            }
            else
            {
                eDel.Left().AnEdge(eDelSym.OriginPrev());
                eDelSym.Origin().AnEdge(eDelSym.OriginNext());
                Fuse.Drawing.Tesselation.HalfEdge.ExchangeOriginNextAkaSplice(eDelSym, eDelSym.OriginPrev());
            }

            Fuse.Drawing.Tesselation.HalfEdge.KillEdge(eDel);
        };

        I.SplitEdge = function(e)
        {
            return e.Split();
        };

        I.Connect = function(eOrg, eDst)
        {
            var ind_128;
            var joiningLoops = false;
            var eNew = Fuse.Drawing.Tesselation.HalfEdge.MakeEdge(eOrg);
            var eNewSym = eNew.Sym();

            if (eDst.Left() != eOrg.Left())
            {
                joiningLoops = true;
                Fuse.Drawing.Tesselation.Face.KillFace(eDst.Left(), eOrg.Left());
            }

            Fuse.Drawing.Tesselation.HalfEdge.ExchangeOriginNextAkaSplice(eNew, eOrg.LeftNext());
            Fuse.Drawing.Tesselation.HalfEdge.ExchangeOriginNextAkaSplice(eNewSym, eDst);
            eNew.Origin(eOrg.Destination());
            eNewSym.Origin(eDst.Origin());
            eNew.Left((ind_128 = eOrg.Left(), eNewSym.Left(ind_128), ind_128));
            eOrg.Left().AnEdge(eNewSym);

            if (!joiningLoops)
            {
                Fuse.Drawing.Tesselation.Face.MakeFace(eNew, eOrg.Left());
            }

            return eNew;
        };

        I.Splice = function(eOrg, eDst)
        {
            var joiningLoops = false;
            var joiningVertices = false;

            if (eOrg == eDst)
            {
                return;
            }

            if (eDst.Origin() != eOrg.Origin())
            {
                joiningVertices = true;
                Fuse.Drawing.Tesselation.Vertex.KillVertex(eDst.Origin(), eOrg.Origin());
            }

            if (eDst.Left() != eOrg.Left())
            {
                joiningLoops = true;
                Fuse.Drawing.Tesselation.Face.KillFace(eDst.Left(), eOrg.Left());
            }

            Fuse.Drawing.Tesselation.HalfEdge.ExchangeOriginNextAkaSplice(eDst, eOrg);

            if (!joiningVertices)
            {
                Fuse.Drawing.Tesselation.Vertex.MakeVertex(eDst, eOrg.Origin());
                eOrg.Origin().AnEdge(eOrg);
            }

            if (!joiningLoops)
            {
                Fuse.Drawing.Tesselation.Face.MakeFace(eDst, eOrg.Left());
                eOrg.Left().AnEdge(eOrg);
            }
        };

        I._ObjInit = function()
        {
            var ind_129;
            var ind_130;
            this.VerticesHead = Fuse.Drawing.Tesselation.Vertex.New_1();
            this.FacesHead = Fuse.Drawing.Tesselation.Face.New_1();
            this.EdgesHead = Fuse.Drawing.Tesselation.HalfEdge.New_1(true);
            this._edgesHeadSym = Fuse.Drawing.Tesselation.HalfEdge.New_1(false);
            this.VerticesHead.Next((ind_129 = this.VerticesHead, this.VerticesHead.Prev(ind_129), ind_129));
            this.VerticesHead.AnEdge(null);
            this.FacesHead.Next((ind_130 = this.FacesHead, this.FacesHead.Prev(ind_130), ind_130));
            this.FacesHead.AnEdge(null);
            this.FacesHead.IsInside(false);
            this.EdgesHead.Next(this.EdgesHead);
            this.EdgesHead.Sym(this._edgesHeadSym);
            this.EdgesHead.OriginNext(null);
            this.EdgesHead.LeftNext(null);
            this.EdgesHead.Origin(null);
            this.EdgesHead.Left(null);
            this.EdgesHead.Winding(0);
            this.EdgesHead.ActiveRegion(null);
            this._edgesHeadSym.Next(this._edgesHeadSym);
            this._edgesHeadSym.Sym(this.EdgesHead);
            this._edgesHeadSym.OriginNext(null);
            this._edgesHeadSym.LeftNext(null);
            this._edgesHeadSym.Origin(null);
            this._edgesHeadSym.Left(null);
            this._edgesHeadSym.Winding(0);
            this._edgesHeadSym.ActiveRegion(null);
        };

        Fuse.Drawing.Tesselation.Mesh.New_1 = function()
        {
            var inst = new Fuse.Drawing.Tesselation.Mesh;
            inst._ObjInit();
            return inst;
        };

    });
