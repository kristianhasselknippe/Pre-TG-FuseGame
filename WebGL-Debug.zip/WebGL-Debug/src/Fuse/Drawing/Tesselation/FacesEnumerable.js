Fuse.Drawing.Tesselation.FacesEnumerable = $CreateClass(
    function() {
        Fuse.Drawing.Tesselation.Collections.LinkedListEnumerable__Fuse_Drawing_Tesselation_Face.call(this);
        this._head = null;
    },
    function(S) {
        var I = S.prototype = new Fuse.Drawing.Tesselation.Collections.LinkedListEnumerable__Fuse_Drawing_Tesselation_Face;

        I.GetType = function()
        {
            return 710;
        };

        I.GetNext = function(v)
        {
            return (v.Next() == this._head) ? null : v.Next();
        };

        I._ObjInit_1 = function(head)
        {
            Fuse.Drawing.Tesselation.Collections.LinkedListEnumerable__Fuse_Drawing_Tesselation_Face.prototype._ObjInit.call(this, (head.Next() == head) ? null : head.Next());
            this._head = head;
        };

        Fuse.Drawing.Tesselation.FacesEnumerable.New_1 = function(head)
        {
            var inst = new Fuse.Drawing.Tesselation.FacesEnumerable;
            inst._ObjInit_1(head);
            return inst;
        };

    });
