Fuse.Drawing.Cache__Fuse_Drawing_Contour = $CreateClass(
    function() {
        this._source = null;
        this._cache = null;
    },
    function(S) {
        var I = S.prototype;

        I.GetType = function()
        {
            return 771;
        };

        I.Items = function()
        {
            this.Evaluate();
            return $DownCast(Uno.Runtime.Implementation.Internal.ArrayEnumerable__Fuse_Drawing_Contour.New_1(this._cache), 32828);
        };

        I.Length = function()
        {
            this.Evaluate();
            return this._cache.length;
        };

        I.Evaluate = function()
        {
            if (this._cache == null)
            {
                this._cache = Uno.Collections.EnumerableExtensions.ToArray__Fuse_Drawing_Contour(this._source);
                this._source = null;
            }
        };

        I._ObjInit_1 = function(source)
        {
            this._source = source;
        };

        Fuse.Drawing.Cache__Fuse_Drawing_Contour.New_2 = function(source)
        {
            var inst = new Fuse.Drawing.Cache__Fuse_Drawing_Contour;
            inst._ObjInit_1(source);
            return inst;
        };

    });
