Fuse.Drawing.Stroke = $CreateClass(
    function() {
        this._brush = null;
        this._width = 0;
        this._offset = 0;
        this._lineCap = 0;
        this.StrokeChanged = null;
        this.ShadingChanged = null;
    },
    function(S) {
        var I = S.prototype;

        I.GetType = function()
        {
            return 737;
        };

        I.Brush = function(value)
        {
            if (value !== undefined)
            {
                if (value == this._brush)
                {
                    return;
                }

                if ($IsOp(this._brush, 722))
                {
                    $DownCast(this._brush, 722).remove_ShadingChanged($CreateDelegate(this, Fuse.Drawing.Stroke.prototype.OnShadingChanged, 436));
                }

                this._brush = value;

                if ($IsOp(this._brush, 722))
                {
                    $DownCast(this._brush, 722).add_ShadingChanged($CreateDelegate(this, Fuse.Drawing.Stroke.prototype.OnShadingChanged, 436));
                }

                this.OnShadingChanged();
            }
            else
            {
                return this._brush;
            }
        };

        I.Width = function(value)
        {
            if (value !== undefined)
            {
                this._width = value;
                this.OnStrokeChanged();
            }
            else
            {
                return this._width;
            }
        };

        I.Offset = function(value)
        {
            if (value !== undefined)
            {
                this._offset = value;
                this.OnStrokeChanged();
            }
            else
            {
                return this._offset;
            }
        };

        I.LineCap = function(value)
        {
            if (value !== undefined)
            {
                if (value == this._lineCap)
                {
                    return;
                }

                this._lineCap = value;
                this.OnStrokeChanged();
            }
            else
            {
                return this._lineCap;
            }
        };

        I.GetDeviceAdjusted = function(ppi, adjustment, alignment)
        {
            var lo = 0.0;
            var hi = 0.0;

            switch (alignment)
            {
                case 2:
                {
                    lo = Uno.Math.Ceil_1((this._offset - 0.5) * ppi) / ppi;
                    hi = lo + this.Adjust(this._width, ppi, adjustment);
                    break;
                }
                case 1:
                {
                    hi = Uno.Math.Floor_1((this._offset + 0.5) * ppi) / ppi;
                    lo = hi - this.Adjust(this._width, ppi, adjustment);
                    break;
                }
                case 0:
                {
                    lo = Uno.Math.Ceil_1((this._offset - (this._width / 2.0)) * ppi) / ppi;
                    hi = lo + this.Adjust(this._width, ppi, adjustment);
                    break;
                }
            }

            var r = Uno.Float2.New_2(hi - lo, (hi + lo) / 2.0);
            return r;
        };

        I.Adjust = function(w, ppi, adjustment)
        {
            switch (adjustment)
            {
                case 0:
                {
                    return w;
                }
                case 1:
                {
                    w = Uno.Math.Ceil_1(w * ppi) / ppi;
                    break;
                }
                case 2:
                {
                    w = Uno.Math.Floor_1((w * ppi) + 0.5) / ppi;
                    break;
                }
                case 3:
                {
                    w = Uno.Math.Floor_1(w * ppi) / ppi;
                    break;
                }
            }

            w = Uno.Math.Max_1(w, 1.0 / ppi);
            return w;
        };

        I.OnStrokeChanged = function()
        {
            if (Uno.Delegate.op_Inequality(this.StrokeChanged, null))
            {
                this.StrokeChanged.Invoke(this);
            }
        };

        I.OnShadingChanged = function()
        {
            if (Uno.Delegate.op_Inequality(this.ShadingChanged, null))
            {
                this.ShadingChanged.Invoke();
            }
        };

        I._ObjInit = function()
        {
            this._width = 1.0;
        };

        Fuse.Drawing.Stroke.New_1 = function()
        {
            var inst = new Fuse.Drawing.Stroke;
            inst._ObjInit();
            return inst;
        };

        I.add_StrokeChanged = function(value)
        {
            this.StrokeChanged = $DownCast(Uno.Delegate.Combine(this.StrokeChanged, value), 478);
        };

        I.remove_StrokeChanged = function(value)
        {
            this.StrokeChanged = $DownCast(Uno.Delegate.Remove(this.StrokeChanged, value), 478);
        };

        I.add_ShadingChanged = function(value)
        {
            this.ShadingChanged = $DownCast(Uno.Delegate.Combine(this.ShadingChanged, value), 436);
        };

        I.remove_ShadingChanged = function(value)
        {
            this.ShadingChanged = $DownCast(Uno.Delegate.Remove(this.ShadingChanged, value), 436);
        };

    });
