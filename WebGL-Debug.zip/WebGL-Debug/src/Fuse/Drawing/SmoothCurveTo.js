Fuse.Drawing.SmoothCurveTo = $CreateClass(
    function() {
        Fuse.Drawing.CurveTo.call(this);
    },
    function(S) {
        var I = S.prototype = new Fuse.Drawing.CurveTo;

        I.GetType = function()
        {
            return 763;
        };

        I.Serialize = function()
        {
            return Uno.String.op_Addition_1(Uno.String.op_Addition(Uno.String.op_Addition_1(Uno.String.op_Addition(Uno.String.op_Addition_1(Uno.String.op_Addition(Uno.String.op_Addition_1("S ", $CreateBox(this.ControlPointEnd().X, 429)), " "), $CreateBox(this.ControlPointEnd().Y, 429)), " "), $CreateBox(this.EndPosition().X, 429)), " "), $CreateBox(this.EndPosition().Y, 429));
        };

        I._ObjInit_3 = function(prev, lastPosition, lastTangent, controlPointEnd, position)
        {
            var lastPosition_123 = new Uno.Float2;
            var controlPointEnd_125 = new Uno.Float2;
            var position_126 = new Uno.Float2;
            lastPosition_123.op_Assign(lastPosition);
            controlPointEnd_125.op_Assign(controlPointEnd);
            position_126.op_Assign(position);
            Fuse.Drawing.CurveTo.prototype._ObjInit_2.call(this);
            this.CurveToCtor(prev, Uno.Float2.New_2(lastPosition_123.X, lastPosition_123.Y), Uno.Float2.op_Addition(lastPosition_123, lastTangent), Uno.Float2.New_2(controlPointEnd_125.X, controlPointEnd_125.Y), Uno.Float2.New_2(position_126.X, position_126.Y));
        };

        Fuse.Drawing.SmoothCurveTo.New_4 = function(prev, lastPosition, lastTangent, controlPointEnd, position)
        {
            var inst = new Fuse.Drawing.SmoothCurveTo;
            inst._ObjInit_3(prev, lastPosition, lastTangent, controlPointEnd, position);
            return inst;
        };

    });
