Fuse.Drawing.PathGeometryRenderer = $CreateClass(
    function() {
        this._fills = null;
        this._fillRenderer = null;
        this._strokes = null;
        this._strokeRenderers = null;
        this._strokeAdjustment = 0;
        this._strokeAlignment = 0;
        this._geometry = null;
        this._hasBoundsCache = false;
        this._bounds = new Uno.Rect;
        this._innerBounds = new Uno.Rect;
        this._strokePadding = new Uno.Float4;
        this._cachedAntialiasing = 0;
        this._antialiasing = 0;
        this._fillRule = null;
        this._preScale = new Uno.Float2;
        this.VisualInvalidated = null;
    },
    function(S) {
        var I = S.prototype;

        I.GetType = function()
        {
            return 758;
        };

        I.Fill = function(value)
        {
            if (value !== undefined)
            {
                if ((this.HasFills() && (this._fills.Count() == 1)) && (this._fills.Item(0) == value))
                {
                    return;
                }

                this.Fills()["Uno.Collections.ICollection__Fuse_Drawing_Brush.Clear"]();

                if (value != null)
                {
                    this.Fills()["Uno.Collections.ICollection__Fuse_Drawing_Brush.Add"](value);
                }
            }
            else
            {
                return this.HasFills() ? Uno.Collections.EnumerableExtensions.FirstOrDefault__Fuse_Drawing_Brush_1($DownCast(this.Fills(), 32838)) : null;
            }
        };

        I.Fills = function()
        {
            var ind_137;
            return $DownCast((ind_137 = this._fills, (ind_137 != null) ? ind_137 : (this._fills = Uno.Collections.ObservableList__Fuse_Drawing_Brush.New_1($CreateDelegate(this, Fuse.Drawing.PathGeometryRenderer.prototype.OnFillAdded, 482), $CreateDelegate(this, Fuse.Drawing.PathGeometryRenderer.prototype.OnFillRemoved, 482)))), 32918);
        };

        I.HasFills = function()
        {
            return (this._fills != null) && (this._fills.Count() > 0);
        };

        I.Strokes = function()
        {
            var ind_138;
            return $DownCast((ind_138 = this._strokes, (ind_138 != null) ? ind_138 : (this._strokes = Uno.Collections.ObservableList__Fuse_Drawing_Stroke.New_1($CreateDelegate(this, Fuse.Drawing.PathGeometryRenderer.prototype.OnStrokeAdded, 478), $CreateDelegate(this, Fuse.Drawing.PathGeometryRenderer.prototype.OnStrokeRemoved, 478)))), 32919);
        };

        I.HasStrokes = function()
        {
            return (this._strokes != null) && (this._strokes.Count() > 0);
        };

        I.Geometry = function(value)
        {
            if (value !== undefined)
            {
                if (value == null)
                {
                    throw new $Error(Uno.ArgumentNullException.New_5("value"));
                }

                if (value == this._geometry)
                {
                    return;
                }

                this._geometry = value;
                this.GeometryChanged(this._geometry);
            }
            else
            {
                return this._geometry;
            }
        };

        I.Bounds = function()
        {
            this.CalcBounds();
            return this._bounds;
        };

        I.InnerBounds = function()
        {
            this.CalcBounds();
            return this._innerBounds;
        };

        I.StrokePadding = function()
        {
            this.CalcBounds();
            return this._strokePadding;
        };

        I.Antialiasing = function(value)
        {
            if (value !== undefined)
            {
                if (value == this._antialiasing)
                {
                    return;
                }

                this._antialiasing = value;
                this.InvalidateVisual();
            }
            else
            {
                return this._antialiasing;
            }
        };

        I.FillRule = function(value)
        {
            if (value !== undefined)
            {
                if (Uno.Delegate.op_Equality(value, this._fillRule))
                {
                    return;
                }

                this._fillRule = value;
                this.InvalidateStrokeAndFill();
            }
            else
            {
                return this._fillRule;
            }
        };

        I.PreScale = function(value)
        {
            if (value !== undefined)
            {
                if (Uno.Float2.op_Inequality(this._preScale, value))
                {
                    this._preScale.op_Assign(value);
                    this.InvalidateStrokeAndFill();
                }
            }
            else
            {
                return this._preScale;
            }
        };

        I.OnFillAdded = function(f)
        {
            if ($IsOp(f, 722))
            {
                $DownCast(f, 722).add_ShadingChanged($CreateDelegate(this, Fuse.Drawing.PathGeometryRenderer.prototype.OnShadingChanged, 436));
            }

            this.OnShadingChanged();
        };

        I.OnFillRemoved = function(f)
        {
            if ($IsOp(f, 722))
            {
                $DownCast(f, 722).remove_ShadingChanged($CreateDelegate(this, Fuse.Drawing.PathGeometryRenderer.prototype.OnShadingChanged, 436));
            }

            this.OnShadingChanged();
        };

        I.DrawFills = function(ctx)
        {
            if (this.HasFills())
            {
                this.EnsureFillRenderer();

                for (var i = 0; i < this._fills.Count(); i++)
                {
                    this._fillRenderer.Draw_1(this._fills.Item(i), ctx);
                }
            }
        };

        I.EnsureFillRenderer = function()
        {
            var ind_136;
            this._fillRenderer = (ind_136 = this._fillRenderer, (ind_136 != null) ? ind_136 : Fuse.Drawing.PolygonFiller.New_1(this._geometry.ToPolygon(this._fillRule, this._preScale), this._antialiasing, Fuse.Environment.ScreenPPIZoomMultiplier()));
        };

        I.OnStrokeAdded = function(s)
        {
            s.add_ShadingChanged($CreateDelegate(this, Fuse.Drawing.PathGeometryRenderer.prototype.OnShadingChanged, 436));
            s.add_StrokeChanged($CreateDelegate(this, Fuse.Drawing.PathGeometryRenderer.prototype.OnStrokeChanged, 478));
            this.OnStrokeChanged(s);
        };

        I.OnStrokeRemoved = function(s)
        {
            s.remove_ShadingChanged($CreateDelegate(this, Fuse.Drawing.PathGeometryRenderer.prototype.OnShadingChanged, 436));
            s.remove_StrokeChanged($CreateDelegate(this, Fuse.Drawing.PathGeometryRenderer.prototype.OnStrokeChanged, 478));
            this.OnStrokeChanged(s);
        };

        I.EnsureStrokeRenderers = function()
        {
            if (this._strokeRenderers == null)
            {
                this._strokeRenderers = Uno.Collections.Dictionary__Fuse_Drawing_Stroke__Fuse_Drawing_PolygonFiller.New_1();
            }
        };

        I.OnStrokeChanged = function(s)
        {
            if (this._strokeRenderers != null)
            {
                var strokeRenderer = null;

                if (this._strokeRenderers.TryGetValue(s, $CreateRef(function(){return strokeRenderer}, function($){strokeRenderer=$}, this)))
                {
                    strokeRenderer.Dispose();
                    this._strokeRenderers.Remove(s);
                }
            }

            this.InvalidateVisual();
        };

        I.DrawStrokes = function(ctx)
        {
            if (this.HasStrokes())
            {
                this.CompleteStrokeRenderers();

                for (var enum_123 = this.Strokes()["Uno.Collections.IEnumerable__Fuse_Drawing_Stroke.GetEnumerator"](); enum_123["Uno.Collections.IEnumerator.MoveNext"](); )
                {
                    var s = enum_123["Uno.Collections.IEnumerator__Fuse_Drawing_Stroke.Current"]();
                    this._strokeRenderers.Item(s).Draw_1(s.Brush(), ctx);
                }
            }
        };

        I.CompleteStrokeRenderers = function()
        {
            if (!this.HasStrokes())
            {
                return;
            }

            this.EnsureStrokeRenderers();

            for (var enum_124 = this.Strokes()["Uno.Collections.IEnumerable__Fuse_Drawing_Stroke.GetEnumerator"](); enum_124["Uno.Collections.IEnumerator.MoveNext"](); )
            {
                var s = enum_124["Uno.Collections.IEnumerator__Fuse_Drawing_Stroke.Current"]();
                var strokeRenderer;

                if (!this._strokeRenderers.TryGetValue(s, $CreateRef(function(){return strokeRenderer}, function($){strokeRenderer=$}, this)))
                {
                    var widthOffset = s.GetDeviceAdjusted(Fuse.Environment.ScreenDensity(), this._strokeAdjustment, this._strokeAlignment);
                    var strokePolygon = this._geometry.ToPolygon(this._fillRule, this._preScale).Stroke(Uno.Math.Max_1(0.0, widthOffset.Item(0)), widthOffset.Item(1), s.LineCap(), s.LineCap());
                    this._strokeRenderers.Item(s, strokeRenderer = Fuse.Drawing.PolygonFiller.New_1(strokePolygon, this._antialiasing, Fuse.Environment.ScreenPPIZoomMultiplier()));
                }
            }
        };

        I.CalcBounds = function()
        {
            var scaled_128 = new Uno.Rect;
            var r_129 = new Uno.Rect;
            var c_130 = new Uno.Rect;

            if (this._hasBoundsCache)
            {
                return;
            }

            this._innerBounds.op_Assign(this._geometry.Bounds());
            scaled_128.op_Assign(this._innerBounds);
            scaled_128.Left = scaled_128.Left * this._preScale.X;
            scaled_128.Top = scaled_128.Top * this._preScale.Y;
            scaled_128.Right = scaled_128.Right * this._preScale.X;
            scaled_128.Bottom = scaled_128.Bottom * this._preScale.Y;
            this._bounds.op_Assign(scaled_128);
            this._strokePadding = Uno.Float4.New_1(0.0);

            if (this.HasStrokes())
            {
                this.UpdateAa();
                this.CompleteStrokeRenderers();
                r_129.op_Assign(scaled_128);

                for (var enum_125 = this._strokeRenderers.Values().GetEnumerator(); enum_125.MoveNext(); )
                {
                    var s = enum_125.Current();
                    c_130.op_Assign(s.Bounds());
                    r_129 = Uno.Rect.Union(r_129, c_130);
                }

                var diffMin = Uno.Float2.op_Subtraction(this._bounds.Minimum(), r_129.Minimum());
                var diffMax = Uno.Float2.op_Subtraction(r_129.Maximum(), this._bounds.Maximum());
                this._strokePadding = Uno.Float4.New_2(diffMin.X, diffMin.Y, diffMax.X, diffMax.Y);
                this._strokePadding = Uno.Math.Max_7(this._strokePadding, Uno.Float4.New_1(0.0));
                this._bounds.op_Assign(r_129);
            }

            this._hasBoundsCache = true;
        };

        I.GeometryChanged = function(geom)
        {
            this.InvalidateStrokeAndFill();
        };

        I.OnShadingChanged = function()
        {
            this.InvalidateVisual();
        };

        I.UpdateAa = function()
        {
            if (this._cachedAntialiasing == this.Antialiasing())
            {
                return;
            }

            this._cachedAntialiasing = this.Antialiasing();
            this.InvalidateStrokeAndFill();
        };

        I.InvalidateStrokeAndFill = function()
        {
            this._hasBoundsCache = false;

            if (this.HasStrokes())
            {
                for (var i = 0; i < this.Strokes()["Uno.Collections.ICollection__Fuse_Drawing_Stroke.Count"](); i++)
                {
                    this.OnStrokeChanged(this.Strokes()["Uno.Collections.IList__Fuse_Drawing_Stroke.Item"](i));
                }
            }

            if (this._fillRenderer != null)
            {
                this._fillRenderer.Dispose();
                this._fillRenderer = null;
            }

            this.InvalidateVisual();
        };

        I.InvalidateVisual = function()
        {
            if (Uno.Delegate.op_Inequality(this.VisualInvalidated, null))
            {
                this.VisualInvalidated.Invoke();
            }
        };

        I.GetHitPart = function(p)
        {
            var stroke_132 = new Uno.Collections.KeyValuePair__Fuse_Drawing_Stroke__Fuse_Drawing_PolygonFiller;
            this.UpdateAa();

            if (this.HasStrokes())
            {
                this.CompleteStrokeRenderers();

                for (var enum_126 = this._strokeRenderers.GetEnumerator(); enum_126.MoveNext(); )
                {
                    stroke_132.op_Assign(enum_126.Current());

                    if (stroke_132.Value().Intersects(p))
                    {
                        return stroke_132.Key();
                    }
                }
            }

            if (this.HasFills())
            {
                this.EnsureFillRenderer();

                if (this._fillRenderer.Intersects(p))
                {
                    return this.Fill();
                }
            }

            return null;
        };

        I.Draw = function(transform, elementSize)
        {
            this.Draw_1(Fuse.Drawing.RendererContext.New_2(transform, elementSize));
        };

        I.Draw_1 = function(ctx)
        {
            this.UpdateAa();
            this.DrawFills(ctx);
            this.DrawStrokes(ctx);
        };

        I.SoftDispose = function()
        {
            if (this._fillRenderer != null)
            {
                this._fillRenderer.Dispose();
                this._fillRenderer = null;
            }

            if (this._strokeRenderers != null)
            {
                for (var enum_127 = this.Strokes()["Uno.Collections.IEnumerable__Fuse_Drawing_Stroke.GetEnumerator"](); enum_127["Uno.Collections.IEnumerator.MoveNext"](); )
                {
                    var s = enum_127["Uno.Collections.IEnumerator__Fuse_Drawing_Stroke.Current"]();
                    var strokeRenderer = null;

                    if (this._strokeRenderers.TryGetValue(s, $CreateRef(function(){return strokeRenderer}, function($){strokeRenderer=$}, this)))
                    {
                        strokeRenderer.Dispose();
                    }
                }

                this._strokeRenderers.Clear();
                this._strokeRenderers = null;
            }
        };

        I._ObjInit = function()
        {
            this._strokeAdjustment = 2;
            this._strokeAlignment = 1;
            this._geometry = Fuse.Drawing.PathGeometry.New_1();
            this._antialiasing = 1;
            this._fillRule = $CreateDelegate(null, Fuse.Drawing.WindingRules.NonZero, 503);
            this._preScale = Uno.Float2.New_1(1.0);
        };

        Fuse.Drawing.PathGeometryRenderer.New_1 = function()
        {
            var inst = new Fuse.Drawing.PathGeometryRenderer;
            inst._ObjInit();
            return inst;
        };

        I.add_VisualInvalidated = function(value)
        {
            this.VisualInvalidated = $DownCast(Uno.Delegate.Combine(this.VisualInvalidated, value), 436);
        };

    });
