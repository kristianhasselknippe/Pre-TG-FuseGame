Fuse.Drawing.LineCapImpl = $CreateClass(
    function() {
    },
    function(S) {
        var I = S.prototype;

        I.GetType = function()
        {
            return 743;
        };

        Fuse.Drawing.LineCapImpl.Create_1 = function(lineCap)
        {
            switch (lineCap)
            {
                case 0:
                {
                    return Fuse.Drawing.ButtCap.New_1();
                }
                case 1:
                {
                    return Fuse.Drawing.RoundCap.New_1();
                }
            }

            throw new $Error(Uno.NotImplementedException.New_3());
        };

        I._ObjInit = function()
        {
        };

    });
