Fuse.Drawing.EllipseFactory = $CreateClass(
    function() {
    },
    function(S) {

        Fuse.Drawing.EllipseFactory.AppendTo = function(self, Radius, Invert)
        {
            var Radius_123 = new Uno.Float2;
            var o_124 = new Uno.Float2;
            var tmp_125 = new Uno.Float2;
            Radius_123.op_Assign(Radius);
            o_124.op_Assign(self.EndPosition());
            var n = Uno.Float2.New_2(0.0, -Radius_123.Y);
            var s = Uno.Float2.New_2(0.0, Radius_123.Y);
            var w = Uno.Float2.New_2(-Radius_123.X, 0.0);
            var e = Uno.Float2.New_2(Radius_123.X, 0.0);

            if (Invert)
            {
                tmp_125.op_Assign(n);
                n.op_Assign(s);
                s.op_Assign(tmp_125);
            }

            var p = 0.55;
            return self.MoveTo_1(Uno.Float2.op_Addition(o_124, w)).CurveTo(Uno.Float2.op_Addition(Uno.Float2.op_Addition(o_124, w), Uno.Float2.op_Multiply(s, p)), Uno.Float2.op_Addition(Uno.Float2.op_Addition(o_124, s), Uno.Float2.op_Multiply(w, p)), Uno.Float2.op_Addition(o_124, s)).CurveTo(Uno.Float2.op_Addition(Uno.Float2.op_Addition(o_124, s), Uno.Float2.op_Multiply(e, p)), Uno.Float2.op_Addition(Uno.Float2.op_Addition(o_124, e), Uno.Float2.op_Multiply(s, p)), Uno.Float2.op_Addition(o_124, e)).CurveTo(Uno.Float2.op_Addition(Uno.Float2.op_Addition(o_124, e), Uno.Float2.op_Multiply(n, p)), Uno.Float2.op_Addition(Uno.Float2.op_Addition(o_124, n), Uno.Float2.op_Multiply(e, p)), Uno.Float2.op_Addition(o_124, n)).CurveTo(Uno.Float2.op_Addition(Uno.Float2.op_Addition(o_124, n), Uno.Float2.op_Multiply(w, p)), Uno.Float2.op_Addition(Uno.Float2.op_Addition(o_124, w), Uno.Float2.op_Multiply(n, p)), Uno.Float2.op_Addition(o_124, w)).ClosePath().MoveTo_1(o_124);
        };

    });
