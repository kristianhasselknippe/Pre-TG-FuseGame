Fuse.Drawing.Brush = $CreateClass(
    function() {
    },
    function(S) {
        var I = S.prototype;

        I.GetType = function()
        {
            return 720;
        };

        I._ObjInit = function()
        {
        };

    });
