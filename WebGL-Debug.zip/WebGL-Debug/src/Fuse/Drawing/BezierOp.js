Fuse.Drawing.BezierOp = $CreateClass(
    function() {
    },
    function(S) {

        Fuse.Drawing.BezierOp.bezierSpline = function(p0, p1, p2, p3, t)
        {
            return ((((((p3 - (3.0 * p2)) + (3.0 * p1)) - p0) * Uno.Math.Pow(t, 3.0)) + ((((3.0 * p2) - (6.0 * p1)) + (3.0 * p0)) * Uno.Math.Pow(t, 2.0))) + (((3.0 * p1) - (3.0 * p0)) * t)) + p0;
        };

        Fuse.Drawing.BezierOp.A = function(p0, p1, p2, p3)
        {
            return (((3.0 * p3) - (9.0 * p2)) + (9.0 * p1)) - (3.0 * p0);
        };

        Fuse.Drawing.BezierOp.B = function(p0, p1, p2)
        {
            return ((6.0 * p2) - (12.0 * p1)) + (6.0 * p0);
        };

        Fuse.Drawing.BezierOp.C = function(p0, p1)
        {
            return (3.0 * p1) - (3.0 * p0);
        };

        Fuse.Drawing.BezierOp.Determinant = function(a, b, c)
        {
            return Uno.Math.Pow(b, 2.0) - ((4.0 * a) * c);
        };

        Fuse.Drawing.BezierOp._Solve = function(a_, b_, c_, s)
        {
            return (-b_ + (Uno.Math.Sqrt((b_ * b_) - ((4.0 * a_) * c_)) * (s ? 1 : -1))) / (2.0 * a_);
        };

        Fuse.Drawing.BezierOp.Solve = function(a, b, c)
        {
            var d = Fuse.Drawing.BezierOp.Determinant(a, b, c);

            if (d < 0.0)
            {
                return Array.Init([], 428);
            }

            if (Uno.Math.Abs(a) < 9.9999997473787516e-06)
            {
                if (Uno.Math.Abs(b) < 9.9999997473787516e-06)
                {
                    return Array.Init([], 428);
                }

                return Array.Init([-c / b], 428);
            }

            if (d == 0.0)
            {
                return Array.Init([Fuse.Drawing.BezierOp._Solve(a, b, c, true)], 428);
            }
            else
            {
                return Array.Init([Fuse.Drawing.BezierOp._Solve(a, b, c, true), Fuse.Drawing.BezierOp._Solve(a, b, c, false)], 428);
            }
        };

        Fuse.Drawing.BezierOp.GetRect = function(p1, c1, c2, p2)
        {
            var p1_129 = new Uno.Float2;
            var c1_130 = new Uno.Float2;
            var c2_131 = new Uno.Float2;
            var p2_132 = new Uno.Float2;
            p1_129.op_Assign(p1);
            c1_130.op_Assign(c1);
            c2_131.op_Assign(c2);
            p2_132.op_Assign(p2);
            var aX = Fuse.Drawing.BezierOp.A(p1_129.X, c1_130.X, c2_131.X, p2_132.X);
            var bX = Fuse.Drawing.BezierOp.B(p1_129.X, c1_130.X, c2_131.X);
            var cX = Fuse.Drawing.BezierOp.C(p1_129.X, c1_130.X);
            var aY = Fuse.Drawing.BezierOp.A(p1_129.Y, c1_130.Y, c2_131.Y, p2_132.Y);
            var bY = Fuse.Drawing.BezierOp.B(p1_129.Y, c1_130.Y, c2_131.Y);
            var cY = Fuse.Drawing.BezierOp.C(p1_129.Y, c1_130.Y);
            var resX = Fuse.Drawing.BezierOp.Solve(aX, bX, cX);
            var resY = Fuse.Drawing.BezierOp.Solve(aY, bY, cY);
            var min = Uno.Math.Min_3(p1_129, p2_132);
            var max = Uno.Math.Max_3(p1_129, p2_132);

            for (var index_124 = 0, length_125 = resX.length; index_124 < length_125; ++index_124)
            {
                var e = resX[index_124];

                if ((e < 0.0) || (e > 1.0))
                {
                    continue;
                }

                var x = Fuse.Drawing.BezierOp.bezierSpline(p1_129.X, c1_130.X, c2_131.X, p2_132.X, e);
                min.X = Uno.Math.Min_1(min.X, x);
                max.X = Uno.Math.Max_1(max.X, x);
            }

            for (var index_127 = 0, length_128 = resY.length; index_127 < length_128; ++index_127)
            {
                var e = resY[index_127];

                if ((e < 0.0) || (e > 1.0))
                {
                    continue;
                }

                var y = Fuse.Drawing.BezierOp.bezierSpline(p1_129.Y, c1_130.Y, c2_131.Y, p2_132.Y, e);
                min.Y = Uno.Math.Min_1(min.Y, y);
                max.Y = Uno.Math.Max_1(max.Y, y);
            }

            return Uno.Rect.New_1(min.X, min.Y, max.X, max.Y);
        };

    });
