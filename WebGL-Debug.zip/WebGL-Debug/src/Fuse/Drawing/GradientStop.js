Fuse.Drawing.GradientStop = $CreateClass(
    function() {
        this._offset = 0;
        this._color = new Uno.Float4;
        this.Changed = null;
    },
    function(S) {
        var I = S.prototype;

        I.GetType = function()
        {
            return 723;
        };

        I.Offset = function(value)
        {
            if (value !== undefined)
            {
                if (this._offset != value)
                {
                    this._offset = value;
                    this.OnChanged();
                }
            }
            else
            {
                return this._offset;
            }
        };

        I.Color = function(value)
        {
            if (value !== undefined)
            {
                if (Uno.Float4.op_Inequality(this._color, value))
                {
                    this._color.op_Assign(value);
                    this.OnChanged();
                }
            }
            else
            {
                return this._color;
            }
        };

        I.OnChanged = function()
        {
            if (Uno.Delegate.op_Inequality(this.Changed, null))
            {
                this.Changed.Invoke();
            }
        };

    });
