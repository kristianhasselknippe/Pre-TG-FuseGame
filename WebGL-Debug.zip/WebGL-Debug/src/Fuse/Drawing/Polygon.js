Fuse.Drawing.Polygon = $CreateClass(
    function() {
        this._windingRule = null;
        this._contours = null;
        this._boundaryContours = null;
    },
    function(S) {
        var I = S.prototype;

        I.GetType = function()
        {
            return 746;
        };

        I.Contours = function()
        {
            return this._contours.Items();
        };

        I.IsDegenerate = function()
        {
            return this._contours.Length() < 1;
        };

        I.Stroke = function(Width, Offset, StartCap, EndCap)
        {
            var last_136 = new Uno.Float2;
            var current_137 = new Uno.Float2;
            var next_138 = new Uno.Float2;
            var lv_139 = new Uno.Float2;
            var rv_140 = new Uno.Float2;
            var bisectNormal_141 = new Uno.Float2;
            var _width = Width;
            var _offset = Offset - (Width * 0.5);
            var strokeContours = Uno.Collections.List__Fuse_Drawing_Contour.New_1();

            for (var enum_125 = this.Contours()["Uno.Collections.IEnumerable__Fuse_Drawing_Contour.GetEnumerator"](); enum_125["Uno.Collections.IEnumerator.MoveNext"](); )
            {
                var contour = enum_125["Uno.Collections.IEnumerator__Fuse_Drawing_Contour.Current"]();
                var vertexCount = contour.VertexCount();

                if (vertexCount < 2)
                {
                    continue;
                }

                var outer = Uno.Collections.List__float2.New_1();
                var inner = Uno.Collections.List__float2.New_1();
                var dist = 0.0;
                var startInner = Uno.Float2.New_1(0.0);
                var startOuter = Uno.Float2.New_1(0.0);
                var endInner = Uno.Float2.New_1(0.0);
                var endOuter = Uno.Float2.New_1(0.0);

                for (var i = 0; i < vertexCount; i++)
                {
                    last_136.op_Assign(contour.Item(i - 1));
                    current_137.op_Assign(contour.Item(i));
                    next_138.op_Assign(contour.Item(i + 1));
                    lv_139.op_Assign(Uno.Vector.Normalize(Uno.Float2.op_Subtraction(current_137, last_136)));
                    var lvn = Uno.Float2.New_2(-lv_139.Y, lv_139.X);
                    rv_140.op_Assign(Uno.Vector.Normalize(Uno.Float2.op_Subtraction(next_138, current_137)));
                    var rvn = Uno.Float2.New_2(-rv_140.Y, rv_140.X);
                    var len = Uno.Vector.Length(Uno.Float2.op_Subtraction(last_136, current_137));

                    if (i > 0)
                    {
                        dist = dist + len;
                    }

                    var outerV = new Uno.Float2;
                    var innerV = new Uno.Float2;

                    if (!contour.IsClosed() && (i == 0))
                    {
                        startInner.op_Assign(innerV = Uno.Float2.op_Addition(current_137, Uno.Float2.op_Multiply(rvn, _offset)));
                        startOuter.op_Assign(outerV = Uno.Float2.op_Addition(current_137, Uno.Float2.op_Multiply(rvn, _width + _offset)));
                    }
                    else if (!contour.IsClosed() && (i == (vertexCount - 1)))
                    {
                        endInner.op_Assign(innerV = Uno.Float2.op_Addition(current_137, Uno.Float2.op_Multiply(lvn, _offset)));
                        endOuter.op_Assign(outerV = Uno.Float2.op_Addition(current_137, Uno.Float2.op_Multiply(lvn, _width + _offset)));
                    }
                    else
                    {
                        var bn0 = Uno.Float2.op_Division_1(Uno.Float2.op_Addition(rvn, lvn), 2.0);
                        bisectNormal_141.op_Assign(((Uno.Math.Abs_1(bn0.X) + Uno.Math.Abs_1(bn0.Y)) < 1e-05) ? lvn : Uno.Vector.Normalize(bn0));
                        var angle = Uno.Geometry.Collision2D.AngleBetween(lv_139, bisectNormal_141);

                        if (((angle < 0.1) || (angle > 3.04159284)) || (len < 1.0))
                        {
                            outerV = Uno.Float2.op_Addition(current_137, Uno.Float2.op_Multiply(bisectNormal_141, _width + _offset));
                            innerV = Uno.Float2.op_Addition(current_137, Uno.Float2.op_Multiply(bisectNormal_141, _offset));
                        }
                        else
                        {
                            var lvo = Uno.Float2.op_Addition(last_136, Uno.Float2.op_Multiply(lvn, _width + _offset));
                            var lvi = Uno.Float2.op_Addition(last_136, Uno.Float2.op_Multiply(lvn, _offset));
                            outerV = Uno.Geometry.Collision2D.LineIntersectionPointVector(lvo, lv_139, current_137, bisectNormal_141);
                            innerV = Uno.Geometry.Collision2D.LineIntersectionPointVector(lvi, lv_139, current_137, bisectNormal_141);
                        }
                    }

                    outer.Add(outerV);
                    inner.Add(innerV);
                }

                var innerRev = Array.Structs(inner.Count(), Uno.Float2, 430);

                for (var i = 0; i < inner.Count(); ++i)
                {
                    innerRev[i].op_Assign(inner.Item((inner.Count() - i) - 1));
                }

                if (contour.IsClosed())
                {
                    strokeContours.Add(Fuse.Drawing.Contour.New_2(true, $DownCast(outer, 32826)));
                    strokeContours.Add(Fuse.Drawing.Contour.New_1(true, innerRev));
                }
                else
                {
                    var start = Fuse.Drawing.LineCapImpl.Create_1(StartCap).Create(startInner, startOuter);
                    var end = Fuse.Drawing.LineCapImpl.Create_1(EndCap).Create(endOuter, endInner);
                    strokeContours.Add(Fuse.Drawing.Contour.New_2(true, Uno.Collections.EnumerableExtensions.Union__float2(Uno.Collections.EnumerableExtensions.Union__float2(Uno.Collections.EnumerableExtensions.Union__float2(start, $DownCast(outer, 32826)), end), $DownCast(Uno.Runtime.Implementation.Internal.ArrayEnumerable__float2.New_1(innerRev), 32826))));
                }
            }

            return Fuse.Drawing.Polygon.New_1($DownCast(strokeContours, 32828));
        };

        I.Triangulate = function()
        {
            var verts = this.GetTriangleVertices();

            if (verts.length < 3)
            {
                return $DownCast(Uno.Runtime.Implementation.Internal.ArrayEnumerable__Fuse_Drawing_PolygonDrawable.New_1(Array.Sized(0, 747)), 32834);
            }

            return $DownCast(Uno.Runtime.Implementation.Internal.ArrayEnumerable__Fuse_Drawing_PolygonDrawable.New_1(Array.Init([Fuse.Drawing.PolygonDrawable.New_1(verts)], 747)), 32834);
        };

        I.GetTriangleVertices = function()
        {
            var mesh = Fuse.Drawing.Tesselation.MeshBuilder.CreateFromContours(this.Contours());
            mesh.ComputeInterior(this._windingRule);
            mesh.TessellateInterior();
            var vertices = Array.Structs(Uno.Collections.EnumerableExtensions.Count__Fuse_Drawing_Tesselation_Face(mesh.InteriorFaces()) * 3, Uno.Float2, 430);
            var v = 0;

            for (var enum_126 = mesh.InteriorFaces()["Uno.Collections.IEnumerable__Fuse_Drawing_Tesselation_Face.GetEnumerator"](); enum_126["Uno.Collections.IEnumerator.MoveNext"](); )
            {
                var face = enum_126["Uno.Collections.IEnumerator__Fuse_Drawing_Tesselation_Face.Current"]();

                for (var enum_127 = face.EdgeLoop()["Uno.Collections.IEnumerable__Fuse_Drawing_Tesselation_HalfEdge.GetEnumerator"](); enum_127["Uno.Collections.IEnumerator.MoveNext"](); )
                {
                    var vert = enum_127["Uno.Collections.IEnumerator__Fuse_Drawing_Tesselation_HalfEdge.Current"]();
                    vertices[v++] = vert.Origin().Coords();
                }
            }

            mesh.Dispose();
            return vertices;
        };

        I.GetBoundaryContours = function()
        {
            if (this.IsDegenerate())
            {
                this._boundaryContours = Array.Sized(0, 742);
            }

            if (this._boundaryContours == null)
            {
                var mesh = Fuse.Drawing.Tesselation.MeshBuilder.CreateFromContours(this.Contours());
                mesh.ComputeInterior(this._windingRule);
                mesh.SetWindingNumber(1);
                mesh.DeleteInternalEdges();
                this._boundaryContours = Uno.Collections.EnumerableExtensions.ToArray__Fuse_Drawing_Contour(mesh.GetContours());
                mesh.Dispose();
            }

            return $DownCast(Uno.Runtime.Implementation.Internal.ArrayEnumerable__Fuse_Drawing_Contour.New_1(this._boundaryContours), 32828);
        };

        I._ObjInit = function(contours)
        {
            this._ObjInit_1($CreateDelegate(null, Fuse.Drawing.WindingRules.NonZero, 503), contours);
        };

        Fuse.Drawing.Polygon.New_1 = function(contours)
        {
            var inst = new Fuse.Drawing.Polygon;
            inst._ObjInit(contours);
            return inst;
        };

        I._ObjInit_1 = function(windingRule, contours)
        {
            this._windingRule = windingRule;
            this._contours = Fuse.Drawing.Cache__Fuse_Drawing_Contour.New_2(contours);
        };

        Fuse.Drawing.Polygon.New_2 = function(windingRule, contours)
        {
            var inst = new Fuse.Drawing.Polygon;
            inst._ObjInit_1(windingRule, contours);
            return inst;
        };

    });
