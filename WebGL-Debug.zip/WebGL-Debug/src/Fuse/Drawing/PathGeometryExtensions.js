Fuse.Drawing.PathGeometryExtensions = $CreateClass(
    function() {
    },
    function(S) {

        Fuse.Drawing.PathGeometryExtensions.RegularPolygon = function(self, Sides, Radius, Invert)
        {
            return Fuse.Drawing.RegularPolygonFactory.AppendTo(self, Sides, Radius, Invert);
        };

        Fuse.Drawing.PathGeometryExtensions.Circle = function(self, Radius, Invert)
        {
            return Fuse.Drawing.EllipseFactory.AppendTo(self, Uno.Float2.New_1(Radius), Invert);
        };

        Fuse.Drawing.PathGeometryExtensions.Ellipse = function(self, Radius, Invert)
        {
            return Fuse.Drawing.EllipseFactory.AppendTo(self, Radius, Invert);
        };

        Fuse.Drawing.PathGeometryExtensions.Rectangle = function(self, Size, CornerRadius, Invert)
        {
            return Fuse.Drawing.RectangleFactory.AppendTo(self, Size, CornerRadius, Invert);
        };

    });
