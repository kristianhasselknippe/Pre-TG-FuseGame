Fuse.Drawing.LineTo = $CreateClass(
    function() {
        Fuse.Drawing.PathGeometry.call(this);
        this._lastPosition = new Uno.Float2;
    },
    function(S) {
        var I = S.prototype = new Fuse.Drawing.PathGeometry;

        I.GetType = function()
        {
            return 764;
        };

        I.HasLastBounds = function()
        {
            return true;
        };

        I.LastBounds = function()
        {
            return Uno.Rect.ContainingPoints(this._lastPosition, this.EndPosition());
        };

        I.LineToCtor = function(prev, lastPosition, position)
        {
            this.PathGeometryCtor(prev, position);
            this._lastPosition.op_Assign(lastPosition);
        };

        I.EvaluateLast = function()
        {
            return $DownCast(Uno.Runtime.Implementation.Internal.ArrayEnumerable__float2.New_1(Array.Init([this._lastPosition, this.EndPosition()], 430)), 32826);
        };

        I.Serialize = function()
        {
            return Uno.String.op_Addition_1(Uno.String.op_Addition(Uno.String.op_Addition_1("L ", $CreateBox(this.EndPosition().X, 429)), " "), $CreateBox(this.EndPosition().Y, 429));
        };

        I._ObjInit_1 = function(prev, lastPosition, position)
        {
            Fuse.Drawing.PathGeometry.prototype._ObjInit.call(this);
            this.LineToCtor(prev, lastPosition, position);
        };

        Fuse.Drawing.LineTo.New_2 = function(prev, lastPosition, position)
        {
            var inst = new Fuse.Drawing.LineTo;
            inst._ObjInit_1(prev, lastPosition, position);
            return inst;
        };

        I._ObjInit_2 = function()
        {
            Fuse.Drawing.PathGeometry.prototype._ObjInit.call(this);
        };

    });
