Fuse.Drawing.StaticBrush = $CreateClass(
    function() {
        Fuse.Drawing.Brush.call(this);
    },
    function(S) {
        var I = S.prototype = new Fuse.Drawing.Brush;

        I.GetType = function()
        {
            return 721;
        };

        I._ObjInit_1 = function()
        {
            Fuse.Drawing.Brush.prototype._ObjInit.call(this);
        };

    });
