Fuse.Drawing.MoveTo = $CreateClass(
    function() {
        Fuse.Drawing.ContourTerminator.call(this);
    },
    function(S) {
        var I = S.prototype = new Fuse.Drawing.ContourTerminator;

        I.GetType = function()
        {
            return 760;
        };

        I.Serialize = function()
        {
            return Uno.String.op_Addition_1(Uno.String.op_Addition(Uno.String.op_Addition_1("M ", $CreateBox(this.EndPosition().X, 429)), " "), $CreateBox(this.EndPosition().Y, 429));
        };

        I._ObjInit_3 = function(prev, position)
        {
            Fuse.Drawing.ContourTerminator.prototype._ObjInit_2.call(this);
            this.ContourTerminatorCtor(prev, position);
        };

        Fuse.Drawing.MoveTo.New_2 = function(prev, position)
        {
            var inst = new Fuse.Drawing.MoveTo;
            inst._ObjInit_3(prev, position);
            return inst;
        };

    });
