Fuse.Drawing.Meshes.MeshGenerator = $CreateClass(
    function() {
    },
    function(S) {

        Fuse.Drawing.Meshes.MeshGenerator.CreateCube = function(pivot, halfExtent)
        {
            var vertexCount = 24;
            var indexCount = 36;
            var vertices = Array.Structs(vertexCount, Uno.Float3, 431);
            var normals = Array.Structs(vertexCount, Uno.Float3, 431);
            var tangents = Array.Structs(vertexCount, Uno.Float4, 432);
            var texCoords = Array.Structs(vertexCount, Uno.Float2, 430);
            var indices = Array.Zeros(indexCount, 424);
            var pitches = Array.Init([0.0, Uno.Math.DegreesToRadians_1(90.0), Uno.Math.DegreesToRadians_1(180.0), Uno.Math.DegreesToRadians_1(270.0), 0.0, 0.0], 429);
            var yaws = Array.Init([0.0, 0.0, 0.0, 0.0, Uno.Math.DegreesToRadians_1(90.0), Uno.Math.DegreesToRadians_1(-90.0)], 429);

            for (var i = 0; i < 6; i++)
            {
                var vi = i * 4;
                var q = Uno.Quaternion.FromEulerAngle_1(pitches[i], yaws[i], 0.0);
                vertices[vi] = Uno.Float3.op_Addition(pivot, Uno.Float3.op_Multiply(Uno.Vector.Transform(Uno.Float3.New_2(-1.0, -1.0, 1.0), q), halfExtent));
                vertices[vi + 1] = Uno.Float3.op_Addition(pivot, Uno.Float3.op_Multiply(Uno.Vector.Transform(Uno.Float3.New_2(1.0, -1.0, 1.0), q), halfExtent));
                vertices[vi + 2] = Uno.Float3.op_Addition(pivot, Uno.Float3.op_Multiply(Uno.Vector.Transform(Uno.Float3.New_2(1.0, 1.0, 1.0), q), halfExtent));
                vertices[vi + 3] = Uno.Float3.op_Addition(pivot, Uno.Float3.op_Multiply(Uno.Vector.Transform(Uno.Float3.New_2(-1.0, 1.0, 1.0), q), halfExtent));
                var n = Uno.Vector.Transform(Uno.Float3.New_2(0.0, 0.0, 1.0), q);
                normals[vi].op_Assign(n);
                normals[vi + 1].op_Assign(n);
                normals[vi + 2].op_Assign(n);
                normals[vi + 3].op_Assign(n);
                var t = Uno.Float4.New_7(Uno.Vector.Transform(Uno.Float3.New_2(1.0, 0.0, 0.0), q), 1.0);
                tangents[vi].op_Assign(t);
                tangents[vi + 1].op_Assign(t);
                tangents[vi + 2].op_Assign(t);
                tangents[vi + 3].op_Assign(t);
                texCoords[vi] = Uno.Float2.New_2(0.0, 0.0);
                texCoords[vi + 1] = Uno.Float2.New_2(1.0, 0.0);
                texCoords[vi + 2] = Uno.Float2.New_2(1.0, 1.0);
                texCoords[vi + 3] = Uno.Float2.New_2(0.0, 1.0);
                var ii = i * 6;
                indices[ii] = vi;
                indices[ii + 1] = (vi + 1);
                indices[ii + 2] = (vi + 2);
                indices[ii + 3] = (vi + 2);
                indices[ii + 4] = (vi + 3);
                indices[ii + 5] = vi;
            }

            var dict = Uno.Collections.Dictionary__string__Uno_Content_Models_VertexAttributeArray.New_1();
            dict.Item("Position", Uno.Content.Models.VertexAttributeArray.New_4(vertices));
            dict.Item("Normal", Uno.Content.Models.VertexAttributeArray.New_4(normals));
            dict.Item("Tangent", Uno.Content.Models.VertexAttributeArray.New_5(tangents));
            dict.Item("TexCoord", Uno.Content.Models.VertexAttributeArray.New_3(texCoords));
            return Uno.Content.Models.ModelMesh.New_1("Cube", 1, dict, Uno.Content.Models.IndexArray.New_3(indices));
        };

    });
