Fuse.Drawing.ButtCap = $CreateClass(
    function() {
        Fuse.Drawing.LineCapImpl.call(this);
    },
    function(S) {
        var I = S.prototype = new Fuse.Drawing.LineCapImpl;

        I.GetType = function()
        {
            return 744;
        };

        I.Create = function(from, to)
        {
            return $DownCast(Uno.Runtime.Implementation.Internal.ArrayEnumerable__float2.New_1(Array.Structs(0, Uno.Float2, 430)), 32826);
        };

        I._ObjInit_1 = function()
        {
            Fuse.Drawing.LineCapImpl.prototype._ObjInit.call(this);
        };

        Fuse.Drawing.ButtCap.New_1 = function()
        {
            var inst = new Fuse.Drawing.ButtCap;
            inst._ObjInit_1();
            return inst;
        };

    });
