Fuse.Drawing.RectangleFactory = $CreateClass(
    function() {
    },
    function(S) {

        Fuse.Drawing.RectangleFactory.AppendTo = function(self, Size, CornerRadius, Invert)
        {
            var Size_123 = new Uno.Float2;
            var CornerRadius_124 = new Uno.Float4;
            var o_125 = new Uno.Float2;
            Size_123.op_Assign(Size);
            CornerRadius_124.op_Assign(CornerRadius);
            o_125.op_Assign(self.EndPosition());
            var t = o_125.Y;
            var b = t + Size_123.Y;
            var l = o_125.X;
            var r = l + Size_123.X;

            if (Invert)
            {
                var tTmp = t;
                t = b;
                b = tTmp;
            }

            if (Uno.Float4.op_Equality(CornerRadius_124, Uno.Float4.New_1(0.0)))
            {
                return self.MoveTo_1(o_125).LineTo(l, b).LineTo(r, b).LineTo(r, t).ClosePath();
            }

            var sign = Invert ? -1 : 1;
            var rtlx = Uno.Float2.New_2(Uno.Math.Min_1(Size_123.X / 2.0, CornerRadius_124.X), 0.0);
            var rtly = Uno.Float2.op_Multiply(Uno.Float2.New_2(0.0, Uno.Math.Min_1(Size_123.Y / 2.0, CornerRadius_124.X)), sign);
            var rtrx = Uno.Float2.New_2(Uno.Math.Min_1(Size_123.X / 2.0, CornerRadius_124.Y), 0.0);
            var rtry = Uno.Float2.op_Multiply(Uno.Float2.New_2(0.0, Uno.Math.Min_1(Size_123.Y / 2.0, CornerRadius_124.Y)), sign);
            var rbrx = Uno.Float2.New_2(Uno.Math.Min_1(Size_123.X / 2.0, CornerRadius_124.Z), 0.0);
            var rbry = Uno.Float2.op_Multiply(Uno.Float2.New_2(0.0, Uno.Math.Min_1(Size_123.Y / 2.0, CornerRadius_124.Z)), sign);
            var rblx = Uno.Float2.New_2(Uno.Math.Min_1(Size_123.X / 2.0, CornerRadius_124.W), 0.0);
            var rbly = Uno.Float2.op_Multiply(Uno.Float2.New_2(0.0, Uno.Math.Min_1(Size_123.Y / 2.0, CornerRadius_124.W)), sign);
            var tl = Uno.Float2.New_2(l, t);
            var tr = Uno.Float2.New_2(r, t);
            var bl = Uno.Float2.New_2(l, b);
            var br = Uno.Float2.New_2(r, b);
            var p = 0.45;
            return self.MoveTo_1(Uno.Float2.op_Subtraction(bl, rbly)).CurveTo(Uno.Float2.op_Subtraction(bl, Uno.Float2.op_Multiply(rbly, p)), Uno.Float2.op_Addition(bl, Uno.Float2.op_Multiply(rblx, p)), Uno.Float2.op_Addition(bl, rblx)).LineTo_1(Uno.Float2.op_Subtraction(br, rbrx)).CurveTo(Uno.Float2.op_Subtraction(br, Uno.Float2.op_Multiply(rbrx, p)), Uno.Float2.op_Subtraction(br, Uno.Float2.op_Multiply(rbry, p)), Uno.Float2.op_Subtraction(br, rbry)).LineTo_1(Uno.Float2.op_Addition(tr, rtry)).CurveTo(Uno.Float2.op_Addition(tr, Uno.Float2.op_Multiply(rtry, p)), Uno.Float2.op_Subtraction(tr, Uno.Float2.op_Multiply(rtrx, p)), Uno.Float2.op_Subtraction(tr, rtrx)).LineTo_1(Uno.Float2.op_Addition(tl, rtlx)).CurveTo(Uno.Float2.op_Addition(tl, Uno.Float2.op_Multiply(rtlx, p)), Uno.Float2.op_Addition(tl, Uno.Float2.op_Multiply(rtly, p)), Uno.Float2.op_Addition(tl, rtly)).ClosePath().MoveTo_1(o_125);
        };

    });
