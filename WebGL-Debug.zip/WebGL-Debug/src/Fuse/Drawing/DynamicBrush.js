Fuse.Drawing.DynamicBrush = $CreateClass(
    function() {
        Fuse.Drawing.Brush.call(this);
        this._opacity = 0;
        this._blendMode = 0;
        this.ShadingChanged = null;
    },
    function(S) {
        var I = S.prototype = new Fuse.Drawing.Brush;

        I.GetType = function()
        {
            return 722;
        };

        I.Opacity = function(value)
        {
            if (value !== undefined)
            {
                if (value == this._opacity)
                {
                    return;
                }

                this._opacity = value;
                this.OnShadingChanged();
            }
            else
            {
                return this._opacity;
            }
        };

        I.BlendMode = function(value)
        {
            if (value !== undefined)
            {
                if (value == this._blendMode)
                {
                    return;
                }

                this._blendMode = value;
                this.OnShadingChanged();
            }
            else
            {
                return this._blendMode;
            }
        };

        I.OnShadingChanged = function()
        {
            if (Uno.Delegate.op_Inequality(this.ShadingChanged, null))
            {
                this.ShadingChanged.Invoke();
            }
        };

        I._ObjInit_1 = function()
        {
            this._opacity = 1.0;
            Fuse.Drawing.Brush.prototype._ObjInit.call(this);
        };

        I.add_ShadingChanged = function(value)
        {
            this.ShadingChanged = $DownCast(Uno.Delegate.Combine(this.ShadingChanged, value), 436);
        };

        I.remove_ShadingChanged = function(value)
        {
            this.ShadingChanged = $DownCast(Uno.Delegate.Remove(this.ShadingChanged, value), 436);
        };

    });
