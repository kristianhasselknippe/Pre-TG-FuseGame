Fuse.Drawing.PolygonFiller = $CreateClass(
    function() {
        this._fills = null;
        this._antialiasingBorders = null;
        this._px = 0;
        this._hasBounds = false;
        this._bounds = new Uno.Rect;
    },
    function(S) {
        var I = S.prototype;

        I.GetType = function()
        {
            return 749;
        };

        I.$II = function(id)
        {
            return [418].indexOf(id) != -1;
        };

        I.Bounds = function()
        {
            if (this._hasBounds)
            {
                return this._bounds;
            }

            this._bounds = this.CalcBounds();
            this._hasBounds = true;
            return this._bounds;
        };

        I.Contour = function(border)
        {
            return border.Contour();
        };

        I.CreateBorder = function(contour)
        {
            return Fuse.Drawing.Border.New_1(Uno.Collections.EnumerableExtensions.ToArray__float2(contour.Vertices()), this._px * 0.5, -this._px);
        };

        I.CalcBounds = function()
        {
            if (this._fills.length == 0)
            {
                return Uno.Rect.New_1(0.0, 0.0, 0.0, 0.0);
            }

            var r = this._fills[0].CalcBounds();

            for (var i = 1; i < this._fills.length; ++i)
            {
                r = Uno.Rect.Union(r, this._fills[i].CalcBounds());
            }

            return r;
        };

        I.Draw_1 = function(f, ctx)
        {
            var array_123;
            var index_124;
            var length_125;
            var array_126;
            var index_127;
            var length_128;

            for (array_123 = this._antialiasingBorders, index_124 = 0, length_125 = array_123.length; index_124 < length_125; ++index_124)
            {
                var aa = array_123[index_124];
                aa.Draw(f, ctx);
            }

            for (array_126 = this._fills, index_127 = 0, length_128 = array_126.length; index_127 < length_128; ++index_127)
            {
                var fill = array_126[index_127];
                fill.Draw(f, ctx);
            }
        };

        I.Dispose = function()
        {
            var array_129;
            var index_130;
            var length_131;
            var array_132;
            var index_133;
            var length_134;

            for (array_129 = this._antialiasingBorders, index_130 = 0, length_131 = array_129.length; index_130 < length_131; ++index_130)
            {
                var border = array_129[index_130];
                border.Dispose();
            }

            for (array_132 = this._fills, index_133 = 0, length_134 = array_132.length; index_133 < length_134; ++index_133)
            {
                var fill = array_132[index_133];
                fill.Dispose();
            }
        };

        I.Intersects = function(p)
        {
            var array_135;
            var index_136;
            var length_137;

            for (array_135 = this._fills, index_136 = 0, length_137 = array_135.length; index_136 < length_137; ++index_136)
            {
                var fill = array_135[index_136];

                if (fill.Intersects(p))
                {
                    return true;
                }
            }

            return false;
        };

        I._ObjInit = function(polygon, antialiasing, zoom)
        {
            if (antialiasing == 1)
            {
                this._px = 1.0 / zoom;
                var boundaries = polygon.GetBoundaryContours();
                this._antialiasingBorders = Uno.Collections.EnumerableExtensions.ToArray__Fuse_Drawing_Border(Uno.Collections.EnumerableExtensions.Select__Fuse_Drawing_Contour__Fuse_Drawing_Border(boundaries, $CreateDelegate(this, Fuse.Drawing.PolygonFiller.prototype.CreateBorder, 501)));
                this._fills = Uno.Collections.EnumerableExtensions.ToArray__Fuse_Drawing_PolygonDrawable(Fuse.Drawing.Polygon.New_1(Uno.Collections.EnumerableExtensions.Select__Fuse_Drawing_Border__Fuse_Drawing_Contour($DownCast(Uno.Runtime.Implementation.Internal.ArrayEnumerable__Fuse_Drawing_Border.New_1(this._antialiasingBorders), 32845), $CreateDelegate(this, Fuse.Drawing.PolygonFiller.prototype.Contour, 502))).Triangulate());
            }
            else
            {
                this._fills = Uno.Collections.EnumerableExtensions.ToArray__Fuse_Drawing_PolygonDrawable(polygon.Triangulate());
                this._antialiasingBorders = Array.Sized(0, 748);
            }
        };

        Fuse.Drawing.PolygonFiller.New_1 = function(polygon, antialiasing, zoom)
        {
            var inst = new Fuse.Drawing.PolygonFiller;
            inst._ObjInit(polygon, antialiasing, zoom);
            return inst;
        };

        I["Uno.IDisposable.Dispose"] = I.Dispose;

    });
