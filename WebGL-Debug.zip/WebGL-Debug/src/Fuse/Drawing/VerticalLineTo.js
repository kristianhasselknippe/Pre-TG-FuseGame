Fuse.Drawing.VerticalLineTo = $CreateClass(
    function() {
        Fuse.Drawing.LineTo.call(this);
        this._y = 0;
    },
    function(S) {
        var I = S.prototype = new Fuse.Drawing.LineTo;

        I.GetType = function()
        {
            return 766;
        };

        I.Serialize = function()
        {
            return Uno.String.op_Addition_1("V ", $CreateBox(this._y, 429));
        };

        I._ObjInit_3 = function(prev, lastPosition, y)
        {
            var lastPosition_123 = new Uno.Float2;
            lastPosition_123.op_Assign(lastPosition);
            Fuse.Drawing.LineTo.prototype._ObjInit_2.call(this);
            this.LineToCtor(prev, lastPosition_123, Uno.Float2.New_2(lastPosition_123.X, y));
            this._y = y;
        };

        Fuse.Drawing.VerticalLineTo.New_4 = function(prev, lastPosition, y)
        {
            var inst = new Fuse.Drawing.VerticalLineTo;
            inst._ObjInit_3(prev, lastPosition, y);
            return inst;
        };

    });
