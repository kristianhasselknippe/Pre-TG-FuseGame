Fuse.Drawing.NonConsecutiveEnumerator = $CreateClass(
    function() {
        this._source = null;
        this._hasCurrent = false;
        this._current = new Uno.Float2;
        this._first = new Uno.Float2;
    },
    function(S) {
        var I = S.prototype;

        I.GetType = function()
        {
            return 741;
        };

        I.$II = function(id)
        {
            return [105, 418, 54].indexOf(id) != -1;
        };

        I.Current = function()
        {
            return Uno.Float2.New_2(this._current.X, this._current.Y);
        };

        I.MoveNext = function()
        {
            var next_123 = new Uno.Float2;

            if (!this._hasCurrent)
            {
                if (!this._source["Uno.Collections.IEnumerator.MoveNext"]())
                {
                    return false;
                }

                this._first.op_Assign(this._source["Uno.Collections.IEnumerator__float2.Current"]());
                this._current.op_Assign(this._source["Uno.Collections.IEnumerator__float2.Current"]());
                this._hasCurrent = true;
                return true;
            }

            while (true)
            {
                if (!this._source["Uno.Collections.IEnumerator.MoveNext"]())
                {
                    return false;
                }

                next_123.op_Assign(this._source["Uno.Collections.IEnumerator__float2.Current"]());

                if ((Uno.Math.Abs_1(next_123.X - this._current.X) > 1e-05) || (Uno.Math.Abs_1(next_123.Y - this._current.Y) > 1e-05))
                {
                    this._current.op_Assign(next_123);
                    return true;
                }
            }

            return false;
        };

        I.Dispose = function()
        {
        };

        I._ObjInit = function(source)
        {
            this._source = source;
        };

        Fuse.Drawing.NonConsecutiveEnumerator.New_1 = function(source)
        {
            var inst = new Fuse.Drawing.NonConsecutiveEnumerator;
            inst._ObjInit(source);
            return inst;
        };

        I["Uno.Collections.IEnumerator__float2.Current"] = I.Current;
        I["Uno.IDisposable.Dispose"] = I.Dispose;
        I["Uno.Collections.IEnumerator.MoveNext"] = I.MoveNext;

    });
