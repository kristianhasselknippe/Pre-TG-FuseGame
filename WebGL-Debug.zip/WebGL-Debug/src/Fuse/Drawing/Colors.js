Fuse.Drawing.Colors = $CreateClass(
    function() {
    },
    function(S) {
        Fuse.Drawing.Colors.Transparent = new Uno.Float4;
        Fuse.Drawing.Colors.Black = new Uno.Float4;
        Fuse.Drawing.Colors.Silver = new Uno.Float4;
        Fuse.Drawing.Colors.Gray = new Uno.Float4;
        Fuse.Drawing.Colors.White = new Uno.Float4;
        Fuse.Drawing.Colors.Maroon = new Uno.Float4;
        Fuse.Drawing.Colors.Red = new Uno.Float4;
        Fuse.Drawing.Colors.Purple = new Uno.Float4;
        Fuse.Drawing.Colors.Fuchsia = new Uno.Float4;
        Fuse.Drawing.Colors.Green = new Uno.Float4;
        Fuse.Drawing.Colors.Lime = new Uno.Float4;
        Fuse.Drawing.Colors.Olive = new Uno.Float4;
        Fuse.Drawing.Colors.Yellow = new Uno.Float4;
        Fuse.Drawing.Colors.Navy = new Uno.Float4;
        Fuse.Drawing.Colors.Blue = new Uno.Float4;
        Fuse.Drawing.Colors.Teal = new Uno.Float4;
        Fuse.Drawing.Colors.Aqua = new Uno.Float4;

        Fuse.Drawing.Colors._TypeInit = function()
        {
            Fuse.Drawing.Colors.Transparent = Uno.Color.FromRgba32_1(0);
            Fuse.Drawing.Colors.Black = Uno.Color.FromRgba32_1(255);
            Fuse.Drawing.Colors.Silver = Uno.Color.FromRgba32_1(3233857791);
            Fuse.Drawing.Colors.Gray = Uno.Color.FromRgba32_1(2155905279);
            Fuse.Drawing.Colors.White = Uno.Color.FromRgba32_1(4294967295);
            Fuse.Drawing.Colors.Maroon = Uno.Color.FromRgba32_1(2147483903);
            Fuse.Drawing.Colors.Red = Uno.Color.FromRgba32_1(4278190335);
            Fuse.Drawing.Colors.Purple = Uno.Color.FromRgba32_1(2147516671);
            Fuse.Drawing.Colors.Fuchsia = Uno.Color.FromRgba32_1(4278255615);
            Fuse.Drawing.Colors.Green = Uno.Color.FromRgba32_1(8388863);
            Fuse.Drawing.Colors.Lime = Uno.Color.FromRgba32_1(16711935);
            Fuse.Drawing.Colors.Olive = Uno.Color.FromRgba32_1(2155872511);
            Fuse.Drawing.Colors.Yellow = Uno.Color.FromRgba32_1(4294902015);
            Fuse.Drawing.Colors.Navy = Uno.Color.FromRgba32_1(33023);
            Fuse.Drawing.Colors.Blue = Uno.Color.FromRgba32_1(65535);
            Fuse.Drawing.Colors.Teal = Uno.Color.FromRgba32_1(8421631);
            Fuse.Drawing.Colors.Aqua = Uno.Color.FromRgba32_1(16777215);
        };

    });
