Fuse.Drawing.NonConsecutiveExtension = $CreateClass(
    function() {
    },
    function(S) {

        Fuse.Drawing.NonConsecutiveExtension.NonConsecutive = function(self)
        {
            return $DownCast(Fuse.Drawing.NonConsecutiveEnumerable.New_1(self), 32826);
        };

    });
