Fuse.Drawing.ContourTerminator = $CreateClass(
    function() {
        Fuse.Drawing.PathGeometry.call(this);
    },
    function(S) {
        var I = S.prototype = new Fuse.Drawing.PathGeometry;

        I.GetType = function()
        {
            return 759;
        };

        I.EndsContour = function()
        {
            return true;
        };

        I.ContourTerminatorCtor = function(prev, position)
        {
            this.PathGeometryCtor(prev, position);
        };

        I.FindStartOfLastContour = function()
        {
            return this.EndPosition();
        };

        I.EvaluateLast = function()
        {
            return $DownCast(Uno.Collections.EmptyEnumerable__float2.New_1(), 32826);
        };

        I._ObjInit_2 = function()
        {
            Fuse.Drawing.PathGeometry.prototype._ObjInit.call(this);
        };

    });
