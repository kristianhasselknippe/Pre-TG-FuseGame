Fuse.Drawing.Batching.BatchVertexBuffer = $CreateClass(
    function() {
        this.dataType = 0;
        this.maxVertices = 0;
        this.usage = 0;
        this.buf = null;
        this.vbo = null;
        this._position = 0;
        this.isDirty = false;
    },
    function(S) {
        var I = S.prototype;

        I.GetType = function()
        {
            return 690;
        };

        I.DataType = function(value)
        {
            if (value !== undefined)
            {
                if (this.buf != null)
                {
                    throw new $Error(Uno.Exception.New_1("Vertex attribute type cannot be changed after Bufferfer is written to"));
                }

                this.dataType = value;
            }
            else
            {
                return this.dataType;
            }
        };

        I.StrideInBytes = function()
        {
            return Uno.Graphics.VertexAttributeTypeHelpers.GetStrideInBytes(this.DataType());
        };

        I.Buffer = function()
        {
            if (this.buf == null)
            {
                this.buf = Uno.Buffer.New_3(this.maxVertices * this.StrideInBytes());
            }

            return this.buf;
        };

        I.VertexBuffer = function()
        {
            if (this.Buffer() == null)
            {
                return null;
            }

            this.Flush();
            return this.vbo;
        };

        I.Position = function(value)
        {
            if (value !== undefined)
            {
                this._position = value;
            }
            else
            {
                return this._position;
            }
        };

        I.Write = function(value)
        {
            this.Buffer().SetFloat2(this._position, value, true);
            this._position = this._position + 8;
        };

        I.Write_1 = function(value)
        {
            this.Buffer().SetFloat3(this._position, value, true);
            this._position = this._position + 12;
        };

        I.Write_2 = function(value)
        {
            this.Buffer().SetFloat4(this._position, value, true);
            this._position = this._position + 16;
        };

        I.Flush = function()
        {
            if ((this.buf != null) && this.isDirty)
            {
                if (this.vbo == null)
                {
                    this.vbo = Uno.Graphics.VertexBuffer.New_2(this.Buffer().SizeInBytes(), this.usage);
                }

                this.vbo.Update(this.buf);
                this.isDirty = false;
            }
        };

        I.Invalidate = function()
        {
            this.isDirty = true;
        };

        I._ObjInit = function(type, maxVertices, staticBatch)
        {
            this.isDirty = true;
            this.DataType(type);
            this.maxVertices = maxVertices;
            this.usage = staticBatch ? 0 : 1;
        };

        Fuse.Drawing.Batching.BatchVertexBuffer.New_1 = function(type, maxVertices, staticBatch)
        {
            var inst = new Fuse.Drawing.Batching.BatchVertexBuffer;
            inst._ObjInit(type, maxVertices, staticBatch);
            return inst;
        };

    });
