Fuse.Drawing.Batching.Entry = $CreateClass(
    function() {
        this.Mesh = null;
        this.InstanceIndex = 0;
    },
    function(S) {
        var I = S.prototype;

        I.GetType = function()
        {
            return 692;
        };

        I._ObjInit = function(m, instanceId)
        {
            this.Mesh = m;
            this.InstanceIndex = instanceId;
        };

        Fuse.Drawing.Batching.Entry.New_1 = function(m, instanceId)
        {
            var inst = new Fuse.Drawing.Batching.Entry;
            inst._ObjInit(m, instanceId);
            return inst;
        };

    });
