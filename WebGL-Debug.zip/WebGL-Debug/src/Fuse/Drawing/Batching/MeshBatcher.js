Fuse.Drawing.Batching.MeshBatcher = $CreateClass(
    function() {
        this.entries = null;
        this.batches = null;
    },
    function(S) {
        var I = S.prototype;

        I.GetType = function()
        {
            return 693;
        };

        I.EntryCount = function()
        {
            return this.entries.Count();
        };

        I.Batches = function()
        {
            this.Flush();
            return $DownCast(Uno.Runtime.Implementation.Internal.ArrayEnumerable__Fuse_Drawing_Batching_Batch.New_1(this.batches), 32818);
        };

        I.AddMesh = function(mesh)
        {
            return this.AddEntry(Fuse.Drawing.Batching.Entry.New_1(mesh, this.entries.Count()));
        };

        I.AddEntry = function(e)
        {
            this.entries.Add(e);
            return e.InstanceIndex;
        };

        I.Flush = function()
        {
            var v_125 = new Uno.Collections.KeyValuePair__string__Uno_Content_Models_VertexAttributeArray;
            var ind_127;
            var ind_128;
            var ind_129;
            var ind_130;
            var ind_131;
            var ind_132;
            var ind_133;
            var ind_134;
            var ind_135;
            var ind_136;
            var ind_137;

            if (this.batches != null)
            {
                return;
            }

            var position;
            var texcoord;
            var texcoord1;
            var texcoord2;
            var texcoord3;
            var texcoord4;
            var texcoord5;
            var texcoord6;
            var texcoord7;
            var normal;
            var tangent;
            var binormal;
            var color;
            var boneWeights;
            var boneIndex;
            var batches = Uno.Collections.List__Fuse_Drawing_Batching_Batch.New_1();
            var b = null;
            var virtualIndexBase = 0;
            var virtualIndexToRealIndex = Uno.Collections.Dictionary__int__int.New_1();
            var batchVertexCount = 0;
            var batchIndexCount = 0;
            var batchVertexCutoff = 0;
            var batchIndexCutoff = 0;

            for (var e = 0; e < this.entries.Count(); e++)
            {
                var m = this.entries.Item(e).Mesh;
                position = texcoord = texcoord1 = texcoord2 = texcoord3 = texcoord4 = texcoord5 = texcoord6 = texcoord7 = normal = tangent = binormal = color = boneWeights = boneIndex = null;

                for (var enum_123 = m.VertexAttributes()["Uno.Collections.IEnumerable__Uno_Collections_KeyValuePair_string_Uno_Content_Models_VertexAttributeArray_.GetEnumerator"](); enum_123["Uno.Collections.IEnumerator.MoveNext"](); )
                {
                    v_125.op_Assign(enum_123["Uno.Collections.IEnumerator__Uno_Collections_KeyValuePair_string_Uno_Content_Models_VertexAttributeArray_.Current"]());

                    if (Uno.String.op_Equality(v_125.Key(), "Position"))
                    {
                        position = v_125.Value();
                    }
                    else if (Uno.String.op_Equality(v_125.Key(), "TexCoord"))
                    {
                        texcoord = v_125.Value();
                    }
                    else if (Uno.String.op_Equality(v_125.Key(), "TexCoord1"))
                    {
                        texcoord1 = v_125.Value();
                    }
                    else if (Uno.String.op_Equality(v_125.Key(), "TexCoord2"))
                    {
                        texcoord2 = v_125.Value();
                    }
                    else if (Uno.String.op_Equality(v_125.Key(), "TexCoord3"))
                    {
                        texcoord3 = v_125.Value();
                    }
                    else if (Uno.String.op_Equality(v_125.Key(), "TexCoord4"))
                    {
                        texcoord4 = v_125.Value();
                    }
                    else if (Uno.String.op_Equality(v_125.Key(), "TexCoord5"))
                    {
                        texcoord5 = v_125.Value();
                    }
                    else if (Uno.String.op_Equality(v_125.Key(), "TexCoord6"))
                    {
                        texcoord6 = v_125.Value();
                    }
                    else if (Uno.String.op_Equality(v_125.Key(), "TexCoord7"))
                    {
                        texcoord7 = v_125.Value();
                    }
                    else if (Uno.String.op_Equality(v_125.Key(), "Normal"))
                    {
                        normal = v_125.Value();
                    }
                    else if (Uno.String.op_Equality(v_125.Key(), "Tangent"))
                    {
                        tangent = v_125.Value();
                    }
                    else if (Uno.String.op_Equality(v_125.Key(), "Binormal"))
                    {
                        binormal = v_125.Value();
                    }
                    else if (Uno.String.op_Equality(v_125.Key(), "Color"))
                    {
                        color = v_125.Value();
                    }
                    else if (Uno.String.op_Equality(v_125.Key(), "BoneWeights"))
                    {
                        boneWeights = v_125.Value();
                    }
                    else if (Uno.String.op_Equality(v_125.Key(), "BoneIndices"))
                    {
                        boneIndex = v_125.Value();
                    }
                }

                if (m.Indices() == null)
                {
                    m = Fuse.Drawing.Batching.MeshBatcher.CreateFakeIndexBuffer(m);
                }

                for (var i = 0; i < m.IndexCount(); i++)
                {
                    if ((batchVertexCount >= batchVertexCutoff) || (batchIndexCount >= batchIndexCutoff))
                    {
                        batchVertexCutoff = 65535;
                        batchIndexCutoff = 100000;
                        b = Fuse.Drawing.Batching.Batch.New_1(batchVertexCutoff, batchIndexCutoff, true);
                        batches.Add(b);
                        virtualIndexToRealIndex = Uno.Collections.Dictionary__int__int.New_1();
                        batchVertexCount = 0;
                        batchIndexCount = 0;
                    }

                    var originalIndex = m.Indices().GetInt(i);
                    var virtualIndex = virtualIndexBase + originalIndex;
                    var newIndex;

                    if (!virtualIndexToRealIndex.TryGetValue(virtualIndex, $CreateRef(function(){return newIndex}, function($){newIndex=$}, this)))
                    {
                        newIndex = batchVertexCount;
                        virtualIndexToRealIndex.Add(virtualIndex, newIndex);

                        if (position != null)
                        {
                            b.Positions().Write_1((ind_127 = position.GetFloat4(originalIndex), Uno.Float3.New_2(ind_127.X, ind_127.Y, ind_127.Z)));
                        }

                        if (texcoord != null)
                        {
                            b.TexCoord0s().Write((ind_128 = texcoord.GetFloat4(originalIndex), Uno.Float2.New_2(ind_128.X, ind_128.Y)));
                        }

                        if (texcoord1 != null)
                        {
                            b.TexCoord1s().Write((ind_129 = texcoord1.GetFloat4(originalIndex), Uno.Float2.New_2(ind_129.X, ind_129.Y)));
                        }

                        if (texcoord2 != null)
                        {
                            b.TexCoord2s().Write((ind_130 = texcoord2.GetFloat4(originalIndex), Uno.Float2.New_2(ind_130.X, ind_130.Y)));
                        }

                        if (texcoord3 != null)
                        {
                            b.TexCoord3s().Write((ind_131 = texcoord3.GetFloat4(originalIndex), Uno.Float2.New_2(ind_131.X, ind_131.Y)));
                        }

                        if (texcoord4 != null)
                        {
                            b.TexCoord4s().Write((ind_132 = texcoord4.GetFloat4(originalIndex), Uno.Float2.New_2(ind_132.X, ind_132.Y)));
                        }

                        if (texcoord5 != null)
                        {
                            b.TexCoord5s().Write((ind_133 = texcoord5.GetFloat4(originalIndex), Uno.Float2.New_2(ind_133.X, ind_133.Y)));
                        }

                        if (texcoord6 != null)
                        {
                            b.TexCoord6s().Write((ind_134 = texcoord6.GetFloat4(originalIndex), Uno.Float2.New_2(ind_134.X, ind_134.Y)));
                        }

                        if (texcoord7 != null)
                        {
                            b.TexCoord7s().Write((ind_135 = texcoord7.GetFloat4(originalIndex), Uno.Float2.New_2(ind_135.X, ind_135.Y)));
                        }

                        if (normal != null)
                        {
                            b.Normals().Write_1((ind_136 = normal.GetFloat4(originalIndex), Uno.Float3.New_2(ind_136.X, ind_136.Y, ind_136.Z)));
                        }

                        if (tangent != null)
                        {
                            b.Tangents().Write_2(tangent.GetFloat4(originalIndex));
                        }

                        if (binormal != null)
                        {
                            b.Binormals().Write_1((ind_137 = binormal.GetFloat4(originalIndex), Uno.Float3.New_2(ind_137.X, ind_137.Y, ind_137.Z)));
                        }

                        if (color != null)
                        {
                            b.Colors().Write_2(color.GetFloat4(originalIndex));
                        }

                        if (boneWeights != null)
                        {
                            b.BoneWeightBuffer().Write_5(boneWeights.GetByte4Normalized(originalIndex));
                        }

                        if (boneIndex != null)
                        {
                            b.BoneIndexBuffer().Write_5(boneIndex.GetByte4(originalIndex));
                        }

                        b.InstanceIndices().Write_9(this.entries.Item(e).InstanceIndex);
                        batchVertexCount++;
                    }

                    b.Indices().Write_1(newIndex);
                    batchIndexCount++;
                }

                virtualIndexBase = virtualIndexBase + m.VertexCount();
            }

            this.batches = batches.ToArray();
        };

        Fuse.Drawing.Batching.MeshBatcher.CreateFakeIndexBuffer = function(m)
        {
            var v_126 = new Uno.Collections.KeyValuePair__string__Uno_Content_Models_VertexAttributeArray;
            var d = Array.Zeros(m.VertexCount(), 429);

            for (var i = 0; i < d.length; i++)
            {
                d[i] = i;
            }

            var dict = Uno.Collections.Dictionary__string__Uno_Content_Models_VertexAttributeArray.New_1();

            for (var enum_124 = m.VertexAttributes()["Uno.Collections.IEnumerable__Uno_Collections_KeyValuePair_string_Uno_Content_Models_VertexAttributeArray_.GetEnumerator"](); enum_124["Uno.Collections.IEnumerator.MoveNext"](); )
            {
                v_126.op_Assign(enum_124["Uno.Collections.IEnumerator__Uno_Collections_KeyValuePair_string_Uno_Content_Models_VertexAttributeArray_.Current"]());
                dict.Item(v_126.Key(), v_126.Value());
            }

            return Uno.Content.Models.ModelMesh.New_1(m.Name(), m.PrimitiveType(), dict, Uno.Content.Models.IndexArray.New_4(d));
        };

        I._ObjInit = function()
        {
            this.entries = Uno.Collections.List__Fuse_Drawing_Batching_Entry.New_1();
        };

        Fuse.Drawing.Batching.MeshBatcher.New_1 = function()
        {
            var inst = new Fuse.Drawing.Batching.MeshBatcher;
            inst._ObjInit();
            return inst;
        };

    });
