Fuse.Drawing.Batching.BatchIndexBuffer = $CreateClass(
    function() {
        this.dataType = 0;
        this.maxIndices = 0;
        this.usage = 0;
        this.buf = null;
        this._position = 0;
        this.ibo = null;
        this.isDirty = false;
    },
    function(S) {
        var I = S.prototype;

        I.GetType = function()
        {
            return 689;
        };

        I.DataType = function(value)
        {
            if (value !== undefined)
            {
                if (this.buf != null)
                {
                    throw new $Error(Uno.Exception.New_1("Index type cannot be changed after buffer is written to"));
                }

                this.dataType = value;
            }
            else
            {
                return this.dataType;
            }
        };

        I.StrideInBytes = function()
        {
            return Uno.Graphics.IndexTypeHelpers.GetStrideInBytes(this.DataType());
        };

        I.Buffer = function()
        {
            if (this.buf == null)
            {
                this.buf = Uno.Buffer.New_3(this.maxIndices * this.StrideInBytes());
            }

            return this.buf;
        };

        I.IndexBuffer = function()
        {
            if (this.buf == null)
            {
                return null;
            }

            if (this.ibo == null)
            {
                this.ibo = Uno.Graphics.IndexBuffer.New_2(this.Buffer().SizeInBytes(), this.usage);
            }

            this.Flush();
            return this.ibo;
        };

        I.Write_1 = function(value)
        {
            this.Buffer().SetUShort(this._position, value, true);
            this._position = this._position + 2;
        };

        I.Flush = function()
        {
            if ((this.buf != null) && this.isDirty)
            {
                this.ibo.Update(this.buf);
                this.isDirty = false;
            }
        };

        I._ObjInit = function(type, maxIndices, staticBatch)
        {
            this.isDirty = true;
            this.dataType = type;
            this.maxIndices = maxIndices;
            this.usage = staticBatch ? 0 : 1;
        };

        Fuse.Drawing.Batching.BatchIndexBuffer.New_1 = function(type, maxIndices, staticBatch)
        {
            var inst = new Fuse.Drawing.Batching.BatchIndexBuffer;
            inst._ObjInit(type, maxIndices, staticBatch);
            return inst;
        };

    });
