Fuse.Drawing.Batching.BatchHelpers = $CreateClass(
    function() {
    },
    function(S) {

        Fuse.Drawing.Batching.BatchHelpers.CreateSingleBatch = function(m)
        {
            var v_124 = new Uno.Collections.KeyValuePair__string__Uno_Content_Models_VertexAttributeArray;
            var b;

            if (m.Indices() != null)
            {
                b = Fuse.Drawing.Batching.Batch.New_1(m.VertexCount(), m.IndexCount(), true);
                b.Indices(Fuse.Drawing.Batching.BatchHelpers.CreateBatchIndexBuffer(m.Indices()));
            }
            else
            {
                b = Fuse.Drawing.Batching.Batch.New_1(m.VertexCount(), m.VertexCount(), true);

                for (var i = 0; i < m.VertexCount(); i++)
                {
                    b.Indices().Write_1(i);
                }
            }

            for (var enum_123 = m.VertexAttributes()["Uno.Collections.IEnumerable__Uno_Collections_KeyValuePair_string_Uno_Content_Models_VertexAttributeArray_.GetEnumerator"](); enum_123["Uno.Collections.IEnumerator.MoveNext"](); )
            {
                v_124.op_Assign(enum_123["Uno.Collections.IEnumerator__Uno_Collections_KeyValuePair_string_Uno_Content_Models_VertexAttributeArray_.Current"]());

                if (Uno.String.op_Equality(v_124.Key(), "Position"))
                {
                    b.Positions(Fuse.Drawing.Batching.BatchHelpers.CreateBatchVertexBuffer(v_124.Value()));
                }
                else if (Uno.String.op_Equality(v_124.Key(), "TexCoord"))
                {
                    b.TexCoord0s(Fuse.Drawing.Batching.BatchHelpers.CreateBatchVertexBuffer(v_124.Value()));
                }
                else if (Uno.String.op_Equality(v_124.Key(), "TexCoord1"))
                {
                    b.TexCoord1s(Fuse.Drawing.Batching.BatchHelpers.CreateBatchVertexBuffer(v_124.Value()));
                }
                else if (Uno.String.op_Equality(v_124.Key(), "TexCoord2"))
                {
                    b.TexCoord2s(Fuse.Drawing.Batching.BatchHelpers.CreateBatchVertexBuffer(v_124.Value()));
                }
                else if (Uno.String.op_Equality(v_124.Key(), "TexCoord3"))
                {
                    b.TexCoord3s(Fuse.Drawing.Batching.BatchHelpers.CreateBatchVertexBuffer(v_124.Value()));
                }
                else if (Uno.String.op_Equality(v_124.Key(), "TexCoord4"))
                {
                    b.TexCoord4s(Fuse.Drawing.Batching.BatchHelpers.CreateBatchVertexBuffer(v_124.Value()));
                }
                else if (Uno.String.op_Equality(v_124.Key(), "TexCoord5"))
                {
                    b.TexCoord5s(Fuse.Drawing.Batching.BatchHelpers.CreateBatchVertexBuffer(v_124.Value()));
                }
                else if (Uno.String.op_Equality(v_124.Key(), "TexCoord6"))
                {
                    b.TexCoord6s(Fuse.Drawing.Batching.BatchHelpers.CreateBatchVertexBuffer(v_124.Value()));
                }
                else if (Uno.String.op_Equality(v_124.Key(), "TexCoord7"))
                {
                    b.TexCoord7s(Fuse.Drawing.Batching.BatchHelpers.CreateBatchVertexBuffer(v_124.Value()));
                }
                else if (Uno.String.op_Equality(v_124.Key(), "Normal"))
                {
                    b.Normals(Fuse.Drawing.Batching.BatchHelpers.CreateBatchVertexBuffer(v_124.Value()));
                }
                else if (Uno.String.op_Equality(v_124.Key(), "Tangent"))
                {
                    b.Tangents(Fuse.Drawing.Batching.BatchHelpers.CreateBatchVertexBuffer(v_124.Value()));
                }
                else if (Uno.String.op_Equality(v_124.Key(), "Binormal"))
                {
                    b.Binormals(Fuse.Drawing.Batching.BatchHelpers.CreateBatchVertexBuffer(v_124.Value()));
                }
                else if (Uno.String.op_Equality(v_124.Key(), "Color"))
                {
                    b.Colors(Fuse.Drawing.Batching.BatchHelpers.CreateBatchVertexBuffer(v_124.Value()));
                }
                else if (Uno.String.op_Equality(v_124.Key(), "TransformIndex"))
                {
                    b.InstanceIndices(Fuse.Drawing.Batching.BatchHelpers.CreateBatchVertexBuffer(v_124.Value()));
                }
                else if (Uno.String.op_Equality(v_124.Key(), "BoneWeights"))
                {
                    b.BoneWeightBuffer(Fuse.Drawing.Batching.BatchHelpers.CreateBatchVertexBuffer(v_124.Value()));
                }
                else if (Uno.String.op_Equality(v_124.Key(), "BoneIndices"))
                {
                    b.BoneIndexBuffer(Fuse.Drawing.Batching.BatchHelpers.CreateBatchVertexBuffer(v_124.Value()));
                }
            }

            return b;
        };

        Fuse.Drawing.Batching.BatchHelpers.CreateBatchVertexBuffer = function(array)
        {
            switch (array.Type())
            {
                case 1:
                {
                    return Fuse.Drawing.Batching.BatchVertexBuffer.New_2(array.Type(), array.Buffer());
                }
                case 2:
                {
                    return Fuse.Drawing.Batching.BatchVertexBuffer.New_2(array.Type(), array.Buffer());
                }
                case 3:
                {
                    return Fuse.Drawing.Batching.BatchVertexBuffer.New_2(array.Type(), array.Buffer());
                }
                case 4:
                {
                    return Fuse.Drawing.Batching.BatchVertexBuffer.New_2(array.Type(), array.Buffer());
                }
                case 17:
                case 18:
                {
                    return Fuse.Drawing.Batching.BatchVertexBuffer.New_2(array.Type(), array.Buffer());
                }
                case 19:
                case 20:
                {
                    return Fuse.Drawing.Batching.BatchVertexBuffer.New_2(array.Type(), array.Buffer());
                }
                default:
                {
                    throw new $Error(Uno.Exception.New_1("Unsupported vertex attribute type"));
                }
            }
        };

        Fuse.Drawing.Batching.BatchHelpers.CreateBatchIndexBuffer = function(array)
        {
            switch (array.Type())
            {
                case 1:
                {
                    return Fuse.Drawing.Batching.BatchIndexBuffer.New_2(array.Type(), array.Buffer());
                }
                case 2:
                {
                    return Fuse.Drawing.Batching.BatchIndexBuffer.New_2(array.Type(), array.Buffer());
                }
                case 4:
                {
                    return Fuse.Drawing.Batching.BatchIndexBuffer.New_2(array.Type(), array.Buffer());
                }
                default:
                {
                    throw new $Error(Uno.Exception.New_1("Unsupported index type"));
                }
            }
        };

    });
