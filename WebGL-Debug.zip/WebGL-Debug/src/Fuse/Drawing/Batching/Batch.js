Fuse.Drawing.Batching.Batch = $CreateClass(
    function() {
        this.maxVertices = 0;
        this.maxIndices = 0;
        this.staticBatch = false;
        this.positions = null;
        this.texCoord0s = null;
        this.normals = null;
        this.attrib0 = null;
        this.attrib1 = null;
        this.hasExplicitVertexCount = false;
        this.explicitVertexCount = 0;
        this.indexBuffer = null;
    },
    function(S) {
        var I = S.prototype;

        I.GetType = function()
        {
            return 688;
        };

        I.Positions = function(value)
        {
            if (value !== undefined)
            {
                this.positions = value;
            }
            else
            {
                var ind_123 = this.positions;
                return (ind_123 != null) ? ind_123 : (this.positions = Fuse.Drawing.Batching.BatchVertexBuffer.New_1(3, this.maxVertices, this.staticBatch));
            }
        };

        I.TexCoord0s = function(value)
        {
            if (value !== undefined)
            {
                this.texCoord0s = value;
            }
            else
            {
                var ind_124 = this.texCoord0s;
                return (ind_124 != null) ? ind_124 : (this.texCoord0s = Fuse.Drawing.Batching.BatchVertexBuffer.New_1(2, this.maxVertices, this.staticBatch));
            }
        };

        I.Normals = function(value)
        {
            if (value !== undefined)
            {
                this.normals = value;
            }
            else
            {
                var ind_132 = this.normals;
                return (ind_132 != null) ? ind_132 : (this.normals = Fuse.Drawing.Batching.BatchVertexBuffer.New_1(3, this.maxVertices, this.staticBatch));
            }
        };

        I.Attrib0Buffer = function(value)
        {
            if (value !== undefined)
            {
                this.attrib0 = value;
            }
            else
            {
                var ind_139 = this.attrib0;
                return (ind_139 != null) ? ind_139 : (this.attrib0 = Fuse.Drawing.Batching.BatchVertexBuffer.New_1(4, this.maxVertices, this.staticBatch));
            }
        };

        I.Attrib1Buffer = function(value)
        {
            if (value !== undefined)
            {
                this.attrib1 = value;
            }
            else
            {
                var ind_140 = this.attrib1;
                return (ind_140 != null) ? ind_140 : (this.attrib1 = Fuse.Drawing.Batching.BatchVertexBuffer.New_1(4, this.maxVertices, this.staticBatch));
            }
        };

        I.VertexCount = function(value)
        {
            if (value !== undefined)
            {
                this.hasExplicitVertexCount = true;
                this.explicitVertexCount = value;
            }
            else
            {
                return this.hasExplicitVertexCount ? this.explicitVertexCount : this.maxIndices;
            }
        };

        I.Indices = function(value)
        {
            if (value !== undefined)
            {
                this.indexBuffer = value;
            }
            else
            {
                var ind_147 = this.indexBuffer;
                return (ind_147 != null) ? ind_147 : (this.indexBuffer = Fuse.Drawing.Batching.BatchIndexBuffer.New_1(2, this.maxIndices, this.staticBatch));
            }
        };

        I.IndexBuffer = function()
        {
            return (this.indexBuffer == null) ? null : this.Indices().IndexBuffer();
        };

        I.IndexType = function()
        {
            return (this.indexBuffer == null) ? 0 : this.Indices().DataType();
        };

        I._ObjInit = function(maxVertices, maxIndices, staticBatch)
        {
            this.maxVertices = maxVertices;
            this.maxIndices = maxIndices;
            this.staticBatch = staticBatch;
        };

        Fuse.Drawing.Batching.Batch.New_1 = function(maxVertices, maxIndices, staticBatch)
        {
            var inst = new Fuse.Drawing.Batching.Batch;
            inst._ObjInit(maxVertices, maxIndices, staticBatch);
            return inst;
        };

    });
