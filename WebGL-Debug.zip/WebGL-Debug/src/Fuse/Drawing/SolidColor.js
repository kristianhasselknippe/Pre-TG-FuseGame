Fuse.Drawing.SolidColor = $CreateClass(
    function() {
        Fuse.Drawing.DynamicBrush.call(this);
        this._color = new Uno.Float4;
    },
    function(S) {
        var I = S.prototype = new Fuse.Drawing.DynamicBrush;

        I.GetType = function()
        {
            return 725;
        };

        I.Color = function(value)
        {
            if (value !== undefined)
            {
                if (Uno.Float4.op_Inequality(this._color, value))
                {
                    this._color.op_Assign(value);
                    this.OnShadingChanged();
                }
            }
            else
            {
                return this._color;
            }
        };

        I._ObjInit_2 = function()
        {
            Fuse.Drawing.DynamicBrush.prototype._ObjInit_1.call(this);
            this._color = Uno.Float4.New_1(1.0);
        };

        Fuse.Drawing.SolidColor.New_1 = function()
        {
            var inst = new Fuse.Drawing.SolidColor;
            inst._ObjInit_2();
            return inst;
        };

        I._ObjInit_3 = function(color)
        {
            Fuse.Drawing.DynamicBrush.prototype._ObjInit_1.call(this);
            this._color.op_Assign(color);
        };

        Fuse.Drawing.SolidColor.New_2 = function(color)
        {
            var inst = new Fuse.Drawing.SolidColor;
            inst._ObjInit_3(color);
            return inst;
        };

    });
