Fuse.Drawing.PolygonDrawable = $CreateClass(
    function() {
        this._vertices = null;
        this._vbo = null;
        this.Draw_BlendSrcRgb_15b76862_6_3_5 = 0;
        this.Draw_BlendSrcAlpha_15b76862_6_5_6 = 0;
        this.Draw_BlendDstRgb_15b76862_6_4_7 = 0;
        this.Draw_BlendDstAlpha_15b76862_6_6_8 = 0;
        this._draw_15b596e6 = new Uno.Runtime.Implementation.ShaderBackends.OpenGL.GLDrawCall;
        this._draw_15b60b45 = new Uno.Runtime.Implementation.ShaderBackends.OpenGL.GLDrawCall;
        this._draw_15b67fa4 = new Uno.Runtime.Implementation.ShaderBackends.OpenGL.GLDrawCall;
        this._draw_15b6f403 = new Uno.Runtime.Implementation.ShaderBackends.OpenGL.GLDrawCall;
    },
    function(S) {
        var I = S.prototype;

        I.GetType = function()
        {
            return 747;
        };

        I.Intersects = function(p)
        {
            for (var i = 2; i < this._vertices.length; i = i + 3)
            {
                if (Uno.Geometry.Collision2D.TriangleContainsPoint(this._vertices[i - 2], this._vertices[i - 1], this._vertices[i], p))
                {
                    return true;
                }
            }

            return false;
        };

        I.Draw = function(f, ctx)
        {
            var Scale_15b596e6_8_19_2_127 = new Uno.Float2;
            var ind_133;
            var ind_134;

            if ($IsOp(f, 728))
            {
                Scale_15b596e6_8_19_2_127.op_Assign(Fuse.Drawing.PolygonDrawable.Draw_Scale_15b596e6_8_19_1($AsOp(f, 728).SizeMode(), ctx.ElementSize(), ($AsOp(f, 728).Texture() == null) ? Uno.Float2.New_1(1.0) : Uno.Float2.op_Implicit($AsOp(f, 728).Texture().Size())));
                {
                    this._draw_15b596e6.BlendEnabled(true);
                    this._draw_15b596e6.BlendSrcRgb(Fuse.Drawing.BlendModeHelpers.GetSrcRgb($AsOp(f, 728).BlendMode()));
                    this._draw_15b596e6.BlendSrcAlpha(Fuse.Drawing.BlendModeHelpers.GetSrcAlpha($AsOp(f, 728).BlendMode()));
                    this._draw_15b596e6.BlendDstRgb(Fuse.Drawing.BlendModeHelpers.GetDstRgb($AsOp(f, 728).BlendMode()));
                    this._draw_15b596e6.BlendDstAlpha(Fuse.Drawing.BlendModeHelpers.GetDstAlpha($AsOp(f, 728).BlendMode()));
                    this._draw_15b596e6.DepthTestEnabled(false);
                    this._draw_15b596e6.CullFace(0);
                    this._draw_15b596e6.Const(0, $AsOp(f, 728).Texture() == null);
                    this._draw_15b596e6.Use();
                    this._draw_15b596e6.Attrib_1(1, 2, this._vbo, 8, 0);
                    this._draw_15b596e6.Uniform_14(2, ctx.Transform());
                    this._draw_15b596e6.Uniform_9(3, Fuse.Spaces.VirtualResolution());
                    this._draw_15b596e6.Uniform_9(4, Uno.Float2.op_Multiply_1(($AsOp(f, 728).Texture() == null) ? Uno.Float2.New_1(1.0) : Uno.Float2.op_Implicit($AsOp(f, 728).Texture().Size()), Scale_15b596e6_8_19_2_127));
                    this._draw_15b596e6.Uniform_11(5, $AsOp(f, 728).Color());
                    this._draw_15b596e6.Uniform_8(6, $AsOp(f, 728).Opacity());
                    this._draw_15b596e6.Uniform_8(7, ($AsOp(f, 728).HorizontalAlignment() == 0) ? 0.0 : (($AsOp(f, 728).HorizontalAlignment() == 1) ? Uno.Math.Floor_1((ctx.ElementSize().X - Uno.Float2.op_Multiply_1(($AsOp(f, 728).Texture() == null) ? Uno.Float2.New_1(1.0) : Uno.Float2.op_Implicit($AsOp(f, 728).Texture().Size()), Scale_15b596e6_8_19_2_127).X) * 0.5) : (($AsOp(f, 728).HorizontalAlignment() == 2) ? (ctx.ElementSize().X - Uno.Float2.op_Multiply_1(($AsOp(f, 728).Texture() == null) ? Uno.Float2.New_1(1.0) : Uno.Float2.op_Implicit($AsOp(f, 728).Texture().Size()), Scale_15b596e6_8_19_2_127).X) : 0.0)));
                    this._draw_15b596e6.Uniform_8(8, ($AsOp(f, 728).VerticalAlignment() == 0) ? 0.0 : (($AsOp(f, 728).VerticalAlignment() == 4) ? Uno.Math.Floor_1((ctx.ElementSize().Y - Uno.Float2.op_Multiply_1(($AsOp(f, 728).Texture() == null) ? Uno.Float2.New_1(1.0) : Uno.Float2.op_Implicit($AsOp(f, 728).Texture().Size()), Scale_15b596e6_8_19_2_127).Y) * 0.5) : (($AsOp(f, 728).VerticalAlignment() == 5) ? (ctx.ElementSize().Y - Uno.Float2.op_Multiply_1(($AsOp(f, 728).Texture() == null) ? Uno.Float2.New_1(1.0) : Uno.Float2.op_Implicit($AsOp(f, 728).Texture().Size()), Scale_15b596e6_8_19_2_127).Y) : 0.0)));
                    this._draw_15b596e6.Sampler_3(9, $AsOp(f, 728).Texture(), Uno.Graphics.SamplerState.New_1($AsOp(f, 728).MinFilter(), $AsOp(f, 728).MagFilter(), 10497));
                    this._draw_15b596e6.DrawArrays(this._vertices.length);
                }
            }
            else if ($IsOp(f, 725))
            {
                {
                    this._draw_15b60b45.BlendEnabled(true);
                    this._draw_15b60b45.BlendSrcRgb(Fuse.Drawing.BlendModeHelpers.GetSrcRgb($AsOp(f, 725).BlendMode()));
                    this._draw_15b60b45.BlendSrcAlpha(Fuse.Drawing.BlendModeHelpers.GetSrcAlpha($AsOp(f, 725).BlendMode()));
                    this._draw_15b60b45.BlendDstRgb(Fuse.Drawing.BlendModeHelpers.GetDstRgb($AsOp(f, 725).BlendMode()));
                    this._draw_15b60b45.BlendDstAlpha(Fuse.Drawing.BlendModeHelpers.GetDstAlpha($AsOp(f, 725).BlendMode()));
                    this._draw_15b60b45.DepthTestEnabled(false);
                    this._draw_15b60b45.CullFace(0);
                    this._draw_15b60b45.Use();
                    this._draw_15b60b45.Attrib_1(0, 2, this._vbo, 8, 0);
                    this._draw_15b60b45.Uniform_14(1, ctx.Transform());
                    this._draw_15b60b45.Uniform_9(2, Fuse.Spaces.VirtualResolution());
                    this._draw_15b60b45.Uniform_11(3, Uno.Float4.New_7(Uno.Float3.op_Multiply(Uno.Float3.op_Multiply((ind_133 = $AsOp(f, 725).Color(), Uno.Float3.New_2(ind_133.X, ind_133.Y, ind_133.Z)), $AsOp(f, 725).Color().W), $AsOp(f, 725).Opacity()), $AsOp(f, 725).Color().W * $AsOp(f, 725).Opacity()));
                    this._draw_15b60b45.DrawArrays(this._vertices.length);
                }
            }
            else if ($IsOp(f, 724))
            {
                var Colors_15b67fa4_8_9_4 = Fuse.Drawing.PolygonDrawable.Draw_Colors_15b67fa4_8_9_3($AsOp(f, 724).SortedStops());
                var Offsets_15b67fa4_8_8_6 = Fuse.Drawing.PolygonDrawable.Draw_Offsets_15b67fa4_8_8_5($AsOp(f, 724).SortedStops());
                {
                    this._draw_15b67fa4.BlendEnabled(true);
                    this._draw_15b67fa4.BlendSrcRgb(Fuse.Drawing.BlendModeHelpers.GetSrcRgb($AsOp(f, 724).BlendMode()));
                    this._draw_15b67fa4.BlendSrcAlpha(Fuse.Drawing.BlendModeHelpers.GetSrcAlpha($AsOp(f, 724).BlendMode()));
                    this._draw_15b67fa4.BlendDstRgb(Fuse.Drawing.BlendModeHelpers.GetDstRgb($AsOp(f, 724).BlendMode()));
                    this._draw_15b67fa4.BlendDstAlpha(Fuse.Drawing.BlendModeHelpers.GetDstAlpha($AsOp(f, 724).BlendMode()));
                    this._draw_15b67fa4.DepthTestEnabled(false);
                    this._draw_15b67fa4.CullFace(0);
                    this._draw_15b67fa4.Const_1(0, Colors_15b67fa4_8_9_4.length);
                    this._draw_15b67fa4.Const_1(1, Offsets_15b67fa4_8_8_6.length);
                    this._draw_15b67fa4.Use();
                    this._draw_15b67fa4.Attrib_1(2, 2, this._vbo, 8, 0);
                    this._draw_15b67fa4.Uniform_14(3, ctx.Transform());
                    this._draw_15b67fa4.Uniform_9(4, Fuse.Spaces.VirtualResolution());
                    this._draw_15b67fa4.Uniform_9(5, ctx.ElementSize());
                    this._draw_15b67fa4.Uniform_9(6, $AsOp(f, 724).EndPoint());
                    this._draw_15b67fa4.Uniform_9(7, $AsOp(f, 724).StartPoint());
                    this._draw_15b67fa4.Uniform_18(8, Colors_15b67fa4_8_9_4);
                    this._draw_15b67fa4.Uniform_15(9, Offsets_15b67fa4_8_8_6);
                    this._draw_15b67fa4.Uniform_8(10, $AsOp(f, 724).Opacity());
                    this._draw_15b67fa4.DrawArrays(this._vertices.length);
                }
            }
            else if ($IsOp(f, 38))
            {
                {
                    this._draw_15b6f403.BlendEnabled(true);
                    this._draw_15b6f403.BlendSrcRgb(Fuse.Drawing.BlendModeHelpers.GetSrcRgb($AsOp(f, 38).BlendMode()));
                    this._draw_15b6f403.BlendSrcAlpha(Fuse.Drawing.BlendModeHelpers.GetSrcAlpha($AsOp(f, 38).BlendMode()));
                    this._draw_15b6f403.BlendDstRgb(Fuse.Drawing.BlendModeHelpers.GetDstRgb($AsOp(f, 38).BlendMode()));
                    this._draw_15b6f403.BlendDstAlpha(Fuse.Drawing.BlendModeHelpers.GetDstAlpha($AsOp(f, 38).BlendMode()));
                    this._draw_15b6f403.DepthTestEnabled(false);
                    this._draw_15b6f403.CullFace(0);
                    this._draw_15b6f403.Use();
                    this._draw_15b6f403.Attrib_1(0, 2, this._vbo, 8, 0);
                    this._draw_15b6f403.Uniform_14(1, ctx.Transform());
                    this._draw_15b6f403.Uniform_9(2, Fuse.Spaces.VirtualResolution());
                    this._draw_15b6f403.Uniform_9(3, ctx.ElementSize());
                    this._draw_15b6f403.Uniform_8(4, $AsOp(f, 38).Split());
                    this._draw_15b6f403.Uniform_11(5, $AsOp(f, 38).Right());
                    this._draw_15b6f403.Uniform_11(6, $AsOp(f, 38).Left());
                    this._draw_15b6f403.Uniform_8(7, $AsOp(f, 38).Opacity());
                    this._draw_15b6f403.DrawArrays(this._vertices.length);
                }
            }
            else if ($IsOp(f, 726))
            {
                {
                    this._draw_15b60b45.BlendEnabled(true);
                    this._draw_15b60b45.BlendSrcRgb(this.Draw_BlendSrcRgb_15b76862_6_3_5);
                    this._draw_15b60b45.BlendSrcAlpha(this.Draw_BlendSrcAlpha_15b76862_6_5_6);
                    this._draw_15b60b45.BlendDstRgb(this.Draw_BlendDstRgb_15b76862_6_4_7);
                    this._draw_15b60b45.BlendDstAlpha(this.Draw_BlendDstAlpha_15b76862_6_6_8);
                    this._draw_15b60b45.DepthTestEnabled(false);
                    this._draw_15b60b45.CullFace(0);
                    this._draw_15b60b45.Use();
                    this._draw_15b60b45.Attrib_1(0, 2, this._vbo, 8, 0);
                    this._draw_15b60b45.Uniform_14(1, ctx.Transform());
                    this._draw_15b60b45.Uniform_9(2, Fuse.Spaces.VirtualResolution());
                    this._draw_15b60b45.Uniform_11(3, Uno.Float4.New_7(Uno.Float3.op_Multiply((ind_134 = $AsOp(f, 726).Color(), Uno.Float3.New_2(ind_134.X, ind_134.Y, ind_134.Z)), $AsOp(f, 726).Color().W), $AsOp(f, 726).Color().W));
                    this._draw_15b60b45.DrawArrays(this._vertices.length);
                }
            }
        };

        I.Dispose = function()
        {
            this.free_DrawCalls();
            this._vbo.Dispose();
        };

        I.CalcBounds = function()
        {
            var min_128 = new Uno.Float2;
            var max_129 = new Uno.Float2;
            var v_130 = new Uno.Float2;
            var array_123;
            var index_124;
            var length_125;

            if (this._vertices.length == 0)
            {
                return Uno.Rect.New_1(0.0, 0.0, 0.0, 0.0);
            }

            min_128.op_Assign(this._vertices[0]);
            max_129.op_Assign(this._vertices[0]);

            for (array_123 = this._vertices, index_124 = 0, length_125 = array_123.length; index_124 < length_125; ++index_124)
            {
                v_130.op_Assign(array_123[index_124]);
                min_128 = Uno.Math.Min_3(min_128, v_130);
                max_129 = Uno.Math.Max_3(max_129, v_130);
            }

            return Uno.Rect.New_1(min_128.X, min_128.Y, max_129.X, max_129.Y);
        };

        I.init_DrawCalls = function()
        {
            this.Draw_BlendSrcRgb_15b76862_6_3_5 = Fuse.Drawing.BlendModeHelpers.GetSrcRgb(0);
            this.Draw_BlendSrcAlpha_15b76862_6_5_6 = Fuse.Drawing.BlendModeHelpers.GetSrcAlpha(0);
            this.Draw_BlendDstRgb_15b76862_6_4_7 = Fuse.Drawing.BlendModeHelpers.GetDstRgb(0);
            this.Draw_BlendDstAlpha_15b76862_6_6_8 = Fuse.Drawing.BlendModeHelpers.GetDstAlpha(0);
            this._draw_15b596e6 = Uno.Runtime.Implementation.ShaderBackends.OpenGL.GLDrawCall.New_1($DownCast(Uno.Runtime.Implementation.Internal.BundleRegistry.Get(5), 383));
            this._draw_15b60b45 = Uno.Runtime.Implementation.ShaderBackends.OpenGL.GLDrawCall.New_1($DownCast(Uno.Runtime.Implementation.Internal.BundleRegistry.Get(6), 383));
            this._draw_15b67fa4 = Uno.Runtime.Implementation.ShaderBackends.OpenGL.GLDrawCall.New_1($DownCast(Uno.Runtime.Implementation.Internal.BundleRegistry.Get(7), 383));
            this._draw_15b6f403 = Uno.Runtime.Implementation.ShaderBackends.OpenGL.GLDrawCall.New_1($DownCast(Uno.Runtime.Implementation.Internal.BundleRegistry.Get(8), 383));
        };

        I.free_DrawCalls = function()
        {
        };

        Fuse.Drawing.PolygonDrawable.Draw_Scale_15b596e6_8_19_1 = function(Scale_8_19_5, Scale_8_19_6, Scale_8_19_7)
        {
            var Scale_8_19_6_131 = new Uno.Float2;
            var Scale_8_19_7_132 = new Uno.Float2;
            Scale_8_19_6_131.op_Assign(Scale_8_19_6);
            Scale_8_19_7_132.op_Assign(Scale_8_19_7);

            switch (Scale_8_19_5)
            {
                case 2:
                {
                    return Uno.Float2.New_1((Scale_8_19_6_131.Ratio() > Scale_8_19_7_132.Ratio()) ? (Scale_8_19_6_131.Y / Scale_8_19_7_132.Y) : (Scale_8_19_6_131.X / Scale_8_19_7_132.X));
                }
                case 1:
                {
                    return Uno.Float2.New_1((Scale_8_19_6_131.Ratio() > Scale_8_19_7_132.Ratio()) ? (Scale_8_19_6_131.X / Scale_8_19_7_132.X) : (Scale_8_19_6_131.Y / Scale_8_19_7_132.Y));
                }
                case 4:
                {
                    return Uno.Float2.New_1(Scale_8_19_6_131.X / Scale_8_19_7_132.Y);
                }
                case 5:
                {
                    return Uno.Float2.New_1(Scale_8_19_6_131.Y / Scale_8_19_7_132.Y);
                }
                case 3:
                {
                    return Uno.Float2.op_Division(Scale_8_19_6_131, Scale_8_19_7_132);
                }
            }

            return Uno.Float2.New_1(1.0);
        };

        Fuse.Drawing.PolygonDrawable.Draw_Colors_15b67fa4_8_9_3 = function(Colors_8_9_4)
        {
            var cols = Array.Structs(Uno.Math.Max_8(Colors_8_9_4.length, 1), Uno.Float4, 432);

            for (var i = 0; i < Colors_8_9_4.length; i++)
            {
                cols[i].op_Assign(Colors_8_9_4[i].Color());
            }

            return cols;
        };

        Fuse.Drawing.PolygonDrawable.Draw_Offsets_15b67fa4_8_8_5 = function(Offsets_8_8_5)
        {
            var ofs = Array.Zeros(Uno.Math.Max_8(Offsets_8_8_5.length, 1), 429);

            for (var i = 0; i < Offsets_8_8_5.length; i++)
            {
                ofs[i] = Offsets_8_8_5[i].Offset();
            }

            return ofs;
        };

        I._ObjInit = function(vertices)
        {
            this._vertices = vertices;
            this._vbo = Uno.Graphics.VertexBuffer.New_3(Uno.Runtime.Implementation.Internal.BufferConverters.ToBuffer_1(vertices), 0);
            this.init_DrawCalls();
        };

        Fuse.Drawing.PolygonDrawable.New_1 = function(vertices)
        {
            var inst = new Fuse.Drawing.PolygonDrawable;
            inst._ObjInit(vertices);
            return inst;
        };

    });
