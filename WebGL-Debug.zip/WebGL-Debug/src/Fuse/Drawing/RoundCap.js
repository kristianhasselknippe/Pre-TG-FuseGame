Fuse.Drawing.RoundCap = $CreateClass(
    function() {
        Fuse.Drawing.LineCapImpl.call(this);
    },
    function(S) {
        var I = S.prototype = new Fuse.Drawing.LineCapImpl;

        I.GetType = function()
        {
            return 745;
        };

        I.Create = function(from, to)
        {
            var center_125 = new Uno.Float2;
            var steps = 20;
            var verts = Array.Structs(18, Uno.Float2, 430);
            center_125.op_Assign(Uno.Math.Lerp_2(from, to, 0.5));
            var u = Uno.Float2.op_Subtraction(from, center_125);
            var v = Uno.Float2.New_2(u.Y, -u.X);
            var matrix = Uno.Float2x2.New_2(u, v);

            for (var i = 1; i < 19; i++)
            {
                var f = i / 20.0;
                var r = (f * 3.1415926535897931);
                var rainbow = Uno.Float2.New_2(Uno.Math.Cos_1(r), Uno.Math.Sin_1(r));
                verts[i - 1] = Uno.Float2.op_Addition(center_125, Uno.Vector.Transform_2(rainbow, matrix));
            }

            return $DownCast(Uno.Runtime.Implementation.Internal.ArrayEnumerable__float2.New_1(verts), 32826);
        };

        I._ObjInit_1 = function()
        {
            Fuse.Drawing.LineCapImpl.prototype._ObjInit.call(this);
        };

        Fuse.Drawing.RoundCap.New_1 = function()
        {
            var inst = new Fuse.Drawing.RoundCap;
            inst._ObjInit_1();
            return inst;
        };

    });
