Fuse.Drawing.Brushes = $CreateClass(
    function() {
    },
    function(S) {
        Fuse.Drawing.Brushes.Transparent = null;
        Fuse.Drawing.Brushes.Black = null;
        Fuse.Drawing.Brushes.Silver = null;
        Fuse.Drawing.Brushes.Gray = null;
        Fuse.Drawing.Brushes.White = null;
        Fuse.Drawing.Brushes.Maroon = null;
        Fuse.Drawing.Brushes.Red = null;
        Fuse.Drawing.Brushes.Purple = null;
        Fuse.Drawing.Brushes.Fuchsia = null;
        Fuse.Drawing.Brushes.Green = null;
        Fuse.Drawing.Brushes.Lime = null;
        Fuse.Drawing.Brushes.Olive = null;
        Fuse.Drawing.Brushes.Yellow = null;
        Fuse.Drawing.Brushes.Navy = null;
        Fuse.Drawing.Brushes.Blue = null;
        Fuse.Drawing.Brushes.Teal = null;
        Fuse.Drawing.Brushes.Aqua = null;

        Fuse.Drawing.Brushes._TypeInit = function()
        {
            Fuse.Drawing.Brushes.Transparent = Fuse.Drawing.StaticSolidColor.New_1(Fuse.Drawing.Colors.Black);
            Fuse.Drawing.Brushes.Black = Fuse.Drawing.StaticSolidColor.New_1(Fuse.Drawing.Colors.Black);
            Fuse.Drawing.Brushes.Silver = Fuse.Drawing.StaticSolidColor.New_1(Fuse.Drawing.Colors.Silver);
            Fuse.Drawing.Brushes.Gray = Fuse.Drawing.StaticSolidColor.New_1(Fuse.Drawing.Colors.Gray);
            Fuse.Drawing.Brushes.White = Fuse.Drawing.StaticSolidColor.New_1(Fuse.Drawing.Colors.White);
            Fuse.Drawing.Brushes.Maroon = Fuse.Drawing.StaticSolidColor.New_1(Fuse.Drawing.Colors.Maroon);
            Fuse.Drawing.Brushes.Red = Fuse.Drawing.StaticSolidColor.New_1(Fuse.Drawing.Colors.Red);
            Fuse.Drawing.Brushes.Purple = Fuse.Drawing.StaticSolidColor.New_1(Fuse.Drawing.Colors.Purple);
            Fuse.Drawing.Brushes.Fuchsia = Fuse.Drawing.StaticSolidColor.New_1(Fuse.Drawing.Colors.Fuchsia);
            Fuse.Drawing.Brushes.Green = Fuse.Drawing.StaticSolidColor.New_1(Fuse.Drawing.Colors.Green);
            Fuse.Drawing.Brushes.Lime = Fuse.Drawing.StaticSolidColor.New_1(Fuse.Drawing.Colors.Lime);
            Fuse.Drawing.Brushes.Olive = Fuse.Drawing.StaticSolidColor.New_1(Fuse.Drawing.Colors.Olive);
            Fuse.Drawing.Brushes.Yellow = Fuse.Drawing.StaticSolidColor.New_1(Fuse.Drawing.Colors.Yellow);
            Fuse.Drawing.Brushes.Navy = Fuse.Drawing.StaticSolidColor.New_1(Fuse.Drawing.Colors.Navy);
            Fuse.Drawing.Brushes.Blue = Fuse.Drawing.StaticSolidColor.New_1(Fuse.Drawing.Colors.Blue);
            Fuse.Drawing.Brushes.Teal = Fuse.Drawing.StaticSolidColor.New_1(Fuse.Drawing.Colors.Teal);
            Fuse.Drawing.Brushes.Aqua = Fuse.Drawing.StaticSolidColor.New_1(Fuse.Drawing.Colors.Aqua);
        };

    });
