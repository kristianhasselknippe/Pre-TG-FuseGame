Fuse.Drawing.NonConsecutiveEnumerable = $CreateClass(
    function() {
        this._source = null;
    },
    function(S) {
        var I = S.prototype;

        I.GetType = function()
        {
            return 740;
        };

        I.$II = function(id)
        {
            return [58].indexOf(id) != -1;
        };

        I.GetEnumerator = function()
        {
            return $DownCast(Fuse.Drawing.NonConsecutiveEnumerator.New_1(this._source["Uno.Collections.IEnumerable__float2.GetEnumerator"]()), 32873);
        };

        I._ObjInit = function(source)
        {
            this._source = source;
        };

        Fuse.Drawing.NonConsecutiveEnumerable.New_1 = function(source)
        {
            var inst = new Fuse.Drawing.NonConsecutiveEnumerable;
            inst._ObjInit(source);
            return inst;
        };

        I["Uno.Collections.IEnumerable__float2.GetEnumerator"] = I.GetEnumerator;

    });
