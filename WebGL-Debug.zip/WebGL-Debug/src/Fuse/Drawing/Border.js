Fuse.Drawing.Border = $CreateClass(
    function() {
        this._vertices = null;
        this._offset = 0;
        this._width = 0;
        this._contour = null;
        this._strokeVertices = null;
        this._vbo = null;
        this.Draw_BlendSrcRgb_dcb3f4b0_6_3_7 = 0;
        this.Draw_BlendSrcAlpha_dcb3f4b0_6_5_8 = 0;
        this.Draw_BlendDstRgb_dcb3f4b0_6_4_9 = 0;
        this.Draw_BlendDstAlpha_dcb3f4b0_6_6_10 = 0;
        this._draw_dcb22334 = new Uno.Runtime.Implementation.ShaderBackends.OpenGL.GLDrawCall;
        this._draw_dcb29793 = new Uno.Runtime.Implementation.ShaderBackends.OpenGL.GLDrawCall;
        this._draw_dcb30bf2 = new Uno.Runtime.Implementation.ShaderBackends.OpenGL.GLDrawCall;
        this._draw_dcb38051 = new Uno.Runtime.Implementation.ShaderBackends.OpenGL.GLDrawCall;
        this._draw_dcb3f4b0 = new Uno.Runtime.Implementation.ShaderBackends.OpenGL.GLDrawCall;
    },
    function(S) {
        var I = S.prototype;

        I.GetType = function()
        {
            return 748;
        };

        I.Contour = function()
        {
            this.CalculateStrokeVertices();
            return this._contour;
        };

        I.StrokeVertices = function()
        {
            this.CalculateStrokeVertices();
            return this._strokeVertices;
        };

        I.VertexCount = function()
        {
            return this._vertices.length + 1;
        };

        I.Draw = function(s, ctx)
        {
            var Scale_dcb22334_8_19_2_123 = new Uno.Float2;

            if (this._vertices.length < 2)
            {
                return;
            }

            if (this.StrokeVertices().length < 4)
            {
                return;
            }

            if ($IsOp(s, 728))
            {
                Scale_dcb22334_8_19_2_123.op_Assign(Fuse.Drawing.Border.Draw_Scale_dcb22334_8_19_1($AsOp(s, 728).SizeMode(), ctx.ElementSize(), ($AsOp(s, 728).Texture() == null) ? Uno.Float2.New_1(1.0) : Uno.Float2.op_Implicit($AsOp(s, 728).Texture().Size())));
                {
                    this._draw_dcb22334.BlendEnabled(true);
                    this._draw_dcb22334.BlendSrcRgb(Fuse.Drawing.BlendModeHelpers.GetSrcRgb($AsOp(s, 728).BlendMode()));
                    this._draw_dcb22334.BlendSrcAlpha(Fuse.Drawing.BlendModeHelpers.GetSrcAlpha($AsOp(s, 728).BlendMode()));
                    this._draw_dcb22334.BlendDstRgb(Fuse.Drawing.BlendModeHelpers.GetDstRgb($AsOp(s, 728).BlendMode()));
                    this._draw_dcb22334.BlendDstAlpha(Fuse.Drawing.BlendModeHelpers.GetDstAlpha($AsOp(s, 728).BlendMode()));
                    this._draw_dcb22334.DepthTestEnabled(false);
                    this._draw_dcb22334.DepthFunc(0);
                    this._draw_dcb22334.CullFace(0);
                    this._draw_dcb22334.PrimitiveType(4);
                    this._draw_dcb22334.Const(0, $AsOp(s, 728).Texture() == null);
                    this._draw_dcb22334.Use();
                    this._draw_dcb22334.Attrib_1(1, 4, this._vbo, 16, 0);
                    this._draw_dcb22334.Uniform_14(2, ctx.Transform());
                    this._draw_dcb22334.Uniform_9(3, Fuse.Spaces.VirtualResolution());
                    this._draw_dcb22334.Uniform_9(4, Uno.Float2.op_Multiply_1(($AsOp(s, 728).Texture() == null) ? Uno.Float2.New_1(1.0) : Uno.Float2.op_Implicit($AsOp(s, 728).Texture().Size()), Scale_dcb22334_8_19_2_123));
                    this._draw_dcb22334.Uniform_11(5, $AsOp(s, 728).Color());
                    this._draw_dcb22334.Uniform_8(6, $AsOp(s, 728).Opacity());
                    this._draw_dcb22334.Uniform_8(7, ($AsOp(s, 728).HorizontalAlignment() == 0) ? 0.0 : (($AsOp(s, 728).HorizontalAlignment() == 1) ? Uno.Math.Floor_1((ctx.ElementSize().X - Uno.Float2.op_Multiply_1(($AsOp(s, 728).Texture() == null) ? Uno.Float2.New_1(1.0) : Uno.Float2.op_Implicit($AsOp(s, 728).Texture().Size()), Scale_dcb22334_8_19_2_123).X) * 0.5) : (($AsOp(s, 728).HorizontalAlignment() == 2) ? (ctx.ElementSize().X - Uno.Float2.op_Multiply_1(($AsOp(s, 728).Texture() == null) ? Uno.Float2.New_1(1.0) : Uno.Float2.op_Implicit($AsOp(s, 728).Texture().Size()), Scale_dcb22334_8_19_2_123).X) : 0.0)));
                    this._draw_dcb22334.Uniform_8(8, ($AsOp(s, 728).VerticalAlignment() == 0) ? 0.0 : (($AsOp(s, 728).VerticalAlignment() == 4) ? Uno.Math.Floor_1((ctx.ElementSize().Y - Uno.Float2.op_Multiply_1(($AsOp(s, 728).Texture() == null) ? Uno.Float2.New_1(1.0) : Uno.Float2.op_Implicit($AsOp(s, 728).Texture().Size()), Scale_dcb22334_8_19_2_123).Y) * 0.5) : (($AsOp(s, 728).VerticalAlignment() == 5) ? (ctx.ElementSize().Y - Uno.Float2.op_Multiply_1(($AsOp(s, 728).Texture() == null) ? Uno.Float2.New_1(1.0) : Uno.Float2.op_Implicit($AsOp(s, 728).Texture().Size()), Scale_dcb22334_8_19_2_123).Y) : 0.0)));
                    this._draw_dcb22334.Sampler_3(9, $AsOp(s, 728).Texture(), Uno.Graphics.SamplerState.New_1($AsOp(s, 728).MinFilter(), $AsOp(s, 728).MagFilter(), 10497));
                    this._draw_dcb22334.DrawArrays(this.StrokeVertices().length);
                }
            }
            else if ($IsOp(s, 725))
            {
                {
                    this._draw_dcb29793.BlendEnabled(true);
                    this._draw_dcb29793.BlendSrcRgb(Fuse.Drawing.BlendModeHelpers.GetSrcRgb($AsOp(s, 725).BlendMode()));
                    this._draw_dcb29793.BlendSrcAlpha(Fuse.Drawing.BlendModeHelpers.GetSrcAlpha($AsOp(s, 725).BlendMode()));
                    this._draw_dcb29793.BlendDstRgb(Fuse.Drawing.BlendModeHelpers.GetDstRgb($AsOp(s, 725).BlendMode()));
                    this._draw_dcb29793.BlendDstAlpha(Fuse.Drawing.BlendModeHelpers.GetDstAlpha($AsOp(s, 725).BlendMode()));
                    this._draw_dcb29793.DepthTestEnabled(false);
                    this._draw_dcb29793.DepthFunc(0);
                    this._draw_dcb29793.CullFace(0);
                    this._draw_dcb29793.PrimitiveType(4);
                    this._draw_dcb29793.Use();
                    this._draw_dcb29793.Attrib_1(0, 4, this._vbo, 16, 0);
                    this._draw_dcb29793.Uniform_14(1, ctx.Transform());
                    this._draw_dcb29793.Uniform_9(2, Fuse.Spaces.VirtualResolution());
                    this._draw_dcb29793.Uniform_11(3, $AsOp(s, 725).Color());
                    this._draw_dcb29793.Uniform_8(4, $AsOp(s, 725).Opacity());
                    this._draw_dcb29793.DrawArrays(this.StrokeVertices().length);
                }
            }
            else if ($IsOp(s, 724))
            {
                var Colors_dcb30bf2_8_9_4 = Fuse.Drawing.Border.Draw_Colors_dcb30bf2_8_9_3($AsOp(s, 724).SortedStops());
                var Offsets_dcb30bf2_8_8_6 = Fuse.Drawing.Border.Draw_Offsets_dcb30bf2_8_8_5($AsOp(s, 724).SortedStops());
                {
                    this._draw_dcb30bf2.BlendEnabled(true);
                    this._draw_dcb30bf2.BlendSrcRgb(Fuse.Drawing.BlendModeHelpers.GetSrcRgb($AsOp(s, 724).BlendMode()));
                    this._draw_dcb30bf2.BlendSrcAlpha(Fuse.Drawing.BlendModeHelpers.GetSrcAlpha($AsOp(s, 724).BlendMode()));
                    this._draw_dcb30bf2.BlendDstRgb(Fuse.Drawing.BlendModeHelpers.GetDstRgb($AsOp(s, 724).BlendMode()));
                    this._draw_dcb30bf2.BlendDstAlpha(Fuse.Drawing.BlendModeHelpers.GetDstAlpha($AsOp(s, 724).BlendMode()));
                    this._draw_dcb30bf2.DepthTestEnabled(false);
                    this._draw_dcb30bf2.DepthFunc(0);
                    this._draw_dcb30bf2.CullFace(0);
                    this._draw_dcb30bf2.PrimitiveType(4);
                    this._draw_dcb30bf2.Const_1(0, Colors_dcb30bf2_8_9_4.length);
                    this._draw_dcb30bf2.Const_1(1, Offsets_dcb30bf2_8_8_6.length);
                    this._draw_dcb30bf2.Use();
                    this._draw_dcb30bf2.Attrib_1(2, 4, this._vbo, 16, 0);
                    this._draw_dcb30bf2.Uniform_14(3, ctx.Transform());
                    this._draw_dcb30bf2.Uniform_9(4, Fuse.Spaces.VirtualResolution());
                    this._draw_dcb30bf2.Uniform_9(5, ctx.ElementSize());
                    this._draw_dcb30bf2.Uniform_9(6, $AsOp(s, 724).EndPoint());
                    this._draw_dcb30bf2.Uniform_9(7, $AsOp(s, 724).StartPoint());
                    this._draw_dcb30bf2.Uniform_18(8, Colors_dcb30bf2_8_9_4);
                    this._draw_dcb30bf2.Uniform_15(9, Offsets_dcb30bf2_8_8_6);
                    this._draw_dcb30bf2.Uniform_8(10, $AsOp(s, 724).Opacity());
                    this._draw_dcb30bf2.DrawArrays(this.StrokeVertices().length);
                }
            }
            else if ($IsOp(s, 38))
            {
                {
                    this._draw_dcb38051.BlendEnabled(true);
                    this._draw_dcb38051.BlendSrcRgb(Fuse.Drawing.BlendModeHelpers.GetSrcRgb($AsOp(s, 38).BlendMode()));
                    this._draw_dcb38051.BlendSrcAlpha(Fuse.Drawing.BlendModeHelpers.GetSrcAlpha($AsOp(s, 38).BlendMode()));
                    this._draw_dcb38051.BlendDstRgb(Fuse.Drawing.BlendModeHelpers.GetDstRgb($AsOp(s, 38).BlendMode()));
                    this._draw_dcb38051.BlendDstAlpha(Fuse.Drawing.BlendModeHelpers.GetDstAlpha($AsOp(s, 38).BlendMode()));
                    this._draw_dcb38051.DepthTestEnabled(false);
                    this._draw_dcb38051.DepthFunc(0);
                    this._draw_dcb38051.CullFace(0);
                    this._draw_dcb38051.PrimitiveType(4);
                    this._draw_dcb38051.Use();
                    this._draw_dcb38051.Attrib_1(0, 4, this._vbo, 16, 0);
                    this._draw_dcb38051.Uniform_14(1, ctx.Transform());
                    this._draw_dcb38051.Uniform_9(2, Fuse.Spaces.VirtualResolution());
                    this._draw_dcb38051.Uniform_9(3, ctx.ElementSize());
                    this._draw_dcb38051.Uniform_8(4, $AsOp(s, 38).Split());
                    this._draw_dcb38051.Uniform_11(5, $AsOp(s, 38).Right());
                    this._draw_dcb38051.Uniform_11(6, $AsOp(s, 38).Left());
                    this._draw_dcb38051.Uniform_8(7, $AsOp(s, 38).Opacity());
                    this._draw_dcb38051.DrawArrays(this.StrokeVertices().length);
                }
            }
            else if ($IsOp(s, 726))
            {
                {
                    this._draw_dcb3f4b0.BlendEnabled(true);
                    this._draw_dcb3f4b0.BlendSrcRgb(this.Draw_BlendSrcRgb_dcb3f4b0_6_3_7);
                    this._draw_dcb3f4b0.BlendSrcAlpha(this.Draw_BlendSrcAlpha_dcb3f4b0_6_5_8);
                    this._draw_dcb3f4b0.BlendDstRgb(this.Draw_BlendDstRgb_dcb3f4b0_6_4_9);
                    this._draw_dcb3f4b0.BlendDstAlpha(this.Draw_BlendDstAlpha_dcb3f4b0_6_6_10);
                    this._draw_dcb3f4b0.DepthTestEnabled(false);
                    this._draw_dcb3f4b0.DepthFunc(0);
                    this._draw_dcb3f4b0.CullFace(0);
                    this._draw_dcb3f4b0.PrimitiveType(4);
                    this._draw_dcb3f4b0.Use();
                    this._draw_dcb3f4b0.Attrib_1(0, 4, this._vbo, 16, 0);
                    this._draw_dcb3f4b0.Uniform_14(1, ctx.Transform());
                    this._draw_dcb3f4b0.Uniform_9(2, Fuse.Spaces.VirtualResolution());
                    this._draw_dcb3f4b0.Uniform_11(3, $AsOp(s, 726).Color());
                    this._draw_dcb3f4b0.DrawArrays(this.StrokeVertices().length);
                }
            }
        };

        I.Dispose = function()
        {
            this.free_DrawCalls();
            this._vbo.Dispose();
        };

        I.CalculateStrokeVertices = function()
        {
            var last_124 = new Uno.Float2;
            var current_125 = new Uno.Float2;
            var next_126 = new Uno.Float2;
            var lv_127 = new Uno.Float2;
            var rv_128 = new Uno.Float2;
            var bisectNormal_129 = new Uno.Float2;

            if (this._strokeVertices != null)
            {
                return;
            }

            if (this._vertices.length < 2)
            {
                this._strokeVertices = Array.Structs(0, Uno.Float4, 432);
                this._contour = Fuse.Drawing.Contour.New_1(true, Array.Structs(0, Uno.Float2, 430));
                return;
            }

            var vertices = Array.Structs(this.VertexCount() * 2, Uno.Float4, 432);
            var shrinkedContour = Array.Structs(this.VertexCount(), Uno.Float2, 430);
            var v = 0;
            var s = 0;
            var dist = 0.0;

            for (var i = 0; i < this.VertexCount(); i++)
            {
                last_124.op_Assign(this.GetVertex(i - 1));
                current_125.op_Assign(this.GetVertex(i));
                next_126.op_Assign(this.GetVertex(i + 1));
                var len = Uno.Vector.Length(Uno.Float2.op_Subtraction(last_124, current_125));

                if (i > 0)
                {
                    dist = dist + len;
                }

                if (len < 1e-05)
                {
                    continue;
                }

                lv_127.op_Assign(Uno.Vector.Normalize(Uno.Float2.op_Subtraction(current_125, last_124)));
                rv_128.op_Assign(Uno.Vector.Normalize(Uno.Float2.op_Subtraction(next_126, current_125)));
                var lvn = Uno.Float2.New_2(-lv_127.Y, lv_127.X);
                var rvn = Uno.Float2.New_2(-rv_128.Y, rv_128.X);
                var bn0 = Uno.Float2.op_Division_1(Uno.Float2.op_Addition(rvn, lvn), 2.0);
                bisectNormal_129.op_Assign(((Uno.Math.Abs_1(bn0.X) + Uno.Math.Abs_1(bn0.Y)) < 1e-05) ? lvn : Uno.Vector.Normalize(bn0));
                var outer = new Uno.Float4;
                var inner = new Uno.Float4;
                var angle = Uno.Geometry.Collision2D.AngleBetween(lv_127, bisectNormal_129);

                if (((angle < 0.2) || (angle > 2.94159269)) || (len < 1.0))
                {
                    var lvo = Uno.Float2.op_Addition(current_125, Uno.Float2.op_Multiply(bisectNormal_129, this._width + this._offset));
                    var lvi = Uno.Float2.op_Addition(current_125, Uno.Float2.op_Multiply(bisectNormal_129, this._offset));
                    outer = Uno.Float4.New_3(lvo, 0.0, dist);
                    inner = Uno.Float4.New_3(lvi, 1.0, dist);
                }
                else
                {
                    var lvo = Uno.Float2.op_Addition(last_124, Uno.Float2.op_Multiply(lvn, this._width + this._offset));
                    var lvi = Uno.Float2.op_Addition(last_124, Uno.Float2.op_Multiply(lvn, this._offset));
                    outer = Uno.Float4.New_3(Uno.Geometry.Collision2D.LineIntersectionPointVector(lvo, lv_127, current_125, bisectNormal_129), 0.0, dist);
                    inner = Uno.Float4.New_3(Uno.Geometry.Collision2D.LineIntersectionPointVector(lvi, lv_127, current_125, bisectNormal_129), 1.0, dist);
                }

                vertices[v++].op_Assign(outer);
                vertices[v++].op_Assign(inner);
                shrinkedContour[s++].op_Assign(Uno.Float2.New_2(inner.X, inner.Y));
            }

            this._strokeVertices = vertices;
            this._vbo = Uno.Graphics.VertexBuffer.New_3(Uno.Runtime.Implementation.Internal.BufferConverters.ToBuffer_3(vertices), 0);
            this._contour = Fuse.Drawing.Contour.New_1(true, shrinkedContour);
        };

        I.GetVertex = function(indexWrap)
        {
            while (indexWrap < 0)
            {
                indexWrap = indexWrap + this._vertices.length;
            }

            while (indexWrap >= this._vertices.length)
            {
                indexWrap = indexWrap - this._vertices.length;
            }

            return this._vertices[indexWrap];
        };

        I.init_DrawCalls = function()
        {
            this.Draw_BlendSrcRgb_dcb3f4b0_6_3_7 = Fuse.Drawing.BlendModeHelpers.GetSrcRgb(0);
            this.Draw_BlendSrcAlpha_dcb3f4b0_6_5_8 = Fuse.Drawing.BlendModeHelpers.GetSrcAlpha(0);
            this.Draw_BlendDstRgb_dcb3f4b0_6_4_9 = Fuse.Drawing.BlendModeHelpers.GetDstRgb(0);
            this.Draw_BlendDstAlpha_dcb3f4b0_6_6_10 = Fuse.Drawing.BlendModeHelpers.GetDstAlpha(0);
            this._draw_dcb22334 = Uno.Runtime.Implementation.ShaderBackends.OpenGL.GLDrawCall.New_1($DownCast(Uno.Runtime.Implementation.Internal.BundleRegistry.Get(9), 383));
            this._draw_dcb29793 = Uno.Runtime.Implementation.ShaderBackends.OpenGL.GLDrawCall.New_1($DownCast(Uno.Runtime.Implementation.Internal.BundleRegistry.Get(10), 383));
            this._draw_dcb30bf2 = Uno.Runtime.Implementation.ShaderBackends.OpenGL.GLDrawCall.New_1($DownCast(Uno.Runtime.Implementation.Internal.BundleRegistry.Get(11), 383));
            this._draw_dcb38051 = Uno.Runtime.Implementation.ShaderBackends.OpenGL.GLDrawCall.New_1($DownCast(Uno.Runtime.Implementation.Internal.BundleRegistry.Get(12), 383));
            this._draw_dcb3f4b0 = Uno.Runtime.Implementation.ShaderBackends.OpenGL.GLDrawCall.New_1($DownCast(Uno.Runtime.Implementation.Internal.BundleRegistry.Get(13), 383));
        };

        I.free_DrawCalls = function()
        {
        };

        Fuse.Drawing.Border.Draw_Scale_dcb22334_8_19_1 = function(Scale_8_19_5, Scale_8_19_6, Scale_8_19_7)
        {
            var Scale_8_19_6_130 = new Uno.Float2;
            var Scale_8_19_7_131 = new Uno.Float2;
            Scale_8_19_6_130.op_Assign(Scale_8_19_6);
            Scale_8_19_7_131.op_Assign(Scale_8_19_7);

            switch (Scale_8_19_5)
            {
                case 2:
                {
                    return Uno.Float2.New_1((Scale_8_19_6_130.Ratio() > Scale_8_19_7_131.Ratio()) ? (Scale_8_19_6_130.Y / Scale_8_19_7_131.Y) : (Scale_8_19_6_130.X / Scale_8_19_7_131.X));
                }
                case 1:
                {
                    return Uno.Float2.New_1((Scale_8_19_6_130.Ratio() > Scale_8_19_7_131.Ratio()) ? (Scale_8_19_6_130.X / Scale_8_19_7_131.X) : (Scale_8_19_6_130.Y / Scale_8_19_7_131.Y));
                }
                case 4:
                {
                    return Uno.Float2.New_1(Scale_8_19_6_130.X / Scale_8_19_7_131.Y);
                }
                case 5:
                {
                    return Uno.Float2.New_1(Scale_8_19_6_130.Y / Scale_8_19_7_131.Y);
                }
                case 3:
                {
                    return Uno.Float2.op_Division(Scale_8_19_6_130, Scale_8_19_7_131);
                }
            }

            return Uno.Float2.New_1(1.0);
        };

        Fuse.Drawing.Border.Draw_Colors_dcb30bf2_8_9_3 = function(Colors_8_9_4)
        {
            var cols = Array.Structs(Uno.Math.Max_8(Colors_8_9_4.length, 1), Uno.Float4, 432);

            for (var i = 0; i < Colors_8_9_4.length; i++)
            {
                cols[i].op_Assign(Colors_8_9_4[i].Color());
            }

            return cols;
        };

        Fuse.Drawing.Border.Draw_Offsets_dcb30bf2_8_8_5 = function(Offsets_8_8_5)
        {
            var ofs = Array.Zeros(Uno.Math.Max_8(Offsets_8_8_5.length, 1), 429);

            for (var i = 0; i < Offsets_8_8_5.length; i++)
            {
                ofs[i] = Offsets_8_8_5[i].Offset();
            }

            return ofs;
        };

        I._ObjInit = function(vertices, offset, width)
        {
            this._vertices = vertices;
            this._offset = offset;
            this._width = width;
            this.init_DrawCalls();
        };

        Fuse.Drawing.Border.New_1 = function(vertices, offset, width)
        {
            var inst = new Fuse.Drawing.Border;
            inst._ObjInit(vertices, offset, width);
            return inst;
        };

    });
