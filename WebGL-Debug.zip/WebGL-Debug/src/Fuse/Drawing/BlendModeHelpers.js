Fuse.Drawing.BlendModeHelpers = $CreateClass(
    function() {
    },
    function(S) {
        Fuse.Drawing.BlendModeHelpers._invalidBlendMode = null;

        Fuse.Drawing.BlendModeHelpers.GetSrcRgb = function(mode)
        {
            switch (mode)
            {
                case 0:
                {
                    return 1;
                }
                case 1:
                {
                    return 1;
                }
                case 2:
                {
                    return 1;
                }
                case 3:
                {
                    return 8;
                }
                default:
                {
                    throw new $Error(Uno.Exception.New_1(Fuse.Drawing.BlendModeHelpers._invalidBlendMode));
                }
            }
        };

        Fuse.Drawing.BlendModeHelpers.GetDstRgb = function(mode)
        {
            switch (mode)
            {
                case 0:
                {
                    return 3;
                }
                case 1:
                {
                    return 1;
                }
                case 2:
                {
                    return 5;
                }
                case 3:
                {
                    return 3;
                }
                default:
                {
                    throw new $Error(Uno.Exception.New_1(Fuse.Drawing.BlendModeHelpers._invalidBlendMode));
                }
            }
        };

        Fuse.Drawing.BlendModeHelpers.GetSrcAlpha = function(mode)
        {
            switch (mode)
            {
                case 0:
                {
                    return 1;
                }
                case 1:
                {
                    return 1;
                }
                case 2:
                {
                    return 1;
                }
                case 3:
                {
                    return 1;
                }
                default:
                {
                    throw new $Error(Uno.Exception.New_1(Fuse.Drawing.BlendModeHelpers._invalidBlendMode));
                }
            }
        };

        Fuse.Drawing.BlendModeHelpers.GetDstAlpha = function(mode)
        {
            switch (mode)
            {
                case 0:
                {
                    return 3;
                }
                case 1:
                {
                    return 3;
                }
                case 2:
                {
                    return 3;
                }
                case 3:
                {
                    return 3;
                }
                default:
                {
                    throw new $Error(Uno.Exception.New_1(Fuse.Drawing.BlendModeHelpers._invalidBlendMode));
                }
            }
        };

        Fuse.Drawing.BlendModeHelpers._TypeInit = function()
        {
            Fuse.Drawing.BlendModeHelpers._invalidBlendMode = "Invalid blend mode";
        };

    });
