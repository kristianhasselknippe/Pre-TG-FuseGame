Fuse.Drawing.Contour = $CreateClass(
    function() {
        this._vertices = null;
        this._count = 0;
        this._IsClosed = false;
    },
    function(S) {
        var I = S.prototype;

        I.GetType = function()
        {
            return 742;
        };

        I.VertexCount = function()
        {
            return this._count;
        };

        I.Vertices = function()
        {
            return this._vertices.Items();
        };

        I.Item = function(vertexIndex)
        {
            if (this.IsClosed())
            {
                while (vertexIndex < 0)
                {
                    vertexIndex = vertexIndex + this.VertexCount();
                }

                while (vertexIndex >= this.VertexCount())
                {
                    vertexIndex = vertexIndex - this.VertexCount();
                }

                return this._vertices.Item(vertexIndex);
            }
            else
            {
                if (vertexIndex < 0)
                {
                    return Uno.Float2.op_Addition(this._vertices.Item(0), Uno.Float2.op_Subtraction(this._vertices.Item(0), this._vertices.Item(1)));
                }

                if (vertexIndex >= this._vertices.Length())
                {
                    return Uno.Float2.op_Addition(this._vertices.Item(this._vertices.Length() - 1), Uno.Float2.op_Subtraction(this._vertices.Item(this._vertices.Length() - 1), this._vertices.Item(this._vertices.Length() - 2)));
                }

                return this._vertices.Item(vertexIndex);
            }
        };

        I.IsClosed = function(value)
        {
            if (value !== undefined)
            {
                this._IsClosed = value;
            }
            else
            {
                return this._IsClosed;
            }
        };

        I._ObjInit = function(isClosed, vertices)
        {
            this._ObjInit_1(isClosed, $DownCast(Uno.Runtime.Implementation.Internal.ArrayEnumerable__float2.New_1(vertices), 32826));
        };

        Fuse.Drawing.Contour.New_1 = function(isClosed, vertices)
        {
            var inst = new Fuse.Drawing.Contour;
            inst._ObjInit(isClosed, vertices);
            return inst;
        };

        I._ObjInit_1 = function(isClosed, vertices)
        {
            this._vertices = Fuse.Drawing.Cache__float2.New_2(Fuse.Drawing.NonConsecutiveExtension.NonConsecutive(vertices));
            this.IsClosed(isClosed);
            this._count = (isClosed && Uno.Float2.op_Equality(this._vertices.Item(0), this._vertices.Item(this._vertices.Length() - 1))) ? (this._vertices.Length() - 1) : this._vertices.Length();
        };

        Fuse.Drawing.Contour.New_2 = function(isClosed, vertices)
        {
            var inst = new Fuse.Drawing.Contour;
            inst._ObjInit_1(isClosed, vertices);
            return inst;
        };

    });
