Fuse.Drawing.RendererContext = $CreateClass(
    function() {
        this._Transform = new Uno.Float4x4;
        this._ElementSize = new Uno.Float2;
    },
    function(S) {
        var I = S.prototype;

        I.GetType = function()
        {
            return 750;
        };

        I.Transform = function(value)
        {
            if (value !== undefined)
            {
                this._Transform.op_Assign(value);
            }
            else
            {
                return this._Transform;
            }
        };

        I.ElementSize = function(value)
        {
            if (value !== undefined)
            {
                this._ElementSize.op_Assign(value);
            }
            else
            {
                return this._ElementSize;
            }
        };

        I._ObjInit_1 = function(transform, elementSize)
        {
            this.Transform(transform);
            this.ElementSize(elementSize);
        };

        Fuse.Drawing.RendererContext.New_2 = function(transform, elementSize)
        {
            var inst = new Fuse.Drawing.RendererContext;
            inst._ObjInit_1(transform, elementSize);
            return inst;
        };

    });
