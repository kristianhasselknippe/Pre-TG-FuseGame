Fuse.Drawing.ContourEnumerator = $CreateClass(
    function() {
        this._currentHead = null;
        this._current = null;
        this._scale = new Uno.Float2;
    },
    function(S) {
        var I = S.prototype;

        I.GetType = function()
        {
            return 752;
        };

        I.$II = function(id)
        {
            return [106, 418, 54].indexOf(id) != -1;
        };

        I.Current = function()
        {
            return this._current;
        };

        I.MoveNext = function()
        {
            var v_124 = new Uno.Float2;

            if (this._currentHead == null)
            {
                return false;
            }

            var isClosed = $IsOp(this._currentHead, 761);
            var revPath = Uno.Collections.List__Fuse_Drawing_PathGeometry.New_1();

            do
            {
                revPath.Add(this._currentHead);
                this._currentHead = this._currentHead.RemoveLast();
            }
            while ((this._currentHead != null) && !this._currentHead.EndsContour());

            var vertices = Uno.Collections.List__float2.New_1();

            for (var i = revPath.Count() - 1; i >= 0; --i)
            {
                var headVertices = revPath.Item(i).EvaluateLast();

                for (var enum_123 = headVertices["Uno.Collections.IEnumerable__float2.GetEnumerator"](); enum_123["Uno.Collections.IEnumerator.MoveNext"](); )
                {
                    v_124.op_Assign(enum_123["Uno.Collections.IEnumerator__float2.Current"]());
                    vertices.Add(Uno.Float2.op_Multiply_1(v_124, this._scale));
                }
            }

            this._current = Fuse.Drawing.Contour.New_2(isClosed, $DownCast(vertices, 32826));
            return true;
        };

        I.Dispose = function()
        {
        };

        I._ObjInit = function(head, scale)
        {
            this._currentHead = head;
            this._scale.op_Assign(scale);
        };

        Fuse.Drawing.ContourEnumerator.New_1 = function(head, scale)
        {
            var inst = new Fuse.Drawing.ContourEnumerator;
            inst._ObjInit(head, scale);
            return inst;
        };

        I["Uno.Collections.IEnumerator__Fuse_Drawing_Contour.Current"] = I.Current;
        I["Uno.IDisposable.Dispose"] = I.Dispose;
        I["Uno.Collections.IEnumerator.MoveNext"] = I.MoveNext;

    });
