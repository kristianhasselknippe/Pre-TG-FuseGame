Fuse.RenderTargetEntry = $CreateClass(
    function() {
        this.RenderTarget = null;
        this.Viewport = null;
        this.Scissor = null;
        this.Aspect = 0;
    },
    function(S) {
        var I = S.prototype;

        I.GetType = function()
        {
            return 916;
        };

        I._ObjInit_1 = function(rt, aspect, viewport, scissor)
        {
            this.RenderTarget = rt;
            this.Aspect = aspect;
            this.Viewport = viewport;
            this.Scissor = scissor;
        };

        Fuse.RenderTargetEntry.New_2 = function(rt, aspect, viewport, scissor)
        {
            var inst = new Fuse.RenderTargetEntry;
            inst._ObjInit_1(rt, aspect, viewport, scissor);
            return inst;
        };

    });
