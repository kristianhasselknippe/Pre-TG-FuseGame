Fuse.Input = $CreateClass(
    function() {
    },
    function(S) {
        Fuse.Input._globalListeners = null;
        Fuse.Input._unhandledListeners = null;
        Fuse.Input._pointersDown = null;
        Fuse.Input._PointerPressedTriggers = null;
        Fuse.Input._PointerReleasedTriggers = null;
        Fuse.Input._softCapturers = null;
        Fuse.Input._softCapturerViewProviders = null;
        Fuse.Input._hardCapturers = null;
        Fuse.Input._hardCapturerViewProviders = null;
        Fuse.Input._lastHitNodes = null;
        Fuse.Input._PointerCoord = new Uno.Float2;

        Fuse.Input.PointerCoord = function(value)
        {
            if (value !== undefined)
            {
                Fuse.Input._PointerCoord.op_Assign(value);
            }
            else
            {
                return Fuse.Input._PointerCoord;
            }
        };

        Fuse.Input.NotifyUpdate = function()
        {
            Fuse.Input._PointerPressedTriggers.Clear();
            Fuse.Input._PointerReleasedTriggers.Clear();
        };

        Fuse.Input.IsPointerPressed_1 = function(pointIndex)
        {
            var p_132 = new Uno.Collections.KeyValuePair__int__Fuse_Input_Pointer;

            for (var enum_124 = Fuse.Input._pointersDown.GetEnumerator(); enum_124.MoveNext(); )
            {
                p_132.op_Assign(enum_124.Current());

                if (p_132.Key() == pointIndex)
                {
                    return true;
                }
            }

            return false;
        };

        Fuse.Input.GetSoftCapturer = function(pointIndex)
        {
            if (Fuse.Input._softCapturers.ContainsKey(pointIndex))
            {
                return Uno.Collections.EnumerableExtensions.FirstOrDefault__Fuse_INode_1($DownCast(Fuse.Input._softCapturers.Item(pointIndex), 32843));
            }
            else
            {
                return null;
            }
        };

        Fuse.Input.GetSoftCapturerViewProvider = function(pointIndex)
        {
            if (Fuse.Input._softCapturerViewProviders.ContainsKey(pointIndex))
            {
                return Uno.Collections.EnumerableExtensions.FirstOrDefault__Fuse_ViewProvider_1($DownCast(Fuse.Input._softCapturerViewProviders.Item(pointIndex), 32844));
            }
            else
            {
                return null;
            }
        };

        Fuse.Input.IsSoftCaptured = function(pointIndex, softCapturer)
        {
            if (Fuse.Input._softCapturers.ContainsKey(pointIndex))
            {
                var sc = Fuse.Input._softCapturers.Item(pointIndex);
                return sc["Uno.Collections.ICollection__Fuse_INode.Contains"](softCapturer);
            }

            return false;
        };

        Fuse.Input.SoftCapture = function(pointIndex, viewProvider, softCapturer)
        {
            if (Fuse.Input.GetHardCapturer(pointIndex) != null)
            {
                return;
            }

            if (!Fuse.Input._softCapturers.ContainsKey(pointIndex))
            {
                Fuse.Input._softCapturers.Add(pointIndex, $DownCast(Uno.Collections.List__Fuse_INode.New_1(), 32926));
            }

            Fuse.Input._softCapturers.Item(pointIndex)["Uno.Collections.ICollection__Fuse_INode.Add"](softCapturer);

            if (!Fuse.Input._softCapturerViewProviders.ContainsKey(pointIndex))
            {
                Fuse.Input._softCapturerViewProviders.Add(pointIndex, $DownCast(Uno.Collections.List__Fuse_ViewProvider.New_1(), 32927));
            }

            Fuse.Input._softCapturerViewProviders.Item(pointIndex)["Uno.Collections.ICollection__Fuse_ViewProvider.Add"](viewProvider);
        };

        Fuse.Input.ReleaseSoftCapture = function(pointIndex, viewProvider, softCapturer)
        {
            if (Fuse.Input._softCapturers.ContainsKey(pointIndex))
            {
                var sc = Fuse.Input._softCapturers.Item(pointIndex);
                sc["Uno.Collections.ICollection__Fuse_INode.Remove"](softCapturer);
            }

            if (Fuse.Input._softCapturerViewProviders.ContainsKey(pointIndex))
            {
                var scvp = Fuse.Input._softCapturerViewProviders.Item(pointIndex);
                scvp["Uno.Collections.ICollection__Fuse_ViewProvider.Remove"](viewProvider);
            }
        };

        Fuse.Input.GetHardCapturer = function(pointIndex)
        {
            if (Fuse.Input._hardCapturers.ContainsKey(pointIndex))
            {
                return Fuse.Input._hardCapturers.Item(pointIndex);
            }
            else
            {
                return null;
            }
        };

        Fuse.Input.GetHardCapturerViewProvider = function(pointIndex)
        {
            if (Fuse.Input._hardCapturerViewProviders.ContainsKey(pointIndex))
            {
                return Fuse.Input._hardCapturerViewProviders.Item(pointIndex);
            }
            else
            {
                return null;
            }
        };

        Fuse.Input.HardCapture = function(pointIndex, viewProvider, capturer)
        {
            if (Fuse.Input._softCapturers.ContainsKey(pointIndex))
            {
                var sc = Fuse.Input._softCapturers.Item(pointIndex);

                for (var i = 0; i < sc["Uno.Collections.ICollection__Fuse_INode.Count"](); i++)
                {
                    if (sc["Uno.Collections.IList__Fuse_INode.Item"](i) == capturer)
                    {
                        continue;
                    }

                    sc["Uno.Collections.IList__Fuse_INode.Item"](i)["Fuse.INode.RaiseEvent"](Fuse.LostSoftCaptureArgs.New_2());
                }

                sc["Uno.Collections.ICollection__Fuse_INode.Clear"]();
            }

            if (Fuse.Input._softCapturerViewProviders.ContainsKey(pointIndex))
            {
                Fuse.Input._softCapturerViewProviders.Remove(pointIndex);
            }

            Fuse.Input._hardCapturers.Item(pointIndex, capturer);
            Fuse.Input._hardCapturerViewProviders.Item(pointIndex, viewProvider);
        };

        Fuse.Input.ReleaseHardCapture = function(pointIndex)
        {
            if (Fuse.Input._hardCapturers.ContainsKey(pointIndex))
            {
                Fuse.Input._hardCapturers.Remove(pointIndex);
            }

            if (Fuse.Input._hardCapturerViewProviders.ContainsKey(pointIndex))
            {
                Fuse.Input._hardCapturerViewProviders.Remove(pointIndex);
            }
        };

        Fuse.Input.RaisePointerPressed = function(root, data)
        {
            var e = Fuse.PointerPressedArgs.New_2(data);
            var target = Fuse.Input.RoutePointerEvent(e, root);
            return Fuse.Input.RaisePointerPressedInternal(target, e);
        };

        Fuse.Input.RaisePointerMoved = function(root, data)
        {
            var e = Fuse.PointerMovedArgs.New_2(data);
            var target = Fuse.Input.RoutePointerEvent(e, root);
            return Fuse.Input.RaisePointerMovedInternal(target, e);
        };

        Fuse.Input.RaisePointerWheelChanged = function(root, data)
        {
            var e = Fuse.PointerWheelChangedArgs.New_2(data);
            var target = Fuse.Input.RoutePointerEvent(e, root);
            return Fuse.Input.RaisePointerWheelChangedInternal(target, e);
        };

        Fuse.Input.RaisePointerLeft = function(root, data)
        {
            var args = Fuse.PointerLeaveArgs.New_2(data);
            Fuse.Input.ProcessPointerEnterLeave(Array.Sized(0, 949), args);
            Fuse.Input.RaiseEvent(null, args);
            return args;
        };

        Fuse.Input.RaisePointerReleased = function(root, data)
        {
            var e = Fuse.PointerReleasedArgs.New_2(data);
            var target = Fuse.Input.RoutePointerEvent(e, root);
            return Fuse.Input.RaisePointerReleasedInternal(target, e);
        };

        Fuse.Input.RoutePointerEvent = function(plainEvent, root)
        {
            var n = Fuse.Input.RouteToSoftCapturer(plainEvent);

            if (n != null)
            {
                return n;
            }

            n = Fuse.Input.RouteToCapturer(plainEvent);

            if (n != null)
            {
                return n;
            }

            n = Fuse.Input.RouteToHit(plainEvent, root);

            if (n != null)
            {
                return n;
            }

            return null;
        };

        Fuse.Input.RouteToSoftCapturer = function(args)
        {
            var sc = Fuse.Input.GetSoftCapturer(args.PointIndex());

            if (sc == null)
            {
                return null;
            }

            args.Reroute(Fuse.Input.GetSoftCapturerViewProvider(args.PointIndex()));
            return sc;
        };

        Fuse.Input.RouteToCapturer = function(args)
        {
            var capturer = Fuse.Input.GetHardCapturer(args.PointIndex());

            if (capturer == null)
            {
                return null;
            }

            args.Reroute(Fuse.Input.GetHardCapturerViewProvider(args.PointIndex()));
            return capturer;
        };

        Fuse.Input.RouteToHit = function(args, root)
        {
            var results = Uno.Collections.EnumerableExtensions.ToArray__Fuse_HitTestResult(Fuse.Input.HitTest(root, args.PointCoord(), args.Camera()));
            Fuse.Input.ProcessPointerEnterLeave(results, args);

            if (results.length == 0)
            {
                return null;
            }

            return Fuse.Input.RouteToNearestHit(results, args);
        };

        Fuse.Input.RouteToNearestHit = function(results, args)
        {
            var hit = Fuse.Input.FindNearestHit(results);

            if (hit != null)
            {
                args.Reroute(Fuse.ViewProviderSnapshot.New_1(hit.Camera(), hit.Viewport()));
                return hit.HitObject();
            }
            else
            {
                return null;
            }
        };

        Fuse.Input.ProcessPointerEnterLeave = function(results, args)
        {
            var lastHitList = $DownCast(Fuse.Input.GetLastHitList(args.PointIndex()), 32926);
            var currentHits = (results.length > 0) ? Fuse.Input.FindAncestorHits(results[0].HitObject()) : $DownCast(Uno.Collections.List__Fuse_INode.New_1(), 32926);

            for (var i = 1; i < results.length; ++i)
            {
                currentHits = $DownCast(Uno.Collections.EnumerableExtensions.ToList__Fuse_INode(Uno.Collections.EnumerableExtensions.Union__Fuse_INode($DownCast(currentHits, 32843), $DownCast(Fuse.Input.FindAncestorHits(results[i].HitObject()), 32843))), 32926);
            }

            var newHits = Fuse.Input.FilterNodes(currentHits, lastHitList);
            var oldHits = Fuse.Input.FilterNodes(lastHitList, currentHits);

            for (var j = 0; j < oldHits["Uno.Collections.ICollection__Fuse_INode.Count"](); ++j)
            {
                var hitObject = oldHits["Uno.Collections.IList__Fuse_INode.Item"](j);
                lastHitList["Uno.Collections.ICollection__Fuse_INode.Remove"](hitObject);
                Fuse.Input.RaisePointerLeave(hitObject, args.Data());
            }

            for (var j = 0; j < newHits["Uno.Collections.ICollection__Fuse_INode.Count"](); ++j)
            {
                var hitObject = newHits["Uno.Collections.IList__Fuse_INode.Item"](j);
                lastHitList["Uno.Collections.ICollection__Fuse_INode.Add"](hitObject);
                Fuse.Input.RaisePointerEnter(hitObject, args.Data());
            }
        };

        Fuse.Input.FilterNodes = function(list1, list2)
        {
            var results = Uno.Collections.List__Fuse_INode.New_1();

            for (var i = 0; i < list1["Uno.Collections.ICollection__Fuse_INode.Count"](); ++i)
            {
                if (!list2["Uno.Collections.ICollection__Fuse_INode.Contains"](list1["Uno.Collections.IList__Fuse_INode.Item"](i)))
                {
                    results.Add(list1["Uno.Collections.IList__Fuse_INode.Item"](i));
                }
            }

            return $DownCast(results, 32926);
        };

        Fuse.Input.FindAncestorHits = function(hitObject)
        {
            var hits = Uno.Collections.List__Fuse_INode.New_1();

            while (hitObject["Fuse.INode.Parent"]() != null)
            {
                hits.Add(hitObject);
                hitObject = hitObject["Fuse.INode.Parent"]();
            }

            return $DownCast(hits, 32926);
        };

        Fuse.Input.GetLastHitList = function(pointIndex)
        {
            var lastHitList = null;

            if (!Fuse.Input._lastHitNodes.TryGetValue(pointIndex, $CreateRef(function(){return lastHitList}, function($){lastHitList=$}, this)))
            {
                lastHitList = Uno.Collections.List__Fuse_INode.New_1();
                Fuse.Input._lastHitNodes.Add(pointIndex, lastHitList);
            }

            return lastHitList;
        };

        Fuse.Input.FindNearestHit = function(results)
        {
            var minDepth = 3.402823e+38;
            var minObject = null;

            for (var i = results.length; (i--) > 0; )
            {
                var result = results[i];

                if (result.HasHitDistance())
                {
                    if (result.HitDistance() <= minDepth)
                    {
                        minDepth = result.HitDistance();
                        minObject = result;
                    }
                }
                else
                {
                    minObject = result;
                }
            }

            return minObject;
        };

        Fuse.Input.RaisePointerLeave = function(hitObject, data)
        {
            Fuse.Input.RaiseEvent(hitObject, Fuse.PointerLeaveArgs.New_2(data));
        };

        Fuse.Input.RaisePointerEnter = function(hitObject, data)
        {
            Fuse.Input.RaiseEvent(hitObject, Fuse.PointerEnterArgs.New_2(data));
        };

        Fuse.Input.HitTest = function(root, point, camera)
        {
            var sq = Fuse.SelectionQuery.New_1();
            var r = sq.Select(root, point, camera);
            return $DownCast(Uno.Runtime.Implementation.Internal.ArrayEnumerable__Fuse_HitTestResult.New_1(r), 32835);
        };

        Fuse.Input.RaisePointerPressedInternal = function(target, args)
        {
            var collection_125;
            collection_125 = Fuse.Input_Pointer.New_1();
            collection_125.PointCoord.op_Assign(args.PointCoord());
            collection_125.DistanceMoved = 0.0;
            var p = collection_125;
            Fuse.Input._pointersDown.Item(args.PointIndex(), p);
            Fuse.Input._PointerPressedTriggers.Add(args);
            Fuse.Input.PointerCoord(args.PointCoord());
            Fuse.Input.RaiseEvent(target, args);

            if (!args.IsHandled())
            {
                Fuse.FocusManager.FocusedObject(null);
            }

            p.WasHandled = args.IsHandled();
            return args;
        };

        Fuse.Input.RaisePointerMovedInternal = function(target, args)
        {
            if (Fuse.Input._pointersDown.ContainsKey(args.PointIndex()))
            {
                var p = Fuse.Input._pointersDown.Item(args.PointIndex());
                p.DistanceMoved = p.DistanceMoved + Uno.Vector.Length(Uno.Float2.op_Subtraction(args.PointCoord(), p.PointCoord));
                p.PointCoord.op_Assign(args.PointCoord());
            }

            Fuse.Input.PointerCoord(args.PointCoord());
            Fuse.Input.RaiseEvent(target, args);
            return args;
        };

        Fuse.Input.RaisePointerWheelChangedInternal = function(target, args)
        {
            Fuse.Input.RaiseEvent(target, args);
            return args;
        };

        Fuse.Input.RaisePointerReleasedInternal = function(target, args)
        {
            if (Fuse.Input._pointersDown.ContainsKey(args.PointIndex()))
            {
                var p = Fuse.Input._pointersDown.Item(args.PointIndex());
                p.DistanceMoved = p.DistanceMoved + Uno.Vector.Length(Uno.Float2.op_Subtraction(args.PointCoord(), p.PointCoord));
                Fuse.Input._pointersDown.Remove(args.PointIndex());
            }

            Fuse.Input._PointerReleasedTriggers.Add(args);
            Fuse.Input.PointerCoord(args.PointCoord());
            Fuse.Input.RaiseEvent(target, args);
            Fuse.Input.ReleaseHardCapture(args.PointIndex());
            return args;
        };

        Fuse.Input.RaiseTextInput = function(text)
        {
            var args = Fuse.TextInputArgs.New_2(text);
            Fuse.Input.RaiseEvent(Fuse.FocusManager.FocusedObject(), args);
            return args;
        };

        Fuse.Input.RaiseEvent = function(target, args)
        {
            if (Fuse.Input._globalListeners.Count() > 0)
            {
                var gl = Fuse.Input._globalListeners.ToArray();

                for (var index_127 = 0, length_128 = gl.length; index_127 < length_128; ++index_127)
                {
                    var s = gl[index_127];
                    s["Fuse.INode.RaiseEvent"](args);
                }
            }

            if (target != null)
            {
                target["Fuse.INode.RaiseEvent"](args);
            }

            if (Fuse.Input._unhandledListeners.Count() > 0)
            {
                var ul = Fuse.Input._unhandledListeners.ToArray();

                for (var index_130 = 0, length_131 = ul.length; index_130 < length_131; ++index_130)
                {
                    var s = ul[index_130];
                    s["Fuse.INode.RaiseEvent"](args);
                }
            }
        };

        Fuse.Input._TypeInit = function()
        {
            Fuse.Input._globalListeners = Uno.Collections.List__Fuse_INode.New_1();
            Fuse.Input._unhandledListeners = Uno.Collections.List__Fuse_INode.New_1();
            Fuse.Input._pointersDown = Uno.Collections.Dictionary__int__Fuse_Input_Pointer.New_1();
            Fuse.Input._PointerPressedTriggers = Uno.Collections.List__Fuse_PointerPressedArgs.New_1();
            Fuse.Input._PointerReleasedTriggers = Uno.Collections.List__Fuse_PointerReleasedArgs.New_1();
            Fuse.Input._softCapturers = Uno.Collections.Dictionary__int__Uno_Collections_IList_Fuse_INode_.New_1();
            Fuse.Input._softCapturerViewProviders = Uno.Collections.Dictionary__int__Uno_Collections_IList_Fuse_ViewProvider_.New_1();
            Fuse.Input._hardCapturers = Uno.Collections.Dictionary__int__Fuse_INode.New_1();
            Fuse.Input._hardCapturerViewProviders = Uno.Collections.Dictionary__int__Fuse_ViewProvider.New_1();
            Fuse.Input._lastHitNodes = Uno.Collections.Dictionary__int__Uno_Collections_List_Fuse_INode_.New_1();
        };

    });
