Fuse.PointerPressedArgs = $CreateClass(
    function() {
        Fuse.PointerEventArgs.call(this);
    },
    function(S) {
        var I = S.prototype = new Fuse.PointerEventArgs;

        I.GetType = function()
        {
            return 923;
        };

        I._ObjInit_3 = function(data)
        {
            Fuse.PointerEventArgs.prototype._ObjInit_2.call(this, data);
        };

        Fuse.PointerPressedArgs.New_2 = function(data)
        {
            var inst = new Fuse.PointerPressedArgs;
            inst._ObjInit_3(data);
            return inst;
        };

    });
