Fuse.Internal.WordWrapper = $CreateClass(
    function() {
    },
    function(S) {

        Fuse.Internal.WordWrapper.WrapLine = function(wrapInfo, text)
        {
            var words = Fuse.Internal.WordWrapper.GetWords(wrapInfo, text);
            var ret = Uno.Collections.List__Fuse_Internal_WrappedLine.New_1();
            var lineStartIndex = 0;
            var lineText = Uno.String.Empty;
            var lineWidth = 0.0;

            for (var i = 0; i < (words.Count() - 1); i++)
            {
                var word = Fuse.Internal.WordWrapper.SplitWord(wrapInfo, ret, words.Item(i), $CreateRef(function(){return lineStartIndex}, function($){lineStartIndex=$}, this));
                var nextWord = words.Item(i + 1);

                if (((lineWidth + word.TotalContentsWidth) + nextWord.ContentsWidth) <= wrapInfo.WrapWidth)
                {
                    lineText = Uno.String.op_Addition(lineText, word.TotalContents);
                    lineWidth = lineWidth + word.TotalContentsWidth;
                }
                else
                {
                    ret.Add(Fuse.Internal.WrappedLine.New_1(Uno.String.op_Addition(lineText, word.TotalContents), lineStartIndex, ret.Count() * wrapInfo.LineHeight, lineWidth + word.ContentsWidth));
                    lineStartIndex = nextWord.StartIndex;
                    lineText = Uno.String.Empty;
                    lineWidth = 0.0;
                }
            }

            var lastWord = Fuse.Internal.WordWrapper.SplitWord(wrapInfo, ret, words.Item(words.Count() - 1), $CreateRef(function(){return lineStartIndex}, function($){lineStartIndex=$}, this));
            ret.Add(Fuse.Internal.WrappedLine.New_1(Uno.String.op_Addition(lineText, lastWord.TotalContents), lineStartIndex, ret.Count() * wrapInfo.LineHeight, lineWidth + lastWord.TotalContentsWidth));
            return ret.ToArray();
        };

        Fuse.Internal.WordWrapper.GetWords = function(wrapInfo, text)
        {
            var ret = Uno.Collections.List__Fuse_Internal_WordWrapperWord.New_1();

            for (var i = 0; i < text.length; )
            {
                var contentsIndex = i;
                var contentsLength = 0;

                for (; (i < text.length) && !Uno.Char.IsWhiteSpace(text.charCodeAt(i)); i++)
                {
                    contentsLength++;
                }

                var contents = text.Substring(contentsIndex, contentsLength);
                var whitespaceIndex = i;
                var whitespaceLength = 0;

                for (; (i < text.length) && Uno.Char.IsWhiteSpace(text.charCodeAt(i)); i++)
                {
                    whitespaceLength++;
                }

                var whitespace = text.Substring(whitespaceIndex, whitespaceLength);
                ret.Add(Fuse.Internal.WordWrapperWord.New_1(contents, whitespace, contentsIndex, wrapInfo.TextRenderer["Fuse.Internal.ITextRenderer.MeasureStringVirtual"](wrapInfo.FontSize, wrapInfo.AbsoluteZoom, contents).X, wrapInfo.TextRenderer["Fuse.Internal.ITextRenderer.MeasureStringVirtual"](wrapInfo.FontSize, wrapInfo.AbsoluteZoom, Uno.String.op_Addition(contents, whitespace)).X));
            }

            return ret;
        };

        Fuse.Internal.WordWrapper.SplitWord = function(wrapInfo, wrappedLines, word, lineStartIndex)
        {
            while ((word.Contents.length > 1) && (word.ContentsWidth > wrapInfo.WrapWidth))
            {
                var c = 1;

                for (; c < word.Contents.length; c++)
                {
                    var leftString = word.Contents.Substring(0, c);
                    var startX = wrapInfo.TextRenderer["Fuse.Internal.ITextRenderer.MeasureStringVirtual"](wrapInfo.FontSize, wrapInfo.AbsoluteZoom, leftString).X;

                    if (startX >= wrapInfo.WrapWidth)
                    {
                        return word;
                    }

                    var endX = startX + wrapInfo.TextRenderer["Fuse.Internal.ITextRenderer.MeasureStringVirtual"](wrapInfo.FontSize, wrapInfo.AbsoluteZoom, word.Contents.Substring(c, 1)).X;

                    if ((startX < wrapInfo.WrapWidth) && (endX >= wrapInfo.WrapWidth))
                    {
                        wrappedLines.Add(Fuse.Internal.WrappedLine.New_1(leftString, word.StartIndex, wrappedLines.Count() * wrapInfo.LineHeight, startX));
                        var newWordContents = word.Contents.Substring_1(c);
                        lineStartIndex(word.StartIndex + c);
                        word = Fuse.Internal.WordWrapperWord.New_1(newWordContents, word.Whitespace, lineStartIndex(), wrapInfo.TextRenderer["Fuse.Internal.ITextRenderer.MeasureStringVirtual"](wrapInfo.FontSize, wrapInfo.AbsoluteZoom, newWordContents).X, wrapInfo.TextRenderer["Fuse.Internal.ITextRenderer.MeasureStringVirtual"](wrapInfo.FontSize, wrapInfo.AbsoluteZoom, Uno.String.op_Addition(newWordContents, word.Whitespace)).X);
                        break;
                    }
                }
            }

            return word;
        };

    });
