Fuse.Internal.RectExtensions = $CreateClass(
    function() {
    },
    function(S) {

        Fuse.Internal.RectExtensions.MoveRectToContainRect = function(a, b)
        {
            var a_123 = new Uno.Rect;
            var b_124 = new Uno.Rect;
            var pos_125 = new Uno.Float2;
            a_123.op_Assign(a);
            b_124.op_Assign(b);
            pos_125.op_Assign(a_123.Position());
            var newX = pos_125.X;
            var newY = pos_125.Y;

            if ((a_123.Size().X < b_124.Size().X) || (b_124.Left < a_123.Left))
            {
                newX = b_124.Left;
            }
            else if (b_124.Right > a_123.Right)
            {
                newX = newX + (b_124.Right - a_123.Right);
            }

            if ((a_123.Size().Y < b_124.Size().Y) || (b_124.Top < a_123.Top))
            {
                newY = b_124.Top;
            }
            else if (b_124.Bottom > a_123.Bottom)
            {
                newY = newY + (b_124.Bottom - a_123.Bottom);
            }

            return Uno.Rect.New_2(Uno.Float2.New_2(newX, newY), a_123.Size());
        };

        Fuse.Internal.RectExtensions.MoveRectInsideRect = function(a, b)
        {
            var a_126 = new Uno.Rect;
            var b_127 = new Uno.Rect;
            var pos_128 = new Uno.Float2;
            a_126.op_Assign(a);
            b_127.op_Assign(b);
            pos_128.op_Assign(a_126.Position());
            var newX = pos_128.X;
            var newY = pos_128.Y;

            if (b_127.Left > a_126.Left)
            {
                newX = b_127.Left;
            }
            else if (b_127.Right < a_126.Right)
            {
                newX = newX - (a_126.Right - b_127.Right);
            }

            if (b_127.Top > a_126.Top)
            {
                newY = b_127.Left;
            }
            else if (b_127.Bottom < a_126.Bottom)
            {
                newY = newY - (a_126.Bottom - b_127.Bottom);
            }

            return Uno.Rect.New_2(Uno.Float2.New_2(newX, newY), a_126.Size());
        };

    });
