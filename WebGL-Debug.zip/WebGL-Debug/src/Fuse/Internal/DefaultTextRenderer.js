Fuse.Internal.DefaultTextRenderer = $CreateClass(
    function() {
        this._impl = null;
    },
    function(S) {
        var I = S.prototype;

        I.GetType = function()
        {
            return 811;
        };

        I.$II = function(id)
        {
            return [812].indexOf(id) != -1;
        };

        I.GetLineHeight = function(fontSize)
        {
            return this._impl["Fuse.Internal.ITextRenderer.GetLineHeight"](fontSize);
        };

        I.MeasureStringVirtual = function(fontSize, absoluteZoom, s)
        {
            return this._impl["Fuse.Internal.ITextRenderer.MeasureStringVirtual"](fontSize, absoluteZoom, s);
        };

        I.BeginRendering = function(fontSize, absoluteZoom, transform, bounds, textColor, maxTextLength)
        {
            this._impl["Fuse.Internal.ITextRenderer.BeginRendering"](fontSize, absoluteZoom, transform, bounds, textColor, maxTextLength);
        };

        I.DrawLine = function(dc, x, y, line)
        {
            this._impl["Fuse.Internal.ITextRenderer.DrawLine"](dc, x, y, line);
        };

        I.EndRendering = function(dc)
        {
            this._impl["Fuse.Internal.ITextRenderer.EndRendering"](dc);
        };

        I._ObjInit_1 = function(fontFace)
        {
            this._impl = $DownCast(Fuse.CanvasTextRenderer.New_1(fontFace), 33580);
        };

        Fuse.Internal.DefaultTextRenderer.New_2 = function(fontFace)
        {
            var inst = new Fuse.Internal.DefaultTextRenderer;
            inst._ObjInit_1(fontFace);
            return inst;
        };

        I["Fuse.Internal.ITextRenderer.GetLineHeight"] = I.GetLineHeight;
        I["Fuse.Internal.ITextRenderer.MeasureStringVirtual"] = I.MeasureStringVirtual;
        I["Fuse.Internal.ITextRenderer.BeginRendering"] = I.BeginRendering;
        I["Fuse.Internal.ITextRenderer.DrawLine"] = I.DrawLine;
        I["Fuse.Internal.ITextRenderer.EndRendering"] = I.EndRendering;

    });
