Fuse.Internal.WordWrapperWord = $CreateClass(
    function() {
        this.Contents = null;
        this.Whitespace = null;
        this.TotalContents = null;
        this.StartIndex = 0;
        this.ContentsWidth = 0;
        this.TotalContentsWidth = 0;
    },
    function(S) {
        var I = S.prototype;

        I.GetType = function()
        {
            return 823;
        };

        I._ObjInit = function(contents, whitespace, startIndex, contentsWidth, totalContentsWidth)
        {
            this.Contents = contents;
            this.Whitespace = whitespace;
            this.TotalContents = Uno.String.op_Addition(this.Contents, this.Whitespace);
            this.StartIndex = startIndex;
            this.ContentsWidth = contentsWidth;
            this.TotalContentsWidth = totalContentsWidth;
        };

        Fuse.Internal.WordWrapperWord.New_1 = function(contents, whitespace, startIndex, contentsWidth, totalContentsWidth)
        {
            var inst = new Fuse.Internal.WordWrapperWord;
            inst._ObjInit(contents, whitespace, startIndex, contentsWidth, totalContentsWidth);
            return inst;
        };

    });
