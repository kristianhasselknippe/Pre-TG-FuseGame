Fuse.Internal.SwipeGestureHelper = $CreateClass(
    function() {
        this._spans = null;
        this._lengthThreshold = 0;
    },
    function(S) {
        var I = S.prototype;

        I.GetType = function()
        {
            return 827;
        };

        I.IsWithinBounds = function(vector)
        {
            var vector_123 = new Uno.Float2;
            vector_123.op_Assign(vector);
            var length = Uno.Vector.Length(vector_123);

            if (length < this._lengthThreshold)
            {
                return false;
            }

            var angle = Uno.Math.RadiansToDegrees_1(Uno.Math.Atan2_1(vector_123.X, vector_123.Y));

            for (var i = 0; i < this._spans.length; i++)
            {
                if (this._spans[i].IsWithinBounds(angle))
                {
                    return true;
                }
            }

            return false;
        };

    });
