Fuse.Internal.TextSpan = $CreateClass(
    function() {
        this.Start = null;
        this.End = null;
    },
    function(S) {
        var I = S.prototype;

        I.GetType = function()
        {
            return 820;
        };

        Fuse.Internal.TextSpan.Intersects = function(a, b)
        {
            return !(Fuse.Internal.TextPosition.op_LessThanOrEqual(a.End, b.Start) || Fuse.Internal.TextPosition.op_GreaterThanOrEqual(a.Start, b.End));
        };

        Fuse.Internal.TextSpan.Intersection = function(a, b)
        {
            return Fuse.Internal.TextSpan.Intersects(a, b) ? Fuse.Internal.TextSpan.New_1(Fuse.Internal.TextPosition.Max(a.Start, b.Start), Fuse.Internal.TextPosition.Min(a.End, b.End)) : null;
        };

        I.Equals = function(obj)
        {
            if (!$IsOp(obj, 820))
            {
                return false;
            }

            var other = $DownCast(obj, 820);
            return Fuse.Internal.TextPosition.op_Equality(this.Start, other.Start) && Fuse.Internal.TextPosition.op_Equality(this.End, other.End);
        };

        I.GetHashCode = function()
        {
            return this.Start.GetHashCode() ^ this.End.GetHashCode();
        };

        I._ObjInit = function(start, end)
        {
            var isValid = Fuse.Internal.TextPosition.op_LessThanOrEqual(start, end);
            this.Start = isValid ? start : end;
            this.End = isValid ? end : start;
        };

        Fuse.Internal.TextSpan.New_1 = function(start, end)
        {
            var inst = new Fuse.Internal.TextSpan;
            inst._ObjInit(start, end);
            return inst;
        };

        Fuse.Internal.TextSpan.op_Equality = function(a, b)
        {
            var aNull = Uno.Object.ReferenceEquals(a, null);
            var bNull = Uno.Object.ReferenceEquals(b, null);

            if (aNull && bNull)
            {
                return true;
            }

            if ((aNull && !bNull) || (!aNull && bNull))
            {
                return false;
            }

            return a.Equals(b);
        };

        Fuse.Internal.TextSpan.op_Inequality = function(a, b)
        {
            return !Fuse.Internal.TextSpan.op_Equality(a, b);
        };

    });
