Fuse.Internal.SizingContainer = $CreateClass(
    function() {
        this.stretchMode = 0;
        this.stretchDirection = 0;
        this.align = 0;
        this.padding = new Uno.Float4;
    },
    function(S) {
        var I = S.prototype;

        I.GetType = function()
        {
            return 818;
        };

        I.PaddingWidth = function()
        {
            return this.padding.Item(0) + this.padding.Item(2);
        };

        I.PaddingHeight = function()
        {
            return this.padding.Item(1) + this.padding.Item(3);
        };

        I.SetStretchMode = function(mode)
        {
            if (mode == this.stretchMode)
            {
                return false;
            }

            this.stretchMode = mode;
            return true;
        };

        I.CalcScale = function(availableSize, desiredSize)
        {
            return this.CalcScale_1(availableSize, desiredSize, false, false);
        };

        I.CalcScale_1 = function(availableSize, desiredSize, autoWidth, autoHeight)
        {
            var desiredSize_126 = new Uno.Float2;
            var d_127 = new Uno.Float2;
            desiredSize_126.op_Assign(desiredSize);
            d_127.op_Assign(availableSize);
            d_127.X = d_127.X - this.PaddingWidth();
            d_127.Y = d_127.Y - this.PaddingHeight();
            var scale = Uno.Float2.New_1(1.0);

            if ((autoWidth && autoHeight) && (this.stretchMode != 0))
            {
                scale = Uno.Float2.New_1(1.0);
            }
            else
            {
                var s = Uno.Float2.New_2((desiredSize_126.X < 1e-05) ? 0.0 : (d_127.X / desiredSize_126.X), (desiredSize_126.Y < 1e-05) ? 0.0 : (d_127.Y / desiredSize_126.Y));

                switch (this.stretchMode)
                {
                    case 0:
                    {
                        scale = Uno.Float2.New_1(1.0);
                        break;
                    }
                    case 2:
                    case 1:
                    {
                        {
                            scale.op_Assign(autoWidth ? Uno.Float2.New_1(s.Y) : (autoHeight ? Uno.Float2.New_1(s.X) : s));
                            break;
                        }
                    }
                    case 3:
                    {
                        {
                            var sm = autoWidth ? s.Y : (autoHeight ? s.X : Uno.Math.Min_1(s.X, s.Y));
                            scale = Uno.Float2.New_1(sm);
                            break;
                        }
                    }
                    case 4:
                    {
                        {
                            var sm = autoWidth ? s.Y : (autoHeight ? s.X : Uno.Math.Max_1(s.X, s.Y));
                            scale = Uno.Float2.New_1(sm);
                            break;
                        }
                    }
                }
            }

            switch (this.stretchDirection)
            {
                case 0:
                {
                    break;
                }
                case 2:
                {
                    scale.X = Uno.Math.Min_1(scale.X, 1.0);
                    scale.Y = Uno.Math.Min_1(scale.Y, 1.0);
                    break;
                }
                case 1:
                {
                    scale.X = Uno.Math.Max_1(1.0, scale.X);
                    scale.Y = Uno.Math.Max_1(1.0, scale.Y);
                    break;
                }
            }

            return scale;
        };

        I.CalcOrigin = function(availableSize, contentActualSize)
        {
            var availableSize_128 = new Uno.Float2;
            var contentActualSize_129 = new Uno.Float2;
            availableSize_128.op_Assign(availableSize);
            contentActualSize_129.op_Assign(contentActualSize);
            var origin = Uno.Float2.New_1(0.0);

            switch (Fuse.AlignmentHelpers.GetHorizontalAlign(this.align))
            {
                case 0:
                case 1:
                {
                    origin.X = this.padding.Item(0);
                    break;
                }
                case 2:
                {
                    origin.X = ((((availableSize_128.X - this.padding.Item(0)) - this.padding.Item(2)) / 2.0) - (contentActualSize_129.X / 2.0)) + this.padding.Item(0);
                    break;
                }
                case 3:
                {
                    origin.X = (availableSize_128.X - this.padding.Item(2)) - contentActualSize_129.X;
                    break;
                }
            }

            switch (Fuse.AlignmentHelpers.GetVerticalAlign(this.align))
            {
                case 0:
                case 4:
                {
                    origin.Y = this.padding.Item(1);
                    break;
                }
                case 8:
                {
                    origin.Y = ((((availableSize_128.Y - this.padding.Item(1)) - this.padding.Item(3)) / 2.0) - (contentActualSize_129.Y / 2.0)) + this.padding.Item(1);
                    break;
                }
                case 12:
                {
                    origin.Y = (availableSize_128.Y - this.padding.Item(3)) - contentActualSize_129.Y;
                    break;
                }
            }

            return origin;
        };

        I.CalcClip = function(availableSize, origin, contentActualSize)
        {
            var availableSize_130 = new Uno.Float2;
            var ind_133;
            var ind_134;
            availableSize_130.op_Assign(availableSize);

            if ((((origin().X > availableSize_130.X) || ((origin().X + contentActualSize().X) < 0.0)) || (origin().Y > availableSize_130.Y)) || ((origin().Y + contentActualSize().Y) < 0.0))
            {
                origin(Uno.Float2.New_2(0.0, 0.0));
                contentActualSize(Uno.Float2.New_1(0.0));
                return Uno.Float4.New_2(0.0, 0.0, 1.0, 1.0);
            }

            var tl = Uno.Math.Max_3(Uno.Float2.New_1(0.0), Uno.Float2.op_Division(Uno.Float2.op_Subtraction((ind_133 = this.padding, Uno.Float2.New_2(ind_133.X, ind_133.Y)), origin()), contentActualSize()));
            var br = Uno.Math.Min_3(Uno.Float2.New_1(1.0), Uno.Float2.op_Division(Uno.Float2.op_Subtraction(Uno.Float2.op_Subtraction(availableSize_130, origin()), (ind_134 = this.padding, Uno.Float2.New_2(ind_134.Z, ind_134.W))), contentActualSize()));
            var dx = this.padding.X - origin().X;

            if (dx > 0.0)
            {
                contentActualSize().X = contentActualSize().X - dx;
                origin().X = this.padding.X;
            }

            dx = ((origin().X + contentActualSize().X) - availableSize_130.X) + this.padding.Z;

            if (dx > 0.0)
            {
                contentActualSize().X = contentActualSize().X - dx;
            }

            var dy = this.padding.Y - origin().Y;

            if (dy > 0.0)
            {
                contentActualSize().Y = contentActualSize().Y - dy;
                origin().Y = this.padding.Y;
            }

            dy = ((origin().Y + contentActualSize().Y) - availableSize_130.Y) + this.padding.W;

            if (dy > 0.0)
            {
                contentActualSize().Y = contentActualSize().Y - dy;
            }

            return Uno.Float4.New_2(tl.X, tl.Y, br.X, br.Y);
        };

        I.ExpandFillSize = function(size, fillSize, fillSet)
        {
            var autoWidth = !((fillSet & 1) == 1);
            var autoHeight = !((fillSet & 2) == 2);
            var scale = this.CalcScale_1(fillSize, size, autoWidth, autoHeight);
            return Uno.Float2.op_Multiply_1(scale, size);
        };

        I._ObjInit = function()
        {
            this.stretchMode = 3;
            this.align = 10;
        };

        Fuse.Internal.SizingContainer.New_1 = function()
        {
            var inst = new Fuse.Internal.SizingContainer;
            inst._ObjInit();
            return inst;
        };

    });
