Fuse.Internal.LineCacheLine = $CreateClass(
    function() {
        this._text = null;
        this._transform = null;
        this._wrappedLinesCache = null;
        this._wordWrapInfoCache = null;
    },
    function(S) {
        var I = S.prototype;

        I.GetType = function()
        {
            return 814;
        };

        I.Text = function(value)
        {
            if (value !== undefined)
            {
                if (Uno.String.op_Equality(value, this._text))
                {
                    return;
                }

                this._text = value;
                this.Invalidate();
            }
            else
            {
                return this._text;
            }
        };

        I.Transform = function(value)
        {
            if (value !== undefined)
            {
                this._transform = value;
                this.Invalidate();
            }
            else
            {
                return this._transform;
            }
        };

        I.VisualText = function()
        {
            if (this._transform != null)
            {
                return this._transform["Fuse.Internal.LineCacheTransform.Transform"](this._text);
            }

            return this._text;
        };

        I.GetWrappedLines = function(wrapInfo)
        {
            if (((this._wrappedLinesCache == null) || (this._wordWrapInfoCache == null)) || !this._wordWrapInfoCache.Equals(wrapInfo))
            {
                this._wrappedLinesCache = (wrapInfo.IsEnabled && (this.Text().length > 0)) ? Fuse.Internal.WordWrapper.WrapLine(wrapInfo, this.VisualText()) : Array.Init([Fuse.Internal.WrappedLine.New_1(this.VisualText(), 0, 0.0, wrapInfo.TextRenderer["Fuse.Internal.ITextRenderer.MeasureStringVirtual"](wrapInfo.FontSize, wrapInfo.AbsoluteZoom, this.VisualText()).X)], 825);
                this._wordWrapInfoCache = wrapInfo;
            }

            return this._wrappedLinesCache;
        };

        I.InsertChar = function(p, c)
        {
            this.Text((p < this.Text().length) ? Uno.String.op_Addition(Uno.String.op_Addition_1(this.Text().Substring(0, p), $CreateBox(c, 420)), this.Text().Substring_1(p)) : Uno.String.op_Addition_1(this.Text(), $CreateBox(c, 420)));
        };

        I.Delete = function(p)
        {
            this.Text(Uno.String.op_Addition(this.Text().Substring(0, p), this.Text().Substring_1(p + 1)));
        };

        I.Backspace = function(p)
        {
            this.Text(Uno.String.op_Addition(this.Text().Substring(0, p - 1), this.Text().Substring_1(p)));
            return p - 1;
        };

        I.Home = function(wrapInfo, p)
        {
            return this.PosToWrappedLine(wrapInfo, p).LineTextStartOffset;
        };

        I.End = function(wrapInfo, p)
        {
            return this.PosToWrappedLine(wrapInfo, p).LineTextEndOffset();
        };

        I.BoundsToPos = function(wrapInfo, textAlignment, boundsWidth, p)
        {
            var p_123 = new Uno.Float2;
            p_123.op_Assign(p);
            var wrappedLine = this.BoundsToWrappedLine(wrapInfo, p_123);
            var xOffset = wrappedLine.GetXOffset(textAlignment, boundsWidth, wrapInfo.AbsoluteZoom);
            return wrappedLine.BoundsToPos(wrapInfo, p_123.X - xOffset) + wrappedLine.LineTextStartOffset;
        };

        I.PosToBounds = function(wrapInfo, textAlignment, boundsWidth, p)
        {
            var wrappedLine = this.PosToWrappedLine(wrapInfo, p);
            var xOffset = wrappedLine.GetXOffset(textAlignment, boundsWidth, wrapInfo.AbsoluteZoom);
            var yOffset = wrappedLine.YOffset;
            return Uno.Float2.New_2(xOffset + wrappedLine.PosToBounds(wrapInfo, p - wrappedLine.LineTextStartOffset), yOffset);
        };

        I.GetTotalHeight = function(wrapInfo)
        {
            var wrappedLines = this.GetWrappedLines(wrapInfo);
            return wrappedLines.length * wrapInfo.LineHeight;
        };

        I.BoundsToWrappedLine = function(wrapInfo, p)
        {
            var p_124 = new Uno.Float2;
            p_124.op_Assign(p);
            var wrappedLines = this.GetWrappedLines(wrapInfo);
            var l = 0;
            var startY = 0.0;

            if (p_124.Y > 0.0)
            {
                for (; l < (wrappedLines.length - 1); l++)
                {
                    var endY = startY + wrapInfo.LineHeight;

                    if ((p_124.Y >= startY) && (p_124.Y < endY))
                    {
                        break;
                    }

                    startY = endY;
                }
            }

            return wrappedLines[l];
        };

        I.PosToWrappedLine = function(wrapInfo, p)
        {
            var wrappedLines = this.GetWrappedLines(wrapInfo);

            for (var i = 0; i < (wrappedLines.length - 1); i++)
            {
                var wrappedLine = wrappedLines[i];

                if ((p >= wrappedLine.LineTextStartOffset) && (p < wrappedLine.LineTextEndOffset()))
                {
                    return wrappedLine;
                }
            }

            return wrappedLines[wrappedLines.length - 1];
        };

        I.Invalidate = function()
        {
            this._wrappedLinesCache = null;
        };

        I._ObjInit = function(text, transform)
        {
            this._text = text;
            this._transform = transform;
        };

        Fuse.Internal.LineCacheLine.New_1 = function(text, transform)
        {
            var inst = new Fuse.Internal.LineCacheLine;
            inst._ObjInit(text, transform);
            return inst;
        };

    });
