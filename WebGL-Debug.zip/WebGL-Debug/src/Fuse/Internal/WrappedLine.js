Fuse.Internal.WrappedLine = $CreateClass(
    function() {
        this.Text = null;
        this.LineTextStartOffset = 0;
        this.YOffset = 0;
        this.LineWidth = 0;
    },
    function(S) {
        var I = S.prototype;

        I.GetType = function()
        {
            return 825;
        };

        I.LineTextEndOffset = function()
        {
            return this.LineTextStartOffset + this.Text.length;
        };

        I.GetXOffset = function(textAlignment, boundsWidth, absoluteZoom)
        {
            switch (textAlignment)
            {
                case 0:
                {
                    return 0.0;
                }
                case 1:
                {
                    return Uno.Math.Round_1(((boundsWidth - this.LineWidth) / 2.0) * absoluteZoom) / absoluteZoom;
                }
                case 2:
                {
                    return boundsWidth - this.LineWidth;
                }
            }

            throw new $Error(Uno.ArgumentException.New_4("unsupported enum-value", "textAlignment"));
        };

        I.BoundsToPos = function(wrapInfo, p)
        {
            var c = 0;

            if (p > 0.0)
            {
                for (; c < this.Text.length; c++)
                {
                    var startX = wrapInfo.TextRenderer["Fuse.Internal.ITextRenderer.MeasureStringVirtual"](wrapInfo.FontSize, wrapInfo.AbsoluteZoom, this.Text.Substring(0, c)).X;

                    if (p >= startX)
                    {
                        var endX = startX + wrapInfo.TextRenderer["Fuse.Internal.ITextRenderer.MeasureStringVirtual"](wrapInfo.FontSize, wrapInfo.AbsoluteZoom, this.Text.Substring(c, 1)).X;

                        if (p < endX)
                        {
                            break;
                        }
                    }
                }
            }

            return c;
        };

        I.PosToBounds = function(wrapInfo, p)
        {
            return wrapInfo.TextRenderer["Fuse.Internal.ITextRenderer.MeasureStringVirtual"](wrapInfo.FontSize, wrapInfo.AbsoluteZoom, this.Text.Substring(0, p)).X;
        };

        I._ObjInit = function(text, lineTextStartOffset, yOffset, lineWidth)
        {
            this.Text = text;
            this.LineTextStartOffset = lineTextStartOffset;
            this.YOffset = yOffset;
            this.LineWidth = lineWidth;
        };

        Fuse.Internal.WrappedLine.New_1 = function(text, lineTextStartOffset, yOffset, lineWidth)
        {
            var inst = new Fuse.Internal.WrappedLine;
            inst._ObjInit(text, lineTextStartOffset, yOffset, lineWidth);
            return inst;
        };

    });
