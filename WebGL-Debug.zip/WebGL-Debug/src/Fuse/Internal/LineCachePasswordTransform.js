Fuse.Internal.LineCachePasswordTransform = $CreateClass(
    function() {
        this._reveal = 0;
    },
    function(S) {
        var I = S.prototype;

        I.GetType = function()
        {
            return 816;
        };

        I.$II = function(id)
        {
            return [815].indexOf(id) != -1;
        };

        I.SetReveal = function(r)
        {
            var b = r != this._reveal;
            this._reveal = r;
            return b;
        };

        I.Transform = function(text)
        {
            var buf = "";

            for (var i = 0; i < text.length; ++i)
            {
                buf = Uno.String.op_Addition_1(buf, $CreateBox((this._reveal == i) ? text.charCodeAt(i) : 183, 420));
            }

            return buf;
        };

        I._ObjInit = function()
        {
            this._reveal = -1;
        };

        Fuse.Internal.LineCachePasswordTransform.New_1 = function()
        {
            var inst = new Fuse.Internal.LineCachePasswordTransform;
            inst._ObjInit();
            return inst;
        };

        I["Fuse.Internal.LineCacheTransform.Transform"] = I.Transform;

    });
