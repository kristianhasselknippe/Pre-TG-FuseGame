Fuse.Internal.DegreeSpan = $CreateClass(
    function() {
        this._a = 0;
        this._b = 0;
    },
    function(S) {
        var I = S.prototype;

        I.GetType = function()
        {
            return 826;
        };

        I.IsWithinBounds = function(x)
        {
            var angle1 = this._a;
            var angle2 = this._b;
            var rAngle = Uno.Math.Mod_1(Uno.Math.Mod_1(angle2 - angle1, 360.0) + 360.0, 360.0);

            if (rAngle >= 180.0)
            {
                var a = angle1;
                angle1 = angle2;
                angle2 = a;
            }

            if (angle1 <= angle2)
            {
                return (x >= angle1) && (x <= angle2);
            }
            else
            {
                return (x >= angle2) || (x <= angle2);
            }
        };

    });
