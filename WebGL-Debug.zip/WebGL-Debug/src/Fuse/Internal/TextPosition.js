Fuse.Internal.TextPosition = $CreateClass(
    function() {
        this.Line = 0;
        this.Char = 0;
    },
    function(S) {
        var I = S.prototype;

        Fuse.Internal.TextPosition.Default = null;

        I.GetType = function()
        {
            return 819;
        };

        Fuse.Internal.TextPosition.Min = function(a, b)
        {
            return Fuse.Internal.TextPosition.op_LessThanOrEqual(a, b) ? a : b;
        };

        Fuse.Internal.TextPosition.Max = function(a, b)
        {
            return Fuse.Internal.TextPosition.op_GreaterThanOrEqual(a, b) ? a : b;
        };

        I.Equals = function(obj)
        {
            if (!$IsOp(obj, 819))
            {
                return false;
            }

            var other = $DownCast(obj, 819);
            return (this.Line == other.Line) && (this.Char == other.Char);
        };

        I.GetHashCode = function()
        {
            return this.Line ^ this.Char;
        };

        Fuse.Internal.TextPosition._TypeInit = function()
        {
            Fuse.Internal.TextPosition.Default = Fuse.Internal.TextPosition.New_1(0, 0);
        };

        I._ObjInit = function(l, c)
        {
            this.Line = l;
            this.Char = c;
        };

        Fuse.Internal.TextPosition.New_1 = function(l, c)
        {
            var inst = new Fuse.Internal.TextPosition;
            inst._ObjInit(l, c);
            return inst;
        };

        Fuse.Internal.TextPosition.op_Equality = function(a, b)
        {
            var aNull = Uno.Object.ReferenceEquals(a, null);
            var bNull = Uno.Object.ReferenceEquals(b, null);

            if (aNull && bNull)
            {
                return true;
            }

            if ((aNull && !bNull) || (!aNull && bNull))
            {
                return false;
            }

            return a.Equals(b);
        };

        Fuse.Internal.TextPosition.op_Inequality = function(a, b)
        {
            return !Fuse.Internal.TextPosition.op_Equality(a, b);
        };

        Fuse.Internal.TextPosition.op_LessThanOrEqual = function(a, b)
        {
            if (a.Line < b.Line)
            {
                return true;
            }

            if (a.Line > b.Line)
            {
                return false;
            }

            return a.Char <= b.Char;
        };

        Fuse.Internal.TextPosition.op_GreaterThanOrEqual = function(a, b)
        {
            if (a.Line > b.Line)
            {
                return true;
            }

            if (a.Line < b.Line)
            {
                return false;
            }

            return a.Char >= b.Char;
        };

    });
