Fuse.Internal.WordWrapInfo = $CreateClass(
    function() {
        this.TextRenderer = null;
        this.IsEnabled = false;
        this.WrapWidth = 0;
        this.FontSize = 0;
        this.LineHeight = 0;
        this.AbsoluteZoom = 0;
    },
    function(S) {
        var I = S.prototype;

        I.GetType = function()
        {
            return 822;
        };

        I.Equals = function(obj)
        {
            if (!$IsOp(obj, 822))
            {
                return false;
            }

            var other = $DownCast(obj, 822);
            return (((((this.TextRenderer == other.TextRenderer) && (this.IsEnabled == other.IsEnabled)) && (this.WrapWidth == other.WrapWidth)) && (this.FontSize == other.FontSize)) && (this.LineHeight == other.LineHeight)) && (this.AbsoluteZoom == other.AbsoluteZoom);
        };

        I.GetHashCode = function()
        {
            var ind_123;
            var ind_124;
            var ind_125;
            var ind_126;
            var ind_127;
            return ((((this.TextRenderer.GetHashCode() ^ (ind_123 = this.IsEnabled, ind_123).GetHashCode()) ^ (ind_124 = this.WrapWidth, ind_124).GetHashCode()) ^ (ind_125 = this.FontSize, ind_125).GetHashCode()) ^ (ind_126 = this.LineHeight, ind_126).GetHashCode()) ^ (ind_127 = this.AbsoluteZoom, ind_127).GetHashCode();
        };

        I._ObjInit = function(textRenderer, isEnabled, wrapWidth, fontSize, lineHeight, absoluteZoom)
        {
            this.TextRenderer = textRenderer;
            this.IsEnabled = isEnabled;
            this.WrapWidth = wrapWidth;
            this.FontSize = fontSize;
            this.LineHeight = lineHeight;
            this.AbsoluteZoom = absoluteZoom;
        };

        Fuse.Internal.WordWrapInfo.New_1 = function(textRenderer, isEnabled, wrapWidth, fontSize, lineHeight, absoluteZoom)
        {
            var inst = new Fuse.Internal.WordWrapInfo;
            inst._ObjInit(textRenderer, isEnabled, wrapWidth, fontSize, lineHeight, absoluteZoom);
            return inst;
        };

    });
