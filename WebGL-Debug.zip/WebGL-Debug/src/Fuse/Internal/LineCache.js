Fuse.Internal.LineCache = $CreateClass(
    function() {
        this._lines = null;
        this._text = null;
        this._isTextValid = false;
        this._isMultiline = false;
        this._transform = null;
        this._onTextChanged = null;
        this._invalideLayout = null;
    },
    function(S) {
        var I = S.prototype;

        I.GetType = function()
        {
            return 813;
        };

        I.Lines = function()
        {
            return this._lines;
        };

        I.Text = function(value)
        {
            if (value !== undefined)
            {
                if (Uno.String.op_Equality(value, this.Text()))
                {
                    return;
                }

                this._text = value;
                this._isTextValid = true;
                this.DecomposeLines(this._text);
            }
            else
            {
                if (!this._isTextValid)
                {
                    this._text = Uno.Collections.EnumerableExtensions.First__Fuse_Internal_LineCacheLine($DownCast(this._lines, 32840)).Text();

                    for (var i = 1; i < this._lines.Count(); i++)
                    {
                        this._text = Uno.String.op_Addition(Uno.String.op_Addition(this._text, "\n"), this._lines.Item(i).Text());
                    }

                    this._isTextValid = true;
                }

                return this._text;
            }
        };

        I.IsMultiline = function(value)
        {
            if (value !== undefined)
            {
                if (value == this._isMultiline)
                {
                    return;
                }

                this._isMultiline = value;
                this.DecomposeLines(this.Text());
            }
            else
            {
                return this._isMultiline;
            }
        };

        I.Transform = function(value)
        {
            if (value !== undefined)
            {
                this._transform = value;

                for (var enum_123 = this._lines.GetEnumerator(); enum_123.MoveNext(); )
                {
                    var line = enum_123.Current();
                    line.Transform(this._transform);
                }

                this.InvalidateText();
            }
            else
            {
                return this._transform;
            }
        };

        I.InsertChar = function(p, c)
        {
            this._lines.Item(p.Line).InsertChar(p.Char, c);
            this.InvalidateText();
            return Fuse.Internal.TextPosition.New_1(p.Line, p.Char + 1);
        };

        I.InsertNewline = function(p)
        {
            var currentLine = this._lines.Item(p.Line);
            var newLine = Fuse.Internal.LineCacheLine.New_1(currentLine.Text().Substring_1(p.Char), this._transform);
            currentLine.Text(currentLine.Text().Substring(0, p.Char));
            this._lines.Insert(p.Line + 1, newLine);
            this.InvalidateText();
            return Fuse.Internal.TextPosition.New_1(p.Line + 1, 0);
        };

        I.TryDelete = function(p)
        {
            var line = this._lines.Item(p.Line);

            if (p.Char == line.Text().length)
            {
                if (p.Line == (this._lines.Count() - 1))
                {
                    return p;
                }

                var nextLine = this._lines.Item(p.Line + 1);
                line.Text(Uno.String.op_Addition(line.Text(), nextLine.Text()));
                this._lines.RemoveAt(p.Line + 1);
                this.InvalidateText();
            }
            else
            {
                this._lines.Item(p.Line).Delete(p.Char);
                this.InvalidateText();
            }

            return p;
        };

        I.TryBackspace = function(p)
        {
            if (p.Char == 0)
            {
                if (p.Line == 0)
                {
                    return p;
                }

                var prevLine = this._lines.Item(p.Line - 1);
                var currentLine = this._lines.Item(p.Line);
                var newChar = prevLine.Text().length;
                prevLine.Text(Uno.String.op_Addition(prevLine.Text(), currentLine.Text()));
                this._lines.RemoveAt(p.Line);
                this.InvalidateText();
                return Fuse.Internal.TextPosition.New_1(p.Line - 1, newChar);
            }

            var ret = Fuse.Internal.TextPosition.New_1(p.Line, this._lines.Item(p.Line).Backspace(p.Char));
            this.InvalidateText();
            return ret;
        };

        I.DeleteSpan = function(s)
        {
            if (Fuse.Internal.TextSpan.op_Equality(s, this.GetFullTextSpan()))
            {
                this.Text("");
            }
            else
            {
                for (var i = this._lines.Count() - 1; i >= 0; i--)
                {
                    var line = this._lines.Item(i);
                    var lineSpan = Fuse.Internal.TextSpan.New_1(Fuse.Internal.TextPosition.New_1(i, 0), Fuse.Internal.TextPosition.New_1(i, line.Text().length));
                    var intersection = Fuse.Internal.TextSpan.Intersection(lineSpan, s);

                    if (Fuse.Internal.TextSpan.op_Equality(intersection, null))
                    {
                        continue;
                    }

                    if (Fuse.Internal.TextSpan.op_Equality(intersection, lineSpan))
                    {
                        this._lines.RemoveAt(i);
                    }
                    else
                    {
                        var text = this._lines.Item(i).Text();
                        var start = text.Substring(0, intersection.Start.Char);
                        var end = text.Substring(intersection.End.Char, text.length - intersection.End.Char);
                        this._lines.Item(i).Text(Uno.String.op_Addition(start, end));
                    }
                }
            }

            this.InvalidateText();
            return Fuse.Internal.TextPosition.New_1(Uno.Math.Min_8(s.Start.Line, this._lines.Count() - 1), s.Start.Char);
        };

        I.TryMoveLeft = function(p)
        {
            if (p.Char == 0)
            {
                if (p.Line == 0)
                {
                    return p;
                }

                var prevLine = this._lines.Item(p.Line - 1);
                return Fuse.Internal.TextPosition.New_1(p.Line - 1, prevLine.Text().length);
            }

            return Fuse.Internal.TextPosition.New_1(p.Line, p.Char - 1);
        };

        I.TryMoveRight = function(p)
        {
            var line = this._lines.Item(p.Line);

            if (p.Char >= line.Text().length)
            {
                if (p.Line == (this._lines.Count() - 1))
                {
                    return p;
                }

                return Fuse.Internal.TextPosition.New_1(p.Line + 1, 0);
            }

            return Fuse.Internal.TextPosition.New_1(p.Line, p.Char + 1);
        };

        I.TryMoveUp = function(wrapInfo, textAlignment, boundsWidth, p)
        {
            var lineBounds = this.TextPosToBounds(wrapInfo, textAlignment, boundsWidth, p);
            var prevLineBounds = Uno.Float2.New_2(lineBounds.X, lineBounds.Y - (wrapInfo.LineHeight * 0.5));
            var prevLineTextPos = this.BoundsToTextPos(wrapInfo, textAlignment, boundsWidth, prevLineBounds);
            return prevLineTextPos;
        };

        I.TryMoveDown = function(wrapInfo, textAlignment, boundsWidth, p)
        {
            var lineBounds = this.TextPosToBounds(wrapInfo, textAlignment, boundsWidth, p);
            var nextLineBounds = Uno.Float2.New_2(lineBounds.X, lineBounds.Y + (wrapInfo.LineHeight * 1.5));
            var nextLineTextPos = this.BoundsToTextPos(wrapInfo, textAlignment, boundsWidth, nextLineBounds);
            return nextLineTextPos;
        };

        I.Home = function(wrapInfo, p)
        {
            return Fuse.Internal.TextPosition.New_1(p.Line, this._lines.Item(p.Line).Home(wrapInfo, p.Char));
        };

        I.End = function(wrapInfo, p)
        {
            return Fuse.Internal.TextPosition.New_1(p.Line, this._lines.Item(p.Line).End(wrapInfo, p.Char));
        };

        I.GetBoundsSize = function(wrapInfo)
        {
            var array_125;
            var index_126;
            var length_127;
            var maxWidth = 0.0;
            var height = 0.0;

            for (var enum_124 = this._lines.GetEnumerator(); enum_124.MoveNext(); )
            {
                var line = enum_124.Current();

                for (array_125 = line.GetWrappedLines(wrapInfo), index_126 = 0, length_127 = array_125.length; index_126 < length_127; ++index_126)
                {
                    var wrappedLine = array_125[index_126];
                    maxWidth = Uno.Math.Max_1(maxWidth, wrappedLine.LineWidth);
                    height = height + wrapInfo.LineHeight;
                }
            }

            return Uno.Float2.New_2(maxWidth, height);
        };

        I.BoundsToTextPos = function(wrapInfo, textAlignment, boundsWidth, p)
        {
            var p_132 = new Uno.Float2;
            p_132.op_Assign(p);
            var l = 0;
            var startY = 0.0;

            if (p_132.Y > 0.0)
            {
                for (; l < (this._lines.Count() - 1); l++)
                {
                    var lineHeight = this._lines.Item(l).GetTotalHeight(wrapInfo);
                    var endY = startY + lineHeight;

                    if ((p_132.Y >= startY) && (p_132.Y < endY))
                    {
                        break;
                    }

                    startY = endY;
                }
            }

            var c = this._lines.Item(l).BoundsToPos(wrapInfo, textAlignment, boundsWidth, Uno.Float2.New_2(p_132.X, p_132.Y - startY));
            return Fuse.Internal.TextPosition.New_1(l, c);
        };

        I.TextPosToBounds = function(wrapInfo, textAlignment, boundsWidth, p)
        {
            var startY = 0.0;

            for (var i = 0; i < p.Line; i++)
            {
                startY = startY + this._lines.Item(i).GetTotalHeight(wrapInfo);
            }

            var linePos = this._lines.Item(p.Line).PosToBounds(wrapInfo, textAlignment, boundsWidth, p.Char);
            return Uno.Float2.New_2(linePos.X, startY + linePos.Y);
        };

        I.GetLastTextPos = function()
        {
            return Fuse.Internal.TextPosition.New_1(this._lines.Count() - 1, this._lines.Item(this._lines.Count() - 1).Text().length);
        };

        I.GetFullTextSpan = function()
        {
            return Fuse.Internal.TextSpan.New_1(Fuse.Internal.TextPosition.Default, this.GetLastTextPos());
        };

        I.InvalidateVisual = function()
        {
            for (var enum_128 = this._lines.GetEnumerator(); enum_128.MoveNext(); )
            {
                var line = enum_128.Current();
                line.Invalidate();
            }

            this.InvalidateLayout();
        };

        I.InvalidateText = function()
        {
            this._text = null;
            this._isTextValid = false;

            if (Uno.Delegate.op_Inequality(this._onTextChanged, null))
            {
                this._onTextChanged.Invoke();
            }

            this.InvalidateLayout();
        };

        I.InvalidateLayout = function()
        {
            if (Uno.Delegate.op_Inequality(this._invalideLayout, null))
            {
                this._invalideLayout.Invoke();
            }
        };

        I.DecomposeLines = function(text)
        {
            var array_129;
            var index_130;
            var length_131;
            this._lines.Clear();

            if (Uno.String.op_Inequality(text, null))
            {
                if (this.IsMultiline())
                {
                    for (array_129 = text.Split(Array.Init([10], 420)), index_130 = 0, length_131 = array_129.length; index_130 < length_131; ++index_130)
                    {
                        var line = array_129[index_130];
                        this._lines.Add(Fuse.Internal.LineCacheLine.New_1(line, this._transform));
                    }
                }
                else
                {
                    this._lines.Add(Fuse.Internal.LineCacheLine.New_1(text, this._transform));
                }
            }

            if (this._lines.Count() == 0)
            {
                this._lines.Add(Fuse.Internal.LineCacheLine.New_1(Uno.String.Empty, this._transform));
            }
        };

        I._ObjInit = function(onTextChanged, invalideLayout)
        {
            this._lines = Uno.Collections.List__Fuse_Internal_LineCacheLine.New_1();
            this._isTextValid = true;
            this._onTextChanged = onTextChanged;
            this._invalideLayout = invalideLayout;
            this.DecomposeLines(this.Text());
        };

        Fuse.Internal.LineCache.New_1 = function(onTextChanged, invalideLayout)
        {
            var inst = new Fuse.Internal.LineCache;
            inst._ObjInit(onTextChanged, invalideLayout);
            return inst;
        };

    });
