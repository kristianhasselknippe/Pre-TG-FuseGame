Fuse.Internal.Drawing.RoundedRectangle_RoundedRectangleImpl = $CreateClass(
    function() {
        this.Draw_v_9dfc1a50_6_1_1 = null;
        this.Draw_verts_9dfc1a50_6_0_12 = null;
        this.Draw_v_9dfc1a6f_7_1_1 = null;
        this.Draw_verts_9dfc1a6f_7_0_12 = null;
        this.Draw_v_9dfc8eaf_6_1_1 = null;
        this.Draw_v_9dfc8ece_7_1_1 = null;
        this.Draw_v_9dfd030e_6_1_1 = null;
        this.Draw_v_9dfd032d_7_1_1 = null;
        this.Draw_v_9dfd776d_6_1_1 = null;
        this.Draw_v_9dfd778c_7_1_1 = null;
        this.Draw_v_9dfdebcc_6_1_1 = null;
        this.Draw_BlendSrcRgb_9dfdebcc_13_3_9 = 0;
        this.Draw_BlendSrcAlpha_9dfdebcc_13_5_10 = 0;
        this.Draw_BlendDstRgb_9dfdebcc_13_4_11 = 0;
        this.Draw_BlendDstAlpha_9dfdebcc_13_6_12 = 0;
        this.Draw_v_9dfdebeb_7_1_1 = null;
        this._draw_9dfc1a50 = new Uno.Runtime.Implementation.ShaderBackends.OpenGL.GLDrawCall;
        this._draw_9dfc1a6f = new Uno.Runtime.Implementation.ShaderBackends.OpenGL.GLDrawCall;
        this._draw_9dfc8eaf = new Uno.Runtime.Implementation.ShaderBackends.OpenGL.GLDrawCall;
        this._draw_9dfc8ece = new Uno.Runtime.Implementation.ShaderBackends.OpenGL.GLDrawCall;
        this._draw_9dfd030e = new Uno.Runtime.Implementation.ShaderBackends.OpenGL.GLDrawCall;
        this._draw_9dfd032d = new Uno.Runtime.Implementation.ShaderBackends.OpenGL.GLDrawCall;
        this._draw_9dfd776d = new Uno.Runtime.Implementation.ShaderBackends.OpenGL.GLDrawCall;
        this._draw_9dfd778c = new Uno.Runtime.Implementation.ShaderBackends.OpenGL.GLDrawCall;
    },
    function(S) {
        var I = S.prototype;

        I.GetType = function()
        {
            return 809;
        };

        I.Draw = function(dc, position, transform, size, brush, radius)
        {
            var size_125 = new Uno.Float2;
            var ind_126;
            var ind_127;
            var ind_128;
            var ind_129;
            size_125.op_Assign(size);

            if ($IsOp(brush, 728))
            {
                var radius_9dfc1a50_3_3_2 = Uno.Math.Min_1(Uno.Math.Min_1(radius, size_125.X / 2.0), size_125.Y / 2.0);
                var BlendSrcRgb_9dfc1a50_14_5_8 = Fuse.Drawing.BlendModeHelpers.GetSrcRgb($AsOp(brush, 728).BlendMode());
                var BlendSrcAlpha_9dfc1a50_14_7_9 = Fuse.Drawing.BlendModeHelpers.GetSrcAlpha($AsOp(brush, 728).BlendMode());
                var BlendDstRgb_9dfc1a50_14_6_10 = Fuse.Drawing.BlendModeHelpers.GetDstRgb($AsOp(brush, 728).BlendMode());
                var BlendDstAlpha_9dfc1a50_14_8_11 = Fuse.Drawing.BlendModeHelpers.GetDstAlpha($AsOp(brush, 728).BlendMode());
                {
                    this._draw_9dfc1a50.BlendEnabled(true);
                    this._draw_9dfc1a50.BlendSrcRgb(BlendSrcRgb_9dfc1a50_14_5_8);
                    this._draw_9dfc1a50.BlendSrcAlpha(BlendSrcAlpha_9dfc1a50_14_7_9);
                    this._draw_9dfc1a50.BlendDstRgb(BlendDstRgb_9dfc1a50_14_6_10);
                    this._draw_9dfc1a50.BlendDstAlpha(BlendDstAlpha_9dfc1a50_14_8_11);
                    this._draw_9dfc1a50.DepthTestEnabled(false);
                    this._draw_9dfc1a50.CullFace(0);
                    this._draw_9dfc1a50.Const(0, $AsOp(brush, 728).Texture() == null);
                    this._draw_9dfc1a50.Use();
                    this._draw_9dfc1a50.Attrib_1(1, 4, this.Draw_v_9dfc1a50_6_1_1, 16, 0);
                    this._draw_9dfc1a50.Uniform_9(2, position);
                    this._draw_9dfc1a50.Uniform_9(3, Uno.Float2.op_Subtraction_1(size_125, radius_9dfc1a50_3_3_2));
                    this._draw_9dfc1a50.Uniform_14(4, transform);
                    this._draw_9dfc1a50.Uniform_9(5, Fuse.Spaces.VirtualResolution());
                    this._draw_9dfc1a50.Uniform_9(6, size_125);
                    this._draw_9dfc1a50.Uniform_11(7, $AsOp(brush, 728).Color());
                    this._draw_9dfc1a50.Uniform_8(8, $AsOp(brush, 728).Opacity());
                    this._draw_9dfc1a50.Uniform_8(9, radius_9dfc1a50_3_3_2);
                    this._draw_9dfc1a50.Sampler_3(10, $AsOp(brush, 728).Texture(), Uno.Graphics.SamplerState.New_1($AsOp(brush, 728).MinFilter(), $AsOp(brush, 728).MagFilter(), 10497));
                    this._draw_9dfc1a50.DrawArrays(this.Draw_verts_9dfc1a50_6_0_12.length);
                }

                {
                    this._draw_9dfc1a6f.BlendEnabled(true);
                    this._draw_9dfc1a6f.BlendSrcRgb(BlendSrcRgb_9dfc1a50_14_5_8);
                    this._draw_9dfc1a6f.BlendSrcAlpha(BlendSrcAlpha_9dfc1a50_14_7_9);
                    this._draw_9dfc1a6f.BlendDstRgb(BlendDstRgb_9dfc1a50_14_6_10);
                    this._draw_9dfc1a6f.BlendDstAlpha(BlendDstAlpha_9dfc1a50_14_8_11);
                    this._draw_9dfc1a6f.DepthTestEnabled(false);
                    this._draw_9dfc1a6f.CullFace(0);
                    this._draw_9dfc1a6f.Const(0, $AsOp(brush, 728).Texture() == null);
                    this._draw_9dfc1a6f.Use();
                    this._draw_9dfc1a6f.Attrib_1(1, 4, this.Draw_v_9dfc1a6f_7_1_1, 16, 0);
                    this._draw_9dfc1a6f.Uniform_8(2, size_125.X - (radius_9dfc1a50_3_3_2 * 2.0));
                    this._draw_9dfc1a6f.Uniform_8(3, size_125.Y - (radius_9dfc1a50_3_3_2 * 2.0));
                    this._draw_9dfc1a6f.Uniform_9(4, position);
                    this._draw_9dfc1a6f.Uniform_14(5, transform);
                    this._draw_9dfc1a6f.Uniform_9(6, Fuse.Spaces.VirtualResolution());
                    this._draw_9dfc1a6f.Uniform_9(7, size_125);
                    this._draw_9dfc1a6f.Uniform_11(8, $AsOp(brush, 728).Color());
                    this._draw_9dfc1a6f.Uniform_8(9, $AsOp(brush, 728).Opacity());
                    this._draw_9dfc1a6f.Uniform_8(10, radius_9dfc1a50_3_3_2);
                    this._draw_9dfc1a6f.Sampler_3(11, $AsOp(brush, 728).Texture(), Uno.Graphics.SamplerState.New_1($AsOp(brush, 728).MinFilter(), $AsOp(brush, 728).MagFilter(), 10497));
                    this._draw_9dfc1a6f.DrawArrays(this.Draw_verts_9dfc1a6f_7_0_12.length);
                }
            }
            else if ($IsOp(brush, 725))
            {
                var radius_9dfc8eaf_3_3_2 = Uno.Math.Min_1(Uno.Math.Min_1(radius, size_125.X / 2.0), size_125.Y / 2.0);
                var BlendSrcRgb_9dfc8eaf_14_5_5 = Fuse.Drawing.BlendModeHelpers.GetSrcRgb($AsOp(brush, 725).BlendMode());
                var BlendSrcAlpha_9dfc8eaf_14_7_6 = Fuse.Drawing.BlendModeHelpers.GetSrcAlpha($AsOp(brush, 725).BlendMode());
                var BlendDstRgb_9dfc8eaf_14_6_7 = Fuse.Drawing.BlendModeHelpers.GetDstRgb($AsOp(brush, 725).BlendMode());
                var BlendDstAlpha_9dfc8eaf_14_8_8 = Fuse.Drawing.BlendModeHelpers.GetDstAlpha($AsOp(brush, 725).BlendMode());
                {
                    this._draw_9dfc8eaf.BlendEnabled(true);
                    this._draw_9dfc8eaf.BlendSrcRgb(BlendSrcRgb_9dfc8eaf_14_5_5);
                    this._draw_9dfc8eaf.BlendSrcAlpha(BlendSrcAlpha_9dfc8eaf_14_7_6);
                    this._draw_9dfc8eaf.BlendDstRgb(BlendDstRgb_9dfc8eaf_14_6_7);
                    this._draw_9dfc8eaf.BlendDstAlpha(BlendDstAlpha_9dfc8eaf_14_8_8);
                    this._draw_9dfc8eaf.DepthTestEnabled(false);
                    this._draw_9dfc8eaf.CullFace(0);
                    this._draw_9dfc8eaf.Use();
                    this._draw_9dfc8eaf.Attrib_1(0, 4, this.Draw_v_9dfc8eaf_6_1_1, 16, 0);
                    this._draw_9dfc8eaf.Uniform_9(1, position);
                    this._draw_9dfc8eaf.Uniform_9(2, Uno.Float2.op_Subtraction_1(size_125, radius_9dfc8eaf_3_3_2));
                    this._draw_9dfc8eaf.Uniform_14(3, transform);
                    this._draw_9dfc8eaf.Uniform_9(4, Fuse.Spaces.VirtualResolution());
                    this._draw_9dfc8eaf.Uniform_11(5, Uno.Float4.New_7(Uno.Float3.op_Multiply(Uno.Float3.op_Multiply((ind_126 = $AsOp(brush, 725).Color(), Uno.Float3.New_2(ind_126.X, ind_126.Y, ind_126.Z)), $AsOp(brush, 725).Color().W), $AsOp(brush, 725).Opacity()), $AsOp(brush, 725).Color().W * $AsOp(brush, 725).Opacity()));
                    this._draw_9dfc8eaf.Uniform_8(6, radius_9dfc8eaf_3_3_2);
                    this._draw_9dfc8eaf.DrawArrays(this.Draw_verts_9dfc1a50_6_0_12.length);
                }

                {
                    this._draw_9dfc8ece.BlendEnabled(true);
                    this._draw_9dfc8ece.BlendSrcRgb(BlendSrcRgb_9dfc8eaf_14_5_5);
                    this._draw_9dfc8ece.BlendSrcAlpha(BlendSrcAlpha_9dfc8eaf_14_7_6);
                    this._draw_9dfc8ece.BlendDstRgb(BlendDstRgb_9dfc8eaf_14_6_7);
                    this._draw_9dfc8ece.BlendDstAlpha(BlendDstAlpha_9dfc8eaf_14_8_8);
                    this._draw_9dfc8ece.DepthTestEnabled(false);
                    this._draw_9dfc8ece.CullFace(0);
                    this._draw_9dfc8ece.Use();
                    this._draw_9dfc8ece.Attrib_1(0, 4, this.Draw_v_9dfc8ece_7_1_1, 16, 0);
                    this._draw_9dfc8ece.Uniform_8(1, size_125.X - (radius_9dfc8eaf_3_3_2 * 2.0));
                    this._draw_9dfc8ece.Uniform_8(2, size_125.Y - (radius_9dfc8eaf_3_3_2 * 2.0));
                    this._draw_9dfc8ece.Uniform_9(3, position);
                    this._draw_9dfc8ece.Uniform_14(4, transform);
                    this._draw_9dfc8ece.Uniform_9(5, Fuse.Spaces.VirtualResolution());
                    this._draw_9dfc8ece.Uniform_11(6, Uno.Float4.New_7(Uno.Float3.op_Multiply(Uno.Float3.op_Multiply((ind_127 = $AsOp(brush, 725).Color(), Uno.Float3.New_2(ind_127.X, ind_127.Y, ind_127.Z)), $AsOp(brush, 725).Color().W), $AsOp(brush, 725).Opacity()), $AsOp(brush, 725).Color().W * $AsOp(brush, 725).Opacity()));
                    this._draw_9dfc8ece.Uniform_8(7, radius_9dfc8eaf_3_3_2);
                    this._draw_9dfc8ece.DrawArrays(this.Draw_verts_9dfc1a6f_7_0_12.length);
                }
            }
            else if ($IsOp(brush, 724))
            {
                var radius_9dfd030e_3_3_2 = Uno.Math.Min_1(Uno.Math.Min_1(radius, size_125.X / 2.0), size_125.Y / 2.0);
                var Colors_9dfd030e_15_9_8 = Fuse.Internal.Drawing.RoundedRectangle_RoundedRectangleImpl.Draw_Colors_9dfd030e_15_9_7($AsOp(brush, 724).SortedStops());
                var Offsets_9dfd030e_15_8_10 = Fuse.Internal.Drawing.RoundedRectangle_RoundedRectangleImpl.Draw_Offsets_9dfd030e_15_8_9($AsOp(brush, 724).SortedStops());
                var BlendSrcRgb_9dfd030e_14_5_13 = Fuse.Drawing.BlendModeHelpers.GetSrcRgb($AsOp(brush, 724).BlendMode());
                var BlendSrcAlpha_9dfd030e_14_7_14 = Fuse.Drawing.BlendModeHelpers.GetSrcAlpha($AsOp(brush, 724).BlendMode());
                var BlendDstRgb_9dfd030e_14_6_15 = Fuse.Drawing.BlendModeHelpers.GetDstRgb($AsOp(brush, 724).BlendMode());
                var BlendDstAlpha_9dfd030e_14_8_16 = Fuse.Drawing.BlendModeHelpers.GetDstAlpha($AsOp(brush, 724).BlendMode());
                {
                    this._draw_9dfd030e.BlendEnabled(true);
                    this._draw_9dfd030e.BlendSrcRgb(BlendSrcRgb_9dfd030e_14_5_13);
                    this._draw_9dfd030e.BlendSrcAlpha(BlendSrcAlpha_9dfd030e_14_7_14);
                    this._draw_9dfd030e.BlendDstRgb(BlendDstRgb_9dfd030e_14_6_15);
                    this._draw_9dfd030e.BlendDstAlpha(BlendDstAlpha_9dfd030e_14_8_16);
                    this._draw_9dfd030e.DepthTestEnabled(false);
                    this._draw_9dfd030e.CullFace(0);
                    this._draw_9dfd030e.Const_1(0, Colors_9dfd030e_15_9_8.length);
                    this._draw_9dfd030e.Const_1(1, Offsets_9dfd030e_15_8_10.length);
                    this._draw_9dfd030e.Use();
                    this._draw_9dfd030e.Attrib_1(2, 4, this.Draw_v_9dfd030e_6_1_1, 16, 0);
                    this._draw_9dfd030e.Uniform_9(3, position);
                    this._draw_9dfd030e.Uniform_9(4, Uno.Float2.op_Subtraction_1(size_125, radius_9dfd030e_3_3_2));
                    this._draw_9dfd030e.Uniform_14(5, transform);
                    this._draw_9dfd030e.Uniform_9(6, Fuse.Spaces.VirtualResolution());
                    this._draw_9dfd030e.Uniform_9(7, size_125);
                    this._draw_9dfd030e.Uniform_9(8, $AsOp(brush, 724).EndPoint());
                    this._draw_9dfd030e.Uniform_9(9, $AsOp(brush, 724).StartPoint());
                    this._draw_9dfd030e.Uniform_18(10, Colors_9dfd030e_15_9_8);
                    this._draw_9dfd030e.Uniform_15(11, Offsets_9dfd030e_15_8_10);
                    this._draw_9dfd030e.Uniform_8(12, $AsOp(brush, 724).Opacity());
                    this._draw_9dfd030e.Uniform_8(13, radius_9dfd030e_3_3_2);
                    this._draw_9dfd030e.DrawArrays(this.Draw_verts_9dfc1a50_6_0_12.length);
                }

                {
                    this._draw_9dfd032d.BlendEnabled(true);
                    this._draw_9dfd032d.BlendSrcRgb(BlendSrcRgb_9dfd030e_14_5_13);
                    this._draw_9dfd032d.BlendSrcAlpha(BlendSrcAlpha_9dfd030e_14_7_14);
                    this._draw_9dfd032d.BlendDstRgb(BlendDstRgb_9dfd030e_14_6_15);
                    this._draw_9dfd032d.BlendDstAlpha(BlendDstAlpha_9dfd030e_14_8_16);
                    this._draw_9dfd032d.DepthTestEnabled(false);
                    this._draw_9dfd032d.CullFace(0);
                    this._draw_9dfd032d.Const_1(0, Colors_9dfd030e_15_9_8.length);
                    this._draw_9dfd032d.Const_1(1, Offsets_9dfd030e_15_8_10.length);
                    this._draw_9dfd032d.Use();
                    this._draw_9dfd032d.Attrib_1(2, 4, this.Draw_v_9dfd032d_7_1_1, 16, 0);
                    this._draw_9dfd032d.Uniform_8(3, size_125.X - (radius_9dfd030e_3_3_2 * 2.0));
                    this._draw_9dfd032d.Uniform_8(4, size_125.Y - (radius_9dfd030e_3_3_2 * 2.0));
                    this._draw_9dfd032d.Uniform_9(5, position);
                    this._draw_9dfd032d.Uniform_14(6, transform);
                    this._draw_9dfd032d.Uniform_9(7, Fuse.Spaces.VirtualResolution());
                    this._draw_9dfd032d.Uniform_9(8, size_125);
                    this._draw_9dfd032d.Uniform_9(9, $AsOp(brush, 724).EndPoint());
                    this._draw_9dfd032d.Uniform_9(10, $AsOp(brush, 724).StartPoint());
                    this._draw_9dfd032d.Uniform_18(11, Colors_9dfd030e_15_9_8);
                    this._draw_9dfd032d.Uniform_15(12, Offsets_9dfd030e_15_8_10);
                    this._draw_9dfd032d.Uniform_8(13, $AsOp(brush, 724).Opacity());
                    this._draw_9dfd032d.Uniform_8(14, radius_9dfd030e_3_3_2);
                    this._draw_9dfd032d.DrawArrays(this.Draw_verts_9dfc1a6f_7_0_12.length);
                }
            }
            else if ($IsOp(brush, 38))
            {
                var radius_9dfd776d_3_3_2 = Uno.Math.Min_1(Uno.Math.Min_1(radius, size_125.X / 2.0), size_125.Y / 2.0);
                var BlendSrcRgb_9dfd776d_14_5_8 = Fuse.Drawing.BlendModeHelpers.GetSrcRgb($AsOp(brush, 38).BlendMode());
                var BlendSrcAlpha_9dfd776d_14_7_9 = Fuse.Drawing.BlendModeHelpers.GetSrcAlpha($AsOp(brush, 38).BlendMode());
                var BlendDstRgb_9dfd776d_14_6_10 = Fuse.Drawing.BlendModeHelpers.GetDstRgb($AsOp(brush, 38).BlendMode());
                var BlendDstAlpha_9dfd776d_14_8_11 = Fuse.Drawing.BlendModeHelpers.GetDstAlpha($AsOp(brush, 38).BlendMode());
                {
                    this._draw_9dfd776d.BlendEnabled(true);
                    this._draw_9dfd776d.BlendSrcRgb(BlendSrcRgb_9dfd776d_14_5_8);
                    this._draw_9dfd776d.BlendSrcAlpha(BlendSrcAlpha_9dfd776d_14_7_9);
                    this._draw_9dfd776d.BlendDstRgb(BlendDstRgb_9dfd776d_14_6_10);
                    this._draw_9dfd776d.BlendDstAlpha(BlendDstAlpha_9dfd776d_14_8_11);
                    this._draw_9dfd776d.DepthTestEnabled(false);
                    this._draw_9dfd776d.CullFace(0);
                    this._draw_9dfd776d.Use();
                    this._draw_9dfd776d.Attrib_1(0, 4, this.Draw_v_9dfd776d_6_1_1, 16, 0);
                    this._draw_9dfd776d.Uniform_9(1, position);
                    this._draw_9dfd776d.Uniform_9(2, Uno.Float2.op_Subtraction_1(size_125, radius_9dfd776d_3_3_2));
                    this._draw_9dfd776d.Uniform_14(3, transform);
                    this._draw_9dfd776d.Uniform_9(4, Fuse.Spaces.VirtualResolution());
                    this._draw_9dfd776d.Uniform_9(5, size_125);
                    this._draw_9dfd776d.Uniform_8(6, $AsOp(brush, 38).Split());
                    this._draw_9dfd776d.Uniform_11(7, $AsOp(brush, 38).Right());
                    this._draw_9dfd776d.Uniform_11(8, $AsOp(brush, 38).Left());
                    this._draw_9dfd776d.Uniform_8(9, $AsOp(brush, 38).Opacity());
                    this._draw_9dfd776d.Uniform_8(10, radius_9dfd776d_3_3_2);
                    this._draw_9dfd776d.DrawArrays(this.Draw_verts_9dfc1a50_6_0_12.length);
                }

                {
                    this._draw_9dfd778c.BlendEnabled(true);
                    this._draw_9dfd778c.BlendSrcRgb(BlendSrcRgb_9dfd776d_14_5_8);
                    this._draw_9dfd778c.BlendSrcAlpha(BlendSrcAlpha_9dfd776d_14_7_9);
                    this._draw_9dfd778c.BlendDstRgb(BlendDstRgb_9dfd776d_14_6_10);
                    this._draw_9dfd778c.BlendDstAlpha(BlendDstAlpha_9dfd776d_14_8_11);
                    this._draw_9dfd778c.DepthTestEnabled(false);
                    this._draw_9dfd778c.CullFace(0);
                    this._draw_9dfd778c.Use();
                    this._draw_9dfd778c.Attrib_1(0, 4, this.Draw_v_9dfd778c_7_1_1, 16, 0);
                    this._draw_9dfd778c.Uniform_8(1, size_125.X - (radius_9dfd776d_3_3_2 * 2.0));
                    this._draw_9dfd778c.Uniform_8(2, size_125.Y - (radius_9dfd776d_3_3_2 * 2.0));
                    this._draw_9dfd778c.Uniform_9(3, position);
                    this._draw_9dfd778c.Uniform_14(4, transform);
                    this._draw_9dfd778c.Uniform_9(5, Fuse.Spaces.VirtualResolution());
                    this._draw_9dfd778c.Uniform_9(6, size_125);
                    this._draw_9dfd778c.Uniform_8(7, $AsOp(brush, 38).Split());
                    this._draw_9dfd778c.Uniform_11(8, $AsOp(brush, 38).Right());
                    this._draw_9dfd778c.Uniform_11(9, $AsOp(brush, 38).Left());
                    this._draw_9dfd778c.Uniform_8(10, $AsOp(brush, 38).Opacity());
                    this._draw_9dfd778c.Uniform_8(11, radius_9dfd776d_3_3_2);
                    this._draw_9dfd778c.DrawArrays(this.Draw_verts_9dfc1a6f_7_0_12.length);
                }
            }
            else if ($IsOp(brush, 726))
            {
                var radius_9dfdebcc_3_3_2 = Uno.Math.Min_1(Uno.Math.Min_1(radius, size_125.X / 2.0), size_125.Y / 2.0);
                {
                    this._draw_9dfc8eaf.BlendEnabled(true);
                    this._draw_9dfc8eaf.BlendSrcRgb(this.Draw_BlendSrcRgb_9dfdebcc_13_3_9);
                    this._draw_9dfc8eaf.BlendSrcAlpha(this.Draw_BlendSrcAlpha_9dfdebcc_13_5_10);
                    this._draw_9dfc8eaf.BlendDstRgb(this.Draw_BlendDstRgb_9dfdebcc_13_4_11);
                    this._draw_9dfc8eaf.BlendDstAlpha(this.Draw_BlendDstAlpha_9dfdebcc_13_6_12);
                    this._draw_9dfc8eaf.DepthTestEnabled(false);
                    this._draw_9dfc8eaf.CullFace(0);
                    this._draw_9dfc8eaf.Use();
                    this._draw_9dfc8eaf.Attrib_1(0, 4, this.Draw_v_9dfdebcc_6_1_1, 16, 0);
                    this._draw_9dfc8eaf.Uniform_9(1, position);
                    this._draw_9dfc8eaf.Uniform_9(2, Uno.Float2.op_Subtraction_1(size_125, radius_9dfdebcc_3_3_2));
                    this._draw_9dfc8eaf.Uniform_14(3, transform);
                    this._draw_9dfc8eaf.Uniform_9(4, Fuse.Spaces.VirtualResolution());
                    this._draw_9dfc8eaf.Uniform_11(5, Uno.Float4.New_7(Uno.Float3.op_Multiply((ind_128 = $AsOp(brush, 726).Color(), Uno.Float3.New_2(ind_128.X, ind_128.Y, ind_128.Z)), $AsOp(brush, 726).Color().W), $AsOp(brush, 726).Color().W));
                    this._draw_9dfc8eaf.Uniform_8(6, radius_9dfdebcc_3_3_2);
                    this._draw_9dfc8eaf.DrawArrays(this.Draw_verts_9dfc1a50_6_0_12.length);
                }

                {
                    this._draw_9dfc8ece.BlendEnabled(true);
                    this._draw_9dfc8ece.BlendSrcRgb(this.Draw_BlendSrcRgb_9dfdebcc_13_3_9);
                    this._draw_9dfc8ece.BlendSrcAlpha(this.Draw_BlendSrcAlpha_9dfdebcc_13_5_10);
                    this._draw_9dfc8ece.BlendDstRgb(this.Draw_BlendDstRgb_9dfdebcc_13_4_11);
                    this._draw_9dfc8ece.BlendDstAlpha(this.Draw_BlendDstAlpha_9dfdebcc_13_6_12);
                    this._draw_9dfc8ece.DepthTestEnabled(false);
                    this._draw_9dfc8ece.CullFace(0);
                    this._draw_9dfc8ece.Use();
                    this._draw_9dfc8ece.Attrib_1(0, 4, this.Draw_v_9dfdebeb_7_1_1, 16, 0);
                    this._draw_9dfc8ece.Uniform_8(1, size_125.X - (radius_9dfdebcc_3_3_2 * 2.0));
                    this._draw_9dfc8ece.Uniform_8(2, size_125.Y - (radius_9dfdebcc_3_3_2 * 2.0));
                    this._draw_9dfc8ece.Uniform_9(3, position);
                    this._draw_9dfc8ece.Uniform_14(4, transform);
                    this._draw_9dfc8ece.Uniform_9(5, Fuse.Spaces.VirtualResolution());
                    this._draw_9dfc8ece.Uniform_11(6, Uno.Float4.New_7(Uno.Float3.op_Multiply((ind_129 = $AsOp(brush, 726).Color(), Uno.Float3.New_2(ind_129.X, ind_129.Y, ind_129.Z)), $AsOp(brush, 726).Color().W), $AsOp(brush, 726).Color().W));
                    this._draw_9dfc8ece.Uniform_8(7, radius_9dfdebcc_3_3_2);
                    this._draw_9dfc8ece.DrawArrays(this.Draw_verts_9dfc1a6f_7_0_12.length);
                }
            }
        };

        I.init_DrawCalls = function()
        {
            var verts_9dfc1a50_6_0_0 = Array.Init([Uno.Float4.New_2(0.0, 0.0, 0.0, 0.0), Uno.Float4.New_2(0.0, 1.0, 0.0, 0.0), Uno.Float4.New_2(1.0, 1.0, 0.0, 0.0), Uno.Float4.New_2(0.0, 0.0, 0.0, 0.0), Uno.Float4.New_2(1.0, 1.0, 0.0, 0.0), Uno.Float4.New_2(1.0, 0.0, 0.0, 0.0), Uno.Float4.New_2(0.0, 0.0, 0.0, 1.0), Uno.Float4.New_2(0.0, 1.0, 0.0, 1.0), Uno.Float4.New_2(1.0, 1.0, 0.0, 1.0), Uno.Float4.New_2(0.0, 0.0, 0.0, 1.0), Uno.Float4.New_2(1.0, 1.0, 0.0, 1.0), Uno.Float4.New_2(1.0, 0.0, 0.0, 1.0), Uno.Float4.New_2(0.0, 0.0, 1.0, 1.0), Uno.Float4.New_2(0.0, 1.0, 1.0, 1.0), Uno.Float4.New_2(1.0, 1.0, 1.0, 1.0), Uno.Float4.New_2(0.0, 0.0, 1.0, 1.0), Uno.Float4.New_2(1.0, 1.0, 1.0, 1.0), Uno.Float4.New_2(1.0, 0.0, 1.0, 1.0), Uno.Float4.New_2(0.0, 0.0, 1.0, 0.0), Uno.Float4.New_2(0.0, 1.0, 1.0, 0.0), Uno.Float4.New_2(1.0, 1.0, 1.0, 0.0), Uno.Float4.New_2(0.0, 0.0, 1.0, 0.0), Uno.Float4.New_2(1.0, 1.0, 1.0, 0.0), Uno.Float4.New_2(1.0, 0.0, 1.0, 0.0)], 432);
            this.Draw_v_9dfc1a50_6_1_1 = Uno.Graphics.VertexBuffer.New_3(Uno.Runtime.Implementation.Internal.BufferConverters.ToBuffer_3(verts_9dfc1a50_6_0_0), 0);
            this.Draw_verts_9dfc1a50_6_0_12 = verts_9dfc1a50_6_0_0;
            var verts_9dfc1a6f_7_0_0 = Array.Init([Uno.Float4.New_2(1.0, 0.0, 0.0, 0.0), Uno.Float4.New_2(1.0, 1.0, 0.0, 0.0), Uno.Float4.New_2(1.0, 1.0, 1.0, 0.0), Uno.Float4.New_2(1.0, 0.0, 0.0, 0.0), Uno.Float4.New_2(1.0, 1.0, 1.0, 0.0), Uno.Float4.New_2(1.0, 0.0, 1.0, 0.0), Uno.Float4.New_2(0.0, 1.0, 0.0, 0.0), Uno.Float4.New_2(0.0, 1.0, 0.0, 1.0), Uno.Float4.New_2(1.0, 1.0, 0.0, 1.0), Uno.Float4.New_2(0.0, 1.0, 0.0, 0.0), Uno.Float4.New_2(1.0, 1.0, 0.0, 1.0), Uno.Float4.New_2(1.0, 1.0, 0.0, 0.0), Uno.Float4.New_2(1.0, 1.0, 0.0, 0.0), Uno.Float4.New_2(1.0, 1.0, 0.0, 1.0), Uno.Float4.New_2(1.0, 1.0, 1.0, 1.0), Uno.Float4.New_2(1.0, 1.0, 0.0, 0.0), Uno.Float4.New_2(1.0, 1.0, 1.0, 1.0), Uno.Float4.New_2(1.0, 1.0, 1.0, 0.0), Uno.Float4.New_2(1.0, 1.0, 0.0, 1.0), Uno.Float4.New_2(1.0, 2.0, 0.0, 1.0), Uno.Float4.New_2(1.0, 2.0, 1.0, 1.0), Uno.Float4.New_2(1.0, 1.0, 0.0, 1.0), Uno.Float4.New_2(1.0, 2.0, 1.0, 1.0), Uno.Float4.New_2(1.0, 1.0, 1.0, 1.0), Uno.Float4.New_2(1.0, 1.0, 1.0, 0.0), Uno.Float4.New_2(1.0, 1.0, 1.0, 1.0), Uno.Float4.New_2(2.0, 1.0, 1.0, 1.0), Uno.Float4.New_2(1.0, 1.0, 1.0, 0.0), Uno.Float4.New_2(2.0, 1.0, 1.0, 1.0), Uno.Float4.New_2(2.0, 1.0, 1.0, 0.0)], 432);
            this.Draw_v_9dfc1a6f_7_1_1 = Uno.Graphics.VertexBuffer.New_3(Uno.Runtime.Implementation.Internal.BufferConverters.ToBuffer_3(verts_9dfc1a6f_7_0_0), 0);
            this.Draw_verts_9dfc1a6f_7_0_12 = verts_9dfc1a6f_7_0_0;
            this.Draw_v_9dfc8eaf_6_1_1 = Uno.Graphics.VertexBuffer.New_3(Uno.Runtime.Implementation.Internal.BufferConverters.ToBuffer_3(verts_9dfc1a50_6_0_0), 0);
            this.Draw_v_9dfc8ece_7_1_1 = Uno.Graphics.VertexBuffer.New_3(Uno.Runtime.Implementation.Internal.BufferConverters.ToBuffer_3(verts_9dfc1a6f_7_0_0), 0);
            this.Draw_v_9dfd030e_6_1_1 = Uno.Graphics.VertexBuffer.New_3(Uno.Runtime.Implementation.Internal.BufferConverters.ToBuffer_3(verts_9dfc1a50_6_0_0), 0);
            this.Draw_v_9dfd032d_7_1_1 = Uno.Graphics.VertexBuffer.New_3(Uno.Runtime.Implementation.Internal.BufferConverters.ToBuffer_3(verts_9dfc1a6f_7_0_0), 0);
            this.Draw_v_9dfd776d_6_1_1 = Uno.Graphics.VertexBuffer.New_3(Uno.Runtime.Implementation.Internal.BufferConverters.ToBuffer_3(verts_9dfc1a50_6_0_0), 0);
            this.Draw_v_9dfd778c_7_1_1 = Uno.Graphics.VertexBuffer.New_3(Uno.Runtime.Implementation.Internal.BufferConverters.ToBuffer_3(verts_9dfc1a6f_7_0_0), 0);
            this.Draw_v_9dfdebcc_6_1_1 = Uno.Graphics.VertexBuffer.New_3(Uno.Runtime.Implementation.Internal.BufferConverters.ToBuffer_3(verts_9dfc1a50_6_0_0), 0);
            this.Draw_BlendSrcRgb_9dfdebcc_13_3_9 = Fuse.Drawing.BlendModeHelpers.GetSrcRgb(0);
            this.Draw_BlendSrcAlpha_9dfdebcc_13_5_10 = Fuse.Drawing.BlendModeHelpers.GetSrcAlpha(0);
            this.Draw_BlendDstRgb_9dfdebcc_13_4_11 = Fuse.Drawing.BlendModeHelpers.GetDstRgb(0);
            this.Draw_BlendDstAlpha_9dfdebcc_13_6_12 = Fuse.Drawing.BlendModeHelpers.GetDstAlpha(0);
            this.Draw_v_9dfdebeb_7_1_1 = Uno.Graphics.VertexBuffer.New_3(Uno.Runtime.Implementation.Internal.BufferConverters.ToBuffer_3(verts_9dfc1a6f_7_0_0), 0);
            this._draw_9dfc1a50 = Uno.Runtime.Implementation.ShaderBackends.OpenGL.GLDrawCall.New_1($DownCast(Uno.Runtime.Implementation.Internal.BundleRegistry.Get(18), 383));
            this._draw_9dfc1a6f = Uno.Runtime.Implementation.ShaderBackends.OpenGL.GLDrawCall.New_1($DownCast(Uno.Runtime.Implementation.Internal.BundleRegistry.Get(19), 383));
            this._draw_9dfc8eaf = Uno.Runtime.Implementation.ShaderBackends.OpenGL.GLDrawCall.New_1($DownCast(Uno.Runtime.Implementation.Internal.BundleRegistry.Get(20), 383));
            this._draw_9dfc8ece = Uno.Runtime.Implementation.ShaderBackends.OpenGL.GLDrawCall.New_1($DownCast(Uno.Runtime.Implementation.Internal.BundleRegistry.Get(21), 383));
            this._draw_9dfd030e = Uno.Runtime.Implementation.ShaderBackends.OpenGL.GLDrawCall.New_1($DownCast(Uno.Runtime.Implementation.Internal.BundleRegistry.Get(22), 383));
            this._draw_9dfd032d = Uno.Runtime.Implementation.ShaderBackends.OpenGL.GLDrawCall.New_1($DownCast(Uno.Runtime.Implementation.Internal.BundleRegistry.Get(23), 383));
            this._draw_9dfd776d = Uno.Runtime.Implementation.ShaderBackends.OpenGL.GLDrawCall.New_1($DownCast(Uno.Runtime.Implementation.Internal.BundleRegistry.Get(24), 383));
            this._draw_9dfd778c = Uno.Runtime.Implementation.ShaderBackends.OpenGL.GLDrawCall.New_1($DownCast(Uno.Runtime.Implementation.Internal.BundleRegistry.Get(25), 383));
        };

        Fuse.Internal.Drawing.RoundedRectangle_RoundedRectangleImpl.Draw_Colors_9dfd030e_15_9_7 = function(Colors_15_9_6)
        {
            var cols = Array.Structs(Uno.Math.Max_8(Colors_15_9_6.length, 1), Uno.Float4, 432);

            for (var i = 0; i < Colors_15_9_6.length; i++)
            {
                cols[i].op_Assign(Colors_15_9_6[i].Color());
            }

            return cols;
        };

        Fuse.Internal.Drawing.RoundedRectangle_RoundedRectangleImpl.Draw_Offsets_9dfd030e_15_8_9 = function(Offsets_15_8_7)
        {
            var ofs = Array.Zeros(Uno.Math.Max_8(Offsets_15_8_7.length, 1), 429);

            for (var i = 0; i < Offsets_15_8_7.length; i++)
            {
                ofs[i] = Offsets_15_8_7[i].Offset();
            }

            return ofs;
        };

        I._ObjInit = function()
        {
            this.init_DrawCalls();
        };

        Fuse.Internal.Drawing.RoundedRectangle_RoundedRectangleImpl.New_1 = function()
        {
            var inst = new Fuse.Internal.Drawing.RoundedRectangle_RoundedRectangleImpl;
            inst._ObjInit();
            return inst;
        };

    });
