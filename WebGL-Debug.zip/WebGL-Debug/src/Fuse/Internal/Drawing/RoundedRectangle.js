Fuse.Internal.Drawing.RoundedRectangle = $CreateClass(
    function() {
    },
    function(S) {
        Fuse.Internal.Drawing.RoundedRectangle._singleton = null;

        Fuse.Internal.Drawing.RoundedRectangle.Draw = function(dc, position, transform, size, color, cornerRadius)
        {
            Fuse.Internal.Drawing.RoundedRectangle.Draw_1(dc, position, transform, size, Fuse.Drawing.SolidColor.New_2(color), cornerRadius);
        };

        Fuse.Internal.Drawing.RoundedRectangle.Draw_1 = function(dc, position, transform, size, brush, cornerRadius)
        {
            if (Fuse.Internal.Drawing.RoundedRectangle._singleton == null)
            {
                Fuse.Internal.Drawing.RoundedRectangle._singleton = Fuse.Internal.Drawing.RoundedRectangle_RoundedRectangleImpl.New_1();
            }

            Fuse.Internal.Drawing.RoundedRectangle._singleton.Draw(dc, position, transform, Uno.Math.Floor_2(Uno.Float2.op_Addition_1(size, 0.5)), brush, cornerRadius);
        };

    });
