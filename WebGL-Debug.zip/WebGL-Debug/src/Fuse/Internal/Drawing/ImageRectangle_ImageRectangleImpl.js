Fuse.Internal.Drawing.ImageRectangle_ImageRectangleImpl = $CreateClass(
    function() {
        this.Draw_Coord_9931b07c_2_1_1 = null;
        this.Draw_Vertices_9931b07c_2_0_10 = null;
        this.Draw_Coord_993224db_2_1_1 = null;
        this.Draw_Coord_9932993a_2_1_1 = null;
        this.Draw_Coord_99330d99_2_1_1 = null;
        this.Draw_Coord_993381f8_2_1_1 = null;
        this.Draw_BlendSrcRgb_993381f8_7_3_7 = 0;
        this.Draw_BlendSrcAlpha_993381f8_7_5_8 = 0;
        this.Draw_BlendDstRgb_993381f8_7_4_9 = 0;
        this.Draw_BlendDstAlpha_993381f8_7_6_10 = 0;
        this._draw_9931b07c = new Uno.Runtime.Implementation.ShaderBackends.OpenGL.GLDrawCall;
        this._draw_993224db = new Uno.Runtime.Implementation.ShaderBackends.OpenGL.GLDrawCall;
        this._draw_9932993a = new Uno.Runtime.Implementation.ShaderBackends.OpenGL.GLDrawCall;
        this._draw_99330d99 = new Uno.Runtime.Implementation.ShaderBackends.OpenGL.GLDrawCall;
    },
    function(S) {
        var I = S.prototype;

        I.GetType = function()
        {
            return 808;
        };

        I.Draw = function(dc, transform, offset, size, uvPosition, uvSize, brush)
        {
            var ind_128;
            var ind_129;

            if ($IsOp(brush, 728))
            {
                {
                    this._draw_9931b07c.BlendEnabled(true);
                    this._draw_9931b07c.BlendSrcRgb(Fuse.Drawing.BlendModeHelpers.GetSrcRgb($AsOp(brush, 728).BlendMode()));
                    this._draw_9931b07c.BlendSrcAlpha(Fuse.Drawing.BlendModeHelpers.GetSrcAlpha($AsOp(brush, 728).BlendMode()));
                    this._draw_9931b07c.BlendDstRgb(Fuse.Drawing.BlendModeHelpers.GetDstRgb($AsOp(brush, 728).BlendMode()));
                    this._draw_9931b07c.BlendDstAlpha(Fuse.Drawing.BlendModeHelpers.GetDstAlpha($AsOp(brush, 728).BlendMode()));
                    this._draw_9931b07c.DepthTestEnabled(false);
                    this._draw_9931b07c.CullFace(0);
                    this._draw_9931b07c.Const(0, $AsOp(brush, 728).Texture() == null);
                    this._draw_9931b07c.Use();
                    this._draw_9931b07c.Attrib_1(1, 2, this.Draw_Coord_9931b07c_2_1_1, 8, 0);
                    this._draw_9931b07c.Uniform_9(2, size);
                    this._draw_9931b07c.Uniform_9(3, offset);
                    this._draw_9931b07c.Uniform_14(4, transform);
                    this._draw_9931b07c.Uniform_9(5, Fuse.Spaces.VirtualResolution());
                    this._draw_9931b07c.Uniform_9(6, uvSize);
                    this._draw_9931b07c.Uniform_9(7, uvPosition);
                    this._draw_9931b07c.Uniform_11(8, $AsOp(brush, 728).Color());
                    this._draw_9931b07c.Uniform_8(9, $AsOp(brush, 728).Opacity());
                    this._draw_9931b07c.Sampler_3(10, $AsOp(brush, 728).Texture(), Uno.Graphics.SamplerState.New_1($AsOp(brush, 728).MinFilter(), $AsOp(brush, 728).MagFilter(), 10497));
                    this._draw_9931b07c.DrawArrays(this.Draw_Vertices_9931b07c_2_0_10.length);
                }
            }
            else if ($IsOp(brush, 725))
            {
                {
                    this._draw_993224db.BlendEnabled(true);
                    this._draw_993224db.BlendSrcRgb(Fuse.Drawing.BlendModeHelpers.GetSrcRgb($AsOp(brush, 725).BlendMode()));
                    this._draw_993224db.BlendSrcAlpha(Fuse.Drawing.BlendModeHelpers.GetSrcAlpha($AsOp(brush, 725).BlendMode()));
                    this._draw_993224db.BlendDstRgb(Fuse.Drawing.BlendModeHelpers.GetDstRgb($AsOp(brush, 725).BlendMode()));
                    this._draw_993224db.BlendDstAlpha(Fuse.Drawing.BlendModeHelpers.GetDstAlpha($AsOp(brush, 725).BlendMode()));
                    this._draw_993224db.DepthTestEnabled(false);
                    this._draw_993224db.CullFace(0);
                    this._draw_993224db.Use();
                    this._draw_993224db.Attrib_1(0, 2, this.Draw_Coord_993224db_2_1_1, 8, 0);
                    this._draw_993224db.Uniform_9(1, size);
                    this._draw_993224db.Uniform_9(2, offset);
                    this._draw_993224db.Uniform_14(3, transform);
                    this._draw_993224db.Uniform_9(4, Fuse.Spaces.VirtualResolution());
                    this._draw_993224db.Uniform_11(5, Uno.Float4.New_7(Uno.Float3.op_Multiply(Uno.Float3.op_Multiply((ind_128 = $AsOp(brush, 725).Color(), Uno.Float3.New_2(ind_128.X, ind_128.Y, ind_128.Z)), $AsOp(brush, 725).Color().W), $AsOp(brush, 725).Opacity()), $AsOp(brush, 725).Color().W * $AsOp(brush, 725).Opacity()));
                    this._draw_993224db.DrawArrays(this.Draw_Vertices_9931b07c_2_0_10.length);
                }
            }
            else if ($IsOp(brush, 724))
            {
                var Colors_9932993a_9_9_6 = Fuse.Internal.Drawing.ImageRectangle_ImageRectangleImpl.Draw_Colors_9932993a_9_9_5($AsOp(brush, 724).SortedStops());
                var Offsets_9932993a_9_8_8 = Fuse.Internal.Drawing.ImageRectangle_ImageRectangleImpl.Draw_Offsets_9932993a_9_8_7($AsOp(brush, 724).SortedStops());
                {
                    this._draw_9932993a.BlendEnabled(true);
                    this._draw_9932993a.BlendSrcRgb(Fuse.Drawing.BlendModeHelpers.GetSrcRgb($AsOp(brush, 724).BlendMode()));
                    this._draw_9932993a.BlendSrcAlpha(Fuse.Drawing.BlendModeHelpers.GetSrcAlpha($AsOp(brush, 724).BlendMode()));
                    this._draw_9932993a.BlendDstRgb(Fuse.Drawing.BlendModeHelpers.GetDstRgb($AsOp(brush, 724).BlendMode()));
                    this._draw_9932993a.BlendDstAlpha(Fuse.Drawing.BlendModeHelpers.GetDstAlpha($AsOp(brush, 724).BlendMode()));
                    this._draw_9932993a.DepthTestEnabled(false);
                    this._draw_9932993a.CullFace(0);
                    this._draw_9932993a.Const_1(0, Colors_9932993a_9_9_6.length);
                    this._draw_9932993a.Const_1(1, Offsets_9932993a_9_8_8.length);
                    this._draw_9932993a.Use();
                    this._draw_9932993a.Attrib_1(2, 2, this.Draw_Coord_9932993a_2_1_1, 8, 0);
                    this._draw_9932993a.Uniform_9(3, size);
                    this._draw_9932993a.Uniform_9(4, offset);
                    this._draw_9932993a.Uniform_14(5, transform);
                    this._draw_9932993a.Uniform_9(6, Fuse.Spaces.VirtualResolution());
                    this._draw_9932993a.Uniform_9(7, uvSize);
                    this._draw_9932993a.Uniform_9(8, uvPosition);
                    this._draw_9932993a.Uniform_9(9, $AsOp(brush, 724).EndPoint());
                    this._draw_9932993a.Uniform_9(10, $AsOp(brush, 724).StartPoint());
                    this._draw_9932993a.Uniform_18(11, Colors_9932993a_9_9_6);
                    this._draw_9932993a.Uniform_15(12, Offsets_9932993a_9_8_8);
                    this._draw_9932993a.Uniform_8(13, $AsOp(brush, 724).Opacity());
                    this._draw_9932993a.DrawArrays(this.Draw_Vertices_9931b07c_2_0_10.length);
                }
            }
            else if ($IsOp(brush, 38))
            {
                {
                    this._draw_99330d99.BlendEnabled(true);
                    this._draw_99330d99.BlendSrcRgb(Fuse.Drawing.BlendModeHelpers.GetSrcRgb($AsOp(brush, 38).BlendMode()));
                    this._draw_99330d99.BlendSrcAlpha(Fuse.Drawing.BlendModeHelpers.GetSrcAlpha($AsOp(brush, 38).BlendMode()));
                    this._draw_99330d99.BlendDstRgb(Fuse.Drawing.BlendModeHelpers.GetDstRgb($AsOp(brush, 38).BlendMode()));
                    this._draw_99330d99.BlendDstAlpha(Fuse.Drawing.BlendModeHelpers.GetDstAlpha($AsOp(brush, 38).BlendMode()));
                    this._draw_99330d99.DepthTestEnabled(false);
                    this._draw_99330d99.CullFace(0);
                    this._draw_99330d99.Use();
                    this._draw_99330d99.Attrib_1(0, 2, this.Draw_Coord_99330d99_2_1_1, 8, 0);
                    this._draw_99330d99.Uniform_9(1, size);
                    this._draw_99330d99.Uniform_9(2, offset);
                    this._draw_99330d99.Uniform_14(3, transform);
                    this._draw_99330d99.Uniform_9(4, Fuse.Spaces.VirtualResolution());
                    this._draw_99330d99.Uniform_9(5, uvSize);
                    this._draw_99330d99.Uniform_9(6, uvPosition);
                    this._draw_99330d99.Uniform_8(7, $AsOp(brush, 38).Split());
                    this._draw_99330d99.Uniform_11(8, $AsOp(brush, 38).Right());
                    this._draw_99330d99.Uniform_11(9, $AsOp(brush, 38).Left());
                    this._draw_99330d99.Uniform_8(10, $AsOp(brush, 38).Opacity());
                    this._draw_99330d99.DrawArrays(this.Draw_Vertices_9931b07c_2_0_10.length);
                }
            }
            else if ($IsOp(brush, 726))
            {
                {
                    this._draw_993224db.BlendEnabled(true);
                    this._draw_993224db.BlendSrcRgb(this.Draw_BlendSrcRgb_993381f8_7_3_7);
                    this._draw_993224db.BlendSrcAlpha(this.Draw_BlendSrcAlpha_993381f8_7_5_8);
                    this._draw_993224db.BlendDstRgb(this.Draw_BlendDstRgb_993381f8_7_4_9);
                    this._draw_993224db.BlendDstAlpha(this.Draw_BlendDstAlpha_993381f8_7_6_10);
                    this._draw_993224db.DepthTestEnabled(false);
                    this._draw_993224db.CullFace(0);
                    this._draw_993224db.Use();
                    this._draw_993224db.Attrib_1(0, 2, this.Draw_Coord_993381f8_2_1_1, 8, 0);
                    this._draw_993224db.Uniform_9(1, size);
                    this._draw_993224db.Uniform_9(2, offset);
                    this._draw_993224db.Uniform_14(3, transform);
                    this._draw_993224db.Uniform_9(4, Fuse.Spaces.VirtualResolution());
                    this._draw_993224db.Uniform_11(5, Uno.Float4.New_7(Uno.Float3.op_Multiply((ind_129 = $AsOp(brush, 726).Color(), Uno.Float3.New_2(ind_129.X, ind_129.Y, ind_129.Z)), $AsOp(brush, 726).Color().W), $AsOp(brush, 726).Color().W));
                    this._draw_993224db.DrawArrays(this.Draw_Vertices_9931b07c_2_0_10.length);
                }
            }
        };

        I.init_DrawCalls = function()
        {
            var Vertices_9931b07c_2_0_0 = Array.Init([Uno.Float2.New_2(0.0, 0.0), Uno.Float2.New_2(0.0, 1.0), Uno.Float2.New_2(1.0, 1.0), Uno.Float2.New_2(0.0, 0.0), Uno.Float2.New_2(1.0, 1.0), Uno.Float2.New_2(1.0, 0.0)], 430);
            this.Draw_Coord_9931b07c_2_1_1 = Uno.Graphics.VertexBuffer.New_3(Uno.Runtime.Implementation.Internal.BufferConverters.ToBuffer_1(Vertices_9931b07c_2_0_0), 0);
            this.Draw_Vertices_9931b07c_2_0_10 = Vertices_9931b07c_2_0_0;
            this.Draw_Coord_993224db_2_1_1 = Uno.Graphics.VertexBuffer.New_3(Uno.Runtime.Implementation.Internal.BufferConverters.ToBuffer_1(Vertices_9931b07c_2_0_0), 0);
            this.Draw_Coord_9932993a_2_1_1 = Uno.Graphics.VertexBuffer.New_3(Uno.Runtime.Implementation.Internal.BufferConverters.ToBuffer_1(Vertices_9931b07c_2_0_0), 0);
            this.Draw_Coord_99330d99_2_1_1 = Uno.Graphics.VertexBuffer.New_3(Uno.Runtime.Implementation.Internal.BufferConverters.ToBuffer_1(Vertices_9931b07c_2_0_0), 0);
            this.Draw_Coord_993381f8_2_1_1 = Uno.Graphics.VertexBuffer.New_3(Uno.Runtime.Implementation.Internal.BufferConverters.ToBuffer_1(Vertices_9931b07c_2_0_0), 0);
            this.Draw_BlendSrcRgb_993381f8_7_3_7 = Fuse.Drawing.BlendModeHelpers.GetSrcRgb(0);
            this.Draw_BlendSrcAlpha_993381f8_7_5_8 = Fuse.Drawing.BlendModeHelpers.GetSrcAlpha(0);
            this.Draw_BlendDstRgb_993381f8_7_4_9 = Fuse.Drawing.BlendModeHelpers.GetDstRgb(0);
            this.Draw_BlendDstAlpha_993381f8_7_6_10 = Fuse.Drawing.BlendModeHelpers.GetDstAlpha(0);
            this._draw_9931b07c = Uno.Runtime.Implementation.ShaderBackends.OpenGL.GLDrawCall.New_1($DownCast(Uno.Runtime.Implementation.Internal.BundleRegistry.Get(14), 383));
            this._draw_993224db = Uno.Runtime.Implementation.ShaderBackends.OpenGL.GLDrawCall.New_1($DownCast(Uno.Runtime.Implementation.Internal.BundleRegistry.Get(15), 383));
            this._draw_9932993a = Uno.Runtime.Implementation.ShaderBackends.OpenGL.GLDrawCall.New_1($DownCast(Uno.Runtime.Implementation.Internal.BundleRegistry.Get(16), 383));
            this._draw_99330d99 = Uno.Runtime.Implementation.ShaderBackends.OpenGL.GLDrawCall.New_1($DownCast(Uno.Runtime.Implementation.Internal.BundleRegistry.Get(17), 383));
        };

        Fuse.Internal.Drawing.ImageRectangle_ImageRectangleImpl.Draw_Colors_9932993a_9_9_5 = function(Colors_9_9_7)
        {
            var cols = Array.Structs(Uno.Math.Max_8(Colors_9_9_7.length, 1), Uno.Float4, 432);

            for (var i = 0; i < Colors_9_9_7.length; i++)
            {
                cols[i].op_Assign(Colors_9_9_7[i].Color());
            }

            return cols;
        };

        Fuse.Internal.Drawing.ImageRectangle_ImageRectangleImpl.Draw_Offsets_9932993a_9_8_7 = function(Offsets_9_8_8)
        {
            var ofs = Array.Zeros(Uno.Math.Max_8(Offsets_9_8_8.length, 1), 429);

            for (var i = 0; i < Offsets_9_8_8.length; i++)
            {
                ofs[i] = Offsets_9_8_8[i].Offset();
            }

            return ofs;
        };

        I._ObjInit = function()
        {
            this.init_DrawCalls();
        };

        Fuse.Internal.Drawing.ImageRectangle_ImageRectangleImpl.New_1 = function()
        {
            var inst = new Fuse.Internal.Drawing.ImageRectangle_ImageRectangleImpl;
            inst._ObjInit();
            return inst;
        };

    });
