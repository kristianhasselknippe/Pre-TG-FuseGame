Fuse.Internal.Drawing.Scale9Rectangle_Scale9Impl = $CreateClass(
    function() {
        this.Draw_xv_94a961d_2_3_2 = null;
        this.Draw_xv_94a961d_2_3_3 = null;
        this.Draw_yv_94a961d_2_4_6 = null;
        this.Draw_indices_94a961d_2_2_17 = null;
        this.Draw_xv_94b0a7c_2_3_2 = null;
        this.Draw_xv_94b0a7c_2_3_3 = null;
        this.Draw_yv_94b0a7c_2_4_6 = null;
        this.Draw_xv_94b7edb_2_3_2 = null;
        this.Draw_xv_94b7edb_2_3_3 = null;
        this.Draw_yv_94b7edb_2_4_6 = null;
        this.Draw_xv_94bf33a_2_3_2 = null;
        this.Draw_xv_94bf33a_2_3_3 = null;
        this.Draw_yv_94bf33a_2_4_6 = null;
        this.Draw_xv_94c6799_2_3_2 = null;
        this.Draw_xv_94c6799_2_3_3 = null;
        this.Draw_yv_94c6799_2_4_6 = null;
        this.Draw_BlendSrcRgb_94c6799_7_3_14 = 0;
        this.Draw_BlendSrcAlpha_94c6799_7_5_15 = 0;
        this.Draw_BlendDstRgb_94c6799_7_4_16 = 0;
        this.Draw_BlendDstAlpha_94c6799_7_6_17 = 0;
        this._draw_94a961d = new Uno.Runtime.Implementation.ShaderBackends.OpenGL.GLDrawCall;
        this._draw_94b0a7c = new Uno.Runtime.Implementation.ShaderBackends.OpenGL.GLDrawCall;
        this._draw_94b7edb = new Uno.Runtime.Implementation.ShaderBackends.OpenGL.GLDrawCall;
        this._draw_94bf33a = new Uno.Runtime.Implementation.ShaderBackends.OpenGL.GLDrawCall;
    },
    function(S) {
        var I = S.prototype;

        I.GetType = function()
        {
            return 810;
        };

        I.Draw = function(dc, transform, size, scaleTextureSize, brush, margin)
        {
            var size_124 = new Uno.Float2;
            var scaleTextureSize_125 = new Uno.Float2;
            var margin_126 = new Uno.Float4;
            var ind_127;
            var ind_128;
            size_124.op_Assign(size);
            scaleTextureSize_125.op_Assign(scaleTextureSize);
            margin_126.op_Assign(margin);

            if ($IsOp(brush, 728))
            {
                {
                    this._draw_94a961d.BlendEnabled(true);
                    this._draw_94a961d.BlendSrcRgb(Fuse.Drawing.BlendModeHelpers.GetSrcRgb($AsOp(brush, 728).BlendMode()));
                    this._draw_94a961d.BlendSrcAlpha(Fuse.Drawing.BlendModeHelpers.GetSrcAlpha($AsOp(brush, 728).BlendMode()));
                    this._draw_94a961d.BlendDstRgb(Fuse.Drawing.BlendModeHelpers.GetDstRgb($AsOp(brush, 728).BlendMode()));
                    this._draw_94a961d.BlendDstAlpha(Fuse.Drawing.BlendModeHelpers.GetDstAlpha($AsOp(brush, 728).BlendMode()));
                    this._draw_94a961d.DepthTestEnabled(false);
                    this._draw_94a961d.CullFace(0);
                    this._draw_94a961d.Const(0, $AsOp(brush, 728).Texture() == null);
                    this._draw_94a961d.Use();
                    this._draw_94a961d.Attrib_1(1, 3, this.Draw_xv_94a961d_2_3_3, 12, 0);
                    this._draw_94a961d.Attrib_1(2, 3, this.Draw_yv_94a961d_2_4_6, 12, 0);
                    this._draw_94a961d.Uniform_8(3, margin_126.X);
                    this._draw_94a961d.Uniform_8(4, size_124.X - margin_126.Z);
                    this._draw_94a961d.Uniform_8(5, size_124.X);
                    this._draw_94a961d.Uniform_8(6, margin_126.Y);
                    this._draw_94a961d.Uniform_8(7, size_124.Y - margin_126.W);
                    this._draw_94a961d.Uniform_8(8, size_124.Y);
                    this._draw_94a961d.Uniform_14(9, transform);
                    this._draw_94a961d.Uniform_9(10, dc.VirtualResolution());
                    this._draw_94a961d.Uniform_8(11, scaleTextureSize_125.X - margin_126.Z);
                    this._draw_94a961d.Uniform_8(12, scaleTextureSize_125.X);
                    this._draw_94a961d.Uniform_8(13, scaleTextureSize_125.Y - margin_126.W);
                    this._draw_94a961d.Uniform_8(14, scaleTextureSize_125.Y);
                    this._draw_94a961d.Uniform_9(15, scaleTextureSize_125);
                    this._draw_94a961d.Uniform_11(16, $AsOp(brush, 728).Color());
                    this._draw_94a961d.Uniform_8(17, $AsOp(brush, 728).Opacity());
                    this._draw_94a961d.Sampler_3(18, $AsOp(brush, 728).Texture(), Uno.Graphics.SamplerState.New_1($AsOp(brush, 728).MinFilter(), $AsOp(brush, 728).MagFilter(), 10497));
                    this._draw_94a961d.Draw(this.Draw_indices_94a961d_2_2_17.length, 2, this.Draw_xv_94a961d_2_3_2);
                }
            }
            else if ($IsOp(brush, 725))
            {
                {
                    this._draw_94b0a7c.BlendEnabled(true);
                    this._draw_94b0a7c.BlendSrcRgb(Fuse.Drawing.BlendModeHelpers.GetSrcRgb($AsOp(brush, 725).BlendMode()));
                    this._draw_94b0a7c.BlendSrcAlpha(Fuse.Drawing.BlendModeHelpers.GetSrcAlpha($AsOp(brush, 725).BlendMode()));
                    this._draw_94b0a7c.BlendDstRgb(Fuse.Drawing.BlendModeHelpers.GetDstRgb($AsOp(brush, 725).BlendMode()));
                    this._draw_94b0a7c.BlendDstAlpha(Fuse.Drawing.BlendModeHelpers.GetDstAlpha($AsOp(brush, 725).BlendMode()));
                    this._draw_94b0a7c.DepthTestEnabled(false);
                    this._draw_94b0a7c.CullFace(0);
                    this._draw_94b0a7c.Use();
                    this._draw_94b0a7c.Attrib_1(0, 3, this.Draw_xv_94b0a7c_2_3_3, 12, 0);
                    this._draw_94b0a7c.Attrib_1(1, 3, this.Draw_yv_94b0a7c_2_4_6, 12, 0);
                    this._draw_94b0a7c.Uniform_8(2, margin_126.X);
                    this._draw_94b0a7c.Uniform_8(3, size_124.X - margin_126.Z);
                    this._draw_94b0a7c.Uniform_8(4, size_124.X);
                    this._draw_94b0a7c.Uniform_8(5, margin_126.Y);
                    this._draw_94b0a7c.Uniform_8(6, size_124.Y - margin_126.W);
                    this._draw_94b0a7c.Uniform_8(7, size_124.Y);
                    this._draw_94b0a7c.Uniform_14(8, transform);
                    this._draw_94b0a7c.Uniform_9(9, dc.VirtualResolution());
                    this._draw_94b0a7c.Uniform_11(10, Uno.Float4.New_7(Uno.Float3.op_Multiply(Uno.Float3.op_Multiply((ind_127 = $AsOp(brush, 725).Color(), Uno.Float3.New_2(ind_127.X, ind_127.Y, ind_127.Z)), $AsOp(brush, 725).Color().W), $AsOp(brush, 725).Opacity()), $AsOp(brush, 725).Color().W * $AsOp(brush, 725).Opacity()));
                    this._draw_94b0a7c.Draw(this.Draw_indices_94a961d_2_2_17.length, 2, this.Draw_xv_94b0a7c_2_3_2);
                }
            }
            else if ($IsOp(brush, 724))
            {
                var Colors_94b7edb_9_9_13 = Fuse.Internal.Drawing.Scale9Rectangle_Scale9Impl.Draw_Colors_94b7edb_9_9_12($AsOp(brush, 724).SortedStops());
                var Offsets_94b7edb_9_8_15 = Fuse.Internal.Drawing.Scale9Rectangle_Scale9Impl.Draw_Offsets_94b7edb_9_8_14($AsOp(brush, 724).SortedStops());
                {
                    this._draw_94b7edb.BlendEnabled(true);
                    this._draw_94b7edb.BlendSrcRgb(Fuse.Drawing.BlendModeHelpers.GetSrcRgb($AsOp(brush, 724).BlendMode()));
                    this._draw_94b7edb.BlendSrcAlpha(Fuse.Drawing.BlendModeHelpers.GetSrcAlpha($AsOp(brush, 724).BlendMode()));
                    this._draw_94b7edb.BlendDstRgb(Fuse.Drawing.BlendModeHelpers.GetDstRgb($AsOp(brush, 724).BlendMode()));
                    this._draw_94b7edb.BlendDstAlpha(Fuse.Drawing.BlendModeHelpers.GetDstAlpha($AsOp(brush, 724).BlendMode()));
                    this._draw_94b7edb.DepthTestEnabled(false);
                    this._draw_94b7edb.CullFace(0);
                    this._draw_94b7edb.Const_1(0, Colors_94b7edb_9_9_13.length);
                    this._draw_94b7edb.Const_1(1, Offsets_94b7edb_9_8_15.length);
                    this._draw_94b7edb.Use();
                    this._draw_94b7edb.Attrib_1(2, 3, this.Draw_xv_94b7edb_2_3_3, 12, 0);
                    this._draw_94b7edb.Attrib_1(3, 3, this.Draw_yv_94b7edb_2_4_6, 12, 0);
                    this._draw_94b7edb.Uniform_8(4, margin_126.X);
                    this._draw_94b7edb.Uniform_8(5, size_124.X - margin_126.Z);
                    this._draw_94b7edb.Uniform_8(6, size_124.X);
                    this._draw_94b7edb.Uniform_8(7, margin_126.Y);
                    this._draw_94b7edb.Uniform_8(8, size_124.Y - margin_126.W);
                    this._draw_94b7edb.Uniform_8(9, size_124.Y);
                    this._draw_94b7edb.Uniform_14(10, transform);
                    this._draw_94b7edb.Uniform_9(11, dc.VirtualResolution());
                    this._draw_94b7edb.Uniform_8(12, scaleTextureSize_125.X - margin_126.Z);
                    this._draw_94b7edb.Uniform_8(13, scaleTextureSize_125.X);
                    this._draw_94b7edb.Uniform_8(14, scaleTextureSize_125.Y - margin_126.W);
                    this._draw_94b7edb.Uniform_8(15, scaleTextureSize_125.Y);
                    this._draw_94b7edb.Uniform_9(16, scaleTextureSize_125);
                    this._draw_94b7edb.Uniform_9(17, $AsOp(brush, 724).EndPoint());
                    this._draw_94b7edb.Uniform_9(18, $AsOp(brush, 724).StartPoint());
                    this._draw_94b7edb.Uniform_18(19, Colors_94b7edb_9_9_13);
                    this._draw_94b7edb.Uniform_15(20, Offsets_94b7edb_9_8_15);
                    this._draw_94b7edb.Uniform_8(21, $AsOp(brush, 724).Opacity());
                    this._draw_94b7edb.Draw(this.Draw_indices_94a961d_2_2_17.length, 2, this.Draw_xv_94b7edb_2_3_2);
                }
            }
            else if ($IsOp(brush, 38))
            {
                {
                    this._draw_94bf33a.BlendEnabled(true);
                    this._draw_94bf33a.BlendSrcRgb(Fuse.Drawing.BlendModeHelpers.GetSrcRgb($AsOp(brush, 38).BlendMode()));
                    this._draw_94bf33a.BlendSrcAlpha(Fuse.Drawing.BlendModeHelpers.GetSrcAlpha($AsOp(brush, 38).BlendMode()));
                    this._draw_94bf33a.BlendDstRgb(Fuse.Drawing.BlendModeHelpers.GetDstRgb($AsOp(brush, 38).BlendMode()));
                    this._draw_94bf33a.BlendDstAlpha(Fuse.Drawing.BlendModeHelpers.GetDstAlpha($AsOp(brush, 38).BlendMode()));
                    this._draw_94bf33a.DepthTestEnabled(false);
                    this._draw_94bf33a.CullFace(0);
                    this._draw_94bf33a.Use();
                    this._draw_94bf33a.Attrib_1(0, 3, this.Draw_xv_94bf33a_2_3_3, 12, 0);
                    this._draw_94bf33a.Attrib_1(1, 3, this.Draw_yv_94bf33a_2_4_6, 12, 0);
                    this._draw_94bf33a.Uniform_8(2, margin_126.X);
                    this._draw_94bf33a.Uniform_8(3, size_124.X - margin_126.Z);
                    this._draw_94bf33a.Uniform_8(4, size_124.X);
                    this._draw_94bf33a.Uniform_8(5, margin_126.Y);
                    this._draw_94bf33a.Uniform_8(6, size_124.Y - margin_126.W);
                    this._draw_94bf33a.Uniform_8(7, size_124.Y);
                    this._draw_94bf33a.Uniform_14(8, transform);
                    this._draw_94bf33a.Uniform_9(9, dc.VirtualResolution());
                    this._draw_94bf33a.Uniform_8(10, scaleTextureSize_125.X - margin_126.Z);
                    this._draw_94bf33a.Uniform_8(11, scaleTextureSize_125.X);
                    this._draw_94bf33a.Uniform_8(12, scaleTextureSize_125.Y - margin_126.W);
                    this._draw_94bf33a.Uniform_8(13, scaleTextureSize_125.Y);
                    this._draw_94bf33a.Uniform_9(14, scaleTextureSize_125);
                    this._draw_94bf33a.Uniform_8(15, $AsOp(brush, 38).Split());
                    this._draw_94bf33a.Uniform_11(16, $AsOp(brush, 38).Right());
                    this._draw_94bf33a.Uniform_11(17, $AsOp(brush, 38).Left());
                    this._draw_94bf33a.Uniform_8(18, $AsOp(brush, 38).Opacity());
                    this._draw_94bf33a.Draw(this.Draw_indices_94a961d_2_2_17.length, 2, this.Draw_xv_94bf33a_2_3_2);
                }
            }
            else if ($IsOp(brush, 726))
            {
                {
                    this._draw_94b0a7c.BlendEnabled(true);
                    this._draw_94b0a7c.BlendSrcRgb(this.Draw_BlendSrcRgb_94c6799_7_3_14);
                    this._draw_94b0a7c.BlendSrcAlpha(this.Draw_BlendSrcAlpha_94c6799_7_5_15);
                    this._draw_94b0a7c.BlendDstRgb(this.Draw_BlendDstRgb_94c6799_7_4_16);
                    this._draw_94b0a7c.BlendDstAlpha(this.Draw_BlendDstAlpha_94c6799_7_6_17);
                    this._draw_94b0a7c.DepthTestEnabled(false);
                    this._draw_94b0a7c.CullFace(0);
                    this._draw_94b0a7c.Use();
                    this._draw_94b0a7c.Attrib_1(0, 3, this.Draw_xv_94c6799_2_3_3, 12, 0);
                    this._draw_94b0a7c.Attrib_1(1, 3, this.Draw_yv_94c6799_2_4_6, 12, 0);
                    this._draw_94b0a7c.Uniform_8(2, margin_126.X);
                    this._draw_94b0a7c.Uniform_8(3, size_124.X - margin_126.Z);
                    this._draw_94b0a7c.Uniform_8(4, size_124.X);
                    this._draw_94b0a7c.Uniform_8(5, margin_126.Y);
                    this._draw_94b0a7c.Uniform_8(6, size_124.Y - margin_126.W);
                    this._draw_94b0a7c.Uniform_8(7, size_124.Y);
                    this._draw_94b0a7c.Uniform_14(8, transform);
                    this._draw_94b0a7c.Uniform_9(9, dc.VirtualResolution());
                    this._draw_94b0a7c.Uniform_11(10, Uno.Float4.New_7(Uno.Float3.op_Multiply((ind_128 = $AsOp(brush, 726).Color(), Uno.Float3.New_2(ind_128.X, ind_128.Y, ind_128.Z)), $AsOp(brush, 726).Color().W), $AsOp(brush, 726).Color().W));
                    this._draw_94b0a7c.Draw(this.Draw_indices_94a961d_2_2_17.length, 2, this.Draw_xv_94c6799_2_3_2);
                }
            }
        };

        I.init_DrawCalls = function()
        {
            var xverts_94a961d_2_0_0 = Array.Init([Uno.Float3.New_2(0.0, 0.0, 0.0), Uno.Float3.New_2(1.0, 0.0, 0.0), Uno.Float3.New_2(0.0, 1.0, 0.0), Uno.Float3.New_2(0.0, 0.0, 1.0), Uno.Float3.New_2(0.0, 0.0, 0.0), Uno.Float3.New_2(1.0, 0.0, 0.0), Uno.Float3.New_2(0.0, 1.0, 0.0), Uno.Float3.New_2(0.0, 0.0, 1.0), Uno.Float3.New_2(0.0, 0.0, 0.0), Uno.Float3.New_2(1.0, 0.0, 0.0), Uno.Float3.New_2(0.0, 1.0, 0.0), Uno.Float3.New_2(0.0, 0.0, 1.0), Uno.Float3.New_2(0.0, 0.0, 0.0), Uno.Float3.New_2(1.0, 0.0, 0.0), Uno.Float3.New_2(0.0, 1.0, 0.0), Uno.Float3.New_2(0.0, 0.0, 1.0)], 431);
            var indices_94a961d_2_2_1 = Array.Init([0, 4, 5, 0, 5, 1, 1, 5, 6, 1, 6, 2, 2, 6, 7, 2, 7, 3, 4, 8, 9, 4, 9, 5, 5, 9, 10, 5, 10, 6, 6, 10, 11, 6, 11, 7, 8, 12, 13, 8, 13, 9, 9, 13, 14, 9, 14, 10, 10, 14, 15, 10, 15, 11], 424);
            this.Draw_xv_94a961d_2_3_2 = Uno.Graphics.IndexBuffer.New_3(Uno.Runtime.Implementation.Internal.BufferConverters.ToBuffer_6(indices_94a961d_2_2_1), 0);
            this.Draw_xv_94a961d_2_3_3 = Uno.Graphics.VertexBuffer.New_3(Uno.Runtime.Implementation.Internal.BufferConverters.ToBuffer_2(xverts_94a961d_2_0_0), 0);
            var yverts_94a961d_2_1_5 = Array.Init([Uno.Float3.New_2(0.0, 0.0, 0.0), Uno.Float3.New_2(0.0, 0.0, 0.0), Uno.Float3.New_2(0.0, 0.0, 0.0), Uno.Float3.New_2(0.0, 0.0, 0.0), Uno.Float3.New_2(1.0, 0.0, 0.0), Uno.Float3.New_2(1.0, 0.0, 0.0), Uno.Float3.New_2(1.0, 0.0, 0.0), Uno.Float3.New_2(1.0, 0.0, 0.0), Uno.Float3.New_2(0.0, 1.0, 0.0), Uno.Float3.New_2(0.0, 1.0, 0.0), Uno.Float3.New_2(0.0, 1.0, 0.0), Uno.Float3.New_2(0.0, 1.0, 0.0), Uno.Float3.New_2(0.0, 0.0, 1.0), Uno.Float3.New_2(0.0, 0.0, 1.0), Uno.Float3.New_2(0.0, 0.0, 1.0), Uno.Float3.New_2(0.0, 0.0, 1.0)], 431);
            this.Draw_yv_94a961d_2_4_6 = Uno.Graphics.VertexBuffer.New_3(Uno.Runtime.Implementation.Internal.BufferConverters.ToBuffer_2(yverts_94a961d_2_1_5), 0);
            this.Draw_indices_94a961d_2_2_17 = indices_94a961d_2_2_1;
            this.Draw_xv_94b0a7c_2_3_2 = Uno.Graphics.IndexBuffer.New_3(Uno.Runtime.Implementation.Internal.BufferConverters.ToBuffer_6(indices_94a961d_2_2_1), 0);
            this.Draw_xv_94b0a7c_2_3_3 = Uno.Graphics.VertexBuffer.New_3(Uno.Runtime.Implementation.Internal.BufferConverters.ToBuffer_2(xverts_94a961d_2_0_0), 0);
            this.Draw_yv_94b0a7c_2_4_6 = Uno.Graphics.VertexBuffer.New_3(Uno.Runtime.Implementation.Internal.BufferConverters.ToBuffer_2(yverts_94a961d_2_1_5), 0);
            this.Draw_xv_94b7edb_2_3_2 = Uno.Graphics.IndexBuffer.New_3(Uno.Runtime.Implementation.Internal.BufferConverters.ToBuffer_6(indices_94a961d_2_2_1), 0);
            this.Draw_xv_94b7edb_2_3_3 = Uno.Graphics.VertexBuffer.New_3(Uno.Runtime.Implementation.Internal.BufferConverters.ToBuffer_2(xverts_94a961d_2_0_0), 0);
            this.Draw_yv_94b7edb_2_4_6 = Uno.Graphics.VertexBuffer.New_3(Uno.Runtime.Implementation.Internal.BufferConverters.ToBuffer_2(yverts_94a961d_2_1_5), 0);
            this.Draw_xv_94bf33a_2_3_2 = Uno.Graphics.IndexBuffer.New_3(Uno.Runtime.Implementation.Internal.BufferConverters.ToBuffer_6(indices_94a961d_2_2_1), 0);
            this.Draw_xv_94bf33a_2_3_3 = Uno.Graphics.VertexBuffer.New_3(Uno.Runtime.Implementation.Internal.BufferConverters.ToBuffer_2(xverts_94a961d_2_0_0), 0);
            this.Draw_yv_94bf33a_2_4_6 = Uno.Graphics.VertexBuffer.New_3(Uno.Runtime.Implementation.Internal.BufferConverters.ToBuffer_2(yverts_94a961d_2_1_5), 0);
            this.Draw_xv_94c6799_2_3_2 = Uno.Graphics.IndexBuffer.New_3(Uno.Runtime.Implementation.Internal.BufferConverters.ToBuffer_6(indices_94a961d_2_2_1), 0);
            this.Draw_xv_94c6799_2_3_3 = Uno.Graphics.VertexBuffer.New_3(Uno.Runtime.Implementation.Internal.BufferConverters.ToBuffer_2(xverts_94a961d_2_0_0), 0);
            this.Draw_yv_94c6799_2_4_6 = Uno.Graphics.VertexBuffer.New_3(Uno.Runtime.Implementation.Internal.BufferConverters.ToBuffer_2(yverts_94a961d_2_1_5), 0);
            this.Draw_BlendSrcRgb_94c6799_7_3_14 = Fuse.Drawing.BlendModeHelpers.GetSrcRgb(0);
            this.Draw_BlendSrcAlpha_94c6799_7_5_15 = Fuse.Drawing.BlendModeHelpers.GetSrcAlpha(0);
            this.Draw_BlendDstRgb_94c6799_7_4_16 = Fuse.Drawing.BlendModeHelpers.GetDstRgb(0);
            this.Draw_BlendDstAlpha_94c6799_7_6_17 = Fuse.Drawing.BlendModeHelpers.GetDstAlpha(0);
            this._draw_94a961d = Uno.Runtime.Implementation.ShaderBackends.OpenGL.GLDrawCall.New_1($DownCast(Uno.Runtime.Implementation.Internal.BundleRegistry.Get(26), 383));
            this._draw_94b0a7c = Uno.Runtime.Implementation.ShaderBackends.OpenGL.GLDrawCall.New_1($DownCast(Uno.Runtime.Implementation.Internal.BundleRegistry.Get(27), 383));
            this._draw_94b7edb = Uno.Runtime.Implementation.ShaderBackends.OpenGL.GLDrawCall.New_1($DownCast(Uno.Runtime.Implementation.Internal.BundleRegistry.Get(28), 383));
            this._draw_94bf33a = Uno.Runtime.Implementation.ShaderBackends.OpenGL.GLDrawCall.New_1($DownCast(Uno.Runtime.Implementation.Internal.BundleRegistry.Get(29), 383));
        };

        Fuse.Internal.Drawing.Scale9Rectangle_Scale9Impl.Draw_Colors_94b7edb_9_9_12 = function(Colors_9_9_15)
        {
            var cols = Array.Structs(Uno.Math.Max_8(Colors_9_9_15.length, 1), Uno.Float4, 432);

            for (var i = 0; i < Colors_9_9_15.length; i++)
            {
                cols[i].op_Assign(Colors_9_9_15[i].Color());
            }

            return cols;
        };

        Fuse.Internal.Drawing.Scale9Rectangle_Scale9Impl.Draw_Offsets_94b7edb_9_8_14 = function(Offsets_9_8_16)
        {
            var ofs = Array.Zeros(Uno.Math.Max_8(Offsets_9_8_16.length, 1), 429);

            for (var i = 0; i < Offsets_9_8_16.length; i++)
            {
                ofs[i] = Offsets_9_8_16[i].Offset();
            }

            return ofs;
        };

        I._ObjInit = function()
        {
            this.init_DrawCalls();
        };

        Fuse.Internal.Drawing.Scale9Rectangle_Scale9Impl.New_1 = function()
        {
            var inst = new Fuse.Internal.Drawing.Scale9Rectangle_Scale9Impl;
            inst._ObjInit();
            return inst;
        };

    });
