Fuse.Internal.Drawing.ImageRectangle = $CreateClass(
    function() {
    },
    function(S) {
        Fuse.Internal.Drawing.ImageRectangle.impl = null;

        Fuse.Internal.Drawing.ImageRectangle.Draw = function(dc, transform, offset, size, uvPosition, uvSize, brush)
        {
            if (Fuse.Internal.Drawing.ImageRectangle.impl == null)
            {
                Fuse.Internal.Drawing.ImageRectangle.impl = Fuse.Internal.Drawing.ImageRectangle_ImageRectangleImpl.New_1();
            }

            Fuse.Internal.Drawing.ImageRectangle.impl.Draw(dc, transform, offset, size, uvPosition, uvSize, brush);
        };

    });
