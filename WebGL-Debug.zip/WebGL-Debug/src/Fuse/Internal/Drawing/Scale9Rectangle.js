Fuse.Internal.Drawing.Scale9Rectangle = $CreateClass(
    function() {
    },
    function(S) {
        Fuse.Internal.Drawing.Scale9Rectangle.impl = null;

        Fuse.Internal.Drawing.Scale9Rectangle.Draw = function(dc, transform, size, scaleTextureSize, brush, margin)
        {
            if (Fuse.Internal.Drawing.Scale9Rectangle.impl == null)
            {
                Fuse.Internal.Drawing.Scale9Rectangle.impl = Fuse.Internal.Drawing.Scale9Rectangle_Scale9Impl.New_1();
            }

            Fuse.Internal.Drawing.Scale9Rectangle.impl.Draw(dc, transform, size, scaleTextureSize, brush, margin);
        };

    });
