Fuse.Internal.TextWindow = $CreateClass(
    function() {
        Fuse.Element.call(this);
        this._lineCache = null;
        this._wrapInfo = null;
        this._selection = null;
        this._textColor_1 = new Uno.Float4;
        this._selectionColor = new Uno.Float4;
        this._maxTextLength = 0;
        this._textAlignment_1 = 0;
        this._textBoundsSize = new Uno.Float2;
        this._offset = new Uno.Float2;
    },
    function(S) {
        var I = S.prototype = new Fuse.Element;

        I.GetType = function()
        {
            return 821;
        };

        I.CalcRenderBounds = function()
        {
            return Uno.Rect.New_2(Uno.Float2.New_1(0.0), this._textBoundsSize);
        };

        I.Draw_1 = function(wrapInfo, selection, textColor, selectionColor, maxTextLength, textAlignment, textBoundsSize, offset, dc)
        {
            if (Uno.Float2.op_Inequality(this._textBoundsSize, textBoundsSize))
            {
                this.InvalidateRenderBounds();
            }

            this._wrapInfo = wrapInfo;
            this._selection = selection;
            this._textColor_1.op_Assign(textColor);
            this._selectionColor.op_Assign(selectionColor);
            this._maxTextLength = maxTextLength;
            this._textAlignment_1 = textAlignment;
            this._textBoundsSize.op_Assign(textBoundsSize);
            this._offset.op_Assign(offset);
            this.Draw(dc);
        };

        I.OnDraw = function(dc)
        {
            var drawMatrix_127 = new Uno.Float4x4;
            drawMatrix_127.op_Assign(this.GetDrawMatrix(dc));
            this._wrapInfo.TextRenderer["Fuse.Internal.ITextRenderer.BeginRendering"](this._wrapInfo.FontSize, this._wrapInfo.AbsoluteZoom, drawMatrix_127, this.ActualSize(), this._textColor_1, this._maxTextLength);
            var lineHeight = this._wrapInfo.LineHeight * this._wrapInfo.AbsoluteZoom;
            var scaledOffset = Uno.Float2.op_Multiply(this._offset, this._wrapInfo.AbsoluteZoom);
            var y = 0.0;
            var selectionY = 0.0;

            for (var i = 0; i < this._lineCache.Lines().Count(); i++)
            {
                var lines = this._lineCache.Lines().Item(i).GetWrappedLines(this._wrapInfo);

                for (var j = 0; j < lines.length; ++j)
                {
                    var wrappedLine = lines[j];
                    var drawY = scaledOffset.Y + y;

                    if (drawY >= (this.ActualSize().Y * this._wrapInfo.AbsoluteZoom))
                    {
                        break;
                    }
                    else if (drawY >= -lineHeight)
                    {
                        var x = wrappedLine.GetXOffset(this._textAlignment_1, this._textBoundsSize.X, this.AbsoluteZoom());

                        if (Fuse.Internal.TextSpan.op_Inequality(this._selection, null))
                        {
                            var start = Fuse.Internal.TextPosition.New_1(i, wrappedLine.LineTextStartOffset);
                            var end = Fuse.Internal.TextPosition.New_1(i, wrappedLine.LineTextEndOffset());
                            var span = Fuse.Internal.TextSpan.New_1(start, end);
                            var intersection = Fuse.Internal.TextSpan.Intersection(span, this._selection);

                            if (Fuse.Internal.TextSpan.op_Inequality(intersection, null))
                            {
                                var startPos = wrappedLine.PosToBounds(this._wrapInfo, intersection.Start.Char - wrappedLine.LineTextStartOffset);
                                var endPos = (intersection.End.Char < wrappedLine.LineTextEndOffset()) ? wrappedLine.PosToBounds(this._wrapInfo, intersection.End.Char - wrappedLine.LineTextStartOffset) : wrappedLine.LineWidth;
                                Fuse.Internal.Drawing.RoundedRectangle.Draw(dc, Uno.Math.Floor_2(Uno.Float2.New_2((this._offset.X + x) + startPos, this._offset.Y + selectionY)), drawMatrix_127, Uno.Float2.New_2(endPos - startPos, this._wrapInfo.LineHeight), this._selectionColor, 1.0);
                            }
                        }

                        this._wrapInfo.TextRenderer["Fuse.Internal.ITextRenderer.DrawLine"](dc, scaledOffset.X + (x * this._wrapInfo.AbsoluteZoom), drawY, wrappedLine.Text);
                    }

                    y = y + lineHeight;
                    selectionY = selectionY + (lineHeight / this._wrapInfo.AbsoluteZoom);
                }
            }

            this._wrapInfo.TextRenderer["Fuse.Internal.ITextRenderer.EndRendering"](dc);
        };

        I._ObjInit_2 = function(parent, lineCache)
        {
            Fuse.Element.prototype._ObjInit_1.call(this);
            this._lineCache = lineCache;
            this.ClipToBounds(true);
            this.OnAdded($DownCast(parent, 33719));
        };

        Fuse.Internal.TextWindow.New_1 = function(parent, lineCache)
        {
            var inst = new Fuse.Internal.TextWindow;
            inst._ObjInit_2(parent, lineCache);
            return inst;
        };

    });
