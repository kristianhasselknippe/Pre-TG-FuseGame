Fuse.Environment = $CreateClass(
    function() {
    },
    function(S) {
        Fuse.Environment._screenDensity = 0;
        Fuse.Environment._screenPPIZoomFactor = 0;

        Fuse.Environment.StatusbarSize = function()
        {
            var wnd = Uno.Runtime.Implementation.Internal.WindowHelpers.GetPlatformWindowHandle(Uno.Application.Current().Window());
            return Uno.Float2.op_Implicit(Uno.Runtime.Implementation.PlatformWindowImpl.GetStatusBarSize(wnd));
        };

        Fuse.Environment.ScreenDensity = function()
        {
            if ((Fuse.Environment._screenDensity == 0.0) || false)
            {
                var wnd = Uno.Runtime.Implementation.Internal.WindowHelpers.GetPlatformWindowHandle(Uno.Application.Current().Window());
                Fuse.Environment._screenDensity = Uno.Runtime.Implementation.PlatformWindowImpl.GetDensity(wnd);
            }

            return Fuse.Environment._screenDensity;
        };

        Fuse.Environment.ScreenPPIZoomMultiplier = function()
        {
            return Fuse.Environment.ScreenDensity() * Fuse.Environment._screenPPIZoomFactor;
        };

        Fuse.Environment.IsOnscreenKeyboardVisible = function()
        {
            var wnd = Uno.Runtime.Implementation.Internal.WindowHelpers.GetPlatformWindowHandle(Uno.Application.Current().Window());
            return Uno.Runtime.Implementation.PlatformWindowImpl.HasOnscreenKeyboardSupport(wnd) && Uno.Runtime.Implementation.PlatformWindowImpl.IsOnscreenKeyboardVisible(wnd);
        };

        Fuse.Environment.OnscreenKeyboardSize = function()
        {
            var wnd = Uno.Runtime.Implementation.Internal.WindowHelpers.GetPlatformWindowHandle(Uno.Application.Current().Window());

            if (Uno.Runtime.Implementation.PlatformWindowImpl.HasOnscreenKeyboardSupport(wnd) && Uno.Runtime.Implementation.PlatformWindowImpl.IsOnscreenKeyboardVisible(wnd))
            {
                return Uno.Float2.op_Implicit(Uno.Runtime.Implementation.PlatformWindowImpl.GetOnscreenKeyboardSize(wnd));
            }

            return Uno.Float2.New_1(0.0);
        };

        Fuse.Environment._TypeInit = function()
        {
            Fuse.Environment._screenDensity = 0.0;
            Fuse.Environment._screenPPIZoomFactor = 1.0;
        };

    });
