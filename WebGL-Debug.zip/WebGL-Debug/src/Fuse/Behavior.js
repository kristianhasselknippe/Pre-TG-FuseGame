Fuse.Behavior = $CreateClass(
    function() {
        this.AddedByStyle = false;
        this._isRooted = false;
    },
    function(S) {
        var I = S.prototype;

        I.GetType = function()
        {
            return 971;
        };

        I.OverridesDefault = function()
        {
            return false;
        };

        I.Rooted = function(e)
        {
            if (this._isRooted)
            {
                return;
            }

            this._isRooted = true;
            this.OnRooted(e);
        };

        I.Unrooted = function(e)
        {
            if (!this._isRooted)
            {
                return;
            }

            this._isRooted = false;
            this.OnUnrooted(e);
        };

        I._ObjInit = function()
        {
        };

    });
