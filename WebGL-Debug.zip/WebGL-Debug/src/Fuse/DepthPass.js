Fuse.DepthPass = $CreateClass(
    function() {
        Fuse.Pass.call(this);
    },
    function(S) {
        var I = S.prototype = new Fuse.Pass;

        I.GetType = function()
        {
            return 942;
        };

    });
