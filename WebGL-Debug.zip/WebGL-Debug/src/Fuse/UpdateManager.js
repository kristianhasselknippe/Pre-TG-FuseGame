Fuse.UpdateManager = $CreateClass(
    function() {
    },
    function(S) {
        Fuse.UpdateManager.listeners = null;
        Fuse.UpdateManager.hasListenersRemoved = false;
        Fuse.UpdateManager.onces = null;
        Fuse.UpdateManager.oncesPending = null;
        Fuse.UpdateManager._frameIndex = 0;

        Fuse.UpdateManager.FrameIndex = function()
        {
            return Fuse.UpdateManager._frameIndex;
        };

        Fuse.UpdateManager.AddAction = function(pu, stage)
        {
            var us = Fuse.UpdateListener.New_1();
            us.action = pu;
            us.stage = stage;
            Fuse.UpdateManager.listeners.Add(us);
        };

        Fuse.UpdateManager.RemoveFrom = function(list, action, stage)
        {
            for (var i = 0; i < list.Count(); ++i)
            {
                if (((stage == list.Item(i).stage) && Uno.Object.Equals_1(action, list.Item(i).action)) && !list.Item(i).removed)
                {
                    list.Item(i).removed = true;
                    return true;
                }
            }

            return false;
        };

        Fuse.UpdateManager.RemoveAction = function(pu, stage)
        {
            if (!Fuse.UpdateManager.RemoveFrom(Fuse.UpdateManager.listeners, pu, stage))
            {
                throw new $Error(Uno.Exception.New_1("no Action found to remove"));
            }

            Fuse.UpdateManager.hasListenersRemoved = true;
        };

        Fuse.UpdateManager.AddOnceAction = function(pu, stage)
        {
            var us = Fuse.UpdateListener.New_1();
            us.action = pu;
            us.stage = stage;
            Fuse.UpdateManager.oncesPending.Add(us);
        };

        Fuse.UpdateManager.PerformNextFrame = function(pu, stage)
        {
            var us = Fuse.UpdateListener.New_1();
            us.action = pu;
            us.stage = stage;
            us.defer = true;
            Fuse.UpdateManager.oncesPending.Add(us);
        };

        Fuse.UpdateManager.IncreaseFrameIndex = function()
        {
            Fuse.UpdateManager._frameIndex++;
        };

        Fuse.UpdateManager.Update = function()
        {
            Fuse.Input.NotifyUpdate();
            Fuse.UpdateManager.Update_1(0);
            Fuse.UpdateManager.Update_1(1);
            Fuse.UpdateManager.Update_1(2);
            Fuse.UpdateManager.Update_1(3);
            var t = Fuse.UpdateManager.onces;
            Fuse.UpdateManager.onces = Fuse.UpdateManager.oncesPending;
            Fuse.UpdateManager.oncesPending = t;
            Fuse.UpdateManager.oncesPending.Clear();

            if (Fuse.UpdateManager.hasListenersRemoved)
            {
                for (var i = Fuse.UpdateManager.listeners.Count() - 1; i >= 0; --i)
                {
                    if (Fuse.UpdateManager.listeners.Item(i).removed)
                    {
                        Fuse.UpdateManager.listeners.RemoveAt(i);
                    }
                }
            }
        };

        Fuse.UpdateManager.Update_1 = function(stage)
        {
            if (Fuse.UpdateManager.onces.Count() > 0)
            {
                for (var enum_123 = Fuse.UpdateManager.onces.GetEnumerator(); enum_123.MoveNext(); )
                {
                    var ul = enum_123.Current();

                    if (ul.defer)
                    {
                        ul.defer = false;
                        Fuse.UpdateManager.oncesPending.Add(ul);
                    }
                    else if (ul.stage == stage)
                    {
                        ul.Invoke();
                    }
                }
            }

            for (var i = 0; i < Fuse.UpdateManager.listeners.Count(); ++i)
            {
                var ul = Fuse.UpdateManager.listeners.Item(i);

                if (ul.stage == stage)
                {
                    ul.Invoke();
                }
            }
        };

        Fuse.UpdateManager._TypeInit = function()
        {
            Fuse.UpdateManager.listeners = Uno.Collections.List__Fuse_UpdateListener.New_1();
            Fuse.UpdateManager.onces = Uno.Collections.List__Fuse_UpdateListener.New_1();
            Fuse.UpdateManager.oncesPending = Uno.Collections.List__Fuse_UpdateListener.New_1();
        };

    });
