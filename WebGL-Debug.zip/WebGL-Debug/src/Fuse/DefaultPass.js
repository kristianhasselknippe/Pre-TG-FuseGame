Fuse.DefaultPass = $CreateClass(
    function() {
        Fuse.Pass.call(this);
    },
    function(S) {
        var I = S.prototype = new Fuse.Pass;

        I.GetType = function()
        {
            return 941;
        };

        I._ObjInit_1 = function()
        {
            Fuse.Pass.prototype._ObjInit.call(this);
        };

        Fuse.DefaultPass.New_1 = function()
        {
            var inst = new Fuse.DefaultPass;
            inst._ObjInit_1();
            return inst;
        };

    });
