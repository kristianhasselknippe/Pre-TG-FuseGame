Fuse.Rotation = $CreateClass(
    function() {
        Fuse.Transform.call(this);
        this._degrees = 0;
    },
    function(S) {
        var I = S.prototype = new Fuse.Transform;

        I.GetType = function()
        {
            return 985;
        };

        I.Degrees = function(value)
        {
            if (value !== undefined)
            {
                if (this._degrees != value)
                {
                    this._degrees = value;
                    this.OnMatrixChanged();
                }
            }
            else
            {
                return this._degrees;
            }
        };

        I.AppendTo = function(m, weight)
        {
            if (this.Degrees() != 0.0)
            {
                m.AppendRotation(Uno.Math.DegreesToRadians_1(this.Degrees() * weight));
            }
        };

        I.PrependTo = function(m)
        {
            if (this.Degrees() != 0.0)
            {
                m.PrependRotation(Uno.Math.DegreesToRadians_1(this.Degrees()));
            }
        };

        I._ObjInit_1 = function()
        {
            Fuse.Transform.prototype._ObjInit.call(this);
        };

        Fuse.Rotation.New_1 = function()
        {
            var inst = new Fuse.Rotation;
            inst._ObjInit_1();
            return inst;
        };

    });
