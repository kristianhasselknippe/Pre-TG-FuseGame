Fuse.KeyEventArgs = $CreateClass(
    function() {
        Fuse.InputEventArgs.call(this);
        this._Key = 0;
    },
    function(S) {
        var I = S.prototype = new Fuse.InputEventArgs;

        I.GetType = function()
        {
            return 972;
        };

        I.Key = function(value)
        {
            if (value !== undefined)
            {
                this._Key = value;
            }
            else
            {
                return this._Key;
            }
        };

        I._ObjInit_2 = function(key)
        {
            Fuse.InputEventArgs.prototype._ObjInit_1.call(this);
            this.Key(key);
        };

    });
