Fuse.Element_GMSCacheItem = $CreateClass(
    function() {
        this.$struct = true;
        this.fillSize = new Uno.Float2;
        this.fillSet = 0;
        this.result = new Uno.Float2;
    },
    function(S) {
        var I = S.prototype;

        I.GetType = function()
        {
            return 1022;
        };

        I.op_Assign = function(value)
        {
            this.fillSize.op_Assign(value.fillSize);
            this.fillSet = value.fillSet;
            this.result.op_Assign(value.result);
        };

    });
