Fuse.FastMatrixTransform = $CreateClass(
    function() {
        Fuse.Transform.call(this);
        this.Matrix = null;
    },
    function(S) {
        var I = S.prototype = new Fuse.Transform;

        I.GetType = function()
        {
            return 987;
        };

        I.AppendTo = function(m, weight)
        {
            m.AppendFastMatrix(this.Matrix);
        };

        I.PrependTo = function(m)
        {
            m.PrependFastMatrix(this.Matrix);
        };

        I.Changed = function()
        {
            this.OnMatrixChanged();
        };

        I._ObjInit_1 = function()
        {
            this.Matrix = Fuse.FastMatrix.Identity();
            Fuse.Transform.prototype._ObjInit.call(this);
        };

        Fuse.FastMatrixTransform.New_1 = function()
        {
            var inst = new Fuse.FastMatrixTransform;
            inst._ObjInit_1();
            return inst;
        };

    });
