Fuse.KeyReleasedArgs = $CreateClass(
    function() {
        Fuse.KeyEventArgs.call(this);
    },
    function(S) {
        var I = S.prototype = new Fuse.KeyEventArgs;

        I.GetType = function()
        {
            return 975;
        };

        I._ObjInit_3 = function(key)
        {
            Fuse.KeyEventArgs.prototype._ObjInit_2.call(this, key);
        };

        Fuse.KeyReleasedArgs.New_2 = function(key)
        {
            var inst = new Fuse.KeyReleasedArgs;
            inst._ObjInit_3(key);
            return inst;
        };

    });
