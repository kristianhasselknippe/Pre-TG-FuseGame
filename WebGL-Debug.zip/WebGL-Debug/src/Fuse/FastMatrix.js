Fuse.FastMatrix = $CreateClass(
    function() {
        this._matrix = new Uno.Float4x4;
        this._hasNonTranslation = false;
    },
    function(S) {
        var I = S.prototype;

        I.GetType = function()
        {
            return 941;
        };

        I.Matrix = function()
        {
            return this._matrix;
        };

        Fuse.FastMatrix.Identity = function()
        {
            return Fuse.FastMatrix.New_1();
        };

        I.ResetIdentity = function()
        {
            this._matrix = Uno.Float4x4.Identity();
        };

        Fuse.FastMatrix.FromFloat4x4 = function(m)
        {
            var k = Fuse.FastMatrix.New_1();
            k._matrix.op_Assign(m);
            k._hasNonTranslation = true;
            return k;
        };

        I.AppendTranslation = function(x, y, z)
        {
            if (!this._hasNonTranslation)
            {
                this.SimpleTranslation(x, y, z);
            }
            else
            {
                this._matrix = Uno.Matrix.Mul_11(this._matrix, Uno.Matrix.Translation(Uno.Float3.New_2(x, y, z)));
            }
        };

        I.PrependTranslation = function(x, y, z)
        {
            if (!this._hasNonTranslation)
            {
                this.SimpleTranslation(x, y, z);
            }
            else
            {
                this._matrix = Uno.Matrix.Mul_11(Uno.Matrix.Translation(Uno.Float3.New_2(x, y, z)), this._matrix);
            }
        };

        I.AppendRotation = function(zDegrees)
        {
            this._matrix = Uno.Matrix.Mul_11(this._matrix, Uno.Matrix.RotationZ(zDegrees));
            this._hasNonTranslation = true;
        };

        I.PrependRotation = function(zDegrees)
        {
            this._matrix = Uno.Matrix.Mul_11(Uno.Matrix.RotationZ(zDegrees), this._matrix);
            this._hasNonTranslation = true;
        };

        I.AppendScale = function(factor)
        {
            this._matrix = Uno.Matrix.Mul_11(this._matrix, Uno.Matrix.Scaling(Uno.Float3.New_2(factor, factor, factor)));
            this._hasNonTranslation = true;
        };

        I.PrependScale = function(factor)
        {
            this._matrix = Uno.Matrix.Mul_11(Uno.Matrix.Scaling(Uno.Float3.New_2(factor, factor, factor)), this._matrix);
            this._hasNonTranslation = true;
        };

        I.SimpleTranslation = function(x, y, z)
        {
            this._matrix.M41 = this._matrix.M41 + x;
            this._matrix.M42 = this._matrix.M42 + y;
            this._matrix.M43 = this._matrix.M43 + z;
        };

        I.Mul = function(m)
        {
            var res = Fuse.FastMatrix.New_1();
            res._matrix = Uno.Matrix.Mul_11(this._matrix, m._matrix);
            res._hasNonTranslation = this._hasNonTranslation || m._hasNonTranslation;
            return res;
        };

        I.Invert = function()
        {
            if (!this._hasNonTranslation)
            {
                this._matrix.M41 = -this._matrix.M41;
                this._matrix.M42 = -this._matrix.M42;
                this._matrix.M43 = -this._matrix.M43;
            }
            else
            {
                this._matrix.op_Assign(Uno.Matrix.Invert(this._matrix));
            }
        };

        I.AppendScale_1 = function(scale)
        {
            this._matrix = Uno.Matrix.Mul_11(this._matrix, Uno.Matrix.Scaling(scale));
            this._hasNonTranslation = true;
        };

        I.AppendRotationQuaternion = function(q)
        {
            this._matrix = Uno.Matrix.Mul_11(this._matrix, Uno.Matrix.RotationQuaternion(q));
            this._hasNonTranslation = true;
        };

        I.AppendTranslation_1 = function(offset)
        {
            this._matrix = Uno.Matrix.Mul_11(this._matrix, Uno.Matrix.Translation(offset));
        };

        I.PrependScale_1 = function(scale)
        {
            this._matrix = Uno.Matrix.Mul_11(Uno.Matrix.Scaling(scale), this._matrix);
            this._hasNonTranslation = true;
        };

        I.PrependRotationQuaternion = function(q)
        {
            this._matrix = Uno.Matrix.Mul_11(Uno.Matrix.RotationQuaternion(q), this._matrix);
            this._hasNonTranslation = true;
        };

        I.PrependTranslation_1 = function(offset)
        {
            this._matrix = Uno.Matrix.Mul_11(Uno.Matrix.Translation(offset), this._matrix);
        };

        I.PrependFastMatrix = function(fm)
        {
            if (this._hasNonTranslation || fm._hasNonTranslation)
            {
                this._matrix = Uno.Matrix.Mul_11(fm.Matrix(), this._matrix);
                this._hasNonTranslation = true;
            }
            else
            {
                this._matrix.M41 = this._matrix.M41 + fm._matrix.M41;
                this._matrix.M42 = this._matrix.M42 + fm._matrix.M42;
                this._matrix.M43 = this._matrix.M43 + fm._matrix.M43;
            }
        };

        I.AppendFastMatrix = function(fm)
        {
            if (this._hasNonTranslation || fm._hasNonTranslation)
            {
                this._matrix = Uno.Matrix.Mul_11(this._matrix, fm.Matrix());
                this._hasNonTranslation = true;
            }
            else
            {
                this._matrix.M41 = this._matrix.M41 + fm._matrix.M41;
                this._matrix.M42 = this._matrix.M42 + fm._matrix.M42;
                this._matrix.M43 = this._matrix.M43 + fm._matrix.M43;
            }
        };

        I._ObjInit = function()
        {
            this._matrix = Uno.Float4x4.Identity();
        };

        Fuse.FastMatrix.New_1 = function()
        {
            var inst = new Fuse.FastMatrix;
            inst._ObjInit();
            return inst;
        };

    });
