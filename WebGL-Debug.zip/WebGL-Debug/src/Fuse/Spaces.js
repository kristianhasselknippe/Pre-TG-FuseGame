Fuse.Spaces = $CreateClass(
    function() {
    },
    function(S) {

        Fuse.Spaces.VirtualResolution = function()
        {
            return Uno.Float2.op_Division_1(Uno.Float2.op_Implicit(Fuse.Spaces.RenderTargetSize()), Fuse.Environment.ScreenPPIZoomMultiplier());
        };

        Fuse.Spaces.RenderTargetSize = function()
        {
            return Uno.Application.Current().GraphicsContext().RenderTarget().Size();
        };

    });
