Fuse.ExtrinsicItem = $CreateClass(
    function() {
        this.Handle = 0;
        this.Value = null;
        this.Next = null;
    },
    function(S) {
        var I = S.prototype;

        I.GetType = function()
        {
            return 980;
        };

        I._ObjInit = function(handle, val, next)
        {
            this.Handle = handle;
            this.Value = val;
            this.Next = next;
        };

        Fuse.ExtrinsicItem.New_1 = function(handle, val, next)
        {
            var inst = new Fuse.ExtrinsicItem;
            inst._ObjInit(handle, val, next);
            return inst;
        };

    });
