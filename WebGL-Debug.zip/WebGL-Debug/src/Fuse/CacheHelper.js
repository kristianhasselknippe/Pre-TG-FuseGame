Fuse.CacheHelper = $CreateClass(
    function() {
        this.Blit_Coord_f2cffa9a_1_1_1 = null;
        this.Blit_Vertices_f2cffa9a_1_0_7 = null;
        this._draw_f2cffa9a = new Uno.Runtime.Implementation.ShaderBackends.OpenGL.GLDrawCall;
    },
    function(S) {
        var I = S.prototype;

        I.GetType = function()
        {
            return 990;
        };

        I.Blit = function(dc, cache, opacity)
        {
            var tile_126 = new Fuse.CacheTile;
            var array_123;
            var index_124;
            var length_125;

            for (array_123 = cache.CacheTiles(), index_124 = 0, length_125 = array_123.length; index_124 < length_125; ++index_124)
            {
                tile_126.op_Assign(array_123[index_124]);
                {
                    this._draw_f2cffa9a.BlendEnabled(true);
                    this._draw_f2cffa9a.BlendDstRgb(3);
                    this._draw_f2cffa9a.BlendDstAlpha(3);
                    this._draw_f2cffa9a.DepthTestEnabled(false);
                    this._draw_f2cffa9a.CullFace(0);
                    this._draw_f2cffa9a.Use();
                    this._draw_f2cffa9a.Attrib_1(0, 2, this.Blit_Coord_f2cffa9a_1_1_1, 8, 0);
                    this._draw_f2cffa9a.Uniform_9(1, Uno.Float2.op_Division_1(Uno.Float2.New_2(tile_126.Texture().Size().X, tile_126.Texture().Size().Y), dc.ResolutionMultiplier()));
                    this._draw_f2cffa9a.Uniform_14(2, tile_126._compositMatrix);
                    this._draw_f2cffa9a.Uniform_9(3, dc.VirtualResolution());
                    this._draw_f2cffa9a.Uniform_8(4, opacity);
                    this._draw_f2cffa9a.Sampler_2(5, tile_126.Texture());
                    this._draw_f2cffa9a.DrawArrays(this.Blit_Vertices_f2cffa9a_1_0_7.length);
                }
            }
        };

        I.init_DrawCalls = function()
        {
            var Vertices_f2cffa9a_1_0_0 = Array.Init([Uno.Float2.New_2(0.0, 0.0), Uno.Float2.New_2(0.0, 1.0), Uno.Float2.New_2(1.0, 1.0), Uno.Float2.New_2(0.0, 0.0), Uno.Float2.New_2(1.0, 1.0), Uno.Float2.New_2(1.0, 0.0)], 430);
            this.Blit_Coord_f2cffa9a_1_1_1 = Uno.Graphics.VertexBuffer.New_3(Uno.Runtime.Implementation.Internal.BufferConverters.ToBuffer_1(Vertices_f2cffa9a_1_0_0), 0);
            this.Blit_Vertices_f2cffa9a_1_0_7 = Vertices_f2cffa9a_1_0_0;
            this._draw_f2cffa9a = Uno.Runtime.Implementation.ShaderBackends.OpenGL.GLDrawCall.New_1($DownCast(Uno.Runtime.Implementation.Internal.BundleRegistry.Get(45), 383));
        };

        I._ObjInit = function()
        {
            this.init_DrawCalls();
        };

        Fuse.CacheHelper.New_1 = function()
        {
            var inst = new Fuse.CacheHelper;
            inst._ObjInit();
            return inst;
        };

    });
