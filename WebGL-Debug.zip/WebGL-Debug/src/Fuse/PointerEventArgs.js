Fuse.PointerEventArgs = $CreateClass(
    function() {
        Fuse.InputEventArgs.call(this);
        this._data = null;
    },
    function(S) {
        var I = S.prototype = new Fuse.InputEventArgs;

        I.GetType = function()
        {
            return 921;
        };

        I.Data = function()
        {
            return this._data;
        };

        I.ViewProvider = function()
        {
            return this._data.ViewProvider;
        };

        I.Camera = function()
        {
            return this._data.ViewProvider.Camera();
        };

        I.PointCoord = function()
        {
            return this._data.PointCoord;
        };

        I.PointIndex = function()
        {
            return this._data.PointIndex;
        };

        I.PointerType = function()
        {
            return this._data.PointerType;
        };

        I.IsPointerHardCaptured = function()
        {
            var capturer = Fuse.Input.GetHardCapturer(this.PointIndex());
            return capturer != null;
        };

        I.HardCapturePointer = function(capturer)
        {
            Fuse.Input.HardCapture(this.PointIndex(), this.ViewProvider(), capturer);
        };

        I.SoftCapturePointer = function(capturer)
        {
            if (!this.IsPointerHardCaptured())
            {
                Fuse.Input.SoftCapture(this.PointIndex(), this.ViewProvider(), capturer);
            }
        };

        I.ReleaseSoftCapture = function(capturer)
        {
            Fuse.Input.ReleaseSoftCapture(this.PointIndex(), this.ViewProvider(), capturer);
        };

        I.ReleaseHardCapture = function()
        {
            Fuse.Input.ReleaseHardCapture(this.PointIndex());
        };

        I.IsSoftCapturedTo = function(capturer)
        {
            return Fuse.Input.IsSoftCaptured(this.PointIndex(), capturer);
        };

        I.IsHardCapturedTo = function(node)
        {
            var capturer = Fuse.Input.GetHardCapturer(this.PointIndex());
            return capturer == node;
        };

        I.Reroute = function(viewProvider)
        {
            this._data.ViewProvider = viewProvider;
        };

        I._ObjInit_2 = function(data)
        {
            Fuse.InputEventArgs.prototype._ObjInit_1.call(this);
            this._data = data;
        };

    });
