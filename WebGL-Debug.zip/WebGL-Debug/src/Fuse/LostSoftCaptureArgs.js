Fuse.LostSoftCaptureArgs = $CreateClass(
    function() {
        Uno.EventArgs.call(this);
    },
    function(S) {
        var I = S.prototype = new Uno.EventArgs;

        I.GetType = function()
        {
            return 940;
        };

        I._ObjInit_1 = function()
        {
            Uno.EventArgs.prototype._ObjInit.call(this);
        };

        Fuse.LostSoftCaptureArgs.New_2 = function()
        {
            var inst = new Fuse.LostSoftCaptureArgs;
            inst._ObjInit_1();
            return inst;
        };

    });
