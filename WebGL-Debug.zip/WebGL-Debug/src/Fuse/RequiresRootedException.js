Fuse.RequiresRootedException = $CreateClass(
    function() {
        Uno.Exception.call(this);
    },
    function(S) {
        var I = S.prototype = new Uno.Exception;

        I.GetType = function()
        {
            return 981;
        };

        I._ObjInit_2 = function()
        {
            Uno.Exception.prototype._ObjInit_1.call(this);
        };

        Fuse.RequiresRootedException.New_3 = function()
        {
            var inst = new Fuse.RequiresRootedException;
            inst._ObjInit_2();
            return inst;
        };

    });
