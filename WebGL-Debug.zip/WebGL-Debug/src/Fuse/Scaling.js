Fuse.Scaling = $CreateClass(
    function() {
        Fuse.Transform.call(this);
        this._factor = 0;
    },
    function(S) {
        var I = S.prototype = new Fuse.Transform;

        I.GetType = function()
        {
            return 986;
        };

        I.Factor = function(value)
        {
            if (value !== undefined)
            {
                if (this._factor != value)
                {
                    this._factor = value;
                    this.OnMatrixChanged();
                }
            }
            else
            {
                return this._factor;
            }
        };

        I.IsIdentity = function()
        {
            return Uno.Math.Abs_1(this._factor - 1.0) < 1e-05;
        };

        I.AppendTo = function(m, weight)
        {
            if (!this.IsIdentity())
            {
                m.AppendScale(Uno.Math.Lerp_1(1.0, this.Factor(), weight));
            }
        };

        I.PrependTo = function(m)
        {
            if (!this.IsIdentity())
            {
                m.PrependScale(this.Factor());
            }
        };

        I._ObjInit_1 = function()
        {
            this._factor = 1.0;
            Fuse.Transform.prototype._ObjInit.call(this);
        };

        Fuse.Scaling.New_1 = function()
        {
            var inst = new Fuse.Scaling;
            inst._ObjInit_1();
            return inst;
        };

    });
