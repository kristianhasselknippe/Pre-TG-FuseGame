Fuse.Controls.NavigateTo = $CreateClass(
    function() {
        Fuse.Triggers.Actions.TriggerAction.call(this);
        this._context = null;
        this._Target = null;
    },
    function(S) {
        var I = S.prototype = new Fuse.Triggers.Actions.TriggerAction;

        I.GetType = function()
        {
            return 872;
        };

        I.Target = function(value)
        {
            if (value !== undefined)
            {
                this._Target = value;
            }
            else
            {
                return this._Target;
            }
        };

        I.Context = function(value)
        {
            if (value !== undefined)
            {
                this._context = value;
            }
            else
            {
                var ind_123 = this._context;
                return (ind_123 != null) ? ind_123 : $DownCast(Fuse.Controls.Navigation.TryFind(this.Target()), 33655);
            }
        };

        I.Perform = function(n)
        {
            var ctx = this.Context();
            var target = this.Target();

            if ((target != null) && (ctx != null))
            {
                ctx["Fuse.Controls.INavigationContext.Goto"](target);
            }
        };

    });
