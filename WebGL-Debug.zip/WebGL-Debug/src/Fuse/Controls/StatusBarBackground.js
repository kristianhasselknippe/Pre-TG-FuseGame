Fuse.Controls.StatusBarBackground = $CreateClass(
    function() {
        Fuse.Controls.Control.call(this);
    },
    function(S) {
        var I = S.prototype = new Fuse.Controls.Control;

        I.GetType = function()
        {
            return 822;
        };

        I.GetContentSize = function(fillSize, fillSet)
        {
            return Uno.Float2.New_2(0.0, 0.0);
        };

        I._ObjInit_3 = function()
        {
            Fuse.Controls.Control.prototype._ObjInit_2.call(this);
        };

        Fuse.Controls.StatusBarBackground.New_2 = function()
        {
            var inst = new Fuse.Controls.StatusBarBackground;
            inst._ObjInit_3();
            return inst;
        };

    });
