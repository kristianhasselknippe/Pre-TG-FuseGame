Fuse.Controls.TitleChangedArgs = $CreateClass(
    function() {
        Uno.EventArgs.call(this);
        this._NewTitleElement = null;
    },
    function(S) {
        var I = S.prototype = new Uno.EventArgs;

        I.GetType = function()
        {
            return 885;
        };

        I.NewTitleElement = function(value)
        {
            if (value !== undefined)
            {
                this._NewTitleElement = value;
            }
            else
            {
                return this._NewTitleElement;
            }
        };

        I._ObjInit_1 = function(newTitleElement)
        {
            Uno.EventArgs.prototype._ObjInit.call(this);
            this.NewTitleElement(newTitleElement);
        };

        Fuse.Controls.TitleChangedArgs.New_2 = function(newTitleElement)
        {
            var inst = new Fuse.Controls.TitleChangedArgs;
            inst._ObjInit_1(newTitleElement);
            return inst;
        };

    });
