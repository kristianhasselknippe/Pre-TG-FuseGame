Fuse.Controls.DefaultSwitchBehavior = $CreateClass(
    function() {
        Fuse.Triggers.ElementTrigger.call(this);
        this._switch = null;
        this._prevCoord = new Uno.Float2;
        this._currentCoord = new Uno.Float2;
        this._originalP = new Uno.Float2;
        this._switchTargetValue = false;
    },
    function(S) {
        var I = S.prototype = new Fuse.Triggers.ElementTrigger;

        I.GetType = function()
        {
            return 896;
        };

        I.Size = function()
        {
            return this._switch.ActualSize();
        };

        I.OnRooted_1 = function(elm)
        {
            if ($IsOp(elm, 897))
            {
                var sw = $AsOp(elm, 897);
                this._switch = sw;
                sw.add_ToggledChanged($CreateDelegate(this, Fuse.Controls.DefaultSwitchBehavior.prototype.OnToggledChanged, 445));
                sw.add_PointerPressed($CreateDelegate(this, Fuse.Controls.DefaultSwitchBehavior.prototype.OnPointerPressed, 924));
                sw.add_PointerMoved($CreateDelegate(this, Fuse.Controls.DefaultSwitchBehavior.prototype.OnPointerMoved, 926));
                sw.add_PointerReleased($CreateDelegate(this, Fuse.Controls.DefaultSwitchBehavior.prototype.OnPointerReleased, 928));
                Fuse.Triggers.Tapped.AddSubscriber(elm, $CreateDelegate(this, Fuse.Controls.DefaultSwitchBehavior.prototype.OnPointerTapped, 785));
                sw.add_Resized($CreateDelegate(this, Fuse.Controls.DefaultSwitchBehavior.prototype.OnResized, 996));
            }
        };

        I.OnUnrooted_1 = function(elm)
        {
            if ($IsOp(elm, 897))
            {
                var sw = $AsOp(elm, 897);
                sw.remove_ToggledChanged($CreateDelegate(this, Fuse.Controls.DefaultSwitchBehavior.prototype.OnToggledChanged, 445));
                sw.remove_PointerPressed($CreateDelegate(this, Fuse.Controls.DefaultSwitchBehavior.prototype.OnPointerPressed, 924));
                sw.remove_PointerMoved($CreateDelegate(this, Fuse.Controls.DefaultSwitchBehavior.prototype.OnPointerMoved, 926));
                sw.remove_PointerReleased($CreateDelegate(this, Fuse.Controls.DefaultSwitchBehavior.prototype.OnPointerReleased, 928));
                sw.remove_Resized($CreateDelegate(this, Fuse.Controls.DefaultSwitchBehavior.prototype.OnResized, 996));
                Fuse.Triggers.Tapped.RemoveSubscriber(elm, $CreateDelegate(this, Fuse.Controls.DefaultSwitchBehavior.prototype.OnPointerTapped, 785));
                this._switch = null;
            }
        };

        I.OnResized = function(sender, args)
        {
            this.Animation().PlayEnd(this._switch.Toggled(), null);
        };

        I.OnPointerPressed = function(sender, args)
        {
            args.HardCapturePointer($DownCast(this._switch, 33719));
            this._prevCoord.op_Assign((this._currentCoord.op_Assign(args.PointCoord()), this._currentCoord));
            this._originalP.op_Assign(args.PointCoord());
        };

        I.OnPointerMoved = function(sender, args)
        {
            if (args.IsHardCapturedTo($AsOp(sender, 33719)))
            {
                this._prevCoord.op_Assign(this._currentCoord);
                this._currentCoord.op_Assign(args.PointCoord());
                var delta = Uno.Float2.op_Subtraction(this._currentCoord, this._prevCoord);
                var p = (delta.X / this.Size().X) / this._switch.AbsoluteZoom();
                this.Seek_1(this.Animation().Progress() + p, this._switch.Toggled() ? 1 : 0);
            }
        };

        I.OnPointerReleased = function(sender, args)
        {
            args.ReleaseHardCapture();
            this.StartRangePlayer(this.Animation().Progress() >= 0.5);
        };

        I.OnPointerTapped = function(sender, args)
        {
            this.StartRangePlayer(!this._switchTargetValue);
        };

        I.OnTriggerPlayerDone = function()
        {
            this._switch.Toggled(this.Animation().Progress() >= 0.5);
        };

        I.OnToggledChanged = function(sender, args)
        {
            if (this._switchTargetValue == this._switch.Toggled())
            {
                return;
            }

            this.StartRangePlayer(this._switch.Toggled());
        };

        I.StartRangePlayer = function(toggle)
        {
            this._switchTargetValue = toggle;
            this.Animation().PlayEnd(toggle, $CreateDelegate(this, Fuse.Controls.DefaultSwitchBehavior.prototype.OnTriggerPlayerDone, 436));
        };

        I._ObjInit_3 = function()
        {
            Fuse.Triggers.ElementTrigger.prototype._ObjInit_2.call(this);
        };

        Fuse.Controls.DefaultSwitchBehavior.New_1 = function()
        {
            var inst = new Fuse.Controls.DefaultSwitchBehavior;
            inst._ObjInit_3();
            return inst;
        };

    });
