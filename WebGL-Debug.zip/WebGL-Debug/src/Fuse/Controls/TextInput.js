Fuse.Controls.TextInput = $CreateClass(
    function() {
        Fuse.Controls.Control.call(this);
        this._editor = null;
        this._isMultiline = false;
        this._textWrapping = 0;
        this._isPassword = false;
        this._inputHint = 0;
        this._text = null;
        this._caretColor = new Uno.Float3;
        this._selectionColor = new Uno.Float4;
        this.TextChanged = null;
    },
    function(S) {
        var I = S.prototype = new Fuse.Controls.Control;

        I.GetType = function()
        {
            return 898;
        };

        I.Editor = function(value)
        {
            if (value !== undefined)
            {
                if (this._editor != value)
                {
                    if (this._editor != null)
                    {
                        this._editor.remove_TextChanged($CreateDelegate(this, Fuse.Controls.TextInput.prototype.OnEditorTextChanged, 445));
                    }

                    this._editor = value;

                    if (this._editor != null)
                    {
                        this._editor.add_TextChanged($CreateDelegate(this, Fuse.Controls.TextInput.prototype.OnEditorTextChanged, 445));
                    }

                    this.VisualTree(value);
                    this.PushProperties();
                }
            }
            else
            {
                return this._editor;
            }
        };

        I.IsMultiline = function(value)
        {
            if (value !== undefined)
            {
                this._isMultiline = value;

                if (this.Editor() != null)
                {
                    this.Editor().IsMultiline(value);
                }
            }
            else
            {
                return this._isMultiline;
            }
        };

        I.TextWrapping = function(value)
        {
            if (value !== undefined)
            {
                this._textWrapping = value;

                if (this.Editor() != null)
                {
                    this.Editor().TextWrapping(value);
                }
            }
            else
            {
                return this._textWrapping;
            }
        };

        I.IsPassword = function(value)
        {
            if (value !== undefined)
            {
                this._isPassword = value;

                if (this.Editor() != null)
                {
                    this.Editor().IsPassword(value);
                }
            }
            else
            {
                return this._isPassword;
            }
        };

        I.InputHint = function(value)
        {
            if (value !== undefined)
            {
                this._inputHint = value;

                if (this.Editor() != null)
                {
                    this.Editor().InputHint(value);
                }
            }
            else
            {
                return this._inputHint;
            }
        };

        I.Text = function(value)
        {
            if (value !== undefined)
            {
                if (Uno.String.op_Inequality(this._text, value))
                {
                    this._text = value;
                    this.OnTextChanged();
                }

                if (this.Editor() != null)
                {
                    this.Editor().Text(value);
                }
            }
            else
            {
                return this._text;
            }
        };

        I.CaretColor = function(value)
        {
            if (value !== undefined)
            {
                this._caretColor.op_Assign(value);

                if (this.Editor() != null)
                {
                    this.Editor().CaretColor(value);
                }
            }
            else
            {
                return this._caretColor;
            }
        };

        I.SelectionColor = function(value)
        {
            if (value !== undefined)
            {
                this._selectionColor.op_Assign(value);

                if (this.Editor() != null)
                {
                    this.Editor().SelectionColor(value);
                }
            }
            else
            {
                return this._selectionColor;
            }
        };

        I.OnEditorTextChanged = function(sender, args)
        {
            this.Text(this.Editor().Text());
        };

        I.PushProperties = function()
        {
            if (this.Editor() == null)
            {
                return;
            }

            this.Editor().IsMultiline(this.IsMultiline());
            this.Editor().TextWrapping(this.TextWrapping());
            this.Editor().IsPassword(this.IsPassword());
            this.Editor().InputHint(this.InputHint());
            this.Editor().Text(this.Text());
            this.Editor().CaretColor(this.CaretColor());
            this.Editor().SelectionColor(this.SelectionColor());
        };

        I.OnTextChanged = function()
        {
            if (Uno.Delegate.op_Inequality(this.TextChanged, null))
            {
                this.TextChanged.Invoke(this, Uno.EventArgs.Empty);
            }
        };

        I.add_TextChanged = function(value)
        {
            this.TextChanged = $DownCast(Uno.Delegate.Combine(this.TextChanged, value), 445);
        };

        I.remove_TextChanged = function(value)
        {
            this.TextChanged = $DownCast(Uno.Delegate.Remove(this.TextChanged, value), 445);
        };

    });
