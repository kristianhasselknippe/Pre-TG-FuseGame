Fuse.Controls.Navigation = $CreateClass(
    function() {
        Fuse.Behavior.call(this);
        this._panel = null;
        this._navigationTween = null;
        this._currentAnimatorPlayer = null;
        this._progress = 0;
        this._active = null;
        this.TitleChanged = null;
        this.Navigated = null;
        this._Mode = 0;
    },
    function(S) {
        var I = S.prototype = new Fuse.Behavior;

        I.GetType = function()
        {
            return 874;
        };

        I.$II = function(id)
        {
            return [887].indexOf(id) != -1;
        };

        I.Mode = function(value)
        {
            if (value !== undefined)
            {
                this._Mode = value;
            }
            else
            {
                return this._Mode;
            }
        };

        I.Owner = function()
        {
            return this._panel;
        };

        I.CanGoBack = function()
        {
            if ((this._panel != null) && this._panel.HasChildren())
            {
                return this._active != this.Front();
            }

            return false;
        };

        I.Progress = function(value)
        {
            if (value !== undefined)
            {
                this._progress = value;
            }
            else
            {
                return this._progress;
            }
        };

        I.Back = function()
        {
            return this._panel.HasChildren() ? this._panel.Children()["Uno.Collections.IList__Fuse_Element.Item"](this._panel.Children()["Uno.Collections.ICollection__Fuse_Element.Count"]() - 1) : null;
        };

        I.Front = function()
        {
            return this._panel.HasChildren() ? this._panel.Children()["Uno.Collections.IList__Fuse_Element.Item"](0) : null;
        };

        I.Previous = function()
        {
            return this._panel.HasChildren() ? this._panel.Children()["Uno.Collections.IList__Fuse_Element.Item"](Uno.Math.Clamp_8(Uno.Collections.EnumerableExtensions.IndexOf__Fuse_Element($DownCast(this._panel.Children(), 32829), this._active) - 1, 0, this._panel.Children()["Uno.Collections.ICollection__Fuse_Element.Count"]() - 1)) : null;
        };

        I.OnRooted = function(node)
        {
            var panel = $AsOp(node, 882);

            if (panel != null)
            {
                this._panel = panel;
                this._panel.add_ChildAdded($CreateDelegate(this, Fuse.Controls.Navigation.prototype.OnChildAdded, 496));
                this._panel.add_ChildRemoved($CreateDelegate(this, Fuse.Controls.Navigation.prototype.OnChildRemoved, 496));
                this._panel.add_Update($CreateDelegate(this, Fuse.Controls.Navigation.prototype.OnUpdate, 445));
                this._panel.add_Resized($CreateDelegate(this, Fuse.Controls.Navigation.prototype.OnResized, 996));

                if (this._panel.HasChildren() && (this._active == null))
                {
                    this._active = Uno.Collections.EnumerableExtensions.First__Fuse_Element($DownCast(this._panel.Children(), 32829));
                }

                this.EnsureChildAnimationState();

                if (this._active != null)
                {
                    this.TransitionTo(this._active, true);
                }
            }
        };

        I.OnUnrooted = function(node)
        {
            if (this._panel != null)
            {
                this._panel.remove_ChildAdded($CreateDelegate(this, Fuse.Controls.Navigation.prototype.OnChildAdded, 496));
                this._panel.remove_ChildRemoved($CreateDelegate(this, Fuse.Controls.Navigation.prototype.OnChildRemoved, 496));
                this._panel.remove_Update($CreateDelegate(this, Fuse.Controls.Navigation.prototype.OnUpdate, 445));
                this._panel.remove_Resized($CreateDelegate(this, Fuse.Controls.Navigation.prototype.OnResized, 996));
                this._panel = null;
            }
        };

        I.OnResized = function(sender, args)
        {
            this.EnsureChildAnimationState();
        };

        I.Goto = function(element)
        {
            if (this._panel == null)
            {
                throw new $Error(Fuse.RequiresRootedException.New_3());
            }

            if (element == this._active)
            {
                return;
            }

            if (!this._panel.Children()["Uno.Collections.ICollection__Fuse_Element.Contains"](element))
            {
                if (this.Mode() == 0)
                {
                    this._panel.Children()["Uno.Collections.ICollection__Fuse_Element.Add"](element);
                }

                if (this.Mode() == 1)
                {
                    this.ClearForwardHistory();
                    this._panel.Children()["Uno.Collections.ICollection__Fuse_Element.Add"](element);
                }
            }
            else
            {
                if (this.Mode() == 1)
                {
                    var diff = this.Progress() - Uno.Collections.EnumerableExtensions.IndexOf__Fuse_Element($DownCast(this._panel.Children(), 32829), this._active);
                    this._panel.Children()["Uno.Collections.ICollection__Fuse_Element.Remove"](element);
                    this.Progress(Uno.Collections.EnumerableExtensions.IndexOf__Fuse_Element($DownCast(this._panel.Children(), 32829), this._active) + diff);
                    this.EnsureChildAnimationState();
                    this.ClearForwardHistory();
                    this._panel.Children()["Uno.Collections.ICollection__Fuse_Element.Add"](element);
                }
            }

            this.TransitionTo(element, false);
        };

        I.TransitionTo = function(element, bypass)
        {
            var targetProgress = Uno.Collections.EnumerableExtensions.IndexOf__Fuse_Element($DownCast(this._panel.Children(), 32829), element);
            this._active = element;

            if ((this.Progress() == targetProgress) && (this._currentAnimatorPlayer == null))
            {
                return;
            }

            this._currentAnimatorPlayer = Fuse.Controls.Internal.PlayerFactory.Start(targetProgress, this.Progress(), Fuse.Controls.Internal.DefaultAnimatorFactory.GetAnimators(this._panel.Children()), $CreateDelegate(this, Fuse.Controls.Navigation.prototype.AnimatorDoneCallback, 436), $CreateDelegate(this, Fuse.Controls.Navigation.prototype.ProgressSetterCallback, 480), this._navigationTween);
        };

        I.GoBack = function()
        {
            if (this.CanGoBack())
            {
                this.TransitionTo(this.Previous(), false);
            }
        };

        I.OnTitleChanged = function(newElement)
        {
            var handler = this.TitleChanged;

            if (Uno.Delegate.op_Inequality(handler, null))
            {
                handler.Invoke(this, Fuse.Controls.TitleChangedArgs.New_2($AsOp(newElement, 33658)));
            }
        };

        I.OnNavigated = function(newElement)
        {
            var handler = this.Navigated;

            if (Uno.Delegate.op_Inequality(handler, null))
            {
                handler.Invoke(this, Fuse.Controls.NavigatedArgs.New_2(newElement));
            }
        };

        I.OnChildAdded = function(sender, child)
        {
            if (this._panel.HasChildren() && (this._active == null))
            {
                this._active = child;
            }

            var animator = Fuse.Controls.Internal.DefaultAnimator.New_1(Uno.Collections.EnumerableExtensions.IndexOf__Fuse_Element($DownCast(this._panel.Children(), 32829), child), child);
            animator.Update(this.Progress(), 1);
        };

        I.OnChildRemoved = function(sender, child)
        {
            if (!this._panel.HasChildren())
            {
                this._active = null;
            }

            var animator = Fuse.Controls.Internal.DefaultAnimator.New_1(0, child);
            animator.Update(0.0, 1);
        };

        I.OnUpdate = function(sender, args)
        {
            if (this._currentAnimatorPlayer != null)
            {
                this._currentAnimatorPlayer["Fuse.Controls.Internal.IAnimatorPlayer.Update"]();
            }
        };

        I.EnsureChildAnimationState = function()
        {
            var animators = Fuse.Controls.Internal.DefaultAnimatorFactory.GetAnimators(this._panel.Children());

            for (var i = 0; i < animators["Uno.Collections.ICollection__Fuse_Controls_Internal_IAnimator.Count"](); i++)
            {
                animators["Uno.Collections.IList__Fuse_Controls_Internal_IAnimator.Item"](i)["Fuse.Controls.Internal.IAnimator.Update"](this.Progress(), 1);
            }
        };

        I.AnimatorDoneCallback = function()
        {
            this._currentAnimatorPlayer["Fuse.Controls.Internal.IAnimatorPlayer.EnsureAtEnd"]();
            this.Progress(Uno.Collections.EnumerableExtensions.IndexOf__Fuse_Element($DownCast(this._panel.Children(), 32829), this._active));
            this._currentAnimatorPlayer = null;
            this.OnNavigated(this._active);
            this.OnTitleChanged(this._active);
        };

        I.ProgressSetterCallback = function(newProgress)
        {
            this.Progress(newProgress);
        };

        I.ProgressGetterCallback = function()
        {
            return this.Progress();
        };

        I.BeginSeek = function()
        {
            this._currentAnimatorPlayer = $DownCast(Fuse.Controls.Internal.SeekAnimatorPlayer.New_1(Fuse.Controls.Internal.DefaultAnimatorFactory.GetAnimators(this._panel.Children()), $CreateDelegate(this, Fuse.Controls.Navigation.prototype.ProgressGetterCallback, 498)), 33630);
        };

        I.Seek = function(args)
        {
            this.Progress(this.Progress() + args.Delta());
        };

        I.EndSeek = function(args)
        {
            this._currentAnimatorPlayer = null;
            var targetIndex = 0;

            switch (args.SnapTo())
            {
                case 0:
                {
                    targetIndex = Uno.Math.Clamp_8(Uno.Math.Floor(this.Progress()) | 0, 0, this._panel.Children()["Uno.Collections.ICollection__Fuse_Element.Count"]() - 1);
                    break;
                }
                case 2:
                {
                    targetIndex = Uno.Math.Clamp_8(Uno.Math.Ceil(this.Progress()) | 0, 0, this._panel.Children()["Uno.Collections.ICollection__Fuse_Element.Count"]() - 1);
                    break;
                }
                case 1:
                {
                    var diff = this.Progress() - Uno.Math.Floor(this.Progress());
                    targetIndex = Uno.Math.Clamp_8((diff > 0.5) ? (Uno.Math.Ceil(this.Progress()) | 0) : (Uno.Math.Floor(this.Progress()) | 0), 0, this._panel.Children()["Uno.Collections.ICollection__Fuse_Element.Count"]() - 1);
                    break;
                }
            }

            if (this._active != this._panel.Children()["Uno.Collections.IList__Fuse_Element.Item"](targetIndex))
            {
                var old = this._active;
                this._active = this._panel.Children()["Uno.Collections.IList__Fuse_Element.Item"](targetIndex);
            }

            this.TransitionTo(this._panel.Children()["Uno.Collections.IList__Fuse_Element.Item"](targetIndex), false);
        };

        Fuse.Controls.Navigation.TryFind = function(node)
        {
            if (node == null)
            {
                return null;
            }

            for (var i = 0; i < node.Behaviors()["Uno.Collections.ICollection__Fuse_Behavior.Count"](); i++)
            {
                if ($IsOp(node.Behaviors()["Uno.Collections.IList__Fuse_Behavior.Item"](i), 874))
                {
                    return $DownCast(node.Behaviors()["Uno.Collections.IList__Fuse_Behavior.Item"](i), 874);
                }
            }

            return Fuse.Controls.Navigation.TryFind($AsOp(node.Parent(), 978));
        };

        I.ClearForwardHistory = function()
        {
            if (this._panel.HasChildren() && (this._active != this.Back()))
            {
                var target = Uno.Collections.EnumerableExtensions.IndexOf__Fuse_Element($DownCast(this._panel.Children(), 32829), this._active);

                for (var i = this._panel.Children()["Uno.Collections.ICollection__Fuse_Element.Count"]() - 1; i > Uno.Collections.EnumerableExtensions.IndexOf__Fuse_Element($DownCast(this._panel.Children(), 32829), this._active); i--)
                {
                    this._panel.Children()["Uno.Collections.IList__Fuse_Element.RemoveAt"](i);
                }
            }
        };

        I.add_Navigated = function(value)
        {
            this.Navigated = $DownCast(Uno.Delegate.Combine(this.Navigated, value), 884);
        };

        I.remove_Navigated = function(value)
        {
            this.Navigated = $DownCast(Uno.Delegate.Remove(this.Navigated, value), 884);
        };

        I["Fuse.Controls.INavigationContext.GoBack"] = I.GoBack;
        I["Fuse.Controls.INavigationContext.Goto"] = I.Goto;
        I["Fuse.Controls.INavigationContext.CanGoBack"] = I.CanGoBack;
        I["Fuse.Controls.INavigationContext.add_Navigated"] = I.add_Navigated;
        I["Fuse.Controls.INavigationContext.remove_Navigated"] = I.remove_Navigated;

    });
