Fuse.Controls.Control = $CreateClass(
    function() {
        Fuse.Element.call(this);
        this._appearance = null;
        this._appearanceState = 0;
        this._visualTree = null;
    },
    function(S) {
        var I = S.prototype = new Fuse.Element;

        I.GetType = function()
        {
            return 880;
        };

        I.IsRedrawCheap = function()
        {
            var res = true;

            if (this.Appearance() != null)
            {
                res = res && this.Appearance().IsRedrawCheap();
            }

            if (this.VisualTree() != null)
            {
                res = res && this.VisualTree().IsRedrawCheap();
            }

            return res;
        };

        I.Appearance = function(value)
        {
            if (value !== undefined)
            {
                if ((this._appearanceState == 0) || (this._appearance != value))
                {
                    this._appearanceState = 2;
                    this.SetAppearanceInternal(value);
                }
            }
            else
            {
                return this._appearance;
            }
        };

        I.VisualTree = function(value)
        {
            if (value !== undefined)
            {
                if (this._visualTree != value)
                {
                    if ((this._visualTree != null) && (this._visualTree.Parent() == this))
                    {
                        this._visualTree.OnRemoved($DownCast(this, 33719));
                    }

                    this.SetVisualTree(value);
                }
            }
            else
            {
                return this._visualTree;
            }
        };

        I.IsVisualTreeHitable = function()
        {
            return true;
        };

        I.SubElementCount = function()
        {
            var c = 0;

            if (this.Appearance() != null)
            {
                c++;
            }

            if (this.VisualTree() != null)
            {
                c++;
            }

            return c;
        };

        I.OnResetStyle = function()
        {
            if (this._appearanceState == 1)
            {
                this.ResetAppearance();
            }

            Fuse.Element.prototype.OnResetStyle.call(this);
        };

        I.SetAppearanceInternal = function(elm)
        {
            if (this._appearance != null)
            {
                this._appearance.OnRemoved($DownCast(this, 33719));
            }

            this._appearance = elm;

            if (this._appearance != null)
            {
                this._appearance.OnAdded($DownCast(this, 33719));
            }

            this.OnAppearanceChanged();
        };

        I.OnAppearanceChanged = function()
        {
            this.InvalidateLayout();
            this.InvalidateVisual();
        };

        I.ResetAppearance = function()
        {
            if (this._appearanceState != 0)
            {
                this._appearanceState = 0;
                this.SetAppearanceInternal(null);
            }
        };

        I.SetStyleAppearance = function(appearance)
        {
            if (this._appearanceState == 0)
            {
                this.SetAppearanceInternal(appearance);
                this._appearanceState = 1;
            }
        };

        I.SetVisualTree = function(newVisualTree)
        {
            this._visualTree = newVisualTree;

            if ((this._visualTree != null) && (this._visualTree.Parent() != this))
            {
                this._visualTree.OnAdded($DownCast(this, 33719));
            }

            this.OnVisualTreeChanged();
        };

        I.OnVisualTreeChanged = function()
        {
            this.InvalidateLayout();
        };

        I.CalcRenderBounds = function()
        {
            return this.CalcRenderBounds_1(Fuse.Element.prototype.CalcRenderBounds.call(this));
        };

        I.CalcRenderBounds_1 = function(baseRect)
        {
            var baseRect_123 = new Uno.Rect;
            baseRect_123.op_Assign(baseRect);

            if (this.Appearance() != null)
            {
                baseRect_123.op_Assign(Fuse.Element.ExpandToContain_1(baseRect_123, this.Appearance()));
            }

            if (this.VisualTree() != null)
            {
                baseRect_123.op_Assign(Fuse.Element.ExpandToContain_1(baseRect_123, this.VisualTree()));
            }

            return baseRect_123;
        };

        I.DrawAppearance = function(dc)
        {
            if (this.Appearance() != null)
            {
                this.Appearance().Draw(dc);
            }
        };

        I.OnDraw = function(dc)
        {
            this.DrawAppearance(dc);

            if (this.VisualTree() != null)
            {
                this.VisualTree().Draw(dc);
            }
        };

        I.GetContentSize = function(fillSize, fillSet)
        {
            if (this.VisualTree() != null)
            {
                return this.VisualTree().GetMarginSize(fillSize, fillSet);
            }
            else
            {
                return Fuse.Element.prototype.GetContentSize.call(this, fillSize, fillSet);
            }
        };

        I.ArrangeAppearance = function(finalSize)
        {
            if (this.Appearance() != null)
            {
                this.Appearance().ArrangeMarginBox(Uno.Float2.New_1(0.0), finalSize, 3);
            }
        };

        I.ArrangePaddingBox = function(size)
        {
            var ind_127;
            var ind_128;
            var ind_129;
            this.ArrangeAppearance(size);

            if (this.VisualTree() != null)
            {
                this.VisualTree().ArrangeMarginBox((ind_127 = this.Padding(), Uno.Float2.New_2(ind_127.X, ind_127.Y)), Uno.Float2.op_Subtraction(Uno.Float2.op_Subtraction(size, (ind_128 = this.Padding(), Uno.Float2.New_2(ind_128.X, ind_128.Y))), (ind_129 = this.Padding(), Uno.Float2.New_2(ind_129.Z, ind_129.W))), 3);
            }
        };

        I.OnHitTest = function(htc)
        {
            if (!this.ClipToBounds() || this.IsPointInside(htc.LocalPoint()))
            {
                if (this.IsVisualTreeHitable())
                {
                    if (this.VisualTree() != null)
                    {
                        this.VisualTree().HitTest(htc);
                    }
                }

                if ((this.HitTestMode() != 2) && (this.Appearance() != null))
                {
                    this.Appearance().HitTest(htc);
                }
            }

            Fuse.Element.prototype.OnHitTest.call(this, htc);
        };

        I.GetSubElement = function(index)
        {
            if (index == 0)
            {
                if (this.Appearance() != null)
                {
                    return this.Appearance();
                }
                else if (this.VisualTree() != null)
                {
                    return this.VisualTree();
                }
            }
            else if (index == 1)
            {
                if (this.VisualTree() != null)
                {
                    return this.VisualTree();
                }
            }

            throw new $Error(Uno.Exception.New_2());
        };

        I.OnPointerPressed = function(c)
        {
            var isMouse = c.PointerType() == 1;

            if (Fuse.FocusManager.CanSetFocus($DownCast(this, 33719)) && isMouse)
            {
                this.Focus();
                c.IsHandled(true);
            }

            Fuse.Node.prototype.OnPointerPressed.call(this, c);
        };

        I._ObjInit_2 = function()
        {
            Fuse.Element.prototype._ObjInit_1.call(this);
        };

    });
