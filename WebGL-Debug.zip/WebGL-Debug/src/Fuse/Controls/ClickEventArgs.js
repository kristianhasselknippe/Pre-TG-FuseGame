Fuse.Controls.ClickEventArgs = $CreateClass(
    function() {
        Fuse.InputEventArgs.call(this);
    },
    function(S) {
        var I = S.prototype = new Fuse.InputEventArgs;

        I.GetType = function()
        {
            return 876;
        };

        I._ObjInit_2 = function()
        {
            Fuse.InputEventArgs.prototype._ObjInit_1.call(this);
        };

        Fuse.Controls.ClickEventArgs.New_2 = function()
        {
            var inst = new Fuse.Controls.ClickEventArgs;
            inst._ObjInit_2();
            return inst;
        };

    });
