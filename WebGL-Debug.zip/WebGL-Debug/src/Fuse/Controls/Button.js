Fuse.Controls.Button = $CreateClass(
    function() {
        Fuse.Controls.Panel.call(this);
        this._textState = 0;
        this.Click = null;
    },
    function(S) {
        var I = S.prototype = new Fuse.Controls.Panel;

        I.GetType = function()
        {
            return 878;
        };

        I.OnClick = function(args)
        {
            if (Uno.Delegate.op_Inequality(this.Click, null))
            {
                this.Click.Invoke(this, args);
            }
        };

        I.Tapped = function(sender, args)
        {
            this.OnClick(Fuse.Controls.ClickEventArgs.New_2());
        };

        I.OnRooted = function()
        {
            Fuse.Controls.Panel.prototype.OnRooted.call(this);
            Fuse.Triggers.Tapped.AddSubscriber(this, $CreateDelegate(this, Fuse.Controls.Button.prototype.Tapped, 785));
        };

        I.OnUnrooted = function()
        {
            Fuse.Controls.Panel.prototype.OnUnrooted.call(this);
            Fuse.Triggers.Tapped.RemoveSubscriber(this, $CreateDelegate(this, Fuse.Controls.Button.prototype.Tapped, 785));
        };

        I.GetTextBlock = function(create)
        {
            if ((this.Children()["Uno.Collections.ICollection__Fuse_Element.Count"]() == 0) || ($AsOp(this.Children()["Uno.Collections.IList__Fuse_Element.Item"](0), 838) == null))
            {
                if (create)
                {
                    var tb = Fuse.Elements.TextBlock.New_2();
                    tb.Alignment(8);
                    this.Children()["Uno.Collections.ICollection__Fuse_Element.Clear"]();
                    this.Children()["Uno.Collections.ICollection__Fuse_Element.Add"](tb);
                    return tb;
                }
                else
                {
                    return null;
                }
            }
            else
            {
                return $AsOp(this.Children()["Uno.Collections.IList__Fuse_Element.Item"](0), 838);
            }
        };

        I.SetStyleText = function(text)
        {
            if (this._textState == 0)
            {
                this._textState = 1;
                this.SetTextInternal(text);
            }
        };

        I.SetTextInternal = function(val)
        {
            var tb = this.GetTextBlock(true);

            if (Uno.String.op_Inequality(tb.Text(), val))
            {
                tb.Text(val);
            }
        };

    });
