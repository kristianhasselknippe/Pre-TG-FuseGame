Fuse.Controls.Internal.DefaultAnimatorPlayer = $CreateClass(
    function() {
        this._progressTimer = null;
        this._animators = null;
        this._progressSetCallback = null;
        this._doneCallback = null;
    },
    function(S) {
        var I = S.prototype;

        I.GetType = function()
        {
            return 866;
        };

        I.$II = function(id)
        {
            return [862].indexOf(id) != -1;
        };

        I.Update = function()
        {
            this._progressTimer.Update();
            this._progressSetCallback.Invoke(this._progressTimer.EasedProgress());

            for (var i = 0; i < this._animators["Uno.Collections.ICollection__Fuse_Controls_Internal_IAnimator.Count"](); i++)
            {
                if (this._progressTimer.Variant() == 0)
                {
                    this._animators["Uno.Collections.IList__Fuse_Controls_Internal_IAnimator.Item"](i)["Fuse.Controls.Internal.IAnimator.Update"](this._progressTimer.EasedProgress(), (this._progressTimer.EasedProgress() > i) ? 2 : 1);
                }
                else
                {
                    this._animators["Uno.Collections.IList__Fuse_Controls_Internal_IAnimator.Item"](i)["Fuse.Controls.Internal.IAnimator.Update"](this._progressTimer.EasedProgress(), (this._progressTimer.EasedProgress() > i) ? 1 : 2);
                }
            }

            if (this._progressTimer.TimeLeft() == 0.0)
            {
                this._doneCallback.Invoke();
            }
        };

        I.EnsureAtEnd = function()
        {
            var endProgress = (this._progressTimer.Variant() == 0) ? this._progressTimer.ProgressSpan().To() : this._progressTimer.ProgressSpan().From();

            for (var i = 0; i < this._animators["Uno.Collections.ICollection__Fuse_Controls_Internal_IAnimator.Count"](); i++)
            {
                if (this._progressTimer.Variant() == 0)
                {
                    this._animators["Uno.Collections.IList__Fuse_Controls_Internal_IAnimator.Item"](i)["Fuse.Controls.Internal.IAnimator.Update"](endProgress, (endProgress > i) ? 2 : 1);
                }
                else
                {
                    this._animators["Uno.Collections.IList__Fuse_Controls_Internal_IAnimator.Item"](i)["Fuse.Controls.Internal.IAnimator.Update"](endProgress, (endProgress > i) ? 1 : 2);
                }
            }
        };

        I._ObjInit = function(progressTimer, animators, progressSetCallback, doneCallback)
        {
            this._progressTimer = progressTimer;
            this._animators = animators;
            this._progressSetCallback = progressSetCallback;
            this._doneCallback = doneCallback;
        };

        Fuse.Controls.Internal.DefaultAnimatorPlayer.New_1 = function(progressTimer, animators, progressSetCallback, doneCallback)
        {
            var inst = new Fuse.Controls.Internal.DefaultAnimatorPlayer;
            inst._ObjInit(progressTimer, animators, progressSetCallback, doneCallback);
            return inst;
        };

        I["Fuse.Controls.Internal.IAnimatorPlayer.Update"] = I.Update;
        I["Fuse.Controls.Internal.IAnimatorPlayer.EnsureAtEnd"] = I.EnsureAtEnd;

    });
