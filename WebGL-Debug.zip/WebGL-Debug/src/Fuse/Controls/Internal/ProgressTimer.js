Fuse.Controls.Internal.ProgressTimer = $CreateClass(
    function() {
        this._duration = 0;
        this._progressSpan = null;
        this._easing = 0;
        this._variant = 0;
        this._elapsedTime = 0;
    },
    function(S) {
        var I = S.prototype;

        I.GetType = function()
        {
            return 869;
        };

        I.Variant = function()
        {
            return this._variant;
        };

        I.TimeLeft = function()
        {
            return Uno.Math.Clamp(this._duration - this._elapsedTime, 0.0, this._duration);
        };

        I.EasedNormalizedProgress = function()
        {
            var progress = this.Ease(this._elapsedTime / this._duration);

            if (this._variant == 1)
            {
                progress = 1.0 - progress;
            }

            return progress;
        };

        I.EasedProgress = function()
        {
            return (this.EasedNormalizedProgress() * (this._progressSpan.To() - this._progressSpan.From())) + this._progressSpan.From();
        };

        I.ProgressSpan = function()
        {
            return this._progressSpan;
        };

        Fuse.Controls.Internal.ProgressTimer.Start = function(duration, progressSpan, easing, variant)
        {
            return Fuse.Controls.Internal.ProgressTimer.New_1(duration, progressSpan, easing, variant);
        };

        I.Ease = function(progress)
        {
            return Fuse.Animations.EasingFunctions.FromEasing(this._easing).Invoke(progress);
        };

        I.Update = function()
        {
            this._elapsedTime = this._elapsedTime + Fuse.Time.FrameInterval();
        };

        I._ObjInit = function(duration, progressSpan, easing, variant)
        {
            this._duration = duration;
            this._easing = easing;
            this._variant = variant;
            this._progressSpan = progressSpan;
        };

        Fuse.Controls.Internal.ProgressTimer.New_1 = function(duration, progressSpan, easing, variant)
        {
            var inst = new Fuse.Controls.Internal.ProgressTimer;
            inst._ObjInit(duration, progressSpan, easing, variant);
            return inst;
        };

    });
