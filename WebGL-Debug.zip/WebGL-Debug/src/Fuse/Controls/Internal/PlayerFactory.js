Fuse.Controls.Internal.PlayerFactory = $CreateClass(
    function() {
    },
    function(S) {

        Fuse.Controls.Internal.PlayerFactory.Start = function(targetProgress, startProgress, animators, doneCallback, progressSetterCallback, navigationTween)
        {
            var duration = (targetProgress > startProgress) ? navigationTween.Duration() : navigationTween.DurationBack();
            var easing = (targetProgress > startProgress) ? navigationTween.Easing() : navigationTween.EasingBack();
            var playDirection = (targetProgress > startProgress) ? 0 : 1;
            var actualStartProgress = (playDirection == 0) ? startProgress : targetProgress;
            var actualTargetProgress = (playDirection == 0) ? targetProgress : startProgress;
            var progressSpan = Fuse.Controls.Internal.ProgressSpan.New_1(actualStartProgress, actualTargetProgress);
            var progressTimer = Fuse.Controls.Internal.ProgressTimer.Start(duration, progressSpan, easing, playDirection);
            return $DownCast(Fuse.Controls.Internal.DefaultAnimatorPlayer.New_1(progressTimer, animators, progressSetterCallback, doneCallback), 33630);
        };

    });
