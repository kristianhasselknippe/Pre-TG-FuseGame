Fuse.Controls.Internal.DefaultAnimator = $CreateClass(
    function() {
        this._index = 0;
        this._element = null;
    },
    function(S) {
        var I = S.prototype;

        I.GetType = function()
        {
            return 863;
        };

        I.$II = function(id)
        {
            return [861].indexOf(id) != -1;
        };

        I.Update = function(progress, direction)
        {
            this._element.NotifyActivationState(Fuse.ActivationState.New_1(progress - this._index, direction));
        };

        I._ObjInit = function(index, element)
        {
            this._index = index;
            this._element = element;
        };

        Fuse.Controls.Internal.DefaultAnimator.New_1 = function(index, element)
        {
            var inst = new Fuse.Controls.Internal.DefaultAnimator;
            inst._ObjInit(index, element);
            return inst;
        };

        I["Fuse.Controls.Internal.IAnimator.Update"] = I.Update;

    });
