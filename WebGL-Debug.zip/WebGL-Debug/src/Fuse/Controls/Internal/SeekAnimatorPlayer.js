Fuse.Controls.Internal.SeekAnimatorPlayer = $CreateClass(
    function() {
        this._animators = null;
        this._getProgress = null;
        this._prevProgress = 0;
    },
    function(S) {
        var I = S.prototype;

        I.GetType = function()
        {
            return 867;
        };

        I.$II = function(id)
        {
            return [862].indexOf(id) != -1;
        };

        I.Update = function()
        {
            var progress = this._getProgress.Invoke();
            var deltaProgress = this._prevProgress - progress;
            var playDirection = (deltaProgress > 0.0) ? 0 : 1;

            for (var i = 0; i < this._animators["Uno.Collections.ICollection__Fuse_Controls_Internal_IAnimator.Count"](); ++i)
            {
                if (playDirection == 0)
                {
                    this._animators["Uno.Collections.IList__Fuse_Controls_Internal_IAnimator.Item"](i)["Fuse.Controls.Internal.IAnimator.Update"](progress, (progress > i) ? 2 : 1);
                }
                else
                {
                    this._animators["Uno.Collections.IList__Fuse_Controls_Internal_IAnimator.Item"](i)["Fuse.Controls.Internal.IAnimator.Update"](progress, (progress > i) ? 1 : 2);
                }
            }
        };

        I.EnsureAtEnd = function()
        {
            throw new $Error(Uno.NotImplementedException.New_3());
        };

        I._ObjInit = function(animators, getProgress)
        {
            this._animators = animators;
            this._getProgress = getProgress;
            this._prevProgress = this._getProgress.Invoke();
        };

        Fuse.Controls.Internal.SeekAnimatorPlayer.New_1 = function(animators, getProgress)
        {
            var inst = new Fuse.Controls.Internal.SeekAnimatorPlayer;
            inst._ObjInit(animators, getProgress);
            return inst;
        };

        I["Fuse.Controls.Internal.IAnimatorPlayer.Update"] = I.Update;
        I["Fuse.Controls.Internal.IAnimatorPlayer.EnsureAtEnd"] = I.EnsureAtEnd;

    });
