Fuse.Controls.Internal.DefaultAnimatorFactory = $CreateClass(
    function() {
    },
    function(S) {

        Fuse.Controls.Internal.DefaultAnimatorFactory.GetAnimators = function(elements)
        {
            var animators = Uno.Collections.List__Fuse_Controls_Internal_IAnimator.New_2(elements["Uno.Collections.ICollection__Fuse_Element.Count"]());

            for (var i = 0; i < elements["Uno.Collections.ICollection__Fuse_Element.Count"](); i++)
            {
                animators.Add($DownCast(Fuse.Controls.Internal.DefaultAnimator.New_1(i, elements["Uno.Collections.IList__Fuse_Element.Item"](i)), 33629));
            }

            return $DownCast(animators, 32924);
        };

    });
