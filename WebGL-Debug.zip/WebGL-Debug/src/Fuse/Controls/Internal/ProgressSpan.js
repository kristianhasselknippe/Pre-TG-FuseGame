Fuse.Controls.Internal.ProgressSpan = $CreateClass(
    function() {
        this._From = 0;
        this._To = 0;
    },
    function(S) {
        var I = S.prototype;

        I.GetType = function()
        {
            return 868;
        };

        I.From = function(value)
        {
            if (value !== undefined)
            {
                this._From = value;
            }
            else
            {
                return this._From;
            }
        };

        I.To = function(value)
        {
            if (value !== undefined)
            {
                this._To = value;
            }
            else
            {
                return this._To;
            }
        };

        I._ObjInit = function(from, to)
        {
            this.From(from);
            this.To(to);
        };

        Fuse.Controls.Internal.ProgressSpan.New_1 = function(from, to)
        {
            var inst = new Fuse.Controls.Internal.ProgressSpan;
            inst._ObjInit(from, to);
            return inst;
        };

    });
