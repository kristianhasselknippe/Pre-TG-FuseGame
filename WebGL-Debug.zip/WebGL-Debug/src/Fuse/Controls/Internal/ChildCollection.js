Fuse.Controls.Internal.ChildCollection = $CreateClass(
    function() {
        this._children = null;
        this._zOrder = null;
        this._owner = null;
    },
    function(S) {
        var I = S.prototype;

        I.GetType = function()
        {
            return 860;
        };

        I.$II = function(id)
        {
            return [145, 126, 61].indexOf(id) != -1;
        };

        I.Children = function()
        {
            if (this._children == null)
            {
                this._children = $DownCast(Uno.Collections.List__Fuse_Element.New_1(), 32913);
            }

            return this._children;
        };

        I.Count = function()
        {
            return this.Children()["Uno.Collections.ICollection__Fuse_Element.Count"]();
        };

        I.Item = function(index)
        {
            return this.Children()["Uno.Collections.IList__Fuse_Element.Item"](index);
        };

        I.HasZOrder = function()
        {
            return this._zOrder != null;
        };

        I.GetEnumerator = function()
        {
            return this.Children()["Uno.Collections.IEnumerable__Fuse_Element.GetEnumerator"]();
        };

        I.Clear = function()
        {
            for (var i = this.Children()["Uno.Collections.ICollection__Fuse_Element.Count"](); (i--) > 0; )
            {
                var child = this.Children()["Uno.Collections.IList__Fuse_Element.Item"](i);
                this.Children()["Uno.Collections.IList__Fuse_Element.RemoveAt"](i);

                if (this._zOrder != null)
                {
                    this._zOrder.RemoveAt(i);
                }

                this.RemoveChild(child);
            }
        };

        I.Add = function(item)
        {
            this.Children()["Uno.Collections.ICollection__Fuse_Element.Add"](item);

            if (this._zOrder != null)
            {
                this._zOrder.Add(item);
            }

            this.AddChild(item);
        };

        I.Remove = function(item)
        {
            var wasRemoved = this.Children()["Uno.Collections.ICollection__Fuse_Element.Remove"](item);

            if (wasRemoved)
            {
                if (this._zOrder != null)
                {
                    this._zOrder.Remove(item);
                }

                this.RemoveChild(item);
            }

            return wasRemoved;
        };

        I.AddChild = function(child)
        {
            $DownCast(child, 33719)["Fuse.INode.OnAdded"]($DownCast(this._owner, 33719));
            this._owner["Fuse.Controls.Internal.IParentElement.OnChildAdded"](child);
        };

        I.RemoveChild = function(child)
        {
            this._owner["Fuse.Controls.Internal.IParentElement.OnChildRemoved"](child);
            $DownCast(child, 33719)["Fuse.INode.OnRemoved"]($DownCast(this._owner, 33719));
        };

        I.Contains = function(item)
        {
            return this.Children()["Uno.Collections.ICollection__Fuse_Element.Contains"](item);
        };

        I.RemoveAt = function(index)
        {
            var child = this.Children()["Uno.Collections.IList__Fuse_Element.Item"](index);

            if (this._zOrder != null)
            {
                this._zOrder.Remove(child);
            }

            this.Children()["Uno.Collections.IList__Fuse_Element.RemoveAt"](index);
            this.RemoveChild(child);
        };

        I.GetZOrderChild = function(index)
        {
            if (this._zOrder != null)
            {
                return this._zOrder.Item(index);
            }

            return this.Children()["Uno.Collections.IList__Fuse_Element.Item"](index);
        };

        I._ObjInit = function(owner)
        {
            this._owner = owner;
        };

        Fuse.Controls.Internal.ChildCollection.New_1 = function(owner)
        {
            var inst = new Fuse.Controls.Internal.ChildCollection;
            inst._ObjInit(owner);
            return inst;
        };

        I["Uno.Collections.IList__Fuse_Element.RemoveAt"] = I.RemoveAt;
        I["Uno.Collections.IList__Fuse_Element.Item"] = I.Item;
        I["Uno.Collections.ICollection__Fuse_Element.Clear"] = I.Clear;
        I["Uno.Collections.ICollection__Fuse_Element.Add"] = I.Add;
        I["Uno.Collections.ICollection__Fuse_Element.Remove"] = I.Remove;
        I["Uno.Collections.ICollection__Fuse_Element.Contains"] = I.Contains;
        I["Uno.Collections.ICollection__Fuse_Element.Count"] = I.Count;
        I["Uno.Collections.IEnumerable__Fuse_Element.GetEnumerator"] = I.GetEnumerator;

    });
