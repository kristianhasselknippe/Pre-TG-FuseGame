Fuse.Controls.ScrollViewer = $CreateClass(
    function() {
        Fuse.Controls.Control.call(this);
        this.allowedScrollDirections = 0;
        this._scrollTranslation = null;
        this.scrollPos = new Uno.Float2;
        this._autoAdjustScrollRange = false;
        this._cacheContentMarginSize = new Uno.Float2;
        this.ScrollPositionChanged = null;
    },
    function(S) {
        var I = S.prototype = new Fuse.Controls.Control;

        I.GetType = function()
        {
            return 893;
        };

        I.Content = function(value)
        {
            if (value !== undefined)
            {
                this.OnContentChanged(this.VisualTree(), value);
                this.VisualTree(value);
            }
            else
            {
                return this.VisualTree();
            }
        };

        I.AllowedScrollDirections = function(value)
        {
            if (value !== undefined)
            {
                if (value != this.allowedScrollDirections)
                {
                    this.allowedScrollDirections = value;
                    this.InvalidateLayout();
                }
            }
            else
            {
                return this.allowedScrollDirections;
            }
        };

        I.ScrollPosition = function(value)
        {
            if (value !== undefined)
            {
                var oldScrollPos_126 = new Uno.Float2;
                oldScrollPos_126.op_Assign(this.scrollPos);
                this.scrollPos.op_Assign(value);

                if (!((this.AllowedScrollDirections() & 1) == 1))
                {
                    this.scrollPos.X = 0.0;
                }

                if (!((this.AllowedScrollDirections() & 2) == 2))
                {
                    this.scrollPos.Y = 0.0;
                }

                if (Uno.Vector.Distance(this.scrollPos, oldScrollPos_126) > 1e-05)
                {
                    this.InvalidateVisual();
                    this._scrollTranslation.Vector(Uno.Float3.New_2(-Uno.Math.Round_1(this.scrollPos.X * this.AbsoluteZoom()) / this.AbsoluteZoom(), -Uno.Math.Round_1(this.scrollPos.Y * this.AbsoluteZoom()) / this.AbsoluteZoom(), 0.0));
                    this.OnScrollPositionChanged();
                }
            }
            else
            {
                return this.scrollPos;
            }
        };

        I.AutoAdjustScrollRange = function(value)
        {
            if (value !== undefined)
            {
                this._autoAdjustScrollRange = value;
            }
            else
            {
                return this._autoAdjustScrollRange;
            }
        };

        I.MaxScroll = function()
        {
            var ind_132;
            var ind_133;

            if (this.Content() == null)
            {
                return Uno.Float2.New_1(0.0);
            }

            var keyboardCompensation = (Fuse.Environment.IsOnscreenKeyboardVisible() && this.AutoAdjustScrollRange()) ? Fuse.Environment.OnscreenKeyboardSize().Y : 0.0;
            return Uno.Math.Max_3(Uno.Float2.op_Addition(Uno.Float2.op_Subtraction(Uno.Float2.op_Addition(Uno.Float2.op_Addition(Uno.Float2.op_Addition(this._cacheContentMarginSize, this.Content().ActualPosition()), (ind_132 = this.Padding(), Uno.Float2.New_2(ind_132.X, ind_132.Y))), (ind_133 = this.Padding(), Uno.Float2.New_2(ind_133.Z, ind_133.W))), this.ActualSize()), Uno.Float2.New_2(0.0, keyboardCompensation)), Uno.Float2.New_1(0.0));
        };

        I.MinScroll = function()
        {
            var ind_134;

            if (this.Content() == null)
            {
                return Uno.Float2.New_1(0.0);
            }

            return Uno.Math.Min_3(Uno.Float2.New_1(0.0), Uno.Float2.op_Subtraction(this.Content().ActualPosition(), (ind_134 = this.Padding(), Uno.Float2.New_2(ind_134.X, ind_134.Y))));
        };

        I.RaiseHandledEvents = function()
        {
            return true;
        };

        I.OnContentChanged = function(oldContent, newContent)
        {
            if (oldContent != null)
            {
                oldContent.Transforms()["Uno.Collections.ICollection__Fuse_Transform.Remove"](this._scrollTranslation);
            }

            if (newContent != null)
            {
                newContent.Transforms()["Uno.Collections.ICollection__Fuse_Transform.Add"](this._scrollTranslation);
            }
        };

        I.OnScrollPositionChanged = function()
        {
            var handler = this.ScrollPositionChanged;

            if (Uno.Delegate.op_Inequality(handler, null))
            {
                handler.Invoke(this, Uno.EventArgs.Empty);
            }
        };

        I.ArrangePaddingBox = function(size)
        {
            var size_123 = new Uno.Float2;
            var ind_127;
            var ind_128;
            var ind_129;
            size_123.op_Assign(size);
            Fuse.Controls.Control.prototype.ArrangePaddingBox.call(this, size_123);

            if (this.Content() == null)
            {
                this._cacheContentMarginSize = Uno.Float2.New_1(0.0);
            }
            else
            {
                size_123 = Uno.Float2.op_Subtraction(size_123, Uno.Float2.op_Addition((ind_127 = this.Padding(), Uno.Float2.New_2(ind_127.X, ind_127.Y)), (ind_128 = this.Padding(), Uno.Float2.New_2(ind_128.Z, ind_128.W))));
                this._cacheContentMarginSize.op_Assign(this.Content().ArrangeMarginBox((ind_129 = this.Padding(), Uno.Float2.New_2(ind_129.X, ind_129.Y)), size_123, 3));
            }
        };

        I.GetContentSize = function(fillSize, fillSet)
        {
            var fillSize_124 = new Uno.Float2;
            var ind_130;
            var ind_131;
            fillSize_124.op_Assign(fillSize);

            if (this.Content() != null)
            {
                fillSize_124 = Uno.Float2.op_Subtraction(fillSize_124, Uno.Float2.op_Addition((ind_130 = this.Padding(), Uno.Float2.New_2(ind_130.X, ind_130.Y)), (ind_131 = this.Padding(), Uno.Float2.New_2(ind_131.Z, ind_131.W))));
                return this.Content().GetMarginSize(fillSize_124, fillSet);
            }

            return Uno.Float2.New_1(0.0);
        };

        I.OnHitTest = function(htc)
        {
            Fuse.Controls.Control.prototype.OnHitTest.call(this, htc);

            if (this.IsPointInside(htc.LocalPoint()))
            {
                htc.Hit($DownCast(this, 33719));
            }
        };

        I.OnApplyStyle = function(target)
        {
            Fuse.Node.prototype.OnApplyStyle.call(this, target);
            var elm = this.Content();

            if (target != elm)
            {
                return;
            }

            if (elm.HasAlignment())
            {
                return;
            }

            var align = 0;
            var setWidth = false;
            var setHeight = false;

            if (this.AllowedScrollDirections() == 3)
            {
                align = 5;
                setWidth = true;
                setHeight = true;
            }
            else if (this.AllowedScrollDirections() == 1)
            {
                align = 1;
                setWidth = true;
            }
            else if (this.AllowedScrollDirections() == 2)
            {
                align = 4;
                setHeight = true;
            }

            var setAlign = false;

            if ((setWidth && !elm.HasWidth()) && !elm.HasMinWidth())
            {
                elm.SetStyleMinWidth_1(100.0, 1);
                setAlign = true;
            }

            if ((setHeight && !elm.HasHeight()) && !elm.HasMinHeight())
            {
                elm.SetStyleMinHeight_1(100.0, 1);
                setAlign = true;
            }

            if (setAlign)
            {
                elm.SetStyleAlignment(align);
            }
        };

        I.add_ScrollPositionChanged = function(value)
        {
            this.ScrollPositionChanged = $DownCast(Uno.Delegate.Combine(this.ScrollPositionChanged, value), 445);
        };

        I.remove_ScrollPositionChanged = function(value)
        {
            this.ScrollPositionChanged = $DownCast(Uno.Delegate.Remove(this.ScrollPositionChanged, value), 445);
        };

    });
