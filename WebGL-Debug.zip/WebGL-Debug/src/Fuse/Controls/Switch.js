Fuse.Controls.Switch = $CreateClass(
    function() {
        Fuse.Controls.Control.call(this);
        this._toggled = false;
        this._hasToggled = false;
        this.ToggledChanged = null;
    },
    function(S) {
        var I = S.prototype = new Fuse.Controls.Control;

        I.GetType = function()
        {
            return 897;
        };

        I.Toggled = function(value)
        {
            if (value !== undefined)
            {
                if (!this._hasToggled || (this._toggled != value))
                {
                    this._toggled = value;
                    this._hasToggled = true;
                    this.OnToggledChanged();
                }
            }
            else
            {
                return this._toggled;
            }
        };

        I.OnToggledChanged = function()
        {
            if (Uno.Delegate.op_Inequality(this.ToggledChanged, null))
            {
                this.ToggledChanged.Invoke(this, Uno.EventArgs.Empty);
            }
        };

        I.add_ToggledChanged = function(value)
        {
            this.ToggledChanged = $DownCast(Uno.Delegate.Combine(this.ToggledChanged, value), 445);
        };

        I.remove_ToggledChanged = function(value)
        {
            this.ToggledChanged = $DownCast(Uno.Delegate.Remove(this.ToggledChanged, value), 445);
        };

    });
