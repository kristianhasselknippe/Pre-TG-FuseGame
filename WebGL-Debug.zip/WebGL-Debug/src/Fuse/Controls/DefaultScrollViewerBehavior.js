Fuse.Controls.DefaultScrollViewerBehavior = $CreateClass(
    function() {
        Fuse.Behavior.call(this);
        this._moveMode = 0;
        this._elm = null;
        this._down = 0;
        this._pointerPos = new Uno.Float2;
        this._prevPos = new Uno.Float2;
        this._velocity = new Uno.Float2;
        this._startPos = new Uno.Float2;
        this._desiredScrollPos = new Uno.Float2;
        this._destination = new Uno.Float2;
        this._destinationFrom = new Uno.Float2;
        this._destinationTime = 0;
        this._softCaptureStart = new Uno.Float2;
        this._softCaptureCurrent = new Uno.Float2;
        this._horizontalGesture = null;
        this._verticalGesture = null;
        this._pendingBringIntoView = null;
    },
    function(S) {
        var I = S.prototype = new Fuse.Behavior;

        Fuse.Controls.DefaultScrollViewerBehavior.staticFrictionSpeed = 0;
        Fuse.Controls.DefaultScrollViewerBehavior.kineticDeceleration = 0;
        Fuse.Controls.DefaultScrollViewerBehavior.lowFluidDeceleration = 0;
        Fuse.Controls.DefaultScrollViewerBehavior.highFluidDeceleration = 0;
        Fuse.Controls.DefaultScrollViewerBehavior.snapDeceleration = 0;
        Fuse.Controls.DefaultScrollViewerBehavior.snapSpeedExp = 0;
        Fuse.Controls.DefaultScrollViewerBehavior.snapSpeedMin = 0;
        Fuse.Controls.DefaultScrollViewerBehavior.snapSpeedFactor = 0;
        Fuse.Controls.DefaultScrollViewerBehavior.elasticDecay = 0;
        Fuse.Controls.DefaultScrollViewerBehavior.arrivalTime = 0;

        I.GetType = function()
        {
            return 894;
        };

        I.ScrollViewer = function()
        {
            return this._elm;
        };

        I.IsActive = function()
        {
            for (var i = 0; i < this.ScrollViewer().Behaviors()["Uno.Collections.ICollection__Fuse_Behavior.Count"](); i++)
            {
                if (this.ScrollViewer().Behaviors()["Uno.Collections.IList__Fuse_Behavior.Item"](i).OverridesDefault())
                {
                    return false;
                }
            }

            return true;
        };

        I.OnRooted = function(elm)
        {
            this._elm = $AsOp(elm, 893);

            if (this.ScrollViewer() != null)
            {
                this.ScrollViewer().add_PointerPressed($CreateDelegate(this, Fuse.Controls.DefaultScrollViewerBehavior.prototype.OnPointerPressed, 924));
                this.ScrollViewer().add_PointerMoved($CreateDelegate(this, Fuse.Controls.DefaultScrollViewerBehavior.prototype.OnPointerMoved, 926));
                this.ScrollViewer().add_PointerReleased($CreateDelegate(this, Fuse.Controls.DefaultScrollViewerBehavior.prototype.OnPointerReleased, 928));
                this.ScrollViewer().add_ManipulationCancelled($CreateDelegate(this, Fuse.Controls.DefaultScrollViewerBehavior.prototype.OnManipulationCancelled, 445));
                this.ScrollViewer().add_Update($CreateDelegate(this, Fuse.Controls.DefaultScrollViewerBehavior.prototype.OnUpdated, 445));
                this.ScrollViewer().add_RequestBringIntoView($CreateDelegate(this, Fuse.Controls.DefaultScrollViewerBehavior.prototype.OnRequestBringIntoView, 1000));
                this.ScrollViewer().add_LostSoftCapture($CreateDelegate(this, Fuse.Controls.DefaultScrollViewerBehavior.prototype.OnLostSoftCapture, 939));
            }
        };

        I.OnUnrooted = function(elm)
        {
            if (this.ScrollViewer() != null)
            {
                this.ScrollViewer().remove_PointerPressed($CreateDelegate(this, Fuse.Controls.DefaultScrollViewerBehavior.prototype.OnPointerPressed, 924));
                this.ScrollViewer().remove_PointerMoved($CreateDelegate(this, Fuse.Controls.DefaultScrollViewerBehavior.prototype.OnPointerMoved, 926));
                this.ScrollViewer().remove_PointerReleased($CreateDelegate(this, Fuse.Controls.DefaultScrollViewerBehavior.prototype.OnPointerReleased, 928));
                this.ScrollViewer().remove_ManipulationCancelled($CreateDelegate(this, Fuse.Controls.DefaultScrollViewerBehavior.prototype.OnManipulationCancelled, 445));
                this.ScrollViewer().remove_Update($CreateDelegate(this, Fuse.Controls.DefaultScrollViewerBehavior.prototype.OnUpdated, 445));
                this.ScrollViewer().remove_RequestBringIntoView($CreateDelegate(this, Fuse.Controls.DefaultScrollViewerBehavior.prototype.OnRequestBringIntoView, 1000));
                this.ScrollViewer().remove_LostSoftCapture($CreateDelegate(this, Fuse.Controls.DefaultScrollViewerBehavior.prototype.OnLostSoftCapture, 939));
            }

            this._elm = null;
        };

        I.OnPointerPressed = function(sender, args)
        {
            if (!this.IsActive())
            {
                return;
            }

            if (this._down == -1)
            {
                if ((this._moveMode == 2) && (Uno.Vector.Length(this._velocity) > 100.0))
                {
                    args.HardCapturePointer($DownCast(this.ScrollViewer(), 33719));
                }
                else
                {
                    args.SoftCapturePointer($DownCast(this.ScrollViewer(), 33719));
                }

                this._softCaptureStart.op_Assign((this._softCaptureCurrent.op_Assign(args.PointCoord()), this._softCaptureCurrent));
                this._moveMode = 1;
                this._down = args.PointIndex();
                this._pointerPos = Uno.Float2.op_Division_1(args.PointCoord(), this._elm.AbsoluteZoom());
                this._prevPos.op_Assign((this._startPos.op_Assign(this._pointerPos), this._startPos));
                this._desiredScrollPos.op_Assign(this.ScrollViewer().ScrollPosition());
            }
        };

        I.OnLostSoftCapture = function(sender, args)
        {
            this._down = -1;
            this._moveMode = 3;
        };

        I.OnManipulationCancelled = function(sender, args)
        {
            if (!this.IsActive())
            {
                return;
            }

            this._desiredScrollPos.op_Assign(this.ScrollViewer().ScrollPosition());
            this._moveMode = 0;
            this._down = -1;
        };

        I.HardCapture = function(args)
        {
            if (!args.IsPointerHardCaptured())
            {
                args.HardCapturePointer($DownCast(this.ScrollViewer(), 33719));
            }
        };

        I.OnPointerMoved = function(sender, args)
        {
            if (!this.IsActive())
            {
                return;
            }

            if (args.IsSoftCapturedTo($DownCast(this.ScrollViewer(), 33719)))
            {
                this._softCaptureCurrent.op_Assign(args.PointCoord());
                var diff = Uno.Float2.op_Subtraction(this._softCaptureCurrent, this._softCaptureStart);

                if (this.ScrollViewer().AllowedScrollDirections() == 3)
                {
                    if (Uno.Vector.Length(diff) > 10.0)
                    {
                        this.HardCapture(args);
                    }
                }

                if (this.ScrollViewer().AllowedScrollDirections() == 1)
                {
                    if (this._horizontalGesture.IsWithinBounds(diff))
                    {
                        this.HardCapture(args);
                    }
                }

                if (this.ScrollViewer().AllowedScrollDirections() == 2)
                {
                    if (this._verticalGesture.IsWithinBounds(diff))
                    {
                        this.HardCapture(args);
                    }
                }
            }

            if (this._down != args.PointIndex())
            {
                return;
            }

            if (!Fuse.Input.IsPointerPressed_1(this._down))
            {
                this._down = -1;
                return;
            }

            this._pointerPos = Uno.Float2.op_Division_1(args.PointCoord(), this._elm.AbsoluteZoom());
        };

        I.OnPointerReleased = function(sender, args)
        {
            if (!this.IsActive())
            {
                return;
            }

            if (args.IsSoftCapturedTo($DownCast(this.ScrollViewer(), 33719)))
            {
                args.ReleaseSoftCapture($DownCast(this.ScrollViewer(), 33719));
            }

            if (this._down == args.PointIndex())
            {
                if (args.IsPointerHardCaptured())
                {
                    args.ReleaseHardCapture();
                }

                this._down = -1;
                this._moveMode = 2;
            }
        };

        I.OnRequestBringIntoView = function(sender, args)
        {
            if (!this.IsActive())
            {
                return;
            }

            this._pendingBringIntoView = args.Element();
            Fuse.UpdateManager.PerformNextFrame($CreateDelegate(this, Fuse.Controls.DefaultScrollViewerBehavior.prototype.PerformBringIntoView, 436), 0);
        };

        I.PerformBringIntoView = function()
        {
            if (this._pendingBringIntoView == null)
            {
                return;
            }

            this._destination = Uno.Math.Min_3(this.ScrollViewer().MaxScroll(), this._pendingBringIntoView.LocalToParent(Uno.Float2.New_1(0.0)));
            this._destinationFrom.op_Assign(this._desiredScrollPos);
            this._destinationTime = Fuse.Time.FrameTime();
            this._moveMode = 4;
            this._pendingBringIntoView = null;
        };

        I.OnUpdated = function(sender, args)
        {
            if (!this.IsActive())
            {
                return;
            }

            switch (this._moveMode)
            {
                case 0:
                {
                    return;
                }
                case 1:
                {
                    this.MoveUser();
                    break;
                }
                case 2:
                {
                    this.MoveFriction();
                    break;
                }
                case 3:
                {
                    this.MoveSnap(true);
                    break;
                }
                case 4:
                {
                    this.MoveDestination();
                    break;
                }
            }

            this.UpdateScrollPosition();
        };

        I.MoveUser = function()
        {
            var diff = Uno.Float2.op_UnaryNegation(Uno.Float2.op_Subtraction(this._pointerPos, this._prevPos));
            this._desiredScrollPos = Uno.Float2.op_Addition(this._desiredScrollPos, diff);
            this._prevPos.op_Assign(this._pointerPos);
            this._velocity = Uno.Float2.op_Addition(Uno.Float2.op_Multiply(this._velocity, 0.5), Uno.Float2.op_Multiply(Uno.Float2.op_Division_1(diff, Fuse.Time.FrameInterval()), 0.5));
        };

        I.MoveFriction = function()
        {
            this._desiredScrollPos = Uno.Float2.op_Addition(this._desiredScrollPos, Uno.Float2.op_Multiply(this._velocity, Fuse.Time.FrameInterval()));
            var over = this.CalcOver(this._desiredScrollPos);
            var linear = Uno.Vector.Length(this._velocity);

            if (linear < Fuse.Controls.DefaultScrollViewerBehavior.staticFrictionSpeed)
            {
                this._moveMode = 3;
                return;
            }

            var fluid = Fuse.Controls.DefaultScrollViewerBehavior.kineticDeceleration + (linear * Fuse.Controls.DefaultScrollViewerBehavior.lowFluidDeceleration);
            linear = linear + (-fluid * Fuse.Time.FrameInterval());

            if (linear < Fuse.Controls.DefaultScrollViewerBehavior.staticFrictionSpeed)
            {
                this._moveMode = 3;
                return;
            }

            this._velocity = Uno.Float2.op_Multiply(Uno.Vector.Normalize(this._velocity), linear);
            var snap = Uno.Float2.op_Multiply(Uno.Float2.op_Multiply(Uno.Float2.op_Multiply_1(over, over), Fuse.Controls.DefaultScrollViewerBehavior.snapDeceleration), Fuse.Time.FrameInterval());
            var axial = Uno.Float2.op_Subtraction(Uno.Math.Abs_2(this._velocity), snap);
            axial = Uno.Math.Max_3(Uno.Float2.New_1(0.0), axial);
            this._velocity = Uno.Float2.op_Multiply_1(axial, Uno.Math.Sign_2(this._velocity));
            this.MoveSnap(false);
        };

        I.MoveSnap = function(proper)
        {
            var over = this.CalcOver(this._desiredScrollPos);
            var off = Uno.Vector.Length(over);
            var speed = Fuse.Controls.DefaultScrollViewerBehavior.snapSpeedFactor * Uno.Math.Max_1(Fuse.Controls.DefaultScrollViewerBehavior.snapSpeedMin, Uno.Math.Pow_1(off, Fuse.Controls.DefaultScrollViewerBehavior.snapSpeedExp));
            var dps = Uno.Float2.op_Multiply(Uno.Float2.op_Multiply(Uno.Vector.Normalize(over), speed), Fuse.Time.FrameInterval());

            if (Uno.Math.Abs_1(dps.X) > Uno.Math.Abs_1(over.X))
            {
                dps.X = over.X;
            }

            if (Uno.Math.Abs_1(dps.Y) > Uno.Math.Abs_1(over.Y))
            {
                dps.Y = over.Y;
            }

            var dp = Uno.Float2.op_Subtraction(this._desiredScrollPos, (off < 0.5) ? over : dps);

            if (proper)
            {
                this._desiredScrollPos.op_Assign(dp);

                if ((off < 0.5) && proper)
                {
                    this._moveMode = 0;
                    return;
                }
            }
            else
            {
                if (this._velocity.X == 0.0)
                {
                    this._desiredScrollPos.X = dp.X;
                }

                if (this._velocity.Y == 0.0)
                {
                    this._desiredScrollPos.Y = dp.Y;
                }
            }
        };

        I.MoveDestination = function()
        {
            var p = ((Fuse.Time.FrameTime() - this._destinationTime) / Fuse.Controls.DefaultScrollViewerBehavior.arrivalTime);

            if (p >= 1.0)
            {
                this._desiredScrollPos.op_Assign(this._destination);
                this._moveMode = 0;
                return;
            }

            var v = Uno.Float2.op_Subtraction(this._destination, this._destinationFrom);
            this._desiredScrollPos = Uno.Float2.op_Addition(this._destinationFrom, Uno.Float2.op_Multiply(v, Fuse.Animations.EasingFunctions.QuadraticInOut(p)));
        };

        I.UpdateScrollPosition = function()
        {
            var sp_123 = new Uno.Float2;
            sp_123.op_Assign(this._desiredScrollPos);
            var over = this.CalcOver(sp_123);

            if ((Uno.Math.Abs_1(over.X) + Uno.Math.Abs_1(over.Y)) > 1e-05)
            {
                sp_123 = Uno.Float2.op_Subtraction(sp_123, over);
                sp_123 = Uno.Float2.op_Addition(sp_123, Uno.Float2.op_Multiply(Uno.Vector.Normalize(over), this.ElasticDistance(Uno.Vector.Length(over))));
            }

            this.ScrollViewer().ScrollPosition(sp_123);
        };

        I.CalcOver = function(sp)
        {
            var sp_124 = new Uno.Float2;
            var min_125 = new Uno.Float2;
            var max_126 = new Uno.Float2;
            sp_124.op_Assign(sp);
            min_125.op_Assign(this.ScrollViewer().MinScroll());
            max_126.op_Assign(this.ScrollViewer().MaxScroll());
            var over = Uno.Float2.New_1(0.0);

            if (sp_124.X < min_125.X)
            {
                over.X = sp_124.X - min_125.X;
            }
            else if (sp_124.X > max_126.X)
            {
                over.X = sp_124.X - max_126.X;
            }

            if (sp_124.Y < min_125.Y)
            {
                over.Y = sp_124.Y - min_125.Y;
            }
            else if (sp_124.Y > max_126.Y)
            {
                over.Y = sp_124.Y - max_126.Y;
            }

            return over;
        };

        I.ElasticDistance = function(v)
        {
            var neg = false;

            if (v < 0.0)
            {
                v = -v;
                neg = true;
            }

            v = (Uno.Math.Pow_1(Fuse.Controls.DefaultScrollViewerBehavior.elasticDecay, v) - 1.0) / Uno.Math.Log_1(Fuse.Controls.DefaultScrollViewerBehavior.elasticDecay);

            if (neg)
            {
                v = -v;
            }

            return v;
        };

        Fuse.Controls.DefaultScrollViewerBehavior._TypeInit = function()
        {
            Fuse.Controls.DefaultScrollViewerBehavior.staticFrictionSpeed = 25.0;
            Fuse.Controls.DefaultScrollViewerBehavior.kineticDeceleration = 60.0;
            Fuse.Controls.DefaultScrollViewerBehavior.lowFluidDeceleration = 1.5;
            Fuse.Controls.DefaultScrollViewerBehavior.highFluidDeceleration = 0.002;
            Fuse.Controls.DefaultScrollViewerBehavior.snapDeceleration = 1.0;
            Fuse.Controls.DefaultScrollViewerBehavior.snapSpeedExp = 1.4;
            Fuse.Controls.DefaultScrollViewerBehavior.snapSpeedMin = 6.0;
            Fuse.Controls.DefaultScrollViewerBehavior.snapSpeedFactor = 1.5;
            Fuse.Controls.DefaultScrollViewerBehavior.elasticDecay = 0.995;
            Fuse.Controls.DefaultScrollViewerBehavior.arrivalTime = 1.0;
        };

    });
