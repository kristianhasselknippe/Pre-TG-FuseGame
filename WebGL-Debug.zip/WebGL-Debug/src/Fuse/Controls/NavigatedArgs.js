Fuse.Controls.NavigatedArgs = $CreateClass(
    function() {
        Uno.EventArgs.call(this);
        this._NewElement = null;
    },
    function(S) {
        var I = S.prototype = new Uno.EventArgs;

        I.GetType = function()
        {
            return 883;
        };

        I.NewElement = function(value)
        {
            if (value !== undefined)
            {
                this._NewElement = value;
            }
            else
            {
                return this._NewElement;
            }
        };

        I._ObjInit_1 = function(newElement)
        {
            Uno.EventArgs.prototype._ObjInit.call(this);
            this.NewElement(newElement);
        };

        Fuse.Controls.NavigatedArgs.New_2 = function(newElement)
        {
            var inst = new Fuse.Controls.NavigatedArgs;
            inst._ObjInit_1(newElement);
            return inst;
        };

    });
