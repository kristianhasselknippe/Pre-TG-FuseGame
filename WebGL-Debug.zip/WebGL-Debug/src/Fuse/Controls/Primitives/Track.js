Fuse.Controls.Primitives.Track = $CreateClass(
    function() {
        Fuse.Controls.Primitives.RangeControl.call(this);
        this._thumbTransform = null;
        this._HandlesInput = false;
    },
    function(S) {
        var I = S.prototype = new Fuse.Controls.Primitives.RangeControl;

        I.GetType = function()
        {
            return 871;
        };

        I.Thumb = function(value)
        {
            if (value !== undefined)
            {
                if (this.VisualTree() != value)
                {
                    if (this.VisualTree() != null)
                    {
                        this.VisualTree().Transforms()["Uno.Collections.ICollection__Fuse_Transform.Remove"](this._thumbTransform);
                    }

                    this.VisualTree(value);

                    if (this.VisualTree() != null)
                    {
                        this.VisualTree().Transforms()["Uno.Collections.ICollection__Fuse_Transform.Add"](this._thumbTransform);
                    }

                    this.UpdateThumbPosition();
                }
            }
            else
            {
                return this.VisualTree();
            }
        };

        I.HandlesInput = function(value)
        {
            if (value !== undefined)
            {
                this._HandlesInput = value;
            }
            else
            {
                return this._HandlesInput;
            }
        };

        I.ThumbSize = function()
        {
            return (this.Thumb() != null) ? this.Thumb().ActualSize() : Uno.Float2.New_1(0.0);
        };

        I.ThumbCenter = function()
        {
            return Uno.Float2.op_Multiply(this.ThumbSize(), 0.5);
        };

        I.ClientRect = function()
        {
            var ind_127;
            var ind_128;
            var ind_129;
            return Uno.Rect.New_2((ind_127 = this.Padding(), Uno.Float2.New_2(ind_127.X, ind_127.Y)), Uno.Float2.op_Subtraction(Uno.Float2.op_Subtraction(this.ActualSize(), (ind_128 = this.Padding(), Uno.Float2.New_2(ind_128.X, ind_128.Y))), (ind_129 = this.Padding(), Uno.Float2.New_2(ind_129.Z, ind_129.W))));
        };

        I.UpdateThumbPosition = function()
        {
            this._thumbTransform.X(this.ValueToPosition(this.Value()).X);
        };

        I.OnPlaced = function(oldPos)
        {
            this.UpdateThumbPosition();
            Fuse.Element.prototype.OnPlaced.call(this, oldPos);
        };

        I.OnResized = function(oldSize)
        {
            this.UpdateThumbPosition();
            Fuse.Element.prototype.OnResized.call(this, oldSize);
        };

        I.OnValueChanged = function()
        {
            this.UpdateThumbPosition();
            Fuse.Controls.Primitives.RangeControl.prototype.OnValueChanged.call(this);
        };

        I.UpdateValue = function(pos)
        {
            this.Value(this.PositionToValue(pos));
        };

        I.PositionToValue = function(pos)
        {
            var pos_126 = new Uno.Float2;
            pos_126.op_Assign(pos);
            var clientRect = this.ClientRect();
            return Uno.Math.Clamp_1(this.Remap(pos_126.X - this.ThumbCenter().X, clientRect.Left, clientRect.Right - this.ThumbSize().X, this.Minimum(), this.Maximum()), this.Minimum(), this.Maximum());
        };

        I.ValueToPosition = function(val)
        {
            val = Uno.Math.Clamp_1(val, this.Minimum(), this.Maximum());
            var clientRect = this.ClientRect();
            return Uno.Float2.New_2(this.Remap(val, this.Minimum(), this.Maximum(), clientRect.Left, clientRect.Right - this.ThumbSize().X), clientRect.Center().Y);
        };

        I.Remap = function(val, min, max, newMin, newMax)
        {
            return (((val - min) / (max - min)) * (newMax - newMin)) + newMin;
        };

        I.OnPointerPressed = function(c)
        {
            if ((this.HandlesInput() && !c.IsHardCapturedTo($DownCast(this, 33719))) && !c.IsHandled())
            {
                c.HardCapturePointer($DownCast(this, 33719));
                this.UpdateValue(this.FromAbsolute(c.PointCoord()));
                c.IsHandled(true);
                this.CancelManipulation();
            }

            Fuse.Controls.Control.prototype.OnPointerPressed.call(this, c);
        };

        I.OnPointerMoved = function(c)
        {
            if ((this.HandlesInput() && c.IsHardCapturedTo($DownCast(this, 33719))) && !c.IsHandled())
            {
                this.UpdateValue(this.FromAbsolute(c.PointCoord()));
                c.IsHandled(true);
                this.CancelManipulation();
            }

            Fuse.Node.prototype.OnPointerMoved.call(this, c);
        };

        I.OnPointerReleased = function(c)
        {
            if ((this.HandlesInput() && c.IsHardCapturedTo($DownCast(this, 33719))) && !c.IsHandled())
            {
                this.UpdateValue(this.FromAbsolute(c.PointCoord()));
                c.ReleaseHardCapture();
            }

            Fuse.Node.prototype.OnPointerReleased.call(this, c);
        };

    });
