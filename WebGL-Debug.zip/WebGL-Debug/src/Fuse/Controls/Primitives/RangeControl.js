Fuse.Controls.Primitives.RangeControl = $CreateClass(
    function() {
        Fuse.Controls.Control.call(this);
        this._minimum = 0;
        this._maxmimum = 0;
        this._value = 0;
        this.MinimumChanged = null;
        this.MaximumChanged = null;
        this.ValueChanged = null;
    },
    function(S) {
        var I = S.prototype = new Fuse.Controls.Control;

        I.GetType = function()
        {
            return 870;
        };

        I.Minimum = function(value)
        {
            if (value !== undefined)
            {
                this._minimum = value;
                this.InvalidateVisual();
                this.OnMinimumChanged();
            }
            else
            {
                return this._minimum;
            }
        };

        I.Maximum = function(value)
        {
            if (value !== undefined)
            {
                this._maxmimum = value;
                this.InvalidateVisual();
                this.OnMaximumChanged();
            }
            else
            {
                return this._maxmimum;
            }
        };

        I.Value = function(value)
        {
            if (value !== undefined)
            {
                var v = value;

                if ((this._value < this.Minimum()) || ((this._value > this.Maximum()) && (this.Minimum() <= this.Maximum())))
                {
                    v = Uno.Math.Min_1(Uno.Math.Max_1(this.Minimum(), value), this.Maximum());
                }

                if (this._value != v)
                {
                    this._value = v;
                    this.InvalidateVisual();
                    this.OnValueChanged();
                }
            }
            else
            {
                return this._value;
            }
        };

        I.OnMinimumChanged = function()
        {
            var handler = this.MinimumChanged;

            if (Uno.Delegate.op_Inequality(handler, null))
            {
                handler.Invoke(this, Uno.EventArgs.New_1());
            }
        };

        I.OnMaximumChanged = function()
        {
            var handler = this.MaximumChanged;

            if (Uno.Delegate.op_Inequality(handler, null))
            {
                handler.Invoke(this, Uno.EventArgs.New_1());
            }
        };

        I.OnValueChanged = function()
        {
            var handler = this.ValueChanged;

            if (Uno.Delegate.op_Inequality(handler, null))
            {
                handler.Invoke(this, Uno.EventArgs.New_1());
            }
        };

    });
