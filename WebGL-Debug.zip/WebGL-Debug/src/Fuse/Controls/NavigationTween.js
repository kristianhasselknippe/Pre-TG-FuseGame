Fuse.Controls.NavigationTween = $CreateClass(
    function() {
        this._easing = 0;
        this._duration = 0;
        this._easingBack = 0;
        this._hasEasingBack = false;
        this._durationBack = 0;
        this._hasDurationBack = false;
    },
    function(S) {
        var I = S.prototype;

        I.GetType = function()
        {
            return 875;
        };

        I.Easing = function(value)
        {
            if (value !== undefined)
            {
                this._easing = value;
            }
            else
            {
                return this._easing;
            }
        };

        I.Duration = function(value)
        {
            if (value !== undefined)
            {
                this._duration = value;
            }
            else
            {
                return this._duration;
            }
        };

        I.EasingBack = function(value)
        {
            if (value !== undefined)
            {
                this._easingBack = value;
                this._hasEasingBack = true;
            }
            else
            {
                if (this._hasEasingBack)
                {
                    return this._easingBack;
                }

                return this.Easing();
            }
        };

        I.DurationBack = function(value)
        {
            if (value !== undefined)
            {
                this._durationBack = value;
                this._hasDurationBack = true;
            }
            else
            {
                if (this._hasDurationBack)
                {
                    return this._durationBack;
                }

                return this.Duration();
            }
        };

    });
