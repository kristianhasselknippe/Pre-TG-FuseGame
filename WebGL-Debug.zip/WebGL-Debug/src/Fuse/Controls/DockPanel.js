Fuse.Controls.DockPanel = $CreateClass(
    function() {
        Fuse.Controls.Panel.call(this);
        this._dockLayout = null;
    },
    function(S) {
        var I = S.prototype = new Fuse.Controls.Panel;

        I.GetType = function()
        {
            return 881;
        };

        Fuse.Controls.DockPanel.SetDock = function(elm, dock)
        {
            Fuse.Layouts.DockLayout.SetDock(elm, dock);
        };

        I._ObjInit_4 = function()
        {
            Fuse.Controls.Panel.prototype._ObjInit_3.call(this);
            this.Layout(this._dockLayout = Fuse.Layouts.DockLayout.New_1());
        };

        Fuse.Controls.DockPanel.New_3 = function()
        {
            var inst = new Fuse.Controls.DockPanel;
            inst._ObjInit_4();
            return inst;
        };

    });
