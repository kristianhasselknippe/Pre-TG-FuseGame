Fuse.Controls.Panel = $CreateClass(
    function() {
        Fuse.Controls.Control.call(this);
        this._layout = null;
        this._children = null;
        this._implicitRectangle = null;
        this.ChildAdded = null;
        this.ChildRemoved = null;
    },
    function(S) {
        var I = S.prototype = new Fuse.Controls.Control;

        I.GetType = function()
        {
            return 882;
        };

        I.$II = function(id)
        {
            return [859, 787, 951, 774, 776, 778, 982].indexOf(id) != -1;
        };

        I.Layout = function(value)
        {
            if (value !== undefined)
            {
                if (this.IsRooted() && (this._layout != null))
                {
                    this._layout.RemoveSubscriber(this);
                }

                this._layout = value;

                if (this.IsRooted() && (this._layout != null))
                {
                    this._layout.AddSubscriber(this);
                    this.InvalidateVisual();
                    this.InvalidateLayout();
                }
            }
            else
            {
                var ind_127 = this._layout;
                return (ind_127 != null) ? ind_127 : Fuse.Layouts.Layouts.Default;
            }
        };

        I.HasChildren = function()
        {
            return (this._children != null) && (this._children.Count() > 0);
        };

        I.IsRedrawCheap = function()
        {
            return this.HasChildren() && (this.Children()["Uno.Collections.ICollection__Fuse_Element.Count"]() < 2);
        };

        I.Children = function()
        {
            var ind_128;
            return $DownCast((ind_128 = this._children, (ind_128 != null) ? ind_128 : (this._children = Fuse.Controls.Internal.ChildCollection.New_1($DownCast(this, 33627)))), 32913);
        };

        I.SubElementCount = function()
        {
            return Fuse.Controls.Control.prototype.SubElementCount.call(this) + (this.HasChildren() ? this._children.Count() : 0);
        };

        I.OnResetStyle = function()
        {
            if (this.HasChildren())
            {
                for (var i = 0; i < this.Children()["Uno.Collections.ICollection__Fuse_Element.Count"](); i++)
                {
                    if (this.Children()["Uno.Collections.IList__Fuse_Element.Item"](i).AddedByStyle())
                    {
                        this.Children()["Uno.Collections.IList__Fuse_Element.RemoveAt"](i--);
                    }
                }
            }

            Fuse.Controls.Control.prototype.OnResetStyle.call(this);
        };

        I.AddStyleChild = function(child)
        {
            child.AddedByStyle(true);
            this.Children()["Uno.Collections.ICollection__Fuse_Element.Add"](child);
        };

        I.OnRooted = function()
        {
            if (this._layout != null)
            {
                this._layout.AddSubscriber(this);
            }

            Fuse.Element.prototype.OnRooted.call(this);
        };

        I.OnUnrooted = function()
        {
            if (this._layout != null)
            {
                this._layout.RemoveSubscriber(this);
            }

            Fuse.Element.prototype.OnUnrooted.call(this);
        };

        I.GetContentSize = function(fillSize, fillSet)
        {
            if (this.HasChildren())
            {
                return this.Layout().GetContentSize($DownCast(this._children, 32913), fillSize, fillSet);
            }

            return Fuse.Controls.Control.prototype.GetContentSize.call(this, fillSize, fillSet);
        };

        I.ArrangePaddingBox = function(size)
        {
            this.ArrangeImplicitRectangle(size);

            if (this.HasChildren())
            {
                this.Layout().ArrangePaddingBox($DownCast(this._children, 32913), this.Padding(), size);
            }

            Fuse.Controls.Control.prototype.ArrangePaddingBox.call(this, size);
        };

        I.CalcRenderBounds_1 = function(baseRect)
        {
            var r = Fuse.Controls.Control.prototype.CalcRenderBounds_1.call(this, baseRect);

            if (this.HasChildren())
            {
                for (var i = 0; i < this._children.Count(); i++)
                {
                    r.op_Assign(Fuse.Element.ExpandToContain_1(r, this._children.Item(i)));
                }
            }

            return r;
        };

        I.DrawChildren = function(dc)
        {
            if (this.HasChildren())
            {
                if (this._children.HasZOrder())
                {
                    for (var i = 0; i < this._children.Count(); ++i)
                    {
                        this._children.GetZOrderChild(i).Draw(dc);
                    }
                }
                else
                {
                    for (var i = this._children.Count(); (i--) > 0; )
                    {
                        this._children.Item(i).Draw(dc);
                    }
                }
            }
        };

        I["Fuse.Controls.Internal.IParentElement.OnChildAdded"] = function(elm)
        {
            this.OnChildAdded(elm);

            if (Uno.Delegate.op_Inequality(this.ChildAdded, null))
            {
                this.ChildAdded.Invoke(this, elm);
            }
        };

        I["Fuse.Controls.Internal.IParentElement.OnChildRemoved"] = function(elm)
        {
            this.OnChildRemoved(elm);

            if (Uno.Delegate.op_Inequality(this.ChildRemoved, null))
            {
                this.ChildRemoved.Invoke(this, elm);
            }
        };

        I.OnChildAdded = function(elm)
        {
            this.InvalidateLayout();
            this.InvalidateVisual();
        };

        I.OnChildRemoved = function(elm)
        {
            this.InvalidateLayout();
            this.InvalidateVisual();
        };

        I.OnDraw = function(dc)
        {
            this.DrawImplicitRectangle(dc);
            Fuse.Controls.Control.prototype.OnDraw.call(this, dc);
            this.DrawChildren(dc);
        };

        I.OnHitTest = function(htc)
        {
            if ((this.Visibility() != 0) || (this.Opacity() <= this.HitTestOpacityThreshold()))
            {
                return;
            }

            if (this.HasChildren() && (!this.ClipToBounds() || this.IsPointInside(htc.LocalPoint())))
            {
                if (this._children.HasZOrder())
                {
                    for (var i = this._children.Count(); (i--) > 0; )
                    {
                        this._children.GetZOrderChild(i).HitTest(htc);
                    }
                }
                else
                {
                    for (var i = 0; i < this._children.Count(); ++i)
                    {
                        this._children.Item(i).HitTest(htc);
                    }
                }
            }

            Fuse.Controls.Control.prototype.OnHitTest.call(this, htc);
        };

        I.GetSubElement = function(index)
        {
            if (index < Fuse.Controls.Control.prototype.SubElementCount.call(this))
            {
                return Fuse.Controls.Control.prototype.GetSubElement.call(this, index);
            }
            else
            {
                return this._children.Item(index - Fuse.Controls.Control.prototype.SubElementCount.call(this));
            }
        };

        I["Fuse.Triggers.IAddRemoveChild.AddChild"] = function(n)
        {
            var e = $AsOp(n, 991);

            if (e != null)
            {
                this.Children()["Uno.Collections.ICollection__Fuse_Element.Add"](e);
            }
        };

        I["Fuse.Triggers.IAddRemoveChild.RemoveChild"] = function(n)
        {
            var e = $AsOp(n, 991);

            if (e != null)
            {
                this.Children()["Uno.Collections.ICollection__Fuse_Element.Remove"](e);
            }
        };

        I.DrawImplicitRectangle = function(dc)
        {
            if (this._implicitRectangle != null)
            {
                this._implicitRectangle.Draw(dc);
            }
        };

        I.ArrangeImplicitRectangle = function(finalSize)
        {
            if (this._implicitRectangle != null)
            {
                this._implicitRectangle.ArrangeMarginBox(Uno.Float2.New_1(0.0), finalSize, 3);
            }
        };

        I._ObjInit_3 = function()
        {
            Fuse.Controls.Control.prototype._ObjInit_2.call(this);
        };

        Fuse.Controls.Panel.New_2 = function()
        {
            var inst = new Fuse.Controls.Panel;
            inst._ObjInit_3();
            return inst;
        };

        I.add_ChildAdded = function(value)
        {
            this.ChildAdded = $DownCast(Uno.Delegate.Combine(this.ChildAdded, value), 496);
        };

        I.remove_ChildAdded = function(value)
        {
            this.ChildAdded = $DownCast(Uno.Delegate.Remove(this.ChildAdded, value), 496);
        };

        I.add_ChildRemoved = function(value)
        {
            this.ChildRemoved = $DownCast(Uno.Delegate.Combine(this.ChildRemoved, value), 496);
        };

        I.remove_ChildRemoved = function(value)
        {
            this.ChildRemoved = $DownCast(Uno.Delegate.Remove(this.ChildRemoved, value), 496);
        };

        I["Fuse.INode.GetResource"] = I.GetResource;
        I["Fuse.INode.ResetStyle"] = I.ResetStyle;
        I["Fuse.INode.ApplyStyle"] = I.ApplyStyle_1;
        I["Fuse.INode.PredictFocus"] = I.PredictFocus;
        I["Fuse.INode.Draw"] = function() { this.Draw.apply(this, arguments); };
        I["Fuse.INode.HitTest"] = I.HitTest;
        I["Fuse.INode.RaiseEvent"] = I.RaiseEvent_1;
        I["Fuse.INode.Parent"] = I.Parent;
        I["Fuse.INode.IsRooted"] = I.IsRooted;
        I["Fuse.INode.IsEnabled"] = I.IsEnabled;
        I["Fuse.INode.IsFocusable"] = function() { return this.IsFocusable.apply(this, arguments); };
        I["Fuse.INode.DrawNextFrame"] = function() { return this.DrawNextFrame.apply(this, arguments); };

    });
