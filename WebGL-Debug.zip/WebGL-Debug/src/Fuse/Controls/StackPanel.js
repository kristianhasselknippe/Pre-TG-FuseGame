Fuse.Controls.StackPanel = $CreateClass(
    function() {
        Fuse.Controls.Panel.call(this);
        this._stackLayout = null;
    },
    function(S) {
        var I = S.prototype = new Fuse.Controls.Panel;

        I.GetType = function()
        {
            return 821;
        };

        I._ObjInit_4 = function()
        {
            Fuse.Controls.Panel.prototype._ObjInit_3.call(this);
            this.Layout(this._stackLayout = Fuse.Layouts.StackLayout.New_1());
        };

        Fuse.Controls.StackPanel.New_3 = function()
        {
            var inst = new Fuse.Controls.StackPanel;
            inst._ObjInit_4();
            return inst;
        };

    });
