Fuse.Controls.Canvas = $CreateClass(
    function() {
        Fuse.Controls.Panel.call(this);
    },
    function(S) {
        var I = S.prototype = new Fuse.Controls.Panel;

        Fuse.Controls.Canvas._xProperty = null;
        Fuse.Controls.Canvas._yProperty = null;

        I.GetType = function()
        {
            return 879;
        };

        Fuse.Controls.Canvas.GetX = function(elm)
        {
            var val;

            if (elm.TryGetValue(Fuse.Controls.Canvas._xProperty, $CreateRef(function(){return val}, function($){val=$}, this)))
            {
                return $DownCast(val, 429);
            }

            return 0.0;
        };

        Fuse.Controls.Canvas.GetY = function(elm)
        {
            var val;

            if (elm.TryGetValue(Fuse.Controls.Canvas._yProperty, $CreateRef(function(){return val}, function($){val=$}, this)))
            {
                return $DownCast(val, 429);
            }

            return 0.0;
        };

        I.ArrangePaddingBox = function(size)
        {
            this.ArrangeAppearance(size);

            if (this.HasChildren())
            {
                for (var i = 0; i < this.Children()["Uno.Collections.ICollection__Fuse_Element.Count"](); i++)
                {
                    this.Children()["Uno.Collections.IList__Fuse_Element.Item"](i).ArrangeMarginBox(Uno.Float2.New_2(Fuse.Controls.Canvas.GetX(this.Children()["Uno.Collections.IList__Fuse_Element.Item"](i)), Fuse.Controls.Canvas.GetY(this.Children()["Uno.Collections.IList__Fuse_Element.Item"](i))), Uno.Float2.New_1(0.0), 0);
                }
            }
        };

        Fuse.Controls.Canvas._TypeInit_2 = function()
        {
            Fuse.Controls.Canvas._xProperty = Fuse.PropertyHandle.New_1();
            Fuse.Controls.Canvas._yProperty = Fuse.PropertyHandle.New_1();
        };

    });
