Fuse.Controls.NavigationBar = $CreateClass(
    function() {
        Fuse.Controls.Panel.call(this);
    },
    function(S) {
        var I = S.prototype = new Fuse.Controls.Panel;

        I.GetType = function()
        {
            return 888;
        };

    });
