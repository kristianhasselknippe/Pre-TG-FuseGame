Fuse.Controls.BackButton = $CreateClass(
    function() {
        Fuse.Controls.Button.call(this);
        this._navContext = null;
    },
    function(S) {
        var I = S.prototype = new Fuse.Controls.Button;

        I.GetType = function()
        {
            return 889;
        };

        I.NavigationContext = function(value)
        {
            if (value !== undefined)
            {
                if (this._navContext != value)
                {
                    if (this._navContext != null)
                    {
                        this._navContext["Fuse.Controls.INavigationContext.remove_Navigated"]($CreateDelegate(this, Fuse.Controls.BackButton.prototype.OnNavigated, 884));
                    }

                    this._navContext = value;

                    if (this._navContext != null)
                    {
                        this._navContext["Fuse.Controls.INavigationContext.add_Navigated"]($CreateDelegate(this, Fuse.Controls.BackButton.prototype.OnNavigated, 884));
                    }

                    this.OnNavigated(this, Uno.EventArgs.Empty);
                }
            }
            else
            {
                var ind_123 = this._navContext;
                return (ind_123 != null) ? ind_123 : $DownCast(Fuse.Controls.Navigation.TryFind(this), 33655);
            }
        };

        I.OnNavigated = function(sender, args)
        {
            if (this.NavigationContext() != null)
            {
                this.IsEnabled(this.NavigationContext()["Fuse.Controls.INavigationContext.CanGoBack"]());
            }
        };

        I.OnClick = function(args)
        {
            if ((this.NavigationContext() != null) && this.NavigationContext()["Fuse.Controls.INavigationContext.CanGoBack"]())
            {
                this.NavigationContext()["Fuse.Controls.INavigationContext.GoBack"]();
                args.IsHandled(true);
            }

            Fuse.Controls.Button.prototype.OnClick.call(this, args);
        };

    });
