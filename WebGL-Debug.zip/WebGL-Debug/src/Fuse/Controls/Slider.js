Fuse.Controls.Slider = $CreateClass(
    function() {
        Fuse.Controls.Primitives.Track.call(this);
    },
    function(S) {
        var I = S.prototype = new Fuse.Controls.Primitives.Track;

        I.GetType = function()
        {
            return 895;
        };

    });
