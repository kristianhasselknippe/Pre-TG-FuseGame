Fuse.Controls.Page = $CreateClass(
    function() {
        Fuse.Controls.Panel.call(this);
    },
    function(S) {
        var I = S.prototype = new Fuse.Controls.Panel;

        I.GetType = function()
        {
            return 891;
        };

        I.$II = function(id)
        {
            return [890, 859, 787, 951, 774, 776, 778, 982].indexOf(id) != -1;
        };

    });
