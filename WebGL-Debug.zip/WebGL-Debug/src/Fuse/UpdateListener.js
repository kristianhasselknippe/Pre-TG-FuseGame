Fuse.UpdateListener = $CreateClass(
    function() {
        this.action = null;
        this.stage = 0;
        this.removed = false;
        this.defer = false;
    },
    function(S) {
        var I = S.prototype;

        I.GetType = function()
        {
            return 969;
        };

        I.Invoke = function()
        {
            if (this.removed)
            {
                return;
            }

            if (Uno.Delegate.op_Inequality(this.action, null))
            {
                this.action.Invoke();
            }
        };

        I._ObjInit = function()
        {
        };

        Fuse.UpdateListener.New_1 = function()
        {
            var inst = new Fuse.UpdateListener;
            inst._ObjInit();
            return inst;
        };

    });
