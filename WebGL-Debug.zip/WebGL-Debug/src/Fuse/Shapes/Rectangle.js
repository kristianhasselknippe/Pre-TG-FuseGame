Fuse.Shapes.Rectangle = $CreateClass(
    function() {
        Fuse.Shapes.Shape.call(this);
        this._renderer = null;
        this._cornerRadius = 0;
        this._shrink = false;
        this._cachedRadius = 0;
        this._cachedPosition = new Uno.Float2;
        this._cachedSize = new Uno.Float2;
    },
    function(S) {
        var I = S.prototype = new Fuse.Shapes.Shape;

        I.GetType = function()
        {
            return 856;
        };

        I.Renderer = function()
        {
            this.UpdatePath();
            return this._renderer;
        };

        I.CornerRadius = function(value)
        {
            if (value !== undefined)
            {
                this._cornerRadius = value;
                this.InvalidateVisual();
            }
            else
            {
                return this._cornerRadius;
            }
        };

        I.OnHitTestVisual = function(htc)
        {
            if (this.CornerRadius() < 4.0)
            {
                if (this.IsPointInside(htc.LocalPoint()))
                {
                    htc.Hit($DownCast(this, 33719));
                }
            }
            else
            {
                Fuse.Shapes.Shape.prototype.OnHitTestVisual.call(this, htc);
            }
        };

        I.UpdatePath = function()
        {
            var strokeWidth = 0.0;

            if (this._shrink)
            {
                for (var enum_123 = this._renderer.Strokes()["Uno.Collections.IEnumerable__Fuse_Drawing_Stroke.GetEnumerator"](); enum_123["Uno.Collections.IEnumerator.MoveNext"](); )
                {
                    var stroke = enum_123["Uno.Collections.IEnumerator__Fuse_Drawing_Stroke.Current"]();
                    strokeWidth = Uno.Math.Max_1(strokeWidth, stroke.Offset() + (stroke.Width() * 0.5));
                }
            }

            var s = strokeWidth;
            var t = s + this.Padding().Y;
            var b = (this.ActualSize().Y - this.Padding().W) - s;
            var l = s + this.Padding().X;
            var r = (this.ActualSize().X - this.Padding().Z) - s;
            var radius = Uno.Math.Max_1(0.0, this._cornerRadius - s);
            var size = Uno.Float2.New_2(r - l, b - t);
            var position = Uno.Float2.New_2(l, t);

            if (((((this._cachedRadius == radius) && (this._cachedSize.X == size.X)) && (this._cachedSize.Y == size.Y)) && (this._cachedPosition.X == position.X)) && (this._cachedPosition.X == position.X))
            {
                return;
            }

            this._cachedRadius = radius;
            this._cachedSize.op_Assign(size);
            this._cachedPosition.op_Assign(position);
            this.InvalidateRenderBounds();
            this._renderer.Geometry(Fuse.Drawing.PathGeometryExtensions.Rectangle(Fuse.Drawing.PathGeometry.New_1().MoveTo_1(position), size, Uno.Float4.New_1(radius), false));
        };

        I._ObjInit_3 = function()
        {
            this._renderer = Fuse.Drawing.PathGeometryRenderer.New_1();
            Fuse.Shapes.Shape.prototype._ObjInit_2.call(this);
            this._renderer.add_VisualInvalidated($CreateDelegate(this, Fuse.Element.prototype.InvalidateVisual, 436));
        };

        Fuse.Shapes.Rectangle.New_1 = function()
        {
            var inst = new Fuse.Shapes.Rectangle;
            inst._ObjInit_3();
            return inst;
        };

    });
