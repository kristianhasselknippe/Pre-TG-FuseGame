Fuse.Shapes.Ellipse = $CreateClass(
    function() {
        Fuse.Shapes.Shape.call(this);
        this._renderer = null;
        this._cachedRadius = new Uno.Float2;
    },
    function(S) {
        var I = S.prototype = new Fuse.Shapes.Shape;

        I.GetType = function()
        {
            return 849;
        };

        I.Renderer = function()
        {
            this.UpdatePath();
            return this._renderer;
        };

        I.UpdatePath = function()
        {
            var radius = Uno.Float2.op_Multiply(this.ActualSize(), 0.5);

            if (Uno.Float2.op_Equality(this._cachedRadius, radius))
            {
                return;
            }

            this._cachedRadius.op_Assign(radius);
            this.InvalidateRenderBounds();
            this.Renderer().Geometry(Fuse.Drawing.PathGeometryExtensions.Ellipse(Fuse.Drawing.PathGeometry.New_1().MoveTo_1(radius), radius, false));
        };

    });
