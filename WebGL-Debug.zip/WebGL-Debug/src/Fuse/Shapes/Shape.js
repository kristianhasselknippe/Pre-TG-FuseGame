Fuse.Shapes.Shape = $CreateClass(
    function() {
        Fuse.Element.call(this);
    },
    function(S) {
        var I = S.prototype = new Fuse.Element;

        I.GetType = function()
        {
            return 858;
        };

        I.Fill = function(value)
        {
            if (value !== undefined)
            {
                this.Renderer().Fill(value);
            }
            else
            {
                return this.Renderer().Fill();
            }
        };

        I.Fills = function()
        {
            return this.Renderer().Fills();
        };

        I.Strokes = function()
        {
            return this.Renderer().Strokes();
        };

        I.Antialiasing = function(value)
        {
            if (value !== undefined)
            {
                this.Renderer().Antialiasing(value);
            }
            else
            {
                return this.Renderer().Antialiasing();
            }
        };

        I.UpdatePath = function()
        {
        };

        I.CalcRenderBounds = function()
        {
            this.UpdatePath();
            return this.Renderer().Bounds();
        };

        I.OnDraw = function(dc)
        {
            this.Renderer().Draw(this.GetDrawMatrix(dc), this.ActualSize());
        };

        I.OnHitTestVisual = function(htc)
        {
            if (this.IsPointInside(htc.LocalPoint()))
            {
                var hitPart = this.GetHitPart(htc.LocalPoint());

                if (hitPart != null)
                {
                    htc.Hit($DownCast(this, 33719));
                }
            }
        };

        I.GetHitPart = function(localCoords)
        {
            return this.Renderer().GetHitPart(localCoords);
        };

        I.SoftDispose = function()
        {
            this.Renderer().SoftDispose();
        };

        I._ObjInit_2 = function()
        {
            Fuse.Element.prototype._ObjInit_1.call(this);
        };

    });
