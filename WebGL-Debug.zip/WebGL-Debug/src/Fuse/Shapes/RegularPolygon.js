Fuse.Shapes.RegularPolygon = $CreateClass(
    function() {
        Fuse.Shapes.Shape.call(this);
        this._renderer = null;
        this._sides = 0;
        this._cachedSides = 0;
        this._cachedRadius = 0;
    },
    function(S) {
        var I = S.prototype = new Fuse.Shapes.Shape;

        I.GetType = function()
        {
            return 857;
        };

        I.Renderer = function()
        {
            this.UpdatePath();
            return this._renderer;
        };

        I.Offset = function()
        {
            return (this.ActualSize().X > this.ActualSize().Y) ? Uno.Float2.New_2((this.ActualSize().X * 0.5) - (this.ActualSize().Y * 0.5), 0.0) : Uno.Float2.New_2(0.0, (this.ActualSize().Y * 0.5) - (this.ActualSize().X * 0.5));
        };

        I.Radius = function()
        {
            return Uno.Math.Min_1(this.ActualSize().X, this.ActualSize().Y) * 0.5;
        };

        I.CalcRenderBounds = function()
        {
            var bounds_123 = new Uno.Rect;
            bounds_123.op_Assign(Fuse.Shapes.Shape.prototype.CalcRenderBounds.call(this));
            var min = Uno.Float2.op_Addition(bounds_123.Minimum(), this.Offset());
            var max = Uno.Float2.op_Addition(bounds_123.Maximum(), this.Offset());
            return Uno.Rect.New_1(min.X, min.Y, max.X, max.Y);
        };

        I.OnDraw = function(dc)
        {
            Fuse.Shapes.Shape.prototype.OnDraw.call(this, dc);
        };

        I.GetHitPart = function(localCoords)
        {
            return Fuse.Shapes.Shape.prototype.GetHitPart.call(this, Uno.Float2.op_Subtraction(localCoords, this.Offset()));
        };

        I.UpdatePath = function()
        {
            if (this._sides < 3)
            {
                return;
            }

            if ((this._cachedSides == this._sides) && (this._cachedRadius == this.Radius()))
            {
                return;
            }

            this._cachedSides = this._sides;
            this._cachedRadius = this.Radius();
            this.InvalidateRenderBounds();
            this._renderer.Geometry(Fuse.Drawing.PathGeometryExtensions.RegularPolygon(Fuse.Drawing.PathGeometry.New_1().MoveTo(this.Radius(), this.Radius()), this._sides, this.Radius(), false));
        };

    });
