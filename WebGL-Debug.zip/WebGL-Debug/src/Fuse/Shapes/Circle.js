Fuse.Shapes.Circle = $CreateClass(
    function() {
        Fuse.Shapes.Shape.call(this);
        this._renderer = null;
        this._cachedRadius = 0;
    },
    function(S) {
        var I = S.prototype = new Fuse.Shapes.Shape;

        I.GetType = function()
        {
            return 848;
        };

        I.Renderer = function()
        {
            this.UpdatePath();
            return this._renderer;
        };

        I.CenterOffset = function()
        {
            return (this.ActualSize().X > this.ActualSize().Y) ? Uno.Float2.New_2((this.ActualSize().X * 0.5) - this._cachedRadius, 0.0) : Uno.Float2.New_2(0.0, (this.ActualSize().Y * 0.5) - this._cachedRadius);
        };

        I.Radius = function()
        {
            return Uno.Math.Min_1(this.ActualSize().X, this.ActualSize().Y) * 0.5;
        };

        I.CalcRenderBounds = function()
        {
            var bounds_123 = new Uno.Rect;
            bounds_123.op_Assign(Fuse.Shapes.Shape.prototype.CalcRenderBounds.call(this));
            var min = Uno.Float2.op_Addition(bounds_123.Minimum(), this.CenterOffset());
            var max = Uno.Float2.op_Addition(bounds_123.Maximum(), this.CenterOffset());
            return Uno.Rect.New_1(min.X, min.Y, max.X, max.Y);
        };

        I.OnDraw = function(dc)
        {
            Fuse.Shapes.Shape.prototype.OnDraw.call(this, dc);
        };

        I.GetHitPart = function(localCoords)
        {
            return Fuse.Shapes.Shape.prototype.GetHitPart.call(this, Uno.Float2.op_Subtraction(localCoords, this.CenterOffset()));
        };

        I.UpdatePath = function()
        {
            if (this._cachedRadius == this.Radius())
            {
                return;
            }

            this._cachedRadius = this.Radius();
            this.InvalidateRenderBounds();
            this._renderer.Geometry(Fuse.Drawing.PathGeometryExtensions.Circle(Fuse.Drawing.PathGeometry.New_1().MoveTo(this.Radius(), this.Radius()), this.Radius(), false));
        };

        I._ObjInit_3 = function()
        {
            this._renderer = Fuse.Drawing.PathGeometryRenderer.New_1();
            this._cachedRadius = 0.0;
            Fuse.Shapes.Shape.prototype._ObjInit_2.call(this);
            this._renderer.add_VisualInvalidated($CreateDelegate(this, Fuse.Element.prototype.InvalidateVisual, 436));
        };

        Fuse.Shapes.Circle.New_1 = function()
        {
            var inst = new Fuse.Shapes.Circle;
            inst._ObjInit_3();
            return inst;
        };

    });
