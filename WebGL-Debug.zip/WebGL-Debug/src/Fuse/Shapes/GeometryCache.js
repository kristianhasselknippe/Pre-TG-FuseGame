Fuse.Shapes.GeometryCache = $CreateClass(
    function() {
        this._cache = null;
        this._frame = 0;
    },
    function(S) {
        var I = S.prototype;

        Fuse.Shapes.GeometryCache._instance = null;

        I.GetType = function()
        {
            return 853;
        };

        Fuse.Shapes.GeometryCache.GetOrParse = function(data)
        {
            var ind_125;
            return (ind_125 = Fuse.Shapes.GeometryCache._instance, ((ind_125 != null) ? ind_125 : (Fuse.Shapes.GeometryCache._instance = Fuse.Shapes.GeometryCache.New_1()))).GetOrCreateImpl(data);
        };

        I.GetOrCreateImpl = function(data)
        {
            var _entry;

            if (!this._cache.TryGetValue(data, $CreateRef(function(){return _entry}, function($){_entry=$}, this)))
            {
                this._cache.Item(data, _entry = Fuse.Shapes.GeometryCacheEntry.New_1(Fuse.Drawing.PathGeometry.Parse(data)));
            }

            _entry.LastUse = this._frame;
            return _entry.Geometry;
        };

        I.Update = function()
        {
            var entry_124 = new Uno.Collections.KeyValuePair__string__Fuse_Shapes_GeometryCacheEntry;
            this._frame++;
            var newCache = Uno.Collections.Dictionary__string__Fuse_Shapes_GeometryCacheEntry.New_1();

            for (var enum_123 = this._cache.GetEnumerator(); enum_123.MoveNext(); )
            {
                entry_124.op_Assign(enum_123.Current());
                var framesSinceLastUse = this._frame - entry_124.Value().LastUse;

                if ((framesSinceLastUse > 0) && (framesSinceLastUse <= 10))
                {
                    newCache.Item(entry_124.Key(), entry_124.Value());
                }
            }

            this._cache = newCache;
        };

        I._ObjInit = function()
        {
            this._cache = Uno.Collections.Dictionary__string__Fuse_Shapes_GeometryCacheEntry.New_1();
            Fuse.UpdateManager.AddAction($CreateDelegate(this, Fuse.Shapes.GeometryCache.prototype.Update, 436), 0);
        };

        Fuse.Shapes.GeometryCache.New_1 = function()
        {
            var inst = new Fuse.Shapes.GeometryCache;
            inst._ObjInit();
            return inst;
        };

    });
