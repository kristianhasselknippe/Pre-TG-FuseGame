Fuse.Shapes.Path = $CreateClass(
    function() {
        Fuse.Shapes.Shape.call(this);
        this._renderer = null;
        this.sizing = null;
        this._fitMode = 0;
        this._scaleMode = 0;
        this._fillRule = 0;
        this._postScale = new Uno.Float2;
        this._origin = new Uno.Float2;
    },
    function(S) {
        var I = S.prototype = new Fuse.Shapes.Shape;

        I.GetType = function()
        {
            return 855;
        };

        I.Renderer = function()
        {
            return this._renderer;
        };

        I.Data = function(value)
        {
            if (value !== undefined)
            {
                this._renderer.Geometry(Fuse.Shapes.GeometryCache.GetOrParse(value));
            }
            else
            {
                return this._renderer.Geometry().ToString();
            }
        };

        I.FillRule = function(value)
        {
            if (value !== undefined)
            {
                this._fillRule = value;
                this._renderer.FillRule((this._fillRule == 1) ? $CreateDelegate(null, Fuse.Drawing.WindingRules.Odd, 503) : $CreateDelegate(null, Fuse.Drawing.WindingRules.NonZero, 503));
            }
            else
            {
                return this._fillRule;
            }
        };

        I.GetNaturalContentSize = function()
        {
            var struct_123 = new Uno.Rect;
            var struct_124 = new Uno.Rect;
            var s_125 = new Uno.Float4;
            var struct_126 = new Uno.Rect;
            var struct_127 = new Uno.Rect;
            var struct_128 = new Uno.Rect;
            var struct_129 = new Uno.Rect;
            var s_130 = new Uno.Float4;
            var hi = Uno.Float2.New_1(0.0);
            var lo = Uno.Float2.New_1(0.0);

            switch (this._fitMode)
            {
                case 0:
                {
                    lo = Uno.Float2.New_1(0.0);
                    hi = (struct_123.op_Assign(this.Renderer().InnerBounds()), struct_123).Maximum();
                    break;
                }
                case 1:
                {
                    hi = (struct_124.op_Assign(this.Renderer().InnerBounds()), struct_124).Maximum();
                    s_125.op_Assign(this.Renderer().StrokePadding());
                    hi.X = hi.X + s_125.Item(2);
                    hi.Y = hi.Y + s_125.Item(3);
                    lo.X = lo.X - s_125.Item(0);
                    lo.Y = lo.Y - s_125.Item(1);
                    break;
                }
                case 2:
                {
                    lo = (struct_126.op_Assign(this.Renderer().InnerBounds()), struct_126).Minimum();
                    hi = (struct_127.op_Assign(this.Renderer().InnerBounds()), struct_127).Maximum();
                    break;
                }
                case 3:
                {
                    {
                        lo = (struct_128.op_Assign(this.Renderer().InnerBounds()), struct_128).Minimum();
                        hi = (struct_129.op_Assign(this.Renderer().InnerBounds()), struct_129).Maximum();
                        s_130.op_Assign(this.Renderer().StrokePadding());
                        lo.X = lo.X - s_130.Item(0);
                        lo.Y = lo.Y - s_130.Item(1);
                        hi.X = hi.X + s_130.Item(2);
                        hi.Y = hi.Y + s_130.Item(3);
                        break;
                    }
                }
            }

            var natural = Uno.Float2.op_Subtraction(hi, lo);
            return natural;
        };

        I.GetContentSize = function(fillSize, fillSet)
        {
            var r_132 = new Uno.Float2;
            var natural = this.GetNaturalContentSize();
            this.sizing.padding = Uno.Float4.New_1(0.0);
            r_132.op_Assign(this.sizing.ExpandFillSize(natural, fillSize, fillSet));
            return r_132;
        };

        I.ArrangePaddingBox = function(size)
        {
            var scale_134 = new Uno.Float2;
            var ind_141;
            var struct_135 = new Uno.Rect;
            var struct_136 = new Uno.Rect;
            var ind_142;
            this.sizing.padding.op_Assign(this.Padding());
            var contentDesiredSize = this.GetNaturalContentSize();
            scale_134.op_Assign(this.sizing.CalcScale(size, contentDesiredSize));
            this._origin = this.sizing.CalcOrigin(size, Uno.Float2.op_Multiply_1(contentDesiredSize, scale_134));

            if (this._scaleMode == 0)
            {
                this.Renderer().PreScale(scale_134);
            }
            else
            {
                this._postScale.op_Assign(scale_134);
            }

            switch (this._fitMode)
            {
                case 0:
                {
                    break;
                }
                case 1:
                {
                    this._origin = Uno.Float2.op_Addition(this._origin, (ind_141 = this.Renderer().StrokePadding(), Uno.Float2.New_2(ind_141.X, ind_141.Y)));
                    break;
                }
                case 2:
                {
                    this._origin = Uno.Float2.op_Subtraction(this._origin, (struct_135.op_Assign(this.Renderer().InnerBounds()), struct_135).Minimum());
                    break;
                }
                case 3:
                {
                    this._origin = Uno.Float2.op_Subtraction(this._origin, (struct_136.op_Assign(this.Renderer().InnerBounds()), struct_136).Minimum());
                    this._origin = Uno.Float2.op_Addition(this._origin, (ind_142 = this.Renderer().StrokePadding(), Uno.Float2.New_2(ind_142.X, ind_142.Y)));
                    break;
                }
            }
        };

        I.OnDraw = function(dc)
        {
            var r = this.AlignMatrix(this.GetDrawMatrix(dc));
            this.Renderer().Draw(r, this.ActualSize());
        };

        I.AlignMatrix = function(b)
        {
            var t = Uno.Matrix.Translation(Uno.Float3.New_3(this._origin, 0.0));
            var r0 = Uno.Matrix.Mul_11(t, b);
            var s = Uno.Matrix.Scaling(Uno.Float3.New_3(this._postScale, 1.0));
            var r1 = Uno.Matrix.Mul_11(s, r0);
            return r1;
        };

        I.CalcRenderBounds = function()
        {
            var b_138 = new Uno.Rect;
            var tl_139 = new Uno.Float2;
            var ind_143;
            var br_140 = new Uno.Float2;
            var ind_144;
            var m = this.AlignMatrix(Uno.Float4x4.Identity());
            b_138.op_Assign(this.Renderer().Bounds());
            tl_139.op_Assign((ind_143 = Uno.Vector.Transform_4(b_138.Minimum(), m), Uno.Float2.New_2(ind_143.X, ind_143.Y)));
            br_140.op_Assign((ind_144 = Uno.Vector.Transform_4(b_138.Maximum(), m), Uno.Float2.New_2(ind_144.X, ind_144.Y)));
            return Uno.Rect.New_2(tl_139, Uno.Float2.op_Subtraction(br_140, tl_139));
        };

        I._ObjInit_3 = function()
        {
            this.sizing = Fuse.Internal.SizingContainer.New_1();
            this._fitMode = 2;
            this._scaleMode = 1;
            this._postScale = Uno.Float2.New_1(1.0);
            Fuse.Shapes.Shape.prototype._ObjInit_2.call(this);
            this._renderer = Fuse.Drawing.PathGeometryRenderer.New_1();
            this._renderer.add_VisualInvalidated($CreateDelegate(this, Fuse.Element.prototype.InvalidateVisual, 436));
        };

        Fuse.Shapes.Path.New_1 = function()
        {
            var inst = new Fuse.Shapes.Path;
            inst._ObjInit_3();
            return inst;
        };

    });
