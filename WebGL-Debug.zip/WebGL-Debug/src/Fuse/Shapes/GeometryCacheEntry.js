Fuse.Shapes.GeometryCacheEntry = $CreateClass(
    function() {
        this.Geometry = null;
        this.LastUse = 0;
    },
    function(S) {
        var I = S.prototype;

        I.GetType = function()
        {
            return 852;
        };

        I._ObjInit = function(geometry)
        {
            this.Geometry = geometry;
        };

        Fuse.Shapes.GeometryCacheEntry.New_1 = function(geometry)
        {
            var inst = new Fuse.Shapes.GeometryCacheEntry;
            inst._ObjInit(geometry);
            return inst;
        };

    });
