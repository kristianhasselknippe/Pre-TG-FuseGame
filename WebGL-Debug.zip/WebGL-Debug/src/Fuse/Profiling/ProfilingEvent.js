Fuse.Profiling.ProfilingEvent = $CreateClass(
    function() {
        this.Action = 0;
        this.Source = null;
        this.TimeStamp = 0;
    },
    function(S) {
        var I = S.prototype;

        I.GetType = function()
        {
            return 556;
        };

        I._ObjInit = function(action, obj, timeStamp)
        {
            this.Action = action;
            this.Source = obj;
            this.TimeStamp = timeStamp;
        };

        Fuse.Profiling.ProfilingEvent.New_1 = function(action, obj, timeStamp)
        {
            var inst = new Fuse.Profiling.ProfilingEvent;
            inst._ObjInit(action, obj, timeStamp);
            return inst;
        };

    });
