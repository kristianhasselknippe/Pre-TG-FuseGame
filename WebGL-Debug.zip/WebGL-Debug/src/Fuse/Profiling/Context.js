Fuse.Profiling.Context = $CreateClass(
    function() {
    },
    function(S) {
        Fuse.Profiling.Context._events = null;
        Fuse.Profiling.Context._IsEnabled = false;

        Fuse.Profiling.Context.IsEnabled = function(value)
        {
            if (value !== undefined)
            {
                Fuse.Profiling.Context._IsEnabled = value;
            }
            else
            {
                return Fuse.Profiling.Context._IsEnabled;
            }
        };

        Fuse.Profiling.Context.PushNode = function(obj)
        {
            if (!Fuse.Profiling.Context.IsEnabled())
            {
                return;
            }

            var e = Fuse.Profiling.ProfilingEvent.New_1(0, obj, Uno.Diagnostics.Clock.GetSeconds());
            Fuse.Profiling.Context._events.Add(e);
        };

        Fuse.Profiling.Context.PopNode = function()
        {
            if (!Fuse.Profiling.Context.IsEnabled())
            {
                return;
            }

            var e = Fuse.Profiling.ProfilingEvent.New_1(1, null, Uno.Diagnostics.Clock.GetSeconds());
            Fuse.Profiling.Context._events.Add(e);
        };

        Fuse.Profiling.Context.Clear = function()
        {
            Fuse.Profiling.Context._events.Clear();
        };

        Fuse.Profiling.Context._TypeInit = function()
        {
            Fuse.Profiling.Context._events = Uno.Collections.List__Fuse_Profiling_ProfilingEvent.New_1();
        };

    });
