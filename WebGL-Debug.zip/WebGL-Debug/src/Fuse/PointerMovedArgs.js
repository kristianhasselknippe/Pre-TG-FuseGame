Fuse.PointerMovedArgs = $CreateClass(
    function() {
        Fuse.PointerEventArgs.call(this);
    },
    function(S) {
        var I = S.prototype = new Fuse.PointerEventArgs;

        I.GetType = function()
        {
            return 925;
        };

        I._ObjInit_3 = function(data)
        {
            Fuse.PointerEventArgs.prototype._ObjInit_2.call(this, data);
        };

        Fuse.PointerMovedArgs.New_2 = function(data)
        {
            var inst = new Fuse.PointerMovedArgs;
            inst._ObjInit_3(data);
            return inst;
        };

    });
