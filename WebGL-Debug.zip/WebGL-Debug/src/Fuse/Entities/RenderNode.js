Fuse.Entities.RenderNode = $CreateClass(
    function() {
        Fuse.Node.call(this);
        this.children = null;
    },
    function(S) {
        var I = S.prototype = new Fuse.Node;

        I.GetType = function()
        {
            return 845;
        };

        I.Children = function()
        {
            return this.children;
        };

        I.SubNodeCount = function()
        {
            return this.Children().Count();
        };

        I.ParentToLocal = function(pointCoord)
        {
            return pointCoord;
        };

        I.LocalToParent = function(pointCoord)
        {
            return pointCoord;
        };

        I.Draw = function(dc)
        {
            if (this.IsVisible())
            {
                this.OnDraw(dc);
            }
        };

        I.OnDraw = function(dc)
        {
            for (var i = 0; i < this.Children().Count(); i++)
            {
                this.Children().Item(i).Draw(dc);
            }
        };

        I.OnHitTest = function(args)
        {
            for (var i = this.Children().Count(); (i--) > 0; )
            {
                this.Children().Item(i).HitTest(args);
            }
        };

        I.GetSubNode = function(index)
        {
            return this.Children().Item(index);
        };

    });
