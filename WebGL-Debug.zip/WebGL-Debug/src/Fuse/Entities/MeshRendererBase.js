Fuse.Entities.MeshRendererBase = $CreateClass(
    function() {
        Fuse.Entities.Component.call(this);
        this.pickable = false;
        this._mesh = null;
        this._material = null;
    },
    function(S) {
        var I = S.prototype = new Fuse.Entities.Component;

        I.GetType = function()
        {
            return 835;
        };

        I.IsPickable = function(value)
        {
            if (value !== undefined)
            {
                this.pickable = value;
            }
            else
            {
                return this.pickable;
            }
        };

        I.Material = function(value)
        {
            if (value !== undefined)
            {
                this._material = value;
            }
            else
            {
                if (this._material != null)
                {
                    return this._material;
                }

                var e = this.Entity();

                while (e != null)
                {
                    e = e.ParentEntity();

                    if ((e != null) && (e.MeshRenderer() != null))
                    {
                        return e.MeshRenderer().Material();
                    }
                }

                return null;
            }
        };

        I.OnAdded = function(e)
        {
            e.add_ComponentDraw($CreateDelegate(this, Fuse.Entities.MeshRendererBase.prototype.OnDraw, 935));
            e.add_ComponentHitTest($CreateDelegate(this, Fuse.Entities.MeshRendererBase.prototype.OnHitTest, 937));
        };

        I.OnRemoved = function(e)
        {
            e.remove_ComponentDraw($CreateDelegate(this, Fuse.Entities.MeshRendererBase.prototype.OnDraw, 935));
            e.remove_ComponentHitTest($CreateDelegate(this, Fuse.Entities.MeshRendererBase.prototype.OnHitTest, 937));
        };

        I.OnHitTest = function(sender, args)
        {
            var objRay_129 = new Uno.Geometry.Ray;
            var hitPoint_130 = new Uno.Float3;
            var htc = args.Context();

            if (this._mesh == null)
            {
                return;
            }

            if (!(false || this.IsPickable()))
            {
                return;
            }

            var cam = $AsOp(htc.Camera(), 827);

            if (cam == null)
            {
                return;
            }

            objRay_129.op_Assign(htc.GetObjectRay(this.Entity().AbsoluteTransformInverse()));
            var distance;

            if (!this.RayIntersectObjectSpace(objRay_129, $CreateRef(function(){return distance}, function($){distance=$}, this)))
            {
                return;
            }

            hitPoint_130.op_Assign(Uno.Vector.TransformCoordinate(Uno.Float3.op_Addition(objRay_129.Position, Uno.Float3.op_Multiply(objRay_129.Direction, distance)), this.Entity().AbsoluteTransform()));
            var dist = Uno.Vector.Length_1(Uno.Float3.op_Subtraction(hitPoint_130, cam.AbsolutePosition()));
            htc.Hit_1($DownCast(this.Entity(), 33701), dist);
        };

        I.RayIntersectObjectSpace = function(objectSpaceRay, distance)
        {
            if (this._mesh == null)
            {
                distance(0.0);
                return false;
            }

            if (!Uno.Geometry.Collision.RayIntersectsBox(objectSpaceRay, this._mesh.BoundingBox(), distance))
            {
                return false;
            }

            if (!Fuse.Entities.ModelMeshCollision.RayIntersectsModelMesh(objectSpaceRay, this._mesh.ModelMesh(), distance))
            {
                return false;
            }

            return true;
        };

        I.OnDraw = function(sender, args)
        {
            var m_133 = new Uno.Float4x4;
            var dc = args.Context();

            if (this._mesh == null)
            {
                return;
            }

            if (this.Material() == null)
            {
                return;
            }

            m_133.op_Assign(this.Entity().AbsoluteTransform());

            if (!this.Material().Draw(this._mesh, m_133))
            {
                Fuse.Entities.MeshBatchingEngine.Singleton().Draw(dc, this._mesh, m_133, this.Material());
                dc.Flush();
            }
        };

    });
