Fuse.Entities.ModelMeshCollision_Indexed = $CreateClass(
    function() {
        Fuse.Entities.TriangleMeshIntersecter.call(this);
        this._positions = null;
        this._indices = null;
    },
    function(S) {
        var I = S.prototype = new Fuse.Entities.TriangleMeshIntersecter;

        I.GetType = function()
        {
            return 844;
        };

        I.GetTriangle = function(t)
        {
            var ind_123;
            var ind_124;
            var ind_125;
            var i = t * 3;
            return Uno.Geometry.Triangle.New_1((ind_123 = this._positions.GetFloat4(this._indices.GetInt(i)), Uno.Float3.New_2(ind_123.X, ind_123.Y, ind_123.Z)), (ind_124 = this._positions.GetFloat4(this._indices.GetInt(i + 1)), Uno.Float3.New_2(ind_124.X, ind_124.Y, ind_124.Z)), (ind_125 = this._positions.GetFloat4(this._indices.GetInt(i + 2)), Uno.Float3.New_2(ind_125.X, ind_125.Y, ind_125.Z)));
        };

        I._ObjInit_1 = function(positions, indices, indexCount)
        {
            Fuse.Entities.TriangleMeshIntersecter.prototype._ObjInit.call(this, (indexCount / 3) | 0);

            if (positions == null)
            {
                throw new $Error(Uno.Exception.New_1("positions can not be null"));
            }

            if (indices == null)
            {
                throw new $Error(Uno.Exception.New_1("indices can not be null"));
            }

            this._positions = positions;
            this._indices = indices;
        };

        Fuse.Entities.ModelMeshCollision_Indexed.New_1 = function(positions, indices, indexCount)
        {
            var inst = new Fuse.Entities.ModelMeshCollision_Indexed;
            inst._ObjInit_1(positions, indices, indexCount);
            return inst;
        };

    });
