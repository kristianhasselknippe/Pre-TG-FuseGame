Fuse.Entities.ModelMeshCollision = $CreateClass(
    function() {
    },
    function(S) {
        var I = S.prototype;

        I.GetType = function()
        {
            return 836;
        };

        Fuse.Entities.ModelMeshCollision.RayIntersectsModelMesh = function(objRay, modelMesh, outDistance)
        {
            if (modelMesh == null)
            {
                throw new $Error(Uno.Exception.New_1("modelMesh can not be null"));
            }

            var useIndices = modelMesh.IndexCount() > 0;
            return useIndices ? Fuse.Entities.ModelMeshCollision_Indexed.New_1(modelMesh.Positions(), modelMesh.Indices(), modelMesh.IndexCount()).IntersectsRay(objRay, outDistance) : Fuse.Entities.ModelMeshCollision_Direct.New_1(modelMesh.Positions(), modelMesh.VertexCount()).IntersectsRay(objRay, outDistance);
        };

    });
