Fuse.Entities.MeshBatchingEngine = $CreateClass(
    function() {
        this.drawLists = null;
        this.batchers = null;
        this.worldArray = null;
        this.normalArray = null;
        this._draw_10c3bf43 = new Uno.Runtime.Implementation.ShaderBackends.OpenGL.GLDrawCall;
        this._draw_6a6fab0f = new Uno.Runtime.Implementation.ShaderBackends.OpenGL.GLDrawCall;
    },
    function(S) {
        var I = S.prototype;

        Fuse.Entities.MeshBatchingEngine._singleton = null;

        I.GetType = function()
        {
            return 833;
        };

        I.$II = function(id)
        {
            return [897].indexOf(id) != -1;
        };

        Fuse.Entities.MeshBatchingEngine.Singleton = function()
        {
            var ind_137 = Fuse.Entities.MeshBatchingEngine._singleton;
            return (ind_137 != null) ? ind_137 : (Fuse.Entities.MeshBatchingEngine._singleton = Fuse.Entities.MeshBatchingEngine.New_1());
        };

        I.Draw = function(dc, mesh, transform, material)
        {
            if (!material.IsBatchable())
            {
                this.Flush(dc);
            }

            var list;

            if (!this.drawLists.TryGetValue(material, $CreateRef(function(){return list}, function($){list=$}, this)))
            {
                list = Uno.Collections.List__Fuse_Entities_Entry.New_1();
                this.drawLists.Add(material, list);
            }

            list.Add(Fuse.Entities.Entry.New_1(mesh, transform, Uno.Matrix.Invert(transform)));
            dc.AddFlushListener($DownCast(this, 33665));
        };

        I.Flush = function(dc)
        {
            var p_130 = new Uno.Collections.KeyValuePair__Fuse_Entities_Material__Uno_Collections_List_Fuse_Entities_Entry_;

            if (dc.Camera() == null)
            {
                return;
            }

            for (var enum_123 = this.drawLists.GetEnumerator(); enum_123.MoveNext(); )
            {
                p_130.op_Assign(enum_123.Current());
                this.DrawList(dc, p_130.Key(), p_130.Value());
            }

            this.drawLists.Clear();
        };

        I.DrawList = function(dc, material, entries)
        {
            var p_131 = new Uno.Collections.KeyValuePair__Fuse_Entities_Mesh__Uno_Collections_List_Fuse_Entities_Entry_;

            if (entries.Count() > 2)
            {
                var meshCounts = Uno.Collections.Dictionary__Fuse_Entities_Mesh__Uno_Collections_List_Fuse_Entities_Entry_.New_1();

                for (var i = 0; i < entries.Count(); i++)
                {
                    if (!meshCounts.ContainsKey(entries.Item(i).Mesh))
                    {
                        meshCounts.Add(entries.Item(i).Mesh, Uno.Collections.List__Fuse_Entities_Entry.New_1());
                    }

                    meshCounts.Item(entries.Item(i).Mesh).Add(entries.Item(i));
                }

                for (var enum_124 = meshCounts.GetEnumerator(); enum_124.MoveNext(); )
                {
                    p_131.op_Assign(enum_124.Current());

                    if ((p_131.Key().ModelMesh().VertexCount() > 20000) || (p_131.Value().Count() < 3))
                    {
                        this.DrawIndividual(dc, material, p_131.Value());
                    }
                    else
                    {
                        var batcher = this.FindOrCreateBatcher(p_131.Key());
                        this.DrawBatched(dc, material, batcher, p_131.Value());
                    }
                }
            }
            else
            {
                this.DrawIndividual(dc, material, entries);
            }
        };

        I.MeshVertexCount = function(mesh)
        {
            return (mesh.ModelMesh().IndexCount() != -1) ? mesh.ModelMesh().IndexCount() : mesh.ModelMesh().VertexCount();
        };

        I.FindOrCreateBatcher = function(mesh)
        {
            var batcher;

            if (!this.batchers.TryGetValue(mesh, $CreateRef(function(){return batcher}, function($){batcher=$}, this)))
            {
                batcher = Fuse.Drawing.Batching.MeshBatcher.New_1();
                this.batchers.Item(mesh, batcher);
                var instanceCount = Uno.Math.Min_8(16, (65535 / Uno.Math.Max_8(1, this.MeshVertexCount(mesh))) | 0);

                for (var i = 0; i < instanceCount; i++)
                {
                    batcher.AddMesh(mesh.ModelMesh());
                }

                batcher.Flush();
            }

            return batcher;
        };

        I.DrawBatched = function(dc, material, batcher, entries)
        {
            for (var k = 0; k < 16; k++)
            {
                this.worldArray[k] = Uno.Float4x4.New_1(0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0);
            }

            var bc = 0;

            for (var i = 0; i < entries.Count(); i++)
            {
                this.worldArray[bc].op_Assign(entries.Item(i).World);
                this.normalArray[bc].op_Assign(entries.Item(i).WorldInverse);
                bc++;

                if ((bc >= (batcher.EntryCount() - 1)) || (i == (entries.Count() - 1)))
                {
                    var batch = Uno.Collections.EnumerableExtensions.FirstOrDefault__Fuse_Drawing_Batching_Batch_1(batcher.Batches());

                    if (batch != null)
                    {
                        var vc = bc * this.MeshVertexCount(entries.Item(0).Mesh);

                        if ($IsOp(material, 826))
                        {
                            if ($IsOp(dc.Pass(), 942))
                            {
                                {
                                    this._draw_10c3bf43.WriteRed(false);
                                    this._draw_10c3bf43.WriteGreen(false);
                                    this._draw_10c3bf43.WriteBlue(false);
                                    this._draw_10c3bf43.WriteAlpha(false);
                                    this._draw_10c3bf43.Const(0, $AsOp(material, 826).DiffuseMap() != null);
                                    this._draw_10c3bf43.Const(1, $AsOp(material, 826).NormalMap() != null);
                                    this._draw_10c3bf43.Const(2, $AsOp(material, 826).SpecularMap() != null);
                                    this._draw_10c3bf43.Use();
                                    this._draw_10c3bf43.Attrib_1(3, batch.Positions().DataType(), batch.Positions().VertexBuffer(), batch.Positions().StrideInBytes(), 0);
                                    this._draw_10c3bf43.Attrib_1(4, batch.InstanceIndices().DataType(), batch.InstanceIndices().VertexBuffer(), batch.InstanceIndices().StrideInBytes(), 0);
                                    this._draw_10c3bf43.Attrib_1(5, batch.TexCoord0s().DataType(), batch.TexCoord0s().VertexBuffer(), batch.TexCoord0s().StrideInBytes(), 0);
                                    this._draw_10c3bf43.Attrib_1(6, batch.Tangents().DataType(), batch.Tangents().VertexBuffer(), batch.Tangents().StrideInBytes(), 0);
                                    this._draw_10c3bf43.Attrib_1(7, batch.Normals().DataType(), batch.Normals().VertexBuffer(), batch.Normals().StrideInBytes(), 0);
                                    this._draw_10c3bf43.Uniform_21(8, Array.Init([this.worldArray[0], this.worldArray[1], this.worldArray[2], this.worldArray[3], this.worldArray[4], this.worldArray[5], this.worldArray[6], this.worldArray[7], this.worldArray[8], this.worldArray[9], this.worldArray[10], this.worldArray[11], this.worldArray[12], this.worldArray[13], this.worldArray[14], this.worldArray[15]], 457));
                                    this._draw_10c3bf43.Uniform_9(9, $AsOp(material, 826).Tiling());
                                    this._draw_10c3bf43.Uniform_9(10, $AsOp(material, 826).Offset());
                                    this._draw_10c3bf43.Uniform_10(11, $AsOp(material, 826).DiffuseColor());
                                    this._draw_10c3bf43.Uniform_21(12, Array.Init([this.normalArray[0], this.normalArray[1], this.normalArray[2], this.normalArray[3], this.normalArray[4], this.normalArray[5], this.normalArray[6], this.normalArray[7], this.normalArray[8], this.normalArray[9], this.normalArray[10], this.normalArray[11], this.normalArray[12], this.normalArray[13], this.normalArray[14], this.normalArray[15]], 457));
                                    this._draw_10c3bf43.Uniform_10(13, $AsOp(material, 826).SpecularColor());
                                    this._draw_10c3bf43.Uniform_10(14, ($AsOp(Fuse.DrawContext.Current().Camera(), 827) != null) ? $AsOp(Fuse.DrawContext.Current().Camera(), 827).AbsolutePosition() : Uno.Float3.New_2(100.0, 100.0, 100.0));
                                    this._draw_10c3bf43.Uniform_8(15, $AsOp(material, 826).Shininess());
                                    this._draw_10c3bf43.Uniform_14(16, Uno.Matrix.Mul_11(Uno.Matrix.LookAtRH(($AsOp(Fuse.DrawContext.Current().Camera(), 827) != null) ? $AsOp(Fuse.DrawContext.Current().Camera(), 827).AbsolutePosition() : Uno.Float3.New_2(100.0, 100.0, 100.0), ($AsOp(Fuse.DrawContext.Current().Camera(), 827) != null) ? Uno.Float3.op_Addition($AsOp(Fuse.DrawContext.Current().Camera(), 827).AbsolutePosition(), $AsOp(Fuse.DrawContext.Current().Camera(), 827).AbsoluteForward()) : Uno.Float3.New_2(0.0, 0.0, 0.0), ($AsOp(Fuse.DrawContext.Current().Camera(), 827) != null) ? $AsOp(Fuse.DrawContext.Current().Camera(), 827).AbsoluteUp() : Uno.Float3.New_2(0.0, 0.0, 1.0)), Uno.Matrix.PerspectiveRH(($AsOp(Fuse.DrawContext.Current().Camera(), 827) != null) ? $AsOp(Fuse.DrawContext.Current().Camera(), 827).Frustum().FovRadians() : 0.7853982, Fuse.DrawContext.Current().Aspect(), ($AsOp(Fuse.DrawContext.Current().Camera(), 827) != null) ? $AsOp(Fuse.DrawContext.Current().Camera(), 827).Frustum().ZNear() : 1.0, ($AsOp(Fuse.DrawContext.Current().Camera(), 827) != null) ? $AsOp(Fuse.DrawContext.Current().Camera(), 827).Frustum().ZFar() : 10000.0)));
                                    this._draw_10c3bf43.Sampler_2(17, $AsOp(material, 826).DiffuseMap());
                                    this._draw_10c3bf43.Sampler_2(18, $AsOp(material, 826).NormalMap());
                                    this._draw_10c3bf43.Sampler_2(19, $AsOp(material, 826).SpecularMap());
                                    this._draw_10c3bf43.Draw(vc, batch.IndexType(), batch.IndexBuffer());
                                }
                            }
                            else if ($IsOp(dc.Pass(), 941))
                            {
                                {
                                    this._draw_10c3bf43.Const(0, $AsOp(material, 826).DiffuseMap() != null);
                                    this._draw_10c3bf43.Const(1, $AsOp(material, 826).NormalMap() != null);
                                    this._draw_10c3bf43.Const(2, $AsOp(material, 826).SpecularMap() != null);
                                    this._draw_10c3bf43.Use();
                                    this._draw_10c3bf43.Attrib_1(3, batch.Positions().DataType(), batch.Positions().VertexBuffer(), batch.Positions().StrideInBytes(), 0);
                                    this._draw_10c3bf43.Attrib_1(4, batch.InstanceIndices().DataType(), batch.InstanceIndices().VertexBuffer(), batch.InstanceIndices().StrideInBytes(), 0);
                                    this._draw_10c3bf43.Attrib_1(5, batch.TexCoord0s().DataType(), batch.TexCoord0s().VertexBuffer(), batch.TexCoord0s().StrideInBytes(), 0);
                                    this._draw_10c3bf43.Attrib_1(6, batch.Tangents().DataType(), batch.Tangents().VertexBuffer(), batch.Tangents().StrideInBytes(), 0);
                                    this._draw_10c3bf43.Attrib_1(7, batch.Normals().DataType(), batch.Normals().VertexBuffer(), batch.Normals().StrideInBytes(), 0);
                                    this._draw_10c3bf43.Uniform_21(8, Array.Init([this.worldArray[0], this.worldArray[1], this.worldArray[2], this.worldArray[3], this.worldArray[4], this.worldArray[5], this.worldArray[6], this.worldArray[7], this.worldArray[8], this.worldArray[9], this.worldArray[10], this.worldArray[11], this.worldArray[12], this.worldArray[13], this.worldArray[14], this.worldArray[15]], 457));
                                    this._draw_10c3bf43.Uniform_9(9, $AsOp(material, 826).Tiling());
                                    this._draw_10c3bf43.Uniform_9(10, $AsOp(material, 826).Offset());
                                    this._draw_10c3bf43.Uniform_10(11, $AsOp(material, 826).DiffuseColor());
                                    this._draw_10c3bf43.Uniform_21(12, Array.Init([this.normalArray[0], this.normalArray[1], this.normalArray[2], this.normalArray[3], this.normalArray[4], this.normalArray[5], this.normalArray[6], this.normalArray[7], this.normalArray[8], this.normalArray[9], this.normalArray[10], this.normalArray[11], this.normalArray[12], this.normalArray[13], this.normalArray[14], this.normalArray[15]], 457));
                                    this._draw_10c3bf43.Uniform_10(13, $AsOp(material, 826).SpecularColor());
                                    this._draw_10c3bf43.Uniform_10(14, ($AsOp(Fuse.DrawContext.Current().Camera(), 827) != null) ? $AsOp(Fuse.DrawContext.Current().Camera(), 827).AbsolutePosition() : Uno.Float3.New_2(100.0, 100.0, 100.0));
                                    this._draw_10c3bf43.Uniform_8(15, $AsOp(material, 826).Shininess());
                                    this._draw_10c3bf43.Uniform_14(16, Uno.Matrix.Mul_11(Uno.Matrix.LookAtRH(($AsOp(Fuse.DrawContext.Current().Camera(), 827) != null) ? $AsOp(Fuse.DrawContext.Current().Camera(), 827).AbsolutePosition() : Uno.Float3.New_2(100.0, 100.0, 100.0), ($AsOp(Fuse.DrawContext.Current().Camera(), 827) != null) ? Uno.Float3.op_Addition($AsOp(Fuse.DrawContext.Current().Camera(), 827).AbsolutePosition(), $AsOp(Fuse.DrawContext.Current().Camera(), 827).AbsoluteForward()) : Uno.Float3.New_2(0.0, 0.0, 0.0), ($AsOp(Fuse.DrawContext.Current().Camera(), 827) != null) ? $AsOp(Fuse.DrawContext.Current().Camera(), 827).AbsoluteUp() : Uno.Float3.New_2(0.0, 0.0, 1.0)), Uno.Matrix.PerspectiveRH(($AsOp(Fuse.DrawContext.Current().Camera(), 827) != null) ? $AsOp(Fuse.DrawContext.Current().Camera(), 827).Frustum().FovRadians() : 0.7853982, Fuse.DrawContext.Current().Aspect(), ($AsOp(Fuse.DrawContext.Current().Camera(), 827) != null) ? $AsOp(Fuse.DrawContext.Current().Camera(), 827).Frustum().ZNear() : 1.0, ($AsOp(Fuse.DrawContext.Current().Camera(), 827) != null) ? $AsOp(Fuse.DrawContext.Current().Camera(), 827).Frustum().ZFar() : 10000.0)));
                                    this._draw_10c3bf43.Sampler_2(17, $AsOp(material, 826).DiffuseMap());
                                    this._draw_10c3bf43.Sampler_2(18, $AsOp(material, 826).NormalMap());
                                    this._draw_10c3bf43.Sampler_2(19, $AsOp(material, 826).SpecularMap());
                                    this._draw_10c3bf43.Draw(vc, batch.IndexType(), batch.IndexBuffer());
                                }
                            }
                        }
                    }

                    bc = 0;

                    for (var k = 0; k < 16; k++)
                    {
                        this.worldArray[k] = Uno.Float4x4.New_1(0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0);
                    }
                }
            }
        };

        I.DrawIndividual = function(dc, m, entries)
        {
            var e_132 = new Fuse.Entities.Entry;

            for (var enum_125 = entries.GetEnumerator(); enum_125.MoveNext(); )
            {
                e_132.op_Assign(enum_125.Current());
                this.DrawMesh(dc, m, e_132.Mesh, e_132.World, e_132.WorldInverse);
            }
        };

        I.DrawMesh = function(dc, m, mesh, world, worldInverse)
        {
            var array_126;
            var index_127;
            var length_128;

            for (array_126 = mesh.Batches(), index_127 = 0, length_128 = array_126.length; index_127 < length_128; ++index_127)
            {
                var b = array_126[index_127];
                this.DrawBatch(dc, m, b, world, worldInverse);
            }
        };

        I.DrawBatch = function(dc, material, batch, world, worldInverse)
        {
            if ($IsOp(material, 826))
            {
                if ($IsOp(dc.Pass(), 942))
                {
                    {
                        this._draw_6a6fab0f.WriteRed(false);
                        this._draw_6a6fab0f.WriteGreen(false);
                        this._draw_6a6fab0f.WriteBlue(false);
                        this._draw_6a6fab0f.WriteAlpha(false);
                        this._draw_6a6fab0f.Const(0, $AsOp(material, 826).DiffuseMap() != null);
                        this._draw_6a6fab0f.Const(1, $AsOp(material, 826).NormalMap() != null);
                        this._draw_6a6fab0f.Const(2, $AsOp(material, 826).SpecularMap() != null);
                        this._draw_6a6fab0f.Use();
                        this._draw_6a6fab0f.Attrib_1(3, batch.Positions().DataType(), batch.Positions().VertexBuffer(), batch.Positions().StrideInBytes(), 0);
                        this._draw_6a6fab0f.Attrib_1(4, batch.TexCoord0s().DataType(), batch.TexCoord0s().VertexBuffer(), batch.TexCoord0s().StrideInBytes(), 0);
                        this._draw_6a6fab0f.Attrib_1(5, batch.Tangents().DataType(), batch.Tangents().VertexBuffer(), batch.Tangents().StrideInBytes(), 0);
                        this._draw_6a6fab0f.Attrib_1(6, batch.Normals().DataType(), batch.Normals().VertexBuffer(), batch.Normals().StrideInBytes(), 0);
                        this._draw_6a6fab0f.Uniform_9(7, $AsOp(material, 826).Tiling());
                        this._draw_6a6fab0f.Uniform_9(8, $AsOp(material, 826).Offset());
                        this._draw_6a6fab0f.Uniform_10(9, $AsOp(material, 826).DiffuseColor());
                        this._draw_6a6fab0f.Uniform_10(10, $AsOp(material, 826).SpecularColor());
                        this._draw_6a6fab0f.Uniform_14(11, world);
                        this._draw_6a6fab0f.Uniform_10(12, ($AsOp(Fuse.DrawContext.Current().Camera(), 827) != null) ? $AsOp(Fuse.DrawContext.Current().Camera(), 827).AbsolutePosition() : Uno.Float3.New_2(100.0, 100.0, 100.0));
                        this._draw_6a6fab0f.Uniform_8(13, $AsOp(material, 826).Shininess());
                        this._draw_6a6fab0f.Uniform_14(14, Uno.Matrix.Mul_11(world, Uno.Matrix.Mul_11(Uno.Matrix.LookAtRH(($AsOp(Fuse.DrawContext.Current().Camera(), 827) != null) ? $AsOp(Fuse.DrawContext.Current().Camera(), 827).AbsolutePosition() : Uno.Float3.New_2(100.0, 100.0, 100.0), ($AsOp(Fuse.DrawContext.Current().Camera(), 827) != null) ? Uno.Float3.op_Addition($AsOp(Fuse.DrawContext.Current().Camera(), 827).AbsolutePosition(), $AsOp(Fuse.DrawContext.Current().Camera(), 827).AbsoluteForward()) : Uno.Float3.New_2(0.0, 0.0, 0.0), ($AsOp(Fuse.DrawContext.Current().Camera(), 827) != null) ? $AsOp(Fuse.DrawContext.Current().Camera(), 827).AbsoluteUp() : Uno.Float3.New_2(0.0, 0.0, 1.0)), Uno.Matrix.PerspectiveRH(($AsOp(Fuse.DrawContext.Current().Camera(), 827) != null) ? $AsOp(Fuse.DrawContext.Current().Camera(), 827).Frustum().FovRadians() : 0.7853982, Fuse.DrawContext.Current().Aspect(), ($AsOp(Fuse.DrawContext.Current().Camera(), 827) != null) ? $AsOp(Fuse.DrawContext.Current().Camera(), 827).Frustum().ZNear() : 1.0, ($AsOp(Fuse.DrawContext.Current().Camera(), 827) != null) ? $AsOp(Fuse.DrawContext.Current().Camera(), 827).Frustum().ZFar() : 10000.0))));
                        this._draw_6a6fab0f.Uniform_14(15, Uno.Matrix.Transpose_2(worldInverse));
                        this._draw_6a6fab0f.Sampler_2(16, $AsOp(material, 826).DiffuseMap());
                        this._draw_6a6fab0f.Sampler_2(17, $AsOp(material, 826).NormalMap());
                        this._draw_6a6fab0f.Sampler_2(18, $AsOp(material, 826).SpecularMap());
                        this._draw_6a6fab0f.Draw(batch.VertexCount(), batch.IndexType(), batch.IndexBuffer());
                    }
                }
                else if ($IsOp(dc.Pass(), 941))
                {
                    {
                        this._draw_6a6fab0f.Const(0, $AsOp(material, 826).DiffuseMap() != null);
                        this._draw_6a6fab0f.Const(1, $AsOp(material, 826).NormalMap() != null);
                        this._draw_6a6fab0f.Const(2, $AsOp(material, 826).SpecularMap() != null);
                        this._draw_6a6fab0f.Use();
                        this._draw_6a6fab0f.Attrib_1(3, batch.Positions().DataType(), batch.Positions().VertexBuffer(), batch.Positions().StrideInBytes(), 0);
                        this._draw_6a6fab0f.Attrib_1(4, batch.TexCoord0s().DataType(), batch.TexCoord0s().VertexBuffer(), batch.TexCoord0s().StrideInBytes(), 0);
                        this._draw_6a6fab0f.Attrib_1(5, batch.Tangents().DataType(), batch.Tangents().VertexBuffer(), batch.Tangents().StrideInBytes(), 0);
                        this._draw_6a6fab0f.Attrib_1(6, batch.Normals().DataType(), batch.Normals().VertexBuffer(), batch.Normals().StrideInBytes(), 0);
                        this._draw_6a6fab0f.Uniform_9(7, $AsOp(material, 826).Tiling());
                        this._draw_6a6fab0f.Uniform_9(8, $AsOp(material, 826).Offset());
                        this._draw_6a6fab0f.Uniform_10(9, $AsOp(material, 826).DiffuseColor());
                        this._draw_6a6fab0f.Uniform_10(10, $AsOp(material, 826).SpecularColor());
                        this._draw_6a6fab0f.Uniform_14(11, world);
                        this._draw_6a6fab0f.Uniform_10(12, ($AsOp(Fuse.DrawContext.Current().Camera(), 827) != null) ? $AsOp(Fuse.DrawContext.Current().Camera(), 827).AbsolutePosition() : Uno.Float3.New_2(100.0, 100.0, 100.0));
                        this._draw_6a6fab0f.Uniform_8(13, $AsOp(material, 826).Shininess());
                        this._draw_6a6fab0f.Uniform_14(14, Uno.Matrix.Mul_11(world, Uno.Matrix.Mul_11(Uno.Matrix.LookAtRH(($AsOp(Fuse.DrawContext.Current().Camera(), 827) != null) ? $AsOp(Fuse.DrawContext.Current().Camera(), 827).AbsolutePosition() : Uno.Float3.New_2(100.0, 100.0, 100.0), ($AsOp(Fuse.DrawContext.Current().Camera(), 827) != null) ? Uno.Float3.op_Addition($AsOp(Fuse.DrawContext.Current().Camera(), 827).AbsolutePosition(), $AsOp(Fuse.DrawContext.Current().Camera(), 827).AbsoluteForward()) : Uno.Float3.New_2(0.0, 0.0, 0.0), ($AsOp(Fuse.DrawContext.Current().Camera(), 827) != null) ? $AsOp(Fuse.DrawContext.Current().Camera(), 827).AbsoluteUp() : Uno.Float3.New_2(0.0, 0.0, 1.0)), Uno.Matrix.PerspectiveRH(($AsOp(Fuse.DrawContext.Current().Camera(), 827) != null) ? $AsOp(Fuse.DrawContext.Current().Camera(), 827).Frustum().FovRadians() : 0.7853982, Fuse.DrawContext.Current().Aspect(), ($AsOp(Fuse.DrawContext.Current().Camera(), 827) != null) ? $AsOp(Fuse.DrawContext.Current().Camera(), 827).Frustum().ZNear() : 1.0, ($AsOp(Fuse.DrawContext.Current().Camera(), 827) != null) ? $AsOp(Fuse.DrawContext.Current().Camera(), 827).Frustum().ZFar() : 10000.0))));
                        this._draw_6a6fab0f.Uniform_14(15, Uno.Matrix.Transpose_2(worldInverse));
                        this._draw_6a6fab0f.Sampler_2(16, $AsOp(material, 826).DiffuseMap());
                        this._draw_6a6fab0f.Sampler_2(17, $AsOp(material, 826).NormalMap());
                        this._draw_6a6fab0f.Sampler_2(18, $AsOp(material, 826).SpecularMap());
                        this._draw_6a6fab0f.Draw(batch.VertexCount(), batch.IndexType(), batch.IndexBuffer());
                    }
                }
            }
        };

        I.init_DrawCalls = function()
        {
            this._draw_10c3bf43 = Uno.Runtime.Implementation.ShaderBackends.OpenGL.GLDrawCall.New_1($DownCast(Uno.Runtime.Implementation.Internal.BundleRegistry.Get(39), 390));
            this._draw_6a6fab0f = Uno.Runtime.Implementation.ShaderBackends.OpenGL.GLDrawCall.New_1($DownCast(Uno.Runtime.Implementation.Internal.BundleRegistry.Get(40), 390));
        };

        I._ObjInit = function()
        {
            this.drawLists = Uno.Collections.Dictionary__Fuse_Entities_Material__Uno_Collections_List_Fuse_Entities_Entry_.New_1();
            this.batchers = Uno.Collections.Dictionary__Fuse_Entities_Mesh__Fuse_Drawing_Batching_MeshBatcher.New_1();
            this.worldArray = Array.Structs(16, Uno.Float4x4, 457);
            this.normalArray = Array.Structs(16, Uno.Float4x4, 457);
            this.init_DrawCalls();
        };

        Fuse.Entities.MeshBatchingEngine.New_1 = function()
        {
            var inst = new Fuse.Entities.MeshBatchingEngine;
            inst._ObjInit();
            return inst;
        };

        I["Fuse.IFlush.Flush"] = I.Flush;

    });
