Fuse.Entities.Frustum = $CreateClass(
    function() {
        Fuse.Entities.Component.call(this);
        this.fovRadians = 0;
        this.zNear = 0;
        this.zFar = 0;
        this._hasExplicitAspect = false;
        this._aspect = 0;
    },
    function(S) {
        var I = S.prototype = new Fuse.Entities.Component;

        I.GetType = function()
        {
            return 844;
        };

        I.FovRadians = function(value)
        {
            if (value !== undefined)
            {
                this.fovRadians = value;
            }
            else
            {
                return this.fovRadians;
            }
        };

        I.ZNear = function(value)
        {
            if (value !== undefined)
            {
                this.zNear = value;
            }
            else
            {
                return this.zNear;
            }
        };

        I.ZFar = function(value)
        {
            if (value !== undefined)
            {
                this.zFar = value;
            }
            else
            {
                return this.zFar;
            }
        };

        I.HasExplicitAspect = function()
        {
            return this._hasExplicitAspect;
        };

        I.ExplicitAspect = function(value)
        {
            if (value !== undefined)
            {
                this._aspect = value;
                this._hasExplicitAspect = true;
            }
            else
            {
                return this._aspect;
            }
        };

    });
