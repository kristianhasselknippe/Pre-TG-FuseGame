Fuse.Entities.Mesh = $CreateClass(
    function() {
        this._drawable = null;
        this._meshBoxDirty = false;
        this._meshBox = new Uno.Geometry.Box;
        this.isDirty = false;
        this.batches = null;
        this.batcher = null;
    },
    function(S) {
        var I = S.prototype;

        I.GetType = function()
        {
            return 831;
        };

        I.ModelMesh = function()
        {
            return this._drawable.Mesh();
        };

        I.BoundingBox = function()
        {
            if (this._meshBoxDirty)
            {
                this._meshBox = Fuse.Entities.ModelMeshHelpers.CalculateAABB(this.ModelMesh());
                this._meshBoxDirty = false;
            }

            return this._meshBox;
        };

        I.Batches = function()
        {
            if (this.isDirty)
            {
                this.Flush();
            }

            var ind_123 = this.batches;
            return (ind_123 != null) ? ind_123 : Uno.Collections.EnumerableExtensions.ToArray__Fuse_Drawing_Batching_Batch(this.batcher.Batches());
        };

        I.Flush = function()
        {
            if (!this.isDirty)
            {
                return;
            }

            if (((this.ModelMesh() != null) && (this.ModelMesh().Indices() != null)) && (this.ModelMesh().Indices().Type() == 4))
            {
                this.batcher = Fuse.Drawing.Batching.MeshBatcher.New_1();
                this.batcher.AddMesh(this.ModelMesh());
                this.batcher.Flush();
                this.batches = null;
            }
            else
            {
                this.batcher = null;
                this.batches = Array.Init([Fuse.Drawing.Batching.BatchHelpers.CreateSingleBatch(this.ModelMesh())], 688);
            }

            this.isDirty = false;
        };

    });
