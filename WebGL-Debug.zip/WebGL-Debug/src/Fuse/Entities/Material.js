Fuse.Entities.Material = $CreateClass(
    function() {
    },
    function(S) {
        var I = S.prototype;

        I.GetType = function()
        {
            return 830;
        };

        I.IsBatchable = function()
        {
            return true;
        };

        I.Draw = function(m, transform)
        {
            return false;
        };

    });
