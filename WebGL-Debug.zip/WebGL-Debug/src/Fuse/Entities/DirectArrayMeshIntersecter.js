Fuse.Entities.DirectArrayMeshIntersecter = $CreateClass(
    function() {
        Fuse.Entities.TriangleMeshIntersecter.call(this);
        this._positions = null;
    },
    function(S) {
        var I = S.prototype = new Fuse.Entities.TriangleMeshIntersecter;

        I.GetType = function()
        {
            return 841;
        };

        I.GetTriangle = function(t)
        {
            var i = t * 3;
            return Uno.Geometry.Triangle.New_1(this._positions[i], this._positions[i + 1], this._positions[i + 2]);
        };

    });
