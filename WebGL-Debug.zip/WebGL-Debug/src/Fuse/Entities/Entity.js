Fuse.Entities.Entity = $CreateClass(
    function() {
        Fuse.Node.call(this);
        this._children = null;
        this._components = null;
        this.ComponentDraw = null;
        this.ComponentHitTest = null;
    },
    function(S) {
        var I = S.prototype = new Fuse.Node;

        I.GetType = function()
        {
            return 843;
        };

        I.$II = function(id)
        {
            return [964, 951].indexOf(id) != -1;
        };

        I["Fuse.ICamera.HasExplicitAspect"] = function()
        {
            return (this.Frustum() != null) && this.Frustum().HasExplicitAspect();
        };

        I["Fuse.ICamera.ExplicitAspect"] = function()
        {
            return (this.Frustum() != null) ? this.Frustum().ExplicitAspect() : 1.0;
        };

        I.Children = function()
        {
            if (this._children == null)
            {
                this._children = Uno.Collections.ObservableList__Fuse_Entities_Entity.New_1($CreateDelegate(this, Fuse.Entities.Entity.prototype.OnChildAdded, 484), $CreateDelegate(this, Fuse.Entities.Entity.prototype.OnChildRemoved, 484));
            }

            return $DownCast(this._children, 32923);
        };

        I.HasChildren = function()
        {
            return (this._children != null) && (this._children.Count() > 0);
        };

        I.AbsolutePosition = function(value)
        {
            if (value !== undefined)
            {
                var localToAbs_128 = new Uno.Float4x4;
                var absToLocal_129 = new Uno.Float4x4;
                var localToParent_130 = new Uno.Float4x4;
                localToAbs_128.op_Assign(this.AbsoluteTransform());
                absToLocal_129.op_Assign(Uno.Matrix.Invert(localToAbs_128));
                localToParent_130.op_Assign(this.LocalTransform());
                var absToParent = Uno.Matrix.Mul_11(absToLocal_129, localToParent_130);
                this.Transform().Position(Uno.Vector.TransformCoordinate(value, absToParent));
            }
            else
            {
                var scale = new Uno.Float3;
                var translation = new Uno.Float3;
                var rotation = new Uno.Float4;
                Uno.Matrix.Decompose(this.AbsoluteTransform(), $CreateRef(function(){return scale}, function($){scale=$}, this), $CreateRef(function(){return rotation}, function($){rotation=$}, this), $CreateRef(function(){return translation}, function($){translation=$}, this));
                return translation;
            }
        };

        I.AbsoluteUp = function()
        {
            return Uno.Vector.Normalize_1(Uno.Vector.TransformNormal(Uno.Float3.New_2(0.0, 1.0, 0.0), this.AbsoluteTransform()));
        };

        I.AbsoluteForward = function()
        {
            return Uno.Vector.Normalize_1(Uno.Vector.TransformNormal(Uno.Float3.New_2(0.0, 0.0, -1.0), this.AbsoluteTransform()));
        };

        I.Frustum = function()
        {
            for (var i = 0; i < this._components.Count(); i++)
            {
                if ($IsOp(this._components.Item(i), 844))
                {
                    return $DownCast(this._components.Item(i), 844);
                }
            }

            return null;
        };

        I.Transform = function()
        {
            for (var i = this.Transforms()["Uno.Collections.ICollection__Fuse_Transform.Count"](); (i--) > 0; )
            {
                if ($IsOp(this.Transforms()["Uno.Collections.IList__Fuse_Transform.Item"](i), 846))
                {
                    return $DownCast(this.Transforms()["Uno.Collections.IList__Fuse_Transform.Item"](i), 846);
                }
            }

            return null;
        };

        I.SubNodeCount = function()
        {
            return this.Children()["Uno.Collections.ICollection__Fuse_Entities_Entity.Count"]();
        };

        I.OnChildAdded = function(c)
        {
            c.OnAdded($DownCast(this, 33719));
        };

        I.OnChildRemoved = function(c)
        {
            c.OnRemoved($DownCast(this, 33719));
        };

        I.ParentToLocal = function(parentPoint)
        {
            return parentPoint;
        };

        I.LocalToParent = function(localPoint)
        {
            return localPoint;
        };

        I.Draw = function(dc)
        {
            if (Uno.Delegate.op_Inequality(this.ComponentDraw, null))
            {
                this.ComponentDraw.Invoke(this, Fuse.DrawArgs.New_2(dc));
            }

            if (this.HasChildren())
            {
                for (var i = 0; i < this._children.Count(); i++)
                {
                    this._children.Item(i).Draw(dc);
                }
            }
        };

        I.OnHitTest = function(htc)
        {
            if (Uno.Delegate.op_Inequality(this.ComponentHitTest, null))
            {
                this.ComponentHitTest.Invoke(this, Fuse.HitTestArgs.New_2(htc));
            }

            if (this.HasChildren())
            {
                for (var i = 0; i < this._children.Count(); i++)
                {
                    this._children.Item(i).HitTest(htc);
                }
            }
        };

        I.GetSubNode = function(index)
        {
            return this.Children()["Uno.Collections.IList__Fuse_Entities_Entity.Item"](index);
        };

    });
