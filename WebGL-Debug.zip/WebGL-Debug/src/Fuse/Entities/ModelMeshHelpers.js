Fuse.Entities.ModelMeshHelpers = $CreateClass(
    function() {
    },
    function(S) {

        Fuse.Entities.ModelMeshHelpers.CalculateAABB = function(modelMesh)
        {
            var p_123 = new Uno.Float3;
            var ind_124;
            var positions = modelMesh.Positions();
            var min = Uno.Float3.New_2(3.402823e+38, 3.402823e+38, 3.402823e+38);
            var max = Uno.Float3.New_2(-3.402823e+38, -3.402823e+38, -3.402823e+38);

            for (var v = 0; v < modelMesh.VertexCount(); v++)
            {
                p_123.op_Assign((ind_124 = positions.GetFloat4(v), Uno.Float3.New_2(ind_124.X, ind_124.Y, ind_124.Z)));
                min = Uno.Float3.New_2(Uno.Math.Min_1(min.X, p_123.X), Uno.Math.Min_1(min.Y, p_123.Y), Uno.Math.Min_1(min.Z, p_123.Z));
                max = Uno.Float3.New_2(Uno.Math.Max_1(max.X, p_123.X), Uno.Math.Max_1(max.Y, p_123.Y), Uno.Math.Max_1(max.Z, p_123.Z));
            }

            return Uno.Geometry.Box.New_1(min, max);
        };

    });
