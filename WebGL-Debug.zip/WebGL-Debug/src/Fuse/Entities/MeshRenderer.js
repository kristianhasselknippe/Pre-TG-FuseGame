Fuse.Entities.MeshRenderer = $CreateClass(
    function() {
        Fuse.Entities.MeshRendererBase.call(this);
    },
    function(S) {
        var I = S.prototype = new Fuse.Entities.MeshRendererBase;

        I.GetType = function()
        {
            return 834;
        };

    });
