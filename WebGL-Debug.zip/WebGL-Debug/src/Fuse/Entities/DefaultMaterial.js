Fuse.Entities.DefaultMaterial = $CreateClass(
    function() {
        Fuse.Entities.Material.call(this);
        this._DiffuseColor = new Uno.Float3;
        this._SpecularColor = new Uno.Float3;
        this._Shininess = 0;
        this._Tiling = new Uno.Float2;
        this._Offset = new Uno.Float2;
        this._DiffuseMap = null;
        this._NormalMap = null;
        this._SpecularMap = null;
    },
    function(S) {
        var I = S.prototype = new Fuse.Entities.Material;

        I.GetType = function()
        {
            return 826;
        };

        I.DiffuseColor = function(value)
        {
            if (value !== undefined)
            {
                this._DiffuseColor.op_Assign(value);
            }
            else
            {
                return this._DiffuseColor;
            }
        };

        I.SpecularColor = function(value)
        {
            if (value !== undefined)
            {
                this._SpecularColor.op_Assign(value);
            }
            else
            {
                return this._SpecularColor;
            }
        };

        I.Shininess = function(value)
        {
            if (value !== undefined)
            {
                this._Shininess = value;
            }
            else
            {
                return this._Shininess;
            }
        };

        I.Tiling = function(value)
        {
            if (value !== undefined)
            {
                this._Tiling.op_Assign(value);
            }
            else
            {
                return this._Tiling;
            }
        };

        I.Offset = function(value)
        {
            if (value !== undefined)
            {
                this._Offset.op_Assign(value);
            }
            else
            {
                return this._Offset;
            }
        };

        I.DiffuseMap = function(value)
        {
            if (value !== undefined)
            {
                this._DiffuseMap = value;
            }
            else
            {
                return this._DiffuseMap;
            }
        };

        I.NormalMap = function(value)
        {
            if (value !== undefined)
            {
                this._NormalMap = value;
            }
            else
            {
                return this._NormalMap;
            }
        };

        I.SpecularMap = function(value)
        {
            if (value !== undefined)
            {
                this._SpecularMap = value;
            }
            else
            {
                return this._SpecularMap;
            }
        };

    });
