Fuse.Entities.NodeCollection__Fuse_Node = $CreateClass(
    function() {
        this.children = null;
    },
    function(S) {
        var I = S.prototype;

        I.GetType = function()
        {
            return 847;
        };

        I.Count = function()
        {
            return (this.children == null) ? 0 : this.children.Count();
        };

        I.Item = function(index)
        {
            return this.children.Item(index);
        };

    });
