Fuse.Entities.TriangleMeshIntersecter = $CreateClass(
    function() {
        this._count = 0;
    },
    function(S) {
        var I = S.prototype;

        I.GetType = function()
        {
            return 840;
        };

        I.IntersectsRay = function(objRay, outDistance)
        {
            var minDistance = 3.402823e+38;
            var hit = false;

            for (var t = 0; t < this._count; t++)
            {
                var distance;

                if (Uno.Geometry.Collision.RayIntersectsTriangle(objRay, this.GetTriangle(t), $CreateRef(function(){return distance}, function($){distance=$}, this)))
                {
                    hit = true;

                    if (distance < minDistance)
                    {
                        minDistance = distance;
                    }
                }
            }

            outDistance(minDistance);
            return hit;
        };

        I._ObjInit = function(count)
        {
            this._count = count;
        };

    });
