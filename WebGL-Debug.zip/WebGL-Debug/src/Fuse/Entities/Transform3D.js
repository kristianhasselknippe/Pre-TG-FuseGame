Fuse.Entities.Transform3D = $CreateClass(
    function() {
        Fuse.Transform.call(this);
        this.position = new Uno.Float3;
        this.rotationQuaternion = new Uno.Float4;
        this.rotationDegrees = new Uno.Float3;
        this.scale = new Uno.Float3;
        this._Entity = null;
    },
    function(S) {
        var I = S.prototype = new Fuse.Transform;

        I.GetType = function()
        {
            return 846;
        };

        I.Entity = function(value)
        {
            if (value !== undefined)
            {
                this._Entity = value;
            }
            else
            {
                return this._Entity;
            }
        };

        I.Position = function(value)
        {
            if (value !== undefined)
            {
                if (Uno.Float3.op_Inequality(this.position, value))
                {
                    this.position.op_Assign(value);
                    this.InvalidateLocal();
                }
            }
            else
            {
                return this.position;
            }
        };

        I.RotationQuaternion = function(value)
        {
            if (value !== undefined)
            {
                this.rotationQuaternion.op_Assign(value);
                this.rotationDegrees.op_Assign(Uno.Quaternion.ToEulerAngleDegrees(value));
                this.InvalidateLocal();
            }
            else
            {
                return this.rotationQuaternion;
            }
        };

        I.Scaling = function(value)
        {
            if (value !== undefined)
            {
                this.scale.op_Assign(value);
                this.InvalidateLocal();
            }
            else
            {
                return this.scale;
            }
        };

        I.InvalidateLocal = function()
        {
            this.OnMatrixChanged();
        };

        I.OnAdded = function(n)
        {
            this.Entity($AsOp(n, 843));
        };

        I.OnRemoved = function(n)
        {
            this.Entity(null);
        };

        I.AppendTo = function(m, weight)
        {
            if (Uno.Float3.op_Inequality(this.Scaling(), Uno.Float3.New_1(1.0)))
            {
                m.AppendScale_1(Uno.Math.Lerp_4(Uno.Float3.New_1(1.0), this.Scaling(), weight));
            }

            if (Uno.Float4.op_Inequality(this.RotationQuaternion(), Uno.Float4.New_2(0.0, 0.0, 0.0, 1.0)))
            {
                m.AppendRotationQuaternion(Uno.Float4.op_Multiply(this.RotationQuaternion(), weight));
            }

            if (Uno.Float3.op_Inequality(this.Position(), Uno.Float3.New_1(0.0)))
            {
                m.AppendTranslation_1(Uno.Float3.op_Multiply(this.Position(), weight));
            }
        };

        I.PrependTo = function(m)
        {
            if (Uno.Float3.op_Inequality(this.Position(), Uno.Float3.New_1(0.0)))
            {
                m.PrependTranslation_1(this.Position());
            }

            if (Uno.Float4.op_Inequality(this.RotationQuaternion(), Uno.Float4.New_2(0.0, 0.0, 0.0, 1.0)))
            {
                m.PrependRotationQuaternion(this.RotationQuaternion());
            }

            if (Uno.Float3.op_Inequality(this.Scaling(), Uno.Float3.New_1(1.0)))
            {
                m.PrependScale_1(this.Scaling());
            }
        };

    });
