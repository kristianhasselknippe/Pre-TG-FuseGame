Fuse.Entities.Light = $CreateClass(
    function() {
        Fuse.Entities.Component.call(this);
    },
    function(S) {
        var I = S.prototype = new Fuse.Entities.Component;

        I.GetType = function()
        {
            return 829;
        };

        I.OnAdded = function(e)
        {
            e.add_ComponentHitTest($CreateDelegate(this, Fuse.Entities.Light.prototype.OnHitTest, 937));
        };

        I.OnRemoved = function(e)
        {
            e.remove_ComponentHitTest($CreateDelegate(this, Fuse.Entities.Light.prototype.OnHitTest, 937));
        };

        I.OnHitTest = function(sender, args)
        {
        };

    });
