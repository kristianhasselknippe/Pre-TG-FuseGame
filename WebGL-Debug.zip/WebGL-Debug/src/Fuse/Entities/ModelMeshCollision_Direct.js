Fuse.Entities.ModelMeshCollision_Direct = $CreateClass(
    function() {
        Fuse.Entities.TriangleMeshIntersecter.call(this);
        this._positions = null;
    },
    function(S) {
        var I = S.prototype = new Fuse.Entities.TriangleMeshIntersecter;

        I.GetType = function()
        {
            return 843;
        };

        I.GetTriangle = function(t)
        {
            var ind_123;
            var ind_124;
            var ind_125;
            var i = t * 3;
            return Uno.Geometry.Triangle.New_1((ind_123 = this._positions.GetFloat4(i), Uno.Float3.New_2(ind_123.X, ind_123.Y, ind_123.Z)), (ind_124 = this._positions.GetFloat4(i + 1), Uno.Float3.New_2(ind_124.X, ind_124.Y, ind_124.Z)), (ind_125 = this._positions.GetFloat4(i + 2), Uno.Float3.New_2(ind_125.X, ind_125.Y, ind_125.Z)));
        };

        I._ObjInit_1 = function(positions, vertexCount)
        {
            Fuse.Entities.TriangleMeshIntersecter.prototype._ObjInit.call(this, (vertexCount / 3) | 0);

            if (positions == null)
            {
                throw new $Error(Uno.Exception.New_1("positions can not be null"));
            }

            this._positions = positions;
        };

        Fuse.Entities.ModelMeshCollision_Direct.New_1 = function(positions, vertexCount)
        {
            var inst = new Fuse.Entities.ModelMeshCollision_Direct;
            inst._ObjInit_1(positions, vertexCount);
            return inst;
        };

    });
