Fuse.Entities.IndexedArrayMeshIntersecter = $CreateClass(
    function() {
        Fuse.Entities.TriangleMeshIntersecter.call(this);
        this._indices = null;
        this._positions = null;
    },
    function(S) {
        var I = S.prototype = new Fuse.Entities.TriangleMeshIntersecter;

        I.GetType = function()
        {
            return 842;
        };

        I.GetTriangle = function(t)
        {
            var i = t * 3;
            return Uno.Geometry.Triangle.New_1(this._positions[this._indices[i]], this._positions[this._indices[i + 1]], this._positions[this._indices[i + 2]]);
        };

    });
