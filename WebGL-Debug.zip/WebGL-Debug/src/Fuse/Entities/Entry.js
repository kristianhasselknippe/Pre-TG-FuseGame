Fuse.Entities.Entry = $CreateClass(
    function() {
        this.$struct = true;
        this.Mesh = null;
        this.World = new Uno.Float4x4;
        this.WorldInverse = new Uno.Float4x4;
    },
    function(S) {
        var I = S.prototype;

        I.GetType = function()
        {
            return 832;
        };

        I.op_Assign = function(value)
        {
            this.Mesh = value.Mesh;
            this.World.op_Assign(value.World);
            this.WorldInverse.op_Assign(value.WorldInverse);
        };

        I._ObjInit = function(m, t, worldInverse)
        {
            this.Mesh = m;
            this.World.op_Assign(t);
            this.WorldInverse.op_Assign(worldInverse);
        };

        Fuse.Entities.Entry.New_1 = function(m, t, worldInverse)
        {
            var inst = new Fuse.Entities.Entry;
            inst._ObjInit(m, t, worldInverse);
            return inst;
        };

    });
