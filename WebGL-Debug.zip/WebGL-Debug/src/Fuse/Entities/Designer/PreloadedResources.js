Fuse.Entities.Designer.PreloadedResources = $CreateClass(
    function() {
    },
    function(S) {
        Fuse.Entities.Designer.PreloadedResources.resources = null;

        Fuse.Entities.Designer.PreloadedResources._TypeInit = function()
        {
            Fuse.Entities.Designer.PreloadedResources.resources = Uno.Collections.Dictionary__string__object.New_1();
        };

    });
