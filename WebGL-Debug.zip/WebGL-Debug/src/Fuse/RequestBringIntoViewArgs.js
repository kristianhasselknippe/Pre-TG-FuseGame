Fuse.RequestBringIntoViewArgs = $CreateClass(
    function() {
        Uno.EventArgs.call(this);
        this._Element = null;
    },
    function(S) {
        var I = S.prototype = new Uno.EventArgs;

        I.GetType = function()
        {
            return 999;
        };

        I.Element = function(value)
        {
            if (value !== undefined)
            {
                this._Element = value;
            }
            else
            {
                return this._Element;
            }
        };

        I._ObjInit_1 = function(elm)
        {
            Uno.EventArgs.prototype._ObjInit.call(this);
            this.Element(elm);
        };

        Fuse.RequestBringIntoViewArgs.New_2 = function(elm)
        {
            var inst = new Fuse.RequestBringIntoViewArgs;
            inst._ObjInit_1(elm);
            return inst;
        };

    });
