Fuse.FocusManager = $CreateClass(
    function() {
    },
    function(S) {
        Fuse.FocusManager._focusedObject = null;
        Fuse.FocusManager._lastFocusedObject = null;
        Fuse.FocusManager.ChangedFocus = null;

        Fuse.FocusManager.FocusedObject = function(value)
        {
            if (value !== undefined)
            {
                Fuse.FocusManager.ChangeFocusedObject(value);
            }
            else
            {
                return Fuse.FocusManager._focusedObject;
            }
        };

        Fuse.FocusManager.OnWindowGotFocus = function(sender, args)
        {
            Fuse.FocusManager.FocusedObject(Fuse.FocusManager._lastFocusedObject);
        };

        Fuse.FocusManager.OnWindowLostFocus = function(sender, args)
        {
            Fuse.FocusManager.SetFocusedObject(null);
        };

        Fuse.FocusManager.Move = function(direction)
        {
            var predictedFocus = Fuse.FocusManager.Predict(direction);

            if (predictedFocus == null)
            {
                return;
            }

            Fuse.FocusManager.FocusedObject(predictedFocus);
        };

        Fuse.FocusManager.Predict = function(direction)
        {
            if (Fuse.FocusManager._focusedObject == null)
            {
                var root = Fuse.FocusManager.FindRoot(null);

                if (root != null)
                {
                    return root["Fuse.INode.PredictFocus"](direction);
                }
            }

            return Fuse.FocusManager._focusedObject["Fuse.INode.PredictFocus"](direction);
        };

        Fuse.FocusManager.ChangeFocusedObject = function(node)
        {
            if (!Fuse.FocusManager.CanSetFocus(node))
            {
                node = Fuse.FocusManager.FindRoot(node);
            }

            Fuse.FocusManager.SetFocusedObject(node);
        };

        Fuse.FocusManager.CanSetFocus = function(node)
        {
            return ((node != null) && node["Fuse.INode.IsEnabled"]()) && node["Fuse.INode.IsFocusable"]();
        };

        Fuse.FocusManager.SetFocusedObject = function(node)
        {
            if (node == Fuse.FocusManager._focusedObject)
            {
                return;
            }

            if (Fuse.FocusManager._focusedObject != null)
            {
                Fuse.FocusManager._focusedObject["Fuse.INode.RaiseEvent"](Fuse.LostFocusArgs.New_2());
            }

            Fuse.FocusManager._lastFocusedObject = Fuse.FocusManager._focusedObject;
            Fuse.FocusManager._focusedObject = node;

            if (Uno.Delegate.op_Inequality(Fuse.FocusManager.ChangedFocus, null))
            {
                Fuse.FocusManager.ChangedFocus.Invoke(Fuse.FocusManager._lastFocusedObject, Fuse.ChangedFocusArgs.New_2(Fuse.FocusManager._lastFocusedObject, Fuse.FocusManager._focusedObject));
            }

            if (Fuse.FocusManager._focusedObject != null)
            {
                Fuse.FocusManager._focusedObject["Fuse.INode.RaiseEvent"](Fuse.GotFocusArgs.New_2());
            }
        };

        Fuse.FocusManager.FindRoot = function(node)
        {
            if (node == null)
            {
                var app = $AsOp(Uno.Application.Current(), 913);

                if (app != null)
                {
                    return $DownCast(app, 33719);
                }
            }

            var o = null;

            for (var r = node; r != null; r = r["Fuse.INode.Parent"]())
            {
                o = r;
            }

            return o;
        };

    });
