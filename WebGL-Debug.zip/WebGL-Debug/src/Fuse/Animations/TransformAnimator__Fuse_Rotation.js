Fuse.Animations.TransformAnimator__Fuse_Rotation = $CreateClass(
    function() {
        Fuse.Animations.Animator.call(this);
        this._Target = null;
    },
    function(S) {
        var I = S.prototype = new Fuse.Animations.Animator;

        I.GetType = function()
        {
            return 633;
        };

        I.Target = function(value)
        {
            if (value !== undefined)
            {
                this._Target = value;
            }
            else
            {
                return this._Target;
            }
        };

        I.CreateState = function(variant, elm)
        {
            var ind_123;
            return Fuse.Animations.TransformAnimatorState__Fuse_Rotation.New_1(this, variant, (ind_123 = this.Target(), (ind_123 != null) ? ind_123 : elm));
        };

    });
