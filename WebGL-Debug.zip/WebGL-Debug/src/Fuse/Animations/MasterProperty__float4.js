Fuse.Animations.MasterProperty__float4 = $CreateClass(
    function() {
        Fuse.Animations.MasterBase__float4.call(this);
        this.Property = null;
    },
    function(S) {
        var I = S.prototype = new Fuse.Animations.MasterBase__float4;

        I.GetType = function()
        {
            return 676;
        };

        I.RestValue = function()
        {
            return this.Property.GetRestState();
        };

        I.OnInactive = function()
        {
            this.Property.Set(this.RestValue());
        };

        I._ObjInit_1 = function(property)
        {
            Fuse.Animations.MasterBase__float4.prototype._ObjInit.call(this);
            this.Property = property;
        };

    });
