Fuse.Animations.MixerHandle__Fuse_Transform = $CreateClass(
    function() {
        this.Value = null;
        this.Strength = 0;
        this._hasValue = false;
        this.Master = null;
    },
    function(S) {
        var I = S.prototype;

        I.GetType = function()
        {
            return 625;
        };

        I.$II = function(id)
        {
            return [623].indexOf(id) != -1;
        };

        I.HasValue = function()
        {
            return this._hasValue;
        };

        I.Unregister = function()
        {
            this.Master.Unregister(this);
            this._hasValue = false;
            this.Master.DirtyValue = true;
        };

        I.Set = function(value, strength)
        {
            this._hasValue = true;
            this.Value = value;
            this.Strength = strength;
            this.Master.DirtyValue = true;
        };

        I._ObjInit = function(master)
        {
            this.Master = master;
            this.Master.Register(this);
        };

        Fuse.Animations.MixerHandle__Fuse_Transform.New_1 = function(master)
        {
            var inst = new Fuse.Animations.MixerHandle__Fuse_Transform;
            inst._ObjInit(master);
            return inst;
        };

        I["Fuse.Animations.IMixerHandle__Fuse_Transform.Unregister"] = I.Unregister;
        I["Fuse.Animations.IMixerHandle__Fuse_Transform.Set"] = I.Set;

    });
