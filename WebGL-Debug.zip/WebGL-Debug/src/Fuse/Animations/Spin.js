Fuse.Animations.Spin = $CreateClass(
    function() {
        Fuse.Animations.Animator.call(this);
        this._Target = null;
    },
    function(S) {
        var I = S.prototype = new Fuse.Animations.Animator;

        I.GetType = function()
        {
            return 610;
        };

        I.Target = function(value)
        {
            if (value !== undefined)
            {
                this._Target = value;
            }
            else
            {
                return this._Target;
            }
        };

        I.HasDirectionVariant = function()
        {
            return false;
        };

        I.CreateState = function(variant, elm)
        {
            var ind_123;
            return Fuse.Animations.SpinState.New_1(this, variant, (ind_123 = this.Target(), (ind_123 != null) ? ind_123 : elm));
        };

    });
