Fuse.Animations.ChangeFloat4 = $CreateClass(
    function() {
        Fuse.Animations.PropertyAnimator__float4.call(this);
    },
    function(S) {
        var I = S.prototype = new Fuse.Animations.PropertyAnimator__float4;

        I.GetType = function()
        {
            return 609;
        };

        I._ObjInit_2 = function()
        {
            Fuse.Animations.PropertyAnimator__float4.prototype._ObjInit_1.call(this);
        };

        Fuse.Animations.ChangeFloat4.New_1 = function()
        {
            var inst = new Fuse.Animations.ChangeFloat4;
            inst._ObjInit_2();
            return inst;
        };

    });
