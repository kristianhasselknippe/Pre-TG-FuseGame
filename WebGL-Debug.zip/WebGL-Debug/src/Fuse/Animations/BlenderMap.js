Fuse.Animations.BlenderMap = $CreateClass(
    function() {
    },
    function(S) {
        var I = S.prototype;

        Fuse.Animations.BlenderMap._blenders = null;

        I.GetType = function()
        {
            return 593;
        };

        Fuse.Animations.BlenderMap.Get__float4 = function(value)
        {
            var blender;

            if (!Fuse.Animations.BlenderMap._blenders.TryGetValue($CopyStruct(value).GetType(), $CreateRef(function(){return blender}, function($){blender=$}, this)))
            {
                if ($CopyStruct(value).GetType() == 429)
                {
                    blender = Fuse.Animations.FloatBlender.New_1();
                }
                else if ($CopyStruct(value).GetType() == 430)
                {
                    blender = Fuse.Animations.Float2Blender.New_1();
                }
                else if ($CopyStruct(value).GetType() == 431)
                {
                    blender = Fuse.Animations.Float3Blender.New_1();
                }
                else if ($CopyStruct(value).GetType() == 432)
                {
                    blender = Fuse.Animations.Float4Blender.New_1();
                }
                else
                {
                    throw new $Error(Uno.Exception.New_1("Unsupported blender type"));
                }

                Fuse.Animations.BlenderMap._blenders.Add($CopyStruct(value).GetType(), blender);
            }

            return $DownCast(blender, 33390);
        };

        Fuse.Animations.BlenderMap.Get__float = function(value)
        {
            var blender;

            if (!Fuse.Animations.BlenderMap._blenders.TryGetValue($CreateBox(value, 429).GetType(), $CreateRef(function(){return blender}, function($){blender=$}, this)))
            {
                if ($CreateBox(value, 429).GetType() == 429)
                {
                    blender = Fuse.Animations.FloatBlender.New_1();
                }
                else if ($CreateBox(value, 429).GetType() == 430)
                {
                    blender = Fuse.Animations.Float2Blender.New_1();
                }
                else if ($CreateBox(value, 429).GetType() == 431)
                {
                    blender = Fuse.Animations.Float3Blender.New_1();
                }
                else if ($CreateBox(value, 429).GetType() == 432)
                {
                    blender = Fuse.Animations.Float4Blender.New_1();
                }
                else
                {
                    throw new $Error(Uno.Exception.New_1("Unsupported blender type"));
                }

                Fuse.Animations.BlenderMap._blenders.Add($CreateBox(value, 429).GetType(), blender);
            }

            return $DownCast(blender, 33387);
        };

        Fuse.Animations.BlenderMap.Get__float2 = function(value)
        {
            var blender;

            if (!Fuse.Animations.BlenderMap._blenders.TryGetValue($CopyStruct(value).GetType(), $CreateRef(function(){return blender}, function($){blender=$}, this)))
            {
                if ($CopyStruct(value).GetType() == 429)
                {
                    blender = Fuse.Animations.FloatBlender.New_1();
                }
                else if ($CopyStruct(value).GetType() == 430)
                {
                    blender = Fuse.Animations.Float2Blender.New_1();
                }
                else if ($CopyStruct(value).GetType() == 431)
                {
                    blender = Fuse.Animations.Float3Blender.New_1();
                }
                else if ($CopyStruct(value).GetType() == 432)
                {
                    blender = Fuse.Animations.Float4Blender.New_1();
                }
                else
                {
                    throw new $Error(Uno.Exception.New_1("Unsupported blender type"));
                }

                Fuse.Animations.BlenderMap._blenders.Add($CopyStruct(value).GetType(), blender);
            }

            return $DownCast(blender, 33388);
        };

        Fuse.Animations.BlenderMap.Get__float3 = function(value)
        {
            var blender;

            if (!Fuse.Animations.BlenderMap._blenders.TryGetValue($CopyStruct(value).GetType(), $CreateRef(function(){return blender}, function($){blender=$}, this)))
            {
                if ($CopyStruct(value).GetType() == 429)
                {
                    blender = Fuse.Animations.FloatBlender.New_1();
                }
                else if ($CopyStruct(value).GetType() == 430)
                {
                    blender = Fuse.Animations.Float2Blender.New_1();
                }
                else if ($CopyStruct(value).GetType() == 431)
                {
                    blender = Fuse.Animations.Float3Blender.New_1();
                }
                else if ($CopyStruct(value).GetType() == 432)
                {
                    blender = Fuse.Animations.Float4Blender.New_1();
                }
                else
                {
                    throw new $Error(Uno.Exception.New_1("Unsupported blender type"));
                }

                Fuse.Animations.BlenderMap._blenders.Add($CopyStruct(value).GetType(), blender);
            }

            return $DownCast(blender, 33389);
        };

        Fuse.Animations.BlenderMap.Get__Fuse_Visibility = function(value)
        {
            var blender;

            if (!Fuse.Animations.BlenderMap._blenders.TryGetValue($CreateBox(value, 1004).GetType(), $CreateRef(function(){return blender}, function($){blender=$}, this)))
            {
                if ($CreateBox(value, 1004).GetType() == 429)
                {
                    blender = Fuse.Animations.FloatBlender.New_1();
                }
                else if ($CreateBox(value, 1004).GetType() == 430)
                {
                    blender = Fuse.Animations.Float2Blender.New_1();
                }
                else if ($CreateBox(value, 1004).GetType() == 431)
                {
                    blender = Fuse.Animations.Float3Blender.New_1();
                }
                else if ($CreateBox(value, 1004).GetType() == 432)
                {
                    blender = Fuse.Animations.Float4Blender.New_1();
                }
                else
                {
                    throw new $Error(Uno.Exception.New_1("Unsupported blender type"));
                }

                Fuse.Animations.BlenderMap._blenders.Add($CreateBox(value, 1004).GetType(), blender);
            }

            return $DownCast(blender, 33436);
        };

        Fuse.Animations.BlenderMap.Get__bool = function(value)
        {
            var blender;

            if (!Fuse.Animations.BlenderMap._blenders.TryGetValue($CreateBox(value, 419).GetType(), $CreateRef(function(){return blender}, function($){blender=$}, this)))
            {
                if ($CreateBox(value, 419).GetType() == 429)
                {
                    blender = Fuse.Animations.FloatBlender.New_1();
                }
                else if ($CreateBox(value, 419).GetType() == 430)
                {
                    blender = Fuse.Animations.Float2Blender.New_1();
                }
                else if ($CreateBox(value, 419).GetType() == 431)
                {
                    blender = Fuse.Animations.Float3Blender.New_1();
                }
                else if ($CreateBox(value, 419).GetType() == 432)
                {
                    blender = Fuse.Animations.Float4Blender.New_1();
                }
                else
                {
                    throw new $Error(Uno.Exception.New_1("Unsupported blender type"));
                }

                Fuse.Animations.BlenderMap._blenders.Add($CreateBox(value, 419).GetType(), blender);
            }

            return $DownCast(blender, 33437);
        };

        Fuse.Animations.BlenderMap._TypeInit = function()
        {
            Fuse.Animations.BlenderMap._blenders = Uno.Collections.Dictionary__Uno_Type__object.New_1();
        };

    });
