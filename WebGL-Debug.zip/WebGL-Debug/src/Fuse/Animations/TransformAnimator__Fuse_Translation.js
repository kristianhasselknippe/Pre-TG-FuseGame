Fuse.Animations.TransformAnimator__Fuse_Translation = $CreateClass(
    function() {
        Fuse.Animations.Animator.call(this);
        this._Target = null;
    },
    function(S) {
        var I = S.prototype = new Fuse.Animations.Animator;

        I.GetType = function()
        {
            return 632;
        };

        I.Target = function(value)
        {
            if (value !== undefined)
            {
                this._Target = value;
            }
            else
            {
                return this._Target;
            }
        };

        I.CreateState = function(variant, elm)
        {
            var ind_123;
            return Fuse.Animations.TransformAnimatorState__Fuse_Translation.New_1(this, variant, (ind_123 = this.Target(), (ind_123 != null) ? ind_123 : elm));
        };

        I._ObjInit_1 = function()
        {
            Fuse.Animations.Animator.prototype._ObjInit.call(this);
            this.Mixer = Fuse.Animations.Mixer.DefaultTransform();
        };

    });
