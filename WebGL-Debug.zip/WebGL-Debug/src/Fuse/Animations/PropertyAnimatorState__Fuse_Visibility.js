Fuse.Animations.PropertyAnimatorState__Fuse_Visibility = $CreateClass(
    function() {
        Fuse.Animations.AnimatorStateProgress.call(this);
        this.mixHandle = null;
        this.Animator_1 = null;
    },
    function(S) {
        var I = S.prototype = new Fuse.Animations.AnimatorStateProgress;

        I.GetType = function()
        {
            return 645;
        };

        I.Disable = function()
        {
            if (this.mixHandle == null)
            {
                return;
            }

            this.mixHandle["Fuse.Animations.IMixerHandle__Fuse_Visibility.Unregister"]();
            this.mixHandle = null;
        };

        I.Seek = function(progress, strength)
        {
            if (this.mixHandle == null)
            {
                Uno.Diagnostics.Debug.Log("Invalid Seek", 1, "/Users/vegard/RealtimeStudio/Uno/Packages/Fuse.Nodes/0.1.0/Animations/PropertyAnimator.uno", 45);
                return;
            }

            this.mixHandle["Fuse.Animations.IMixerHandle__Fuse_Visibility.Set"](this.Animator_1.Value(), strength * progress);
        };

        I._ObjInit_2 = function(animator, variant, node)
        {
            Fuse.Animations.AnimatorStateProgress.prototype._ObjInit_1.call(this, animator, variant, node);
            this.Animator_1 = animator;
            this.mixHandle = this.Animator_1.Mixer["Fuse.Animations.IMixer.Register__Fuse_Visibility"](this.Animator_1.Target());
        };

        Fuse.Animations.PropertyAnimatorState__Fuse_Visibility.New_1 = function(animator, variant, node)
        {
            var inst = new Fuse.Animations.PropertyAnimatorState__Fuse_Visibility;
            inst._ObjInit_2(animator, variant, node);
            return inst;
        };

    });
