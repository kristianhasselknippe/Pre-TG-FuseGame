Fuse.Animations.Float4Blender = $CreateClass(
    function() {
    },
    function(S) {
        var I = S.prototype;

        I.GetType = function()
        {
            return 597;
        };

        I.$II = function(id)
        {
            return [622].indexOf(id) != -1;
        };

        I.Weight = function(v, w)
        {
            return Uno.Float4.op_Multiply(v, w);
        };

        I.Add = function(a, b)
        {
            return Uno.Float4.op_Addition(a, b);
        };

        I._ObjInit = function()
        {
        };

        Fuse.Animations.Float4Blender.New_1 = function()
        {
            var inst = new Fuse.Animations.Float4Blender;
            inst._ObjInit();
            return inst;
        };

        I["Fuse.Animations.Blender__float4.Weight"] = I.Weight;
        I["Fuse.Animations.Blender__float4.Add"] = I.Add;

    });
