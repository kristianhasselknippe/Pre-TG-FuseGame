Fuse.Animations.AverageMasterProperty__float = $CreateClass(
    function() {
        Fuse.Animations.MasterProperty__float.call(this);
        this.blender = null;
    },
    function(S) {
        var I = S.prototype = new Fuse.Animations.MasterProperty__float;

        I.GetType = function()
        {
            return 663;
        };

        I.OnActive = function()
        {
            if (this.blender == null)
            {
                this.blender = Fuse.Animations.BlenderMap.Get__float(this.RestValue());
            }
        };

        I.OnComplete = function()
        {
            var fullWeight = 0.0;

            for (var enum_123 = this.Handles.GetEnumerator(); enum_123.MoveNext(); )
            {
                var v = enum_123.Current();
                fullWeight = fullWeight + (v.HasValue() ? v.Strength : 0.0);
            }

            var restWeight = 1.0 - Uno.Math.Min_1(fullWeight, 1.0);
            fullWeight = Uno.Math.Max_1(1.0, fullWeight);
            var nv = this.blender["Fuse.Animations.Blender__float.Weight"](this.RestValue(), restWeight / fullWeight);

            for (var enum_124 = this.Handles.GetEnumerator(); enum_124.MoveNext(); )
            {
                var v = enum_124.Current();

                if (v.HasValue())
                {
                    nv = this.blender["Fuse.Animations.Blender__float.Add"](nv, this.blender["Fuse.Animations.Blender__float.Weight"](v.Value, v.Strength / fullWeight));
                }
            }

            this.Property.Set(nv);
        };

        I._ObjInit_2 = function(property)
        {
            Fuse.Animations.MasterProperty__float.prototype._ObjInit_1.call(this, property);
        };

        Fuse.Animations.AverageMasterProperty__float.New_1 = function(property)
        {
            var inst = new Fuse.Animations.AverageMasterProperty__float;
            inst._ObjInit_2(property);
            return inst;
        };

    });
