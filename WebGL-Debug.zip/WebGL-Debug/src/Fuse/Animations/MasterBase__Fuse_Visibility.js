Fuse.Animations.MasterBase__Fuse_Visibility = $CreateClass(
    function() {
        this.Handles = null;
        this.masterAdded = false;
        this.DirtyValue = false;
    },
    function(S) {
        var I = S.prototype;

        I.GetType = function()
        {
            return 654;
        };

        I.$II = function(id)
        {
            return [602].indexOf(id) != -1;
        };

        I.PostLayout = function()
        {
            return false;
        };

        I.Register = function(handle)
        {
            this.Handles.Add(handle);

            if (!this.masterAdded)
            {
                this.masterAdded = true;
                Fuse.Animations.Mixer.AddMaster($DownCast(this, 33370), this.PostLayout());
                this.OnActive();
            }
        };

        I.Unregister = function(handle)
        {
            this.Handles.Remove(handle);
        };

        I.OnActive = function()
        {
        };

        I.Complete = function()
        {
            if (this.Handles.Count() == 0)
            {
                if (this.masterAdded)
                {
                    Fuse.Animations.Mixer.RemoveMaster($DownCast(this, 33370), this.PostLayout());
                    this.masterAdded = false;
                    this.OnInactive();
                }

                return;
            }

            if (this.DirtyValue)
            {
                this.OnComplete();
                this.DirtyValue = false;
            }
        };

        I._ObjInit = function()
        {
            this.Handles = Uno.Collections.List__Fuse_Animations_MixerHandle_Fuse_Visibility_.New_1();
        };

        I["Fuse.Animations.IMixerMaster.Complete"] = I.Complete;

    });
