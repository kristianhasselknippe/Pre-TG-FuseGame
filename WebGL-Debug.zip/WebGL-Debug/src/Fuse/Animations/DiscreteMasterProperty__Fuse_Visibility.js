Fuse.Animations.DiscreteMasterProperty__Fuse_Visibility = $CreateClass(
    function() {
        Fuse.Animations.MasterProperty__Fuse_Visibility.call(this);
    },
    function(S) {
        var I = S.prototype = new Fuse.Animations.MasterProperty__Fuse_Visibility;

        I.GetType = function()
        {
            return 674;
        };

        I.OnComplete = function()
        {
            var nv = this.RestValue();
            var str = 0.5;

            for (var enum_123 = this.Handles.GetEnumerator(); enum_123.MoveNext(); )
            {
                var v = enum_123.Current();

                if (v.HasValue() && (v.Strength > str))
                {
                    nv = v.Value;
                    str = v.Strength;
                }
            }

            this.Property.Set(nv);
        };

        I._ObjInit_2 = function(property)
        {
            Fuse.Animations.MasterProperty__Fuse_Visibility.prototype._ObjInit_1.call(this, property);
        };

        Fuse.Animations.DiscreteMasterProperty__Fuse_Visibility.New_1 = function(property)
        {
            var inst = new Fuse.Animations.DiscreteMasterProperty__Fuse_Visibility;
            inst._ObjInit_2(property);
            return inst;
        };

    });
