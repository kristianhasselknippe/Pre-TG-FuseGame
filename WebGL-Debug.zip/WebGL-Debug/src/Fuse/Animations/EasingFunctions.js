Fuse.Animations.EasingFunctions = $CreateClass(
    function() {
    },
    function(S) {

        Fuse.Animations.EasingFunctions.FromEasing = function(e)
        {
            switch (e)
            {
                case 0:
                {
                    return $CreateDelegate(null, Fuse.Animations.EasingFunctions.Linear, 583);
                }
                case 1:
                {
                    return $CreateDelegate(null, Fuse.Animations.EasingFunctions.QuadraticIn, 583);
                }
                case 2:
                {
                    return $CreateDelegate(null, Fuse.Animations.EasingFunctions.QuadraticOut, 583);
                }
                case 3:
                {
                    return $CreateDelegate(null, Fuse.Animations.EasingFunctions.QuadraticInOut, 583);
                }
                case 4:
                {
                    return $CreateDelegate(null, Fuse.Animations.EasingFunctions.CubicIn, 583);
                }
                case 5:
                {
                    return $CreateDelegate(null, Fuse.Animations.EasingFunctions.CubicOut, 583);
                }
                case 6:
                {
                    return $CreateDelegate(null, Fuse.Animations.EasingFunctions.CubicInOut, 583);
                }
                case 7:
                {
                    return $CreateDelegate(null, Fuse.Animations.EasingFunctions.QuarticIn, 583);
                }
                case 8:
                {
                    return $CreateDelegate(null, Fuse.Animations.EasingFunctions.QuarticOut, 583);
                }
                case 9:
                {
                    return $CreateDelegate(null, Fuse.Animations.EasingFunctions.QuarticInOut, 583);
                }
                case 10:
                {
                    return $CreateDelegate(null, Fuse.Animations.EasingFunctions.QuinticIn, 583);
                }
                case 11:
                {
                    return $CreateDelegate(null, Fuse.Animations.EasingFunctions.QuinticOut, 583);
                }
                case 12:
                {
                    return $CreateDelegate(null, Fuse.Animations.EasingFunctions.QuinticInOut, 583);
                }
                case 13:
                {
                    return $CreateDelegate(null, Fuse.Animations.EasingFunctions.SinusoidalIn, 583);
                }
                case 14:
                {
                    return $CreateDelegate(null, Fuse.Animations.EasingFunctions.SinusoidalOut, 583);
                }
                case 15:
                {
                    return $CreateDelegate(null, Fuse.Animations.EasingFunctions.SinusoidalInOut, 583);
                }
                case 16:
                {
                    return $CreateDelegate(null, Fuse.Animations.EasingFunctions.ExponentialIn, 583);
                }
                case 17:
                {
                    return $CreateDelegate(null, Fuse.Animations.EasingFunctions.ExponentialOut, 583);
                }
                case 18:
                {
                    return $CreateDelegate(null, Fuse.Animations.EasingFunctions.ExponentialInOut, 583);
                }
                case 19:
                {
                    return $CreateDelegate(null, Fuse.Animations.EasingFunctions.CircularIn, 583);
                }
                case 20:
                {
                    return $CreateDelegate(null, Fuse.Animations.EasingFunctions.CircularOut, 583);
                }
                case 21:
                {
                    return $CreateDelegate(null, Fuse.Animations.EasingFunctions.CircularInOut, 583);
                }
                case 22:
                {
                    return $CreateDelegate(null, Fuse.Animations.EasingFunctions.ElasticIn, 583);
                }
                case 23:
                {
                    return $CreateDelegate(null, Fuse.Animations.EasingFunctions.ElasticOut, 583);
                }
                case 24:
                {
                    return $CreateDelegate(null, Fuse.Animations.EasingFunctions.ElasticInOut, 583);
                }
                case 25:
                {
                    return $CreateDelegate(null, Fuse.Animations.EasingFunctions.BackIn, 583);
                }
                case 26:
                {
                    return $CreateDelegate(null, Fuse.Animations.EasingFunctions.BackOut, 583);
                }
                case 27:
                {
                    return $CreateDelegate(null, Fuse.Animations.EasingFunctions.BackInOut, 583);
                }
                case 28:
                {
                    return $CreateDelegate(null, Fuse.Animations.EasingFunctions.BounceIn, 583);
                }
                case 29:
                {
                    return $CreateDelegate(null, Fuse.Animations.EasingFunctions.BounceOut, 583);
                }
                case 30:
                {
                    return $CreateDelegate(null, Fuse.Animations.EasingFunctions.BounceInOut, 583);
                }
                default:
                {
                    return $CreateDelegate(null, Fuse.Animations.EasingFunctions.Linear, 583);
                }
            }
        };

        Fuse.Animations.EasingFunctions.Linear = function(k)
        {
            return k;
        };

        Fuse.Animations.EasingFunctions.QuadraticIn = function(k)
        {
            return k * k;
        };

        Fuse.Animations.EasingFunctions.QuadraticOut = function(k)
        {
            return k * (2.0 - k);
        };

        Fuse.Animations.EasingFunctions.QuadraticInOut = function(k)
        {
            if ((k = k * 2.0) < 1.0)
            {
                return (0.5 * k) * k;
            }

            k = k - 1.0;
            return -0.5 * ((k * (k - 2.0)) - 1.0);
        };

        Fuse.Animations.EasingFunctions.CubicIn = function(k)
        {
            return (k * k) * k;
        };

        Fuse.Animations.EasingFunctions.CubicOut = function(k)
        {
            k = k - 1.0;
            return ((k * k) * k) + 1.0;
        };

        Fuse.Animations.EasingFunctions.CubicInOut = function(k)
        {
            if ((k = k * 2.0) < 1.0)
            {
                return ((0.5 * k) * k) * k;
            }

            return 0.5 * ((((k = k - 2.0) * k) * k) + 2.0);
        };

        Fuse.Animations.EasingFunctions.QuarticIn = function(k)
        {
            return ((k * k) * k) * k;
        };

        Fuse.Animations.EasingFunctions.QuarticOut = function(k)
        {
            k = k - 1.0;
            return 1.0 - (((k * k) * k) * k);
        };

        Fuse.Animations.EasingFunctions.QuarticInOut = function(k)
        {
            if ((k = k * 2.0) < 1.0)
            {
                return (((0.5 * k) * k) * k) * k;
            }

            return -0.5 * (((((k = k - 2.0) * k) * k) * k) - 2.0);
        };

        Fuse.Animations.EasingFunctions.QuinticIn = function(k)
        {
            return (((k * k) * k) * k) * k;
        };

        Fuse.Animations.EasingFunctions.QuinticOut = function(k)
        {
            k = k - 1.0;
            return ((((k * k) * k) * k) * k) + 1.0;
        };

        Fuse.Animations.EasingFunctions.QuinticInOut = function(k)
        {
            if ((k = k * 2.0) < 1.0)
            {
                return ((((0.5 * k) * k) * k) * k) * k;
            }

            return 0.5 * ((((((k = k - 2.0) * k) * k) * k) * k) + 2.0);
        };

        Fuse.Animations.EasingFunctions.SinusoidalIn = function(k)
        {
            return 1.0 - Uno.Math.Cos_1((k * 3.14159274) / 2.0);
        };

        Fuse.Animations.EasingFunctions.SinusoidalOut = function(k)
        {
            return Uno.Math.Sin_1((k * 3.14159274) / 2.0);
        };

        Fuse.Animations.EasingFunctions.SinusoidalInOut = function(k)
        {
            return 0.5 * (1.0 - Uno.Math.Cos_1(3.14159274 * k));
        };

        Fuse.Animations.EasingFunctions.ExponentialIn = function(k)
        {
            return (k == 0.0) ? 0.0 : Uno.Math.Pow_1(1024.0, k - 1.0);
        };

        Fuse.Animations.EasingFunctions.ExponentialOut = function(k)
        {
            return (k == 1.0) ? 1.0 : (1.0 - Uno.Math.Pow_1(2.0, -10.0 * k));
        };

        Fuse.Animations.EasingFunctions.ExponentialInOut = function(k)
        {
            if (k == 0.0)
            {
                return 0.0;
            }

            if (k == 1.0)
            {
                return 1.0;
            }

            if ((k = k * 2.0) < 1.0)
            {
                return 0.5 * Uno.Math.Pow_1(1024.0, k - 1.0);
            }

            return 0.5 * (-Uno.Math.Pow_1(2.0, -10.0 * (k - 1.0)) + 2.0);
        };

        Fuse.Animations.EasingFunctions.CircularIn = function(k)
        {
            return 1.0 - Uno.Math.Sqrt_1(1.0 - (k * k));
        };

        Fuse.Animations.EasingFunctions.CircularOut = function(k)
        {
            k = k - 1.0;
            return Uno.Math.Sqrt_1(1.0 - (k * k));
        };

        Fuse.Animations.EasingFunctions.CircularInOut = function(k)
        {
            if ((k = k * 2.0) < 1.0)
            {
                return -0.5 * (Uno.Math.Sqrt_1(1.0 - (k * k)) - 1.0);
            }

            return 0.5 * (Uno.Math.Sqrt_1(1.0 - ((k = k - 2.0) * k)) + 1.0);
        };

        Fuse.Animations.EasingFunctions.ElasticIn = function(k)
        {
            var s = 0.0;
            var a = 0.1;
            var p = 0.4;

            if (k == 0.0)
            {
                return 0.0;
            }

            if (k == 1.0)
            {
                return 1.0;
            }

            if ((a != 0.0) || (a < 1.0))
            {
                a = 1.0;
                s = p / 4.0;
            }
            else
            {
                s = (p * Uno.Math.Asin_1(1.0 / a)) / 6.28318548;
            }

            return -((a * Uno.Math.Pow_1(2.0, 10.0 * (k = k - 1.0))) * Uno.Math.Sin_1(((k - s) * 6.28318548) / p));
        };

        Fuse.Animations.EasingFunctions.ElasticOut = function(k)
        {
            var s = 0.0;
            var a = 0.1;
            var p = 0.4;

            if (k == 0.0)
            {
                return 0.0;
            }

            if (k == 1.0)
            {
                return 1.0;
            }

            if ((a != 0.0) || (a < 1.0))
            {
                a = 1.0;
                s = p / 4.0;
            }
            else
            {
                s = (p * Uno.Math.Asin_1(1.0 / a)) / 6.28318548;
            }

            return ((a * Uno.Math.Pow_1(2.0, -10.0 * k)) * Uno.Math.Sin_1(((k - s) * 6.28318548) / p)) + 1.0;
        };

        Fuse.Animations.EasingFunctions.ElasticInOut = function(k)
        {
            var s = 0.0;
            var a = 0.1;
            var p = 0.4;

            if (k == 0.0)
            {
                return 0.0;
            }

            if (k == 1.0)
            {
                return 1.0;
            }

            if ((a != 0.0) || (a < 1.0))
            {
                a = 1.0;
                s = p / 4.0;
            }
            else
            {
                s = (p * Uno.Math.Asin_1(1.0 / a)) / 6.28318548;
            }

            if ((k = k * 2.0) < 1.0)
            {
                return -0.5 * ((a * Uno.Math.Pow_1(2.0, 10.0 * (k = k - 1.0))) * Uno.Math.Sin_1(((k - s) * 6.28318548) / p));
            }

            return (((a * Uno.Math.Pow_1(2.0, -10.0 * (k = k - 1.0))) * Uno.Math.Sin_1(((k - s) * 6.28318548) / p)) * 0.5) + 1.0;
        };

        Fuse.Animations.EasingFunctions.BackIn = function(k)
        {
            var s = 1.70158;
            return (k * k) * (((s + 1.0) * k) - s);
        };

        Fuse.Animations.EasingFunctions.BackOut = function(k)
        {
            var s = 1.70158;
            k = k - 1.0;
            return ((k * k) * (((s + 1.0) * k) + s)) + 1.0;
        };

        Fuse.Animations.EasingFunctions.BackInOut = function(k)
        {
            var s = 2.59490943;

            if ((k = k * 2.0) < 1.0)
            {
                return 0.5 * ((k * k) * (((s + 1.0) * k) - s));
            }

            return 0.5 * ((((k = k - 2.0) * k) * (((s + 1.0) * k) + s)) + 2.0);
        };

        Fuse.Animations.EasingFunctions.BounceIn = function(k)
        {
            return 1.0 - Fuse.Animations.EasingFunctions.BounceOut(1.0 - k);
        };

        Fuse.Animations.EasingFunctions.BounceOut = function(k)
        {
            if (k < 0.363636374)
            {
                return (7.5625 * k) * k;
            }
            else if (k < 0.727272749)
            {
                return ((7.5625 * (k = k - 0.545454562)) * k) + 0.75;
            }
            else if (k < 0.909090936)
            {
                return ((7.562 * (k = k - 0.8181818)) * k) + 0.9375;
            }
            else
            {
                return ((7.5625 * (k = k - 0.954545438)) * k) + 0.984375;
            }
        };

        Fuse.Animations.EasingFunctions.BounceInOut = function(k)
        {
            if (k < 0.5)
            {
                return Fuse.Animations.EasingFunctions.BounceIn(k * 2.0) * 0.5;
            }

            return (Fuse.Animations.EasingFunctions.BounceOut((k * 2.0) - 1.0) * 0.5) + 0.5;
        };

    });
