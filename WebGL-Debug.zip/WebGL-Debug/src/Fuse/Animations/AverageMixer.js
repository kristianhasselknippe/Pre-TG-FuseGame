Fuse.Animations.AverageMixer = $CreateClass(
    function() {
        Fuse.Animations.MixerBase.call(this);
    },
    function(S) {
        var I = S.prototype = new Fuse.Animations.MixerBase;

        I.GetType = function()
        {
            return 591;
        };

        I.CreateMasterTransform = function(element)
        {
            return Fuse.Animations.AverageMasterTransform.New_1(element);
        };

        I.CreateMaster__float4 = function(property)
        {
            return Fuse.Animations.AverageMasterProperty__float4.New_1(property);
        };

        I.CreateMaster__float = function(property)
        {
            return Fuse.Animations.AverageMasterProperty__float.New_1(property);
        };

        I.CreateMaster__float2 = function(property)
        {
            return Fuse.Animations.AverageMasterProperty__float2.New_1(property);
        };

        I.CreateMaster__float3 = function(property)
        {
            return Fuse.Animations.AverageMasterProperty__float3.New_1(property);
        };

        I.CreateMaster__Fuse_Visibility = function(property)
        {
            return Fuse.Animations.AverageMasterProperty__Fuse_Visibility.New_1(property);
        };

        I.CreateMaster__bool = function(property)
        {
            return Fuse.Animations.AverageMasterProperty__bool.New_1(property);
        };

        I._ObjInit_1 = function()
        {
            Fuse.Animations.MixerBase.prototype._ObjInit.call(this);
        };

        Fuse.Animations.AverageMixer.New_1 = function()
        {
            var inst = new Fuse.Animations.AverageMixer;
            inst._ObjInit_1();
            return inst;
        };

    });
