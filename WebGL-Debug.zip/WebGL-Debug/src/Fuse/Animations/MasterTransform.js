Fuse.Animations.MasterTransform = $CreateClass(
    function() {
        Fuse.Animations.MasterBase__Fuse_Transform.call(this);
        this.Node = null;
        this.FMT = null;
    },
    function(S) {
        var I = S.prototype = new Fuse.Animations.MasterBase__Fuse_Transform;

        Fuse.Animations.MasterTransform.identity = null;

        I.GetType = function()
        {
            return 605;
        };

        I.PostLayout = function()
        {
            return true;
        };

        I.OnActive = function()
        {
            this.FMT = Fuse.FastMatrixTransform.New_1();
            this.Node.Transforms()["Uno.Collections.ICollection__Fuse_Transform.Add"](this.FMT);
        };

        I.OnInactive = function()
        {
            this.Node.Transforms()["Uno.Collections.ICollection__Fuse_Transform.Remove"](this.FMT);
            this.FMT = null;
        };

        Fuse.Animations.MasterTransform._TypeInit = function()
        {
            Fuse.Animations.MasterTransform.identity = Fuse.Translation.New_1();
        };

        I._ObjInit_1 = function(node)
        {
            Fuse.Animations.MasterBase__Fuse_Transform.prototype._ObjInit.call(this);
            this.Node = node;
        };

    });
