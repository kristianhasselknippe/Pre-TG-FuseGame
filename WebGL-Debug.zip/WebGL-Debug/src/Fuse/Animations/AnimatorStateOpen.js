Fuse.Animations.AnimatorStateOpen = $CreateClass(
    function() {
        Fuse.Animations.AnimatorState.call(this);
    },
    function(S) {
        var I = S.prototype = new Fuse.Animations.AnimatorState;

        I.GetType = function()
        {
            return 590;
        };

        I.SeekProgress = function(progress, dir, strength)
        {
            return true;
        };

        I.SeekTime = function(elapsed, totalDuration, dir, strength)
        {
            var relTime = elapsed - this.Animator.GetDelay(this.Variant, totalDuration);
            relTime = Uno.Math.Max(0.0, relTime);
            return this.Seek(relTime, strength, dir);
        };

        I._ObjInit_1 = function(animator, variant, node)
        {
            Fuse.Animations.AnimatorState.prototype._ObjInit.call(this, animator, variant, node);
        };

    });
