Fuse.Animations.PropertyAnimator__float3 = $CreateClass(
    function() {
        Fuse.Animations.Animator.call(this);
        this._Target = null;
        this._Value = new Uno.Float3;
    },
    function(S) {
        var I = S.prototype = new Fuse.Animations.Animator;

        I.GetType = function()
        {
            return 629;
        };

        I.Target = function(value)
        {
            if (value !== undefined)
            {
                this._Target = value;
            }
            else
            {
                return this._Target;
            }
        };

        I.Value = function(value)
        {
            if (value !== undefined)
            {
                this._Value.op_Assign(value);
            }
            else
            {
                return this._Value;
            }
        };

        I.CreateState = function(variant, elm)
        {
            return Fuse.Animations.PropertyAnimatorState__float3.New_1(this, variant, elm);
        };

    });
