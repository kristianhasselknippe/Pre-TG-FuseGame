Fuse.Animations.PlayerPart = $CreateClass(
    function() {
        this.IsProgress = false;
        this.Duration = 0;
        this.Animate = false;
        this.Current = 0;
        this.Source = 0;
        this.Target = 0;
        this.SourceTime = 0;
    },
    function(S) {
        var I = S.prototype;

        I.GetType = function()
        {
            return 607;
        };

        I.Progress = function()
        {
            if (this.IsProgress)
            {
                return this.Current;
            }
            else
            {
                return this.Current / this.Duration;
            }
        };

        I.PlayToEnd = function()
        {
            this.Animate = true;

            if (this.Duration < 9.9999997473787516e-06)
            {
                this.IsProgress = true;
                this.Source = this.Current;
                this.Target = 1.0;
            }
            else
            {
                this.IsProgress = false;
                this.Source = this.Current;
                this.Target = this.Duration;
                this.SourceTime = Fuse.Time.FrameTimeDouble();
            }
        };

        I.PlayForever = function()
        {
            this.Animate = true;
            this.Source = this.Current;
            this.Target = (1./0.);
            this.SourceTime = Fuse.Time.FrameTimeDouble();
        };

        I.PlayToStart = function()
        {
            this.Animate = true;

            if (this.Duration < 9.9999997473787516e-06)
            {
                this.IsProgress = true;
                this.Source = this.Current;
                this.Target = 0.0;
            }
            else
            {
                this.IsProgress = false;
                this.Source = this.Current;
                this.Target = 0.0;
                this.SourceTime = Fuse.Time.FrameTimeDouble();
            }
        };

        I.Step = function()
        {
            if (this.IsProgress)
            {
                this.Current = this.Target;
                this.Animate = false;
                return true;
            }

            var elapsed = Fuse.Time.FrameTimeDouble() - this.SourceTime;

            if (this.Target > this.Source)
            {
                this.Current = elapsed + this.Source;
            }
            else
            {
                this.Current = this.Source - elapsed;
            }

            if (((this.Target >= this.Source) && (this.Current >= this.Target)) || ((this.Target <= this.Source) && (this.Current <= this.Target)))
            {
                this.Current = this.Target;
                this.Animate = false;
                return true;
            }

            return false;
        };

        I.SeekProgress = function(p)
        {
            this.Animate = false;

            if (this.Duration < 9.9999997473787516e-06)
            {
                this.IsProgress = true;
                this.Current = p;
            }
            else
            {
                this.IsProgress = false;
                this.Current = p * this.Duration;
            }
        };

        I.AlterDuration = function(t)
        {
            var p = this.Progress();
            this.Duration = t;
            this.SeekProgress(p);
        };

        I._ObjInit = function(currentProgress)
        {
            this.IsProgress = true;
            this.Current = currentProgress;
        };

        Fuse.Animations.PlayerPart.New_1 = function(currentProgress)
        {
            var inst = new Fuse.Animations.PlayerPart;
            inst._ObjInit(currentProgress);
            return inst;
        };

    });
