Fuse.Animations.MixerHandle__float4 = $CreateClass(
    function() {
        this.Value = new Uno.Float4;
        this.Strength = 0;
        this._hasValue = false;
        this.Master = null;
    },
    function(S) {
        var I = S.prototype;

        I.GetType = function()
        {
            return 656;
        };

        I.$II = function(id)
        {
            return [635].indexOf(id) != -1;
        };

        I.HasValue = function()
        {
            return this._hasValue;
        };

        I.Unregister = function()
        {
            this.Master.Unregister(this);
            this._hasValue = false;
            this.Master.DirtyValue = true;
        };

        I.Set = function(value, strength)
        {
            this._hasValue = true;
            this.Value.op_Assign(value);
            this.Strength = strength;
            this.Master.DirtyValue = true;
        };

        I._ObjInit = function(master)
        {
            this.Master = master;
            this.Master.Register(this);
        };

        Fuse.Animations.MixerHandle__float4.New_1 = function(master)
        {
            var inst = new Fuse.Animations.MixerHandle__float4;
            inst._ObjInit(master);
            return inst;
        };

        I["Fuse.Animations.IMixerHandle__float4.Unregister"] = I.Unregister;
        I["Fuse.Animations.IMixerHandle__float4.Set"] = I.Set;

    });
