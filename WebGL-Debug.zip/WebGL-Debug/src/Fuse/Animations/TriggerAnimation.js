Fuse.Animations.TriggerAnimation = $CreateClass(
    function() {
        this._animators = null;
        this._forePlayer = null;
        this._backPlayer = null;
        this._curPlayer = null;
        this._node = null;
    },
    function(S) {
        var I = S.prototype;

        I.GetType = function()
        {
            return 618;
        };

        I.Animators = function()
        {
            if (this._animators == null)
            {
                this._animators = Uno.Collections.List__Fuse_Animations_Animator.New_1();
            }

            return $DownCast(this._animators, 32916);
        };

        I.HasAnimators = function()
        {
            return (this._animators != null) && (this._animators.Count() > 0);
        };

        I.HasDirectionVariant = function()
        {
            if (!this.HasAnimators())
            {
                return false;
            }

            for (var enum_124 = this.Animators()["Uno.Collections.IEnumerable__Fuse_Animations_Animator.GetEnumerator"](); enum_124["Uno.Collections.IEnumerator.MoveNext"](); )
            {
                var a = enum_124["Uno.Collections.IEnumerator__Fuse_Animations_Animator.Current"]();

                if (!a.HasDirectionVariant())
                {
                    return false;
                }
            }

            return true;
        };

        I.Progress = function()
        {
            if (this._curPlayer != null)
            {
                return this._curPlayer.Progress();
            }

            return 0.0;
        };

        I.CreateAnimatorsState = function(variant, elm)
        {
            var state = Array.Sized(this.Animators()["Uno.Collections.ICollection__Fuse_Animations_Animator.Count"](), 588);

            for (var i = 0; i < this.Animators()["Uno.Collections.ICollection__Fuse_Animations_Animator.Count"](); ++i)
            {
                state[i] = this.Animators()["Uno.Collections.IList__Fuse_Animations_Animator.Item"](i).CreateState(variant, elm);
            }

            return state;
        };

        I.GetTotalDuration = function(variant)
        {
            if (this._animators == null)
            {
                return 0.0;
            }

            var max = 0.0;

            for (var enum_123 = this._animators.GetEnumerator(); enum_123.MoveNext(); )
            {
                var s = enum_123.Current();
                max = Uno.Math.Max(max, s.GetDurationWithDelay(variant));
            }

            return max;
        };

        I.Attach = function(node)
        {
            this._node = node;
        };

        I.Disable = function()
        {
            if (this._forePlayer != null)
            {
                this._forePlayer.Disable();
                this._forePlayer = null;
            }

            if (this._backPlayer != null)
            {
                this._backPlayer.Disable();
                this._backPlayer = null;
            }

            this._curPlayer = null;
            this._node = null;
        };

        I.GetPlayer = function(variant)
        {
            var cur;
            var prev;

            if (!this.HasDirectionVariant())
            {
                variant = 0;
            }

            if ((this._curPlayer != null) && (this._curPlayer.Variant() == variant))
            {
                return $DownCast(this._curPlayer, 33374);
            }

            if (variant == 0)
            {
                if (this._forePlayer == null)
                {
                    this._forePlayer = Fuse.Animations.Player.New_1(this._node, this, 0);
                }

                cur = this._forePlayer;
                prev = this._backPlayer;
            }
            else
            {
                if (this._backPlayer == null)
                {
                    this._backPlayer = Fuse.Animations.Player.New_1(this._node, this, 1);
                    this._backPlayer.SeekProgress(1.0);
                }

                cur = this._backPlayer;
                prev = this._forePlayer;
            }

            if (prev != null)
            {
                var prevProgress = prev.Progress();
                var remainTime = prev.RemainTime();
                var fadeTime = Uno.Math.Min(remainTime, 0.5);
                prev.SeekProgress(prevProgress);
                prev.FadeOut(fadeTime);

                if (cur.IsSyncState())
                {
                    cur.Strength(0.0);
                }

                cur.FadeIn(fadeTime);
                cur.SeekProgress(prevProgress);
            }

            this._curPlayer = cur;
            return $DownCast(cur, 33374);
        };

        I.PlayOff = function(done)
        {
            if (!this.HasAnimators())
            {
                return;
            }

            var p = this.GetPlayer(1);
            p["Fuse.Animations.IPlayer.DoneCallback"](done);
            p["Fuse.Animations.IPlayer.PlayToStart"]();
        };

        I.PlayOn = function(done)
        {
            if (!this.HasAnimators())
            {
                return;
            }

            var p = this.GetPlayer(0);
            p["Fuse.Animations.IPlayer.DoneCallback"](done);
            p["Fuse.Animations.IPlayer.PlayToEnd"]();
        };

        I.PlayEnd = function(on, done)
        {
            if (on)
            {
                this.PlayOn(done);
            }
            else
            {
                this.PlayOff(done);
            }
        };

        I.SeekProgress = function(progress, tendTo)
        {
            var player = (this._curPlayer != null) ? this._curPlayer : $AsOp(this.GetPlayer(0), 608);
            player.SeekProgress(progress);
        };

        I._ObjInit = function()
        {
        };

        Fuse.Animations.TriggerAnimation.New_1 = function()
        {
            var inst = new Fuse.Animations.TriggerAnimation;
            inst._ObjInit();
            return inst;
        };

    });
