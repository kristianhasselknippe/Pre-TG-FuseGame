Fuse.Animations.MixerBase = $CreateClass(
    function() {
        this.Masters = null;
        this._propHandle = null;
    },
    function(S) {
        var I = S.prototype;

        I.GetType = function()
        {
            return 604;
        };

        I.$II = function(id)
        {
            return [601].indexOf(id) != -1;
        };

        I.RegisterTransform = function(element)
        {
            var master;

            if (!element.TryGetValue(this._propHandle, $CreateRef(function(){return master}, function($){master=$}, this)))
            {
                master = this.CreateMasterTransform(element);
                element.SetValue(this._propHandle, master);
            }

            var masterT = $DownCast(master, 624);
            return $DownCast(Fuse.Animations.MixerHandle__Fuse_Transform.New_1(masterT), 33391);
        };

        I.Register__float4 = function(property)
        {
            var master;

            if (!this.Masters.TryGetValue(property, $CreateRef(function(){return master}, function($){master=$}, this)))
            {
                master = this.CreateMaster__float4(property);
                this.Masters.Add(property, master);
            }

            var masterT = $DownCast(master, 650);
            return $DownCast(Fuse.Animations.MixerHandle__float4.New_1(masterT), 33403);
        };

        I.Register__float = function(property)
        {
            var master;

            if (!this.Masters.TryGetValue(property, $CreateRef(function(){return master}, function($){master=$}, this)))
            {
                master = this.CreateMaster__float(property);
                this.Masters.Add(property, master);
            }

            var masterT = $DownCast(master, 651);
            return $DownCast(Fuse.Animations.MixerHandle__float.New_1(masterT), 33404);
        };

        I.Register__float2 = function(property)
        {
            var master;

            if (!this.Masters.TryGetValue(property, $CreateRef(function(){return master}, function($){master=$}, this)))
            {
                master = this.CreateMaster__float2(property);
                this.Masters.Add(property, master);
            }

            var masterT = $DownCast(master, 652);
            return $DownCast(Fuse.Animations.MixerHandle__float2.New_1(masterT), 33405);
        };

        I.Register__float3 = function(property)
        {
            var master;

            if (!this.Masters.TryGetValue(property, $CreateRef(function(){return master}, function($){master=$}, this)))
            {
                master = this.CreateMaster__float3(property);
                this.Masters.Add(property, master);
            }

            var masterT = $DownCast(master, 653);
            return $DownCast(Fuse.Animations.MixerHandle__float3.New_1(masterT), 33406);
        };

        I.Register__Fuse_Visibility = function(property)
        {
            var master;

            if (!this.Masters.TryGetValue(property, $CreateRef(function(){return master}, function($){master=$}, this)))
            {
                master = this.CreateMaster__Fuse_Visibility(property);
                this.Masters.Add(property, master);
            }

            var masterT = $DownCast(master, 654);
            return $DownCast(Fuse.Animations.MixerHandle__Fuse_Visibility.New_1(masterT), 33407);
        };

        I.Register__bool = function(property)
        {
            var master;

            if (!this.Masters.TryGetValue(property, $CreateRef(function(){return master}, function($){master=$}, this)))
            {
                master = this.CreateMaster__bool(property);
                this.Masters.Add(property, master);
            }

            var masterT = $DownCast(master, 655);
            return $DownCast(Fuse.Animations.MixerHandle__bool.New_1(masterT), 33408);
        };

        I._ObjInit = function()
        {
            this.Masters = Uno.Collections.Dictionary__object__object.New_1();
            this._propHandle = Fuse.PropertyHandle.New_1();
        };

        I["Fuse.Animations.IMixer.RegisterTransform"] = I.RegisterTransform;
        I["Fuse.Animations.IMixer.Register__float4"] = I.Register__float4;
        I["Fuse.Animations.IMixer.Register__float"] = I.Register__float;
        I["Fuse.Animations.IMixer.Register__float2"] = I.Register__float2;
        I["Fuse.Animations.IMixer.Register__float3"] = I.Register__float3;
        I["Fuse.Animations.IMixer.Register__Fuse_Visibility"] = I.Register__Fuse_Visibility;
        I["Fuse.Animations.IMixer.Register__bool"] = I.Register__bool;

    });
