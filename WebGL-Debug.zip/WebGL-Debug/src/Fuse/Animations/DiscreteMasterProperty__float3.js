Fuse.Animations.DiscreteMasterProperty__float3 = $CreateClass(
    function() {
        Fuse.Animations.MasterProperty__float3.call(this);
    },
    function(S) {
        var I = S.prototype = new Fuse.Animations.MasterProperty__float3;

        I.GetType = function()
        {
            return 673;
        };

        I.OnComplete = function()
        {
            var nv_123 = new Uno.Float3;
            nv_123.op_Assign(this.RestValue());
            var str = 0.5;

            for (var enum_123 = this.Handles.GetEnumerator(); enum_123.MoveNext(); )
            {
                var v = enum_123.Current();

                if (v.HasValue() && (v.Strength > str))
                {
                    nv_123.op_Assign(v.Value);
                    str = v.Strength;
                }
            }

            this.Property.Set(nv_123);
        };

        I._ObjInit_2 = function(property)
        {
            Fuse.Animations.MasterProperty__float3.prototype._ObjInit_1.call(this, property);
        };

        Fuse.Animations.DiscreteMasterProperty__float3.New_1 = function(property)
        {
            var inst = new Fuse.Animations.DiscreteMasterProperty__float3;
            inst._ObjInit_2(property);
            return inst;
        };

    });
