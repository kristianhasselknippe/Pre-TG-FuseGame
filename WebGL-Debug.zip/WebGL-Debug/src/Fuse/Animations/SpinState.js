Fuse.Animations.SpinState = $CreateClass(
    function() {
        Fuse.Animations.AnimatorStateOpen.call(this);
        this.Animator_1 = null;
        this.mixHandle = null;
        this.transform = null;
        this._lastDir = 0;
        this._referElapsed = 0;
        this._lastElapsed = 0;
    },
    function(S) {
        var I = S.prototype = new Fuse.Animations.AnimatorStateOpen;

        I.GetType = function()
        {
            return 611;
        };

        I.Seek = function(elapsed, strength, dir)
        {
            if ((this.mixHandle == null) || (this.transform == null))
            {
                Uno.Diagnostics.Debug.Log("Invalid seek", 1, "/Users/vegard/RealtimeStudio/Uno/Packages/Fuse.Nodes/0.1.0/Animations/Spin.uno", 49);
                return true;
            }

            if (dir != this._lastDir)
            {
                this._referElapsed = this._lastElapsed;
                this._lastDir = dir;
            }

            var degrees;
            var done = false;

            if (dir == 1)
            {
                degrees = Uno.Math.Mod_1(this._referElapsed * 180.0, 360.0);
                degrees = degrees - ((this._referElapsed - elapsed) * 180.0);

                if (degrees <= 0.0)
                {
                    done = true;
                    degrees = 0.0;
                }
            }
            else
            {
                degrees = Uno.Math.Mod_1(elapsed * 180.0, 360.0);
            }

            this.transform.Degrees(degrees);
            this.mixHandle["Fuse.Animations.IMixerHandle__Fuse_Transform.Set"](this.transform, strength);
            this._lastElapsed = elapsed;
            return done;
        };

        I._ObjInit_2 = function(animator, variant, node)
        {
            this.transform = Fuse.Rotation.New_1();
            Fuse.Animations.AnimatorStateOpen.prototype._ObjInit_1.call(this, animator, variant, node);
            this.Animator_1 = animator;
            this.mixHandle = this.Animator_1.Mixer["Fuse.Animations.IMixer.RegisterTransform"](node);
        };

        Fuse.Animations.SpinState.New_1 = function(animator, variant, node)
        {
            var inst = new Fuse.Animations.SpinState;
            inst._ObjInit_2(animator, variant, node);
            return inst;
        };

    });
