Fuse.Animations.DiscreteMixer = $CreateClass(
    function() {
        Fuse.Animations.MixerBase.call(this);
    },
    function(S) {
        var I = S.prototype = new Fuse.Animations.MixerBase;

        I.GetType = function()
        {
            return 599;
        };

        I.CreateMasterTransform = function(element)
        {
            return Fuse.Animations.DiscreteMasterTransform.New_1(element);
        };

        I.CreateMaster__float4 = function(property)
        {
            return Fuse.Animations.DiscreteMasterProperty__float4.New_1(property);
        };

        I.CreateMaster__float = function(property)
        {
            return Fuse.Animations.DiscreteMasterProperty__float.New_1(property);
        };

        I.CreateMaster__float2 = function(property)
        {
            return Fuse.Animations.DiscreteMasterProperty__float2.New_1(property);
        };

        I.CreateMaster__float3 = function(property)
        {
            return Fuse.Animations.DiscreteMasterProperty__float3.New_1(property);
        };

        I.CreateMaster__Fuse_Visibility = function(property)
        {
            return Fuse.Animations.DiscreteMasterProperty__Fuse_Visibility.New_1(property);
        };

        I.CreateMaster__bool = function(property)
        {
            return Fuse.Animations.DiscreteMasterProperty__bool.New_1(property);
        };

        I._ObjInit_1 = function()
        {
            Fuse.Animations.MixerBase.prototype._ObjInit.call(this);
        };

        Fuse.Animations.DiscreteMixer.New_1 = function()
        {
            var inst = new Fuse.Animations.DiscreteMixer;
            inst._ObjInit_1();
            return inst;
        };

    });
