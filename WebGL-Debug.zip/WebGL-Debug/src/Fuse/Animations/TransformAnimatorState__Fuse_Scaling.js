Fuse.Animations.TransformAnimatorState__Fuse_Scaling = $CreateClass(
    function() {
        Fuse.Animations.AnimatorStateProgress.call(this);
        this.Animator_1 = null;
        this.mixHandle = null;
        this.transform = null;
    },
    function(S) {
        var I = S.prototype = new Fuse.Animations.AnimatorStateProgress;

        I.GetType = function()
        {
            return 649;
        };

        I.Disable = function()
        {
            if (this.mixHandle == null)
            {
                return;
            }

            this.mixHandle["Fuse.Animations.IMixerHandle__Fuse_Transform.Unregister"]();
            this.mixHandle = null;
            this.transform = null;
        };

        I.Seek = function(progress, strength)
        {
            if ((this.mixHandle == null) || (this.transform == null))
            {
                Uno.Diagnostics.Debug.Log("Invalid seek", 1, "/Users/vegard/RealtimeStudio/Uno/Packages/Fuse.Nodes/0.1.0/Animations/TransformAnimator.uno", 51);
                return;
            }

            this.Animator_1.Update(this.Node, this.transform);
            this.mixHandle["Fuse.Animations.IMixerHandle__Fuse_Transform.Set"](this.transform, progress * strength);
        };

        I._ObjInit_2 = function(animator, variant, node)
        {
            this.transform = Fuse.Scaling.New_1();
            Fuse.Animations.AnimatorStateProgress.prototype._ObjInit_1.call(this, animator, variant, node);
            this.Animator_1 = animator;
            this.mixHandle = this.Animator_1.Mixer["Fuse.Animations.IMixer.RegisterTransform"](node);
        };

        Fuse.Animations.TransformAnimatorState__Fuse_Scaling.New_1 = function(animator, variant, node)
        {
            var inst = new Fuse.Animations.TransformAnimatorState__Fuse_Scaling;
            inst._ObjInit_2(animator, variant, node);
            return inst;
        };

    });
