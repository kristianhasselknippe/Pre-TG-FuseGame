Fuse.Animations.Scale = $CreateClass(
    function() {
        Fuse.Animations.TransformAnimator__Fuse_Scaling.call(this);
        this._Factor = 0;
    },
    function(S) {
        var I = S.prototype = new Fuse.Animations.TransformAnimator__Fuse_Scaling;

        I.GetType = function()
        {
            return 616;
        };

        I.Factor = function(value)
        {
            if (value !== undefined)
            {
                this._Factor = value;
            }
            else
            {
                return this._Factor;
            }
        };

        I.Update = function(elm, t)
        {
            t.Factor(this.Factor());
        };

    });
