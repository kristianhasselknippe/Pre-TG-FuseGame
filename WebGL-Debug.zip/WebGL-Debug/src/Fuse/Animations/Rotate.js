Fuse.Animations.Rotate = $CreateClass(
    function() {
        Fuse.Animations.TransformAnimator__Fuse_Rotation.call(this);
        this._Degrees = 0;
    },
    function(S) {
        var I = S.prototype = new Fuse.Animations.TransformAnimator__Fuse_Rotation;

        I.GetType = function()
        {
            return 615;
        };

        I.Degrees = function(value)
        {
            if (value !== undefined)
            {
                this._Degrees = value;
            }
            else
            {
                return this._Degrees;
            }
        };

        I.Update = function(elm, t)
        {
            t.Degrees(this.Degrees());
        };

    });
