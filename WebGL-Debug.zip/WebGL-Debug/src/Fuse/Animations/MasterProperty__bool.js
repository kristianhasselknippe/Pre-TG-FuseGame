Fuse.Animations.MasterProperty__bool = $CreateClass(
    function() {
        Fuse.Animations.MasterBase__bool.call(this);
        this.Property = null;
    },
    function(S) {
        var I = S.prototype = new Fuse.Animations.MasterBase__bool;

        I.GetType = function()
        {
            return 681;
        };

        I.RestValue = function()
        {
            return this.Property.GetRestState();
        };

        I.OnInactive = function()
        {
            this.Property.Set(this.RestValue());
        };

        I._ObjInit_1 = function(property)
        {
            Fuse.Animations.MasterBase__bool.prototype._ObjInit.call(this);
            this.Property = property;
        };

    });
