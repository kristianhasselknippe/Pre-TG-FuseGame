Fuse.Animations.AverageMasterTransform = $CreateClass(
    function() {
        Fuse.Animations.MasterTransform.call(this);
    },
    function(S) {
        var I = S.prototype = new Fuse.Animations.MasterTransform;

        I.GetType = function()
        {
            return 592;
        };

        I.OnComplete = function()
        {
        };

        I._ObjInit_2 = function(node)
        {
            Fuse.Animations.MasterTransform.prototype._ObjInit_1.call(this, node);
        };

        Fuse.Animations.AverageMasterTransform.New_1 = function(node)
        {
            var inst = new Fuse.Animations.AverageMasterTransform;
            inst._ObjInit_2(node);
            return inst;
        };

    });
