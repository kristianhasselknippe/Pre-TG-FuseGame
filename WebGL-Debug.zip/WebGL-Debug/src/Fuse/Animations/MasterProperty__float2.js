Fuse.Animations.MasterProperty__float2 = $CreateClass(
    function() {
        Fuse.Animations.MasterBase__float2.call(this);
        this.Property = null;
    },
    function(S) {
        var I = S.prototype = new Fuse.Animations.MasterBase__float2;

        I.GetType = function()
        {
            return 678;
        };

        I.RestValue = function()
        {
            return this.Property.GetRestState();
        };

        I.OnInactive = function()
        {
            this.Property.Set(this.RestValue());
        };

        I._ObjInit_1 = function(property)
        {
            Fuse.Animations.MasterBase__float2.prototype._ObjInit.call(this);
            this.Property = property;
        };

    });
