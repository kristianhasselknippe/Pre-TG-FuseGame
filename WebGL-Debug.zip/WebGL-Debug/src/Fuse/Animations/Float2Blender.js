Fuse.Animations.Float2Blender = $CreateClass(
    function() {
    },
    function(S) {
        var I = S.prototype;

        I.GetType = function()
        {
            return 595;
        };

        I.$II = function(id)
        {
            return [620].indexOf(id) != -1;
        };

        I.Weight = function(v, w)
        {
            return Uno.Float2.op_Multiply(v, w);
        };

        I.Add = function(a, b)
        {
            return Uno.Float2.op_Addition(a, b);
        };

        I._ObjInit = function()
        {
        };

        Fuse.Animations.Float2Blender.New_1 = function()
        {
            var inst = new Fuse.Animations.Float2Blender;
            inst._ObjInit();
            return inst;
        };

        I["Fuse.Animations.Blender__float2.Weight"] = I.Weight;
        I["Fuse.Animations.Blender__float2.Add"] = I.Add;

    });
