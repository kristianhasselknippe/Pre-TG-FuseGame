Fuse.Animations.Mixer = $CreateClass(
    function() {
    },
    function(S) {
        var I = S.prototype;

        Fuse.Animations.Mixer._default = null;
        Fuse.Animations.Mixer._defaultTransform = null;
        Fuse.Animations.Mixer._defaultDiscrete = null;
        Fuse.Animations.Mixer.PreMasters = null;
        Fuse.Animations.Mixer.PostMasters = null;

        I.GetType = function()
        {
            return 603;
        };

        Fuse.Animations.Mixer.Default = function()
        {
            return Fuse.Animations.Mixer._default;
        };

        Fuse.Animations.Mixer.DefaultTransform = function()
        {
            return Fuse.Animations.Mixer._defaultTransform;
        };

        Fuse.Animations.Mixer.AddMaster = function(master, postLayout)
        {
            var list = postLayout ? Fuse.Animations.Mixer.PostMasters : Fuse.Animations.Mixer.PreMasters;
            var stage = postLayout ? 3 : 1;
            var act = postLayout ? $CreateDelegate(null, Fuse.Animations.Mixer.CompletePost, 436) : $CreateDelegate(null, Fuse.Animations.Mixer.CompletePre, 436);

            if (list.Count() == 0)
            {
                Fuse.UpdateManager.AddAction(act, stage);
            }

            list.Add(master);
        };

        Fuse.Animations.Mixer.RemoveMaster = function(master, postLayout)
        {
            var list = postLayout ? Fuse.Animations.Mixer.PostMasters : Fuse.Animations.Mixer.PreMasters;
            var stage = postLayout ? 3 : 1;
            var act = postLayout ? $CreateDelegate(null, Fuse.Animations.Mixer.CompletePost, 436) : $CreateDelegate(null, Fuse.Animations.Mixer.CompletePre, 436);
            list.Remove(master);

            if (list.Count() == 0)
            {
                Fuse.UpdateManager.RemoveAction(act, stage);
            }
        };

        Fuse.Animations.Mixer.CompletePre = function()
        {
            {
                var l = Fuse.Animations.Mixer.PreMasters.DeferLock();
                try
                {
                    {
                        for (var enum_123 = Fuse.Animations.Mixer.PreMasters.GetEnumerator(); enum_123["Uno.Collections.IEnumerator.MoveNext"](); )
                        {
                            var master = enum_123["Uno.Collections.IEnumerator__Fuse_Animations_IMixerMaster.Current"]();
                            master["Fuse.Animations.IMixerMaster.Complete"]();
                        }
                    }
                }

                finally
                {
                    l["Uno.IDisposable.Dispose"]();
                }
            }
        };

        Fuse.Animations.Mixer.CompletePost = function()
        {
            {
                var l = Fuse.Animations.Mixer.PostMasters.DeferLock();
                try
                {
                    {
                        for (var enum_124 = Fuse.Animations.Mixer.PostMasters.GetEnumerator(); enum_124["Uno.Collections.IEnumerator.MoveNext"](); )
                        {
                            var master = enum_124["Uno.Collections.IEnumerator__Fuse_Animations_IMixerMaster.Current"]();
                            master["Fuse.Animations.IMixerMaster.Complete"]();
                        }
                    }
                }

                finally
                {
                    l["Uno.IDisposable.Dispose"]();
                }
            }
        };

        Fuse.Animations.Mixer._TypeInit = function()
        {
            Fuse.Animations.Mixer._default = $DownCast(Fuse.Animations.AverageMixer.New_1(), 33369);
            Fuse.Animations.Mixer._defaultTransform = $DownCast(Fuse.Animations.StackMixer.New_1(), 33369);
            Fuse.Animations.Mixer._defaultDiscrete = $DownCast(Fuse.Animations.DiscreteMixer.New_1(), 33369);
            Fuse.Animations.Mixer.PreMasters = Uno.Collections.ConcurrentCollection__Fuse_Animations_IMixerMaster.New_1();
            Fuse.Animations.Mixer.PostMasters = Uno.Collections.ConcurrentCollection__Fuse_Animations_IMixerMaster.New_1();
        };

    });
