Fuse.Animations.MixerHandle__Fuse_Visibility = $CreateClass(
    function() {
        this.Value = 0;
        this.Strength = 0;
        this._hasValue = false;
        this.Master = null;
    },
    function(S) {
        var I = S.prototype;

        I.GetType = function()
        {
            return 660;
        };

        I.$II = function(id)
        {
            return [639].indexOf(id) != -1;
        };

        I.HasValue = function()
        {
            return this._hasValue;
        };

        I.Unregister = function()
        {
            this.Master.Unregister(this);
            this._hasValue = false;
            this.Master.DirtyValue = true;
        };

        I.Set = function(value, strength)
        {
            this._hasValue = true;
            this.Value = value;
            this.Strength = strength;
            this.Master.DirtyValue = true;
        };

        I._ObjInit = function(master)
        {
            this.Master = master;
            this.Master.Register(this);
        };

        Fuse.Animations.MixerHandle__Fuse_Visibility.New_1 = function(master)
        {
            var inst = new Fuse.Animations.MixerHandle__Fuse_Visibility;
            inst._ObjInit(master);
            return inst;
        };

        I["Fuse.Animations.IMixerHandle__Fuse_Visibility.Unregister"] = I.Unregister;
        I["Fuse.Animations.IMixerHandle__Fuse_Visibility.Set"] = I.Set;

    });
