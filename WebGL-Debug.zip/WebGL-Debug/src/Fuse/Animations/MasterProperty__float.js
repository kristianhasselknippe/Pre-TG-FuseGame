Fuse.Animations.MasterProperty__float = $CreateClass(
    function() {
        Fuse.Animations.MasterBase__float.call(this);
        this.Property = null;
    },
    function(S) {
        var I = S.prototype = new Fuse.Animations.MasterBase__float;

        I.GetType = function()
        {
            return 677;
        };

        I.RestValue = function()
        {
            return this.Property.GetRestState();
        };

        I.OnInactive = function()
        {
            this.Property.Set(this.RestValue());
        };

        I._ObjInit_1 = function(property)
        {
            Fuse.Animations.MasterBase__float.prototype._ObjInit.call(this);
            this.Property = property;
        };

    });
