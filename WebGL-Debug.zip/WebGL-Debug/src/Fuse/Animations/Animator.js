Fuse.Animations.Animator = $CreateClass(
    function() {
        this.Mixer = null;
        this._easing = 0;
        this._duration = 0;
        this._easingBack = 0;
        this._hasEasingBack = false;
        this._hasDelayBack = false;
        this._delayBack = 0;
        this._durationBack = 0;
        this._hasDurationBack = false;
        this._Delay = 0;
    },
    function(S) {
        var I = S.prototype;

        I.GetType = function()
        {
            return 586;
        };

        I.Easing = function(value)
        {
            if (value !== undefined)
            {
                this._easing = value;
            }
            else
            {
                return this._easing;
            }
        };

        I.Delay = function(value)
        {
            if (value !== undefined)
            {
                this._Delay = value;
            }
            else
            {
                return this._Delay;
            }
        };

        I.Duration = function(value)
        {
            if (value !== undefined)
            {
                this._duration = value;
            }
            else
            {
                return this._duration;
            }
        };

        I.EasingBack = function(value)
        {
            if (value !== undefined)
            {
                this._easingBack = value;
                this._hasEasingBack = true;
            }
            else
            {
                if (this._hasEasingBack)
                {
                    return this._easingBack;
                }

                return this.Easing();
            }
        };

        I.DelayBack = function(value)
        {
            if (value !== undefined)
            {
                this._delayBack = value;
                this._hasDelayBack = true;
            }
            else
            {
                if (this._hasDelayBack)
                {
                    return this._delayBack;
                }

                return this.Delay();
            }
        };

        I.DurationBack = function(value)
        {
            if (value !== undefined)
            {
                this._durationBack = value;
                this._hasDurationBack = true;
            }
            else
            {
                if (this._hasDurationBack)
                {
                    return this._durationBack;
                }

                return this.Duration();
            }
        };

        I.HasDirectionVariant = function()
        {
            return true;
        };

        I.GetDelay = function(dir, totalDuration)
        {
            if (dir == 1)
            {
                if (this._hasDelayBack)
                {
                    return this.DelayBack();
                }

                return totalDuration - (this.Delay() + this.GetDurationWithoutDelay(dir));
            }
            else
            {
                return this.Delay();
            }
        };

        I.GetDurationWithoutDelay = function(dir)
        {
            if (dir == 1)
            {
                return this.DurationBack();
            }
            else
            {
                return this.Duration();
            }
        };

        I.GetDurationWithDelay = function(dir)
        {
            if (dir == 1)
            {
                return this.DurationBack() + this.DelayBack();
            }
            else
            {
                return this.Duration() + this.Delay();
            }
        };

        I.GetEasing = function(dir)
        {
            if (dir == 1)
            {
                return this.EasingBack();
            }
            else
            {
                return this.Easing();
            }
        };

        I._ObjInit = function()
        {
            this.Mixer = Fuse.Animations.Mixer.Default();
            this._duration = 0.25;
        };

    });
