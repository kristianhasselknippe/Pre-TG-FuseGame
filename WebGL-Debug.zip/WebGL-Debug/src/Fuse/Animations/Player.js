Fuse.Animations.Player = $CreateClass(
    function() {
        this._states = null;
        this._isStarted = false;
        this._isDone = false;
        this._progress = null;
        this._seekDirection = 0;
        this._strength = null;
        this.ProgressUpdated = null;
        this.StrengthUpdated = null;
        this._Node = null;
        this._Animation = null;
        this._Variant = 0;
        this._DoneCallback = null;
    },
    function(S) {
        var I = S.prototype;

        I.GetType = function()
        {
            return 608;
        };

        I.$II = function(id)
        {
            return [606].indexOf(id) != -1;
        };

        I.Node = function(value)
        {
            if (value !== undefined)
            {
                this._Node = value;
            }
            else
            {
                return this._Node;
            }
        };

        I.Animation = function(value)
        {
            if (value !== undefined)
            {
                this._Animation = value;
            }
            else
            {
                return this._Animation;
            }
        };

        I.Variant = function(value)
        {
            if (value !== undefined)
            {
                this._Variant = value;
            }
            else
            {
                return this._Variant;
            }
        };

        I.States = function()
        {
            if (this._states == null)
            {
                this._states = this.Animation().CreateAnimatorsState(this.Variant(), this.Node());
            }

            return this._states;
        };

        I.DoneCallback = function(value)
        {
            if (value !== undefined)
            {
                this._DoneCallback = value;
            }
            else
            {
                return this._DoneCallback;
            }
        };

        I.Progress = function()
        {
            return this._progress.Progress();
        };

        I.RemainTime = function()
        {
            return (this.Variant() == 0) ? (this._progress.Duration - this._progress.Current) : this._progress.Current;
        };

        I.IsSyncState = function()
        {
            return (this._progress.Current == 0.0) || (this._progress.Progress() == 1.0);
        };

        I.AnyEffect = function()
        {
            return (this._progress.Current > 0.0) && (this._strength.Current > 0.0);
        };

        I.Strength = function(value)
        {
            if (value !== undefined)
            {
                this._strength.SeekProgress(value);
                this.UpdateStates();
                this.CheckNeedUpdate();
            }
            else
            {
                return this._strength.Progress();
            }
        };

        I.Update = function(s, a)
        {
            this.OnUpdate();
        };

        I.OnUpdate = function()
        {
            if (this._progress.Animate)
            {
                if (this._progress.Step())
                {
                    this.Done();
                }

                if (Uno.Delegate.op_Inequality(this.ProgressUpdated, null))
                {
                    this.ProgressUpdated.Invoke(this, Uno.EventArgs.New_1());
                }
            }

            if (this._strength.Animate)
            {
                this._strength.Step();

                if (Uno.Delegate.op_Inequality(this.StrengthUpdated, null))
                {
                    this.StrengthUpdated.Invoke(this, Uno.EventArgs.New_1());
                }
            }

            this.UpdateStates();
            this.CheckNeedUpdate();
        };

        I.CheckNeedUpdate = function()
        {
            if (this._progress.Animate || this._strength.Animate)
            {
                this.Start();
            }
            else
            {
                this.Stop();

                if (!this.AnyEffect())
                {
                    this.Disable();
                }
            }
        };

        I.Start = function()
        {
            if (!this._isStarted)
            {
                this._isStarted = true;

                if (this.Node() != null)
                {
                    this.Node().add_Update($CreateDelegate(this, Fuse.Animations.Player.prototype.Update, 445));
                }
                else
                {
                    Fuse.UpdateManager.AddAction($CreateDelegate(this, Fuse.Animations.Player.prototype.OnUpdate, 436), 0);
                }

                this.OnUpdate();
            }
        };

        I.Stop = function()
        {
            if (this._isStarted)
            {
                if (this.Node() != null)
                {
                    this.Node().remove_Update($CreateDelegate(this, Fuse.Animations.Player.prototype.Update, 445));
                }
                else
                {
                    Fuse.UpdateManager.RemoveAction($CreateDelegate(this, Fuse.Animations.Player.prototype.OnUpdate, 436), 0);
                }

                this._isStarted = false;
            }
        };

        I.Done = function()
        {
            this._progress.Animate = false;

            if (!this._isDone)
            {
                if (Uno.Delegate.op_Inequality(this.DoneCallback(), null))
                {
                    this.DoneCallback().Invoke();
                }

                this._isDone = true;
                this.CheckNeedUpdate();
            }
        };

        I.Disable = function()
        {
            if (this._states != null)
            {
                for (var i = 0; i < this._states.length; i++)
                {
                    this._states[i].Disable();
                }

                this._states = null;
                this.CheckNeedUpdate();
            }
        };

        I.SeekProgress = function(progress)
        {
            this._progress.SeekProgress(progress);
            this._isDone = false;
            this.CheckNeedUpdate();
            this.UpdateStates();
        };

        I.UpdateStates = function()
        {
            var array_123;
            var index_124;
            var length_125;

            if ((this._states == null) && !this.AnyEffect())
            {
                return;
            }

            var allDone = true;

            for (array_123 = this.States(), index_124 = 0, length_125 = array_123.length; index_124 < length_125; ++index_124)
            {
                var s = array_123[index_124];
                var done;

                if (this._progress.IsProgress)
                {
                    done = s.SeekProgress(this._progress.Current, this._seekDirection, this._strength.Progress());
                }
                else
                {
                    done = s.SeekTime(this._progress.Current, this._progress.Duration, this._seekDirection, this._strength.Progress());
                }

                allDone = allDone && done;
            }

            if (allDone)
            {
                this.Done();
            }
        };

        I.PlayToEnd = function()
        {
            this._seekDirection = 0;
            this._progress.PlayForever();
            this._isDone = false;
            this.CheckNeedUpdate();
        };

        I.PlayToStart = function()
        {
            this._seekDirection = 1;
            this._progress.PlayToStart();
            this._isDone = false;
            this.CheckNeedUpdate();
        };

        I.FadeIn = function(time)
        {
            this._strength.AlterDuration(time);
            this._strength.PlayToEnd();
            this.CheckNeedUpdate();
        };

        I.FadeOut = function(time)
        {
            this._strength.AlterDuration(time);
            this._strength.PlayToStart();
            this.CheckNeedUpdate();
        };

        I._ObjInit = function(elm, animation, variant)
        {
            this._progress = Fuse.Animations.PlayerPart.New_1(0.0);
            this._strength = Fuse.Animations.PlayerPart.New_1(1.0);
            this.Animation(animation);
            this.Node(elm);
            this.Variant(variant);
            this._progress.AlterDuration(this.Animation().GetTotalDuration(this.Variant()));
        };

        Fuse.Animations.Player.New_1 = function(elm, animation, variant)
        {
            var inst = new Fuse.Animations.Player;
            inst._ObjInit(elm, animation, variant);
            return inst;
        };

        I["Fuse.Animations.IPlayer.PlayToEnd"] = I.PlayToEnd;
        I["Fuse.Animations.IPlayer.PlayToStart"] = I.PlayToStart;
        I["Fuse.Animations.IPlayer.DoneCallback"] = I.DoneCallback;

    });
