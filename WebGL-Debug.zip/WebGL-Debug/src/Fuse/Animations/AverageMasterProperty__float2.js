Fuse.Animations.AverageMasterProperty__float2 = $CreateClass(
    function() {
        Fuse.Animations.MasterProperty__float2.call(this);
        this.blender = null;
    },
    function(S) {
        var I = S.prototype = new Fuse.Animations.MasterProperty__float2;

        I.GetType = function()
        {
            return 664;
        };

        I.OnActive = function()
        {
            if (this.blender == null)
            {
                this.blender = Fuse.Animations.BlenderMap.Get__float2(this.RestValue());
            }
        };

        I.OnComplete = function()
        {
            var nv_123 = new Uno.Float2;
            var fullWeight = 0.0;

            for (var enum_123 = this.Handles.GetEnumerator(); enum_123.MoveNext(); )
            {
                var v = enum_123.Current();
                fullWeight = fullWeight + (v.HasValue() ? v.Strength : 0.0);
            }

            var restWeight = 1.0 - Uno.Math.Min_1(fullWeight, 1.0);
            fullWeight = Uno.Math.Max_1(1.0, fullWeight);
            nv_123.op_Assign(this.blender["Fuse.Animations.Blender__float2.Weight"](this.RestValue(), restWeight / fullWeight));

            for (var enum_124 = this.Handles.GetEnumerator(); enum_124.MoveNext(); )
            {
                var v = enum_124.Current();

                if (v.HasValue())
                {
                    nv_123.op_Assign(this.blender["Fuse.Animations.Blender__float2.Add"](nv_123, this.blender["Fuse.Animations.Blender__float2.Weight"](v.Value, v.Strength / fullWeight)));
                }
            }

            this.Property.Set(nv_123);
        };

        I._ObjInit_2 = function(property)
        {
            Fuse.Animations.MasterProperty__float2.prototype._ObjInit_1.call(this, property);
        };

        Fuse.Animations.AverageMasterProperty__float2.New_1 = function(property)
        {
            var inst = new Fuse.Animations.AverageMasterProperty__float2;
            inst._ObjInit_2(property);
            return inst;
        };

    });
