Fuse.Animations.FloatBlender = $CreateClass(
    function() {
    },
    function(S) {
        var I = S.prototype;

        I.GetType = function()
        {
            return 594;
        };

        I.$II = function(id)
        {
            return [619].indexOf(id) != -1;
        };

        I.Weight = function(v, w)
        {
            return v * w;
        };

        I.Add = function(a, b)
        {
            return a + b;
        };

        I._ObjInit = function()
        {
        };

        Fuse.Animations.FloatBlender.New_1 = function()
        {
            var inst = new Fuse.Animations.FloatBlender;
            inst._ObjInit();
            return inst;
        };

        I["Fuse.Animations.Blender__float.Weight"] = I.Weight;
        I["Fuse.Animations.Blender__float.Add"] = I.Add;

    });
