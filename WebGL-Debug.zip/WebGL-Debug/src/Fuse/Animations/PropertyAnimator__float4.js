Fuse.Animations.PropertyAnimator__float4 = $CreateClass(
    function() {
        Fuse.Animations.Animator.call(this);
        this._Target = null;
        this._Value = new Uno.Float4;
    },
    function(S) {
        var I = S.prototype = new Fuse.Animations.Animator;

        I.GetType = function()
        {
            return 626;
        };

        I.Target = function(value)
        {
            if (value !== undefined)
            {
                this._Target = value;
            }
            else
            {
                return this._Target;
            }
        };

        I.Value = function(value)
        {
            if (value !== undefined)
            {
                this._Value.op_Assign(value);
            }
            else
            {
                return this._Value;
            }
        };

        I.CreateState = function(variant, elm)
        {
            return Fuse.Animations.PropertyAnimatorState__float4.New_1(this, variant, elm);
        };

        I._ObjInit_1 = function()
        {
            Fuse.Animations.Animator.prototype._ObjInit.call(this);
        };

    });
