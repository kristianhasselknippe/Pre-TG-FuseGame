Fuse.Animations.Float3Blender = $CreateClass(
    function() {
    },
    function(S) {
        var I = S.prototype;

        I.GetType = function()
        {
            return 596;
        };

        I.$II = function(id)
        {
            return [621].indexOf(id) != -1;
        };

        I.Weight = function(v, w)
        {
            return Uno.Float3.op_Multiply(v, w);
        };

        I.Add = function(a, b)
        {
            return Uno.Float3.op_Addition(a, b);
        };

        I._ObjInit = function()
        {
        };

        Fuse.Animations.Float3Blender.New_1 = function()
        {
            var inst = new Fuse.Animations.Float3Blender;
            inst._ObjInit();
            return inst;
        };

        I["Fuse.Animations.Blender__float3.Weight"] = I.Weight;
        I["Fuse.Animations.Blender__float3.Add"] = I.Add;

    });
