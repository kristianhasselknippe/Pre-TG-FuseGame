Fuse.Animations.PropertyAnimatorState__float3 = $CreateClass(
    function() {
        Fuse.Animations.AnimatorStateProgress.call(this);
        this.mixHandle = null;
        this.Animator_1 = null;
    },
    function(S) {
        var I = S.prototype = new Fuse.Animations.AnimatorStateProgress;

        I.GetType = function()
        {
            return 644;
        };

        I.Disable = function()
        {
            if (this.mixHandle == null)
            {
                return;
            }

            this.mixHandle["Fuse.Animations.IMixerHandle__float3.Unregister"]();
            this.mixHandle = null;
        };

        I.Seek = function(progress, strength)
        {
            if (this.mixHandle == null)
            {
                Uno.Diagnostics.Debug.Log("Invalid Seek", 1, "/Users/vegard/RealtimeStudio/Uno/Packages/Fuse.Nodes/0.1.0/Animations/PropertyAnimator.uno", 45);
                return;
            }

            this.mixHandle["Fuse.Animations.IMixerHandle__float3.Set"](this.Animator_1.Value(), strength * progress);
        };

        I._ObjInit_2 = function(animator, variant, node)
        {
            Fuse.Animations.AnimatorStateProgress.prototype._ObjInit_1.call(this, animator, variant, node);
            this.Animator_1 = animator;
            this.mixHandle = this.Animator_1.Mixer["Fuse.Animations.IMixer.Register__float3"](this.Animator_1.Target());
        };

        Fuse.Animations.PropertyAnimatorState__float3.New_1 = function(animator, variant, node)
        {
            var inst = new Fuse.Animations.PropertyAnimatorState__float3;
            inst._ObjInit_2(animator, variant, node);
            return inst;
        };

    });
