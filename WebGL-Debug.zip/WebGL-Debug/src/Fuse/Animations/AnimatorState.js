Fuse.Animations.AnimatorState = $CreateClass(
    function() {
        this.Animator = null;
        this.Variant = 0;
        this.Node = null;
    },
    function(S) {
        var I = S.prototype;

        I.GetType = function()
        {
            return 588;
        };

        I.Disable = function()
        {
        };

        I._ObjInit = function(animator, variant, node)
        {
            this.Animator = animator;
            this.Variant = variant;
            this.Node = node;
        };

    });
