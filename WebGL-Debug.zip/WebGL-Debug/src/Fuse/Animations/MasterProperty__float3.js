Fuse.Animations.MasterProperty__float3 = $CreateClass(
    function() {
        Fuse.Animations.MasterBase__float3.call(this);
        this.Property = null;
    },
    function(S) {
        var I = S.prototype = new Fuse.Animations.MasterBase__float3;

        I.GetType = function()
        {
            return 679;
        };

        I.RestValue = function()
        {
            return this.Property.GetRestState();
        };

        I.OnInactive = function()
        {
            this.Property.Set(this.RestValue());
        };

        I._ObjInit_1 = function(property)
        {
            Fuse.Animations.MasterBase__float3.prototype._ObjInit.call(this);
            this.Property = property;
        };

    });
