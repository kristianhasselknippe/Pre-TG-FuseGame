Fuse.Animations.StackMasterProperty__bool = $CreateClass(
    function() {
        Fuse.Animations.MasterProperty__bool.call(this);
        this.blender = null;
    },
    function(S) {
        var I = S.prototype = new Fuse.Animations.MasterProperty__bool;

        I.GetType = function()
        {
            return 687;
        };

        I.OnActive = function()
        {
            if (this.blender == null)
            {
                this.blender = Fuse.Animations.BlenderMap.Get__bool(this.RestValue());
            }
        };

        I.OnComplete = function()
        {
            var nv = this.RestValue();

            for (var enum_123 = this.Handles.GetEnumerator(); enum_123.MoveNext(); )
            {
                var v = enum_123.Current();

                if (v.HasValue())
                {
                    nv = this.blender["Fuse.Animations.Blender__bool.Add"](nv, this.blender["Fuse.Animations.Blender__bool.Weight"](v.Value, v.Strength));
                }
            }

            this.Property.Set(nv);
        };

        I._ObjInit_2 = function(property)
        {
            Fuse.Animations.MasterProperty__bool.prototype._ObjInit_1.call(this, property);
        };

        Fuse.Animations.StackMasterProperty__bool.New_1 = function(property)
        {
            var inst = new Fuse.Animations.StackMasterProperty__bool;
            inst._ObjInit_2(property);
            return inst;
        };

    });
