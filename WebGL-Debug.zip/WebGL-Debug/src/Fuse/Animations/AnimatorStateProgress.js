Fuse.Animations.AnimatorStateProgress = $CreateClass(
    function() {
        Fuse.Animations.AnimatorState.call(this);
    },
    function(S) {
        var I = S.prototype = new Fuse.Animations.AnimatorState;

        I.GetType = function()
        {
            return 589;
        };

        I.SeekProgress = function(progress, dir, strength)
        {
            progress = Uno.Math.Clamp(progress, 0.0, 1.0);
            var ease = Fuse.Animations.EasingFunctions.FromEasing(this.Animator.GetEasing(this.Variant)).Invoke(progress);
            this.Seek(ease, strength);
            return (dir == 0) ? (progress >= 1.0) : (progress <= 0.0);
        };

        I.SeekTime = function(elapsed, totalDuration, dir, strength)
        {
            var relTime = elapsed - this.Animator.GetDelay(this.Variant, totalDuration);
            var progress = relTime / this.Animator.GetDurationWithoutDelay(this.Variant);
            return this.SeekProgress(progress, dir, strength);
        };

        I._ObjInit_1 = function(animator, variant, node)
        {
            Fuse.Animations.AnimatorState.prototype._ObjInit.call(this, animator, variant, node);
        };

    });
