Fuse.Animations.StackMasterProperty__float = $CreateClass(
    function() {
        Fuse.Animations.MasterProperty__float.call(this);
        this.blender = null;
    },
    function(S) {
        var I = S.prototype = new Fuse.Animations.MasterProperty__float;

        I.GetType = function()
        {
            return 683;
        };

        I.OnActive = function()
        {
            if (this.blender == null)
            {
                this.blender = Fuse.Animations.BlenderMap.Get__float(this.RestValue());
            }
        };

        I.OnComplete = function()
        {
            var nv = this.RestValue();

            for (var enum_123 = this.Handles.GetEnumerator(); enum_123.MoveNext(); )
            {
                var v = enum_123.Current();

                if (v.HasValue())
                {
                    nv = this.blender["Fuse.Animations.Blender__float.Add"](nv, this.blender["Fuse.Animations.Blender__float.Weight"](v.Value, v.Strength));
                }
            }

            this.Property.Set(nv);
        };

        I._ObjInit_2 = function(property)
        {
            Fuse.Animations.MasterProperty__float.prototype._ObjInit_1.call(this, property);
        };

        Fuse.Animations.StackMasterProperty__float.New_1 = function(property)
        {
            var inst = new Fuse.Animations.StackMasterProperty__float;
            inst._ObjInit_2(property);
            return inst;
        };

    });
