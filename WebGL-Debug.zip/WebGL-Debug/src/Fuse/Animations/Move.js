Fuse.Animations.Move = $CreateClass(
    function() {
        Fuse.Animations.TransformAnimator__Fuse_Translation.call(this);
        this._RelativeTo = 0;
        this._X = 0;
        this._Y = 0;
        this._Z = 0;
    },
    function(S) {
        var I = S.prototype = new Fuse.Animations.TransformAnimator__Fuse_Translation;

        I.GetType = function()
        {
            return 614;
        };

        I.RelativeTo = function(value)
        {
            if (value !== undefined)
            {
                this._RelativeTo = value;
            }
            else
            {
                return this._RelativeTo;
            }
        };

        I.X = function(value)
        {
            if (value !== undefined)
            {
                this._X = value;
            }
            else
            {
                return this._X;
            }
        };

        I.Y = function(value)
        {
            if (value !== undefined)
            {
                this._Y = value;
            }
            else
            {
                return this._Y;
            }
        };

        I.Z = function(value)
        {
            if (value !== undefined)
            {
                this._Z = value;
            }
            else
            {
                return this._Z;
            }
        };

        I.Vector = function(value)
        {
            if (value !== undefined)
            {
                var value_123 = new Uno.Float3;
                value_123.op_Assign(value);
                this.X(value_123.X);
                this.Y(value_123.Y);
                this.Z(value_123.Z);
            }
            else
            {
                return Uno.Float3.New_2(this.X(), this.Y(), this.Z());
            }
        };

        I.Update = function(elm, t)
        {
            t.RelativeNode(elm);
            t.RelativeTo(this.RelativeTo());
            t.Vector(this.Vector());
        };

        I._ObjInit_2 = function()
        {
            Fuse.Animations.TransformAnimator__Fuse_Translation.prototype._ObjInit_1.call(this);
        };

        Fuse.Animations.Move.New_1 = function()
        {
            var inst = new Fuse.Animations.Move;
            inst._ObjInit_2();
            return inst;
        };

    });
