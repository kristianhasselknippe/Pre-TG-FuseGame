Fuse.Animations.DiscreteMasterTransform = $CreateClass(
    function() {
        Fuse.Animations.MasterTransform.call(this);
    },
    function(S) {
        var I = S.prototype = new Fuse.Animations.MasterTransform;

        I.GetType = function()
        {
            return 600;
        };

        I.OnComplete = function()
        {
            this.FMT.Matrix.ResetIdentity();
            var str = 0.5;
            var value = null;

            for (var enum_123 = this.Handles.GetEnumerator(); enum_123.MoveNext(); )
            {
                var v = enum_123.Current();

                if (v.HasValue() && (v.Strength > str))
                {
                    value = v.Value;
                    str = v.Strength;
                }
            }

            if (value != null)
            {
                value.AppendTo(this.FMT.Matrix, 1.0);
            }

            this.FMT.Changed();
        };

        I._ObjInit_2 = function(node)
        {
            Fuse.Animations.MasterTransform.prototype._ObjInit_1.call(this, node);
        };

        Fuse.Animations.DiscreteMasterTransform.New_1 = function(node)
        {
            var inst = new Fuse.Animations.DiscreteMasterTransform;
            inst._ObjInit_2(node);
            return inst;
        };

    });
