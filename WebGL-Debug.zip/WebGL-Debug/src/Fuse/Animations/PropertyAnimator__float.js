Fuse.Animations.PropertyAnimator__float = $CreateClass(
    function() {
        Fuse.Animations.Animator.call(this);
        this._Target = null;
        this._Value = 0;
    },
    function(S) {
        var I = S.prototype = new Fuse.Animations.Animator;

        I.GetType = function()
        {
            return 627;
        };

        I.Target = function(value)
        {
            if (value !== undefined)
            {
                this._Target = value;
            }
            else
            {
                return this._Target;
            }
        };

        I.Value = function(value)
        {
            if (value !== undefined)
            {
                this._Value = value;
            }
            else
            {
                return this._Value;
            }
        };

        I.CreateState = function(variant, elm)
        {
            return Fuse.Animations.PropertyAnimatorState__float.New_1(this, variant, elm);
        };

    });
