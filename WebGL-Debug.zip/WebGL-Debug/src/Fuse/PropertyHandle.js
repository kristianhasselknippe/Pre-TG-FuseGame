Fuse.PropertyHandle = $CreateClass(
    function() {
        this.Handle = 0;
    },
    function(S) {
        var I = S.prototype;

        Fuse.PropertyHandle._counter = 0;

        I.GetType = function()
        {
            return 979;
        };

        I._ObjInit = function()
        {
            this.Handle = Fuse.PropertyHandle._counter;
            Fuse.PropertyHandle._counter++;
        };

        Fuse.PropertyHandle.New_1 = function()
        {
            var inst = new Fuse.PropertyHandle;
            inst._ObjInit();
            return inst;
        };

    });
