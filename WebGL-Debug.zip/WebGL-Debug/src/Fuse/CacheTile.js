Fuse.CacheTile = $CreateClass(
    function() {
        this.$struct = true;
        this._compositMatrix = new Uno.Float4x4;
        this._framebuffer = null;
        this._rect = new Uno.Recti;
    },
    function(S) {
        var I = S.prototype;

        I.GetType = function()
        {
            return 989;
        };

        I.Texture = function()
        {
            return this._framebuffer.Framebuffer().ColorBuffer();
        };

        I.EnsureHasFramebuffer = function()
        {
            if (((this._framebuffer == null) || (this._framebuffer.Width() != this._rect.Size().X)) || (this._framebuffer.Height() != this._rect.Size().Y))
            {
                if (this._framebuffer != null)
                {
                    this._framebuffer.Dispose();
                }

                this._framebuffer = Fuse.CacheFramebuffer.New_1(this._rect.Size().X, this._rect.Size().Y, 3, 0);
            }
        };

        I.op_Assign = function(value)
        {
            this._compositMatrix.op_Assign(value._compositMatrix);
            this._framebuffer = value._framebuffer;
            this._rect.op_Assign(value._rect);
        };

    });
