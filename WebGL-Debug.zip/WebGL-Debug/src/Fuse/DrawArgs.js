Fuse.DrawArgs = $CreateClass(
    function() {
        Uno.EventArgs.call(this);
        this._Context = null;
    },
    function(S) {
        var I = S.prototype = new Uno.EventArgs;

        I.GetType = function()
        {
            return 952;
        };

        I.Context = function(value)
        {
            if (value !== undefined)
            {
                this._Context = value;
            }
            else
            {
                return this._Context;
            }
        };

        I._ObjInit_1 = function(dc)
        {
            Uno.EventArgs.prototype._ObjInit.call(this);
            this.Context(dc);
        };

        Fuse.DrawArgs.New_2 = function(dc)
        {
            var inst = new Fuse.DrawArgs;
            inst._ObjInit_1(dc);
            return inst;
        };

    });
