Fuse.PointerEventData = $CreateClass(
    function() {
        this.ViewProvider = null;
        this.PointIndex = 0;
        this.PointCoord = new Uno.Float2;
        this.WheelDelta = new Uno.Float2;
        this.WheelDeltaMode = 0;
        this.IsPrimary = false;
        this.PointerType = 0;
    },
    function(S) {
        var I = S.prototype;

        I.GetType = function()
        {
            return 919;
        };

        I._ObjInit = function(pointIndex, pointCoord, wheelDelta, wheelDeltaMode, isPrimary, viewProvider, pointerType)
        {
            this.ViewProvider = viewProvider;
            this.PointIndex = pointIndex;
            this.PointCoord.op_Assign(pointCoord);
            this.WheelDelta.op_Assign(wheelDelta);
            this.WheelDeltaMode = wheelDeltaMode;
            this.IsPrimary = isPrimary;
            this.PointerType = pointerType;
        };

        Fuse.PointerEventData.New_1 = function(pointIndex, pointCoord, wheelDelta, wheelDeltaMode, isPrimary, viewProvider, pointerType)
        {
            var inst = new Fuse.PointerEventData;
            inst._ObjInit(pointIndex, pointCoord, wheelDelta, wheelDeltaMode, isPrimary, viewProvider, pointerType);
            return inst;
        };

    });
