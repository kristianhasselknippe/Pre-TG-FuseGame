Fuse.Pass = $CreateClass(
    function() {
    },
    function(S) {
        var I = S.prototype;

        I.GetType = function()
        {
            return 958;
        };

    });
