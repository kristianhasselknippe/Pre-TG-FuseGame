Fuse.AlignmentHelpers = $CreateClass(
    function() {
    },
    function(S) {

        Fuse.AlignmentHelpers.GetVerticalAlign = function(a)
        {
            return a & 12;
        };

        Fuse.AlignmentHelpers.GetHorizontalAlign = function(a)
        {
            return a & 3;
        };

    });
