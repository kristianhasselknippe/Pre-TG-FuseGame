Fuse.ActivationState = $CreateClass(
    function() {
        this._Progress = 0;
        this._Direction = 0;
    },
    function(S) {
        var I = S.prototype;

        I.GetType = function()
        {
            return 992;
        };

        I.Progress = function(value)
        {
            if (value !== undefined)
            {
                this._Progress = value;
            }
            else
            {
                return this._Progress;
            }
        };

        I.Direction = function(value)
        {
            if (value !== undefined)
            {
                this._Direction = value;
            }
            else
            {
                return this._Direction;
            }
        };

        I._ObjInit = function(progress, direction)
        {
            this.Progress(progress);
            this.Direction(direction);
        };

        Fuse.ActivationState.New_1 = function(progress, direction)
        {
            var inst = new Fuse.ActivationState;
            inst._ObjInit(progress, direction);
            return inst;
        };

    });
