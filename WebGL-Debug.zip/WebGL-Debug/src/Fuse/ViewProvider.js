Fuse.ViewProvider = $CreateClass(
    function() {
    },
    function(S) {
        var I = S.prototype;

        Fuse.ViewProvider._default = null;

        I.GetType = function()
        {
            return 965;
        };

        Fuse.ViewProvider.Default = function()
        {
            if (Fuse.ViewProvider._default == null)
            {
                Fuse.ViewProvider._default = Fuse.ViewProviderSnapshot.New_1(null, Uno.Application.Current().GraphicsContext().Viewport());
            }

            return Fuse.ViewProvider._default;
        };

        I._ObjInit = function()
        {
        };

    });
