Fuse.Triggers.EdgeSwiped = $CreateClass(
    function() {
        Fuse.Triggers.ElementTrigger.call(this);
        this._leftRightSwipe = null;
        this._upDownSwipe = null;
        this._pointBody1D = null;
        this._edgeThreshold = 0;
        this._progress = 0;
        this._edge = 0;
        this._target = null;
        this._previousCoord = new Uno.Float2;
        this._currentCoord = new Uno.Float2;
        this._startCoord = new Uno.Float2;
        this._startTime = 0;
        this._velocity = 0;
        this._down = 0;
        this._element = null;
    },
    function(S) {
        var I = S.prototype = new Fuse.Triggers.ElementTrigger;

        I.GetType = function()
        {
            return 792;
        };

        I.Edge = function(value)
        {
            if (value !== undefined)
            {
                this._edge = value;
            }
            else
            {
                return this._edge;
            }
        };

        I.EdgeThreshold = function(value)
        {
            if (value !== undefined)
            {
                this._edgeThreshold = value;
            }
            else
            {
                return this._edgeThreshold;
            }
        };

        I.Target = function(value)
        {
            if (value !== undefined)
            {
                this._target = value;
            }
            else
            {
                return this._target;
            }
        };

        I.Progress = function(value)
        {
            if (value !== undefined)
            {
                this.Seek(this._progress = Uno.Math.Max(value, 0.0));
            }
            else
            {
                return this._progress;
            }
        };

        I.OnRooted_1 = function(e)
        {
            if (this._element == null)
            {
                this._element = e;
                this._element.add_PointerMoved($CreateDelegate(this, Fuse.Triggers.EdgeSwiped.prototype.OnPointerMoved, 926));
                this._element.add_PointerReleased($CreateDelegate(this, Fuse.Triggers.EdgeSwiped.prototype.OnPointerReleased, 928));
                this._element.add_PointerPressed($CreateDelegate(this, Fuse.Triggers.EdgeSwiped.prototype.OnPointerPressed, 924));
                this._element.add_LostSoftCapture($CreateDelegate(this, Fuse.Triggers.EdgeSwiped.prototype.OnLostSoftCapture, 939));
            }
        };

        I.OnUnrooted_1 = function(e)
        {
            if (this._element != null)
            {
                this._element.remove_PointerMoved($CreateDelegate(this, Fuse.Triggers.EdgeSwiped.prototype.OnPointerMoved, 926));
                this._element.remove_PointerReleased($CreateDelegate(this, Fuse.Triggers.EdgeSwiped.prototype.OnPointerReleased, 928));
                this._element.remove_PointerPressed($CreateDelegate(this, Fuse.Triggers.EdgeSwiped.prototype.OnPointerPressed, 924));
                this._element.remove_LostSoftCapture($CreateDelegate(this, Fuse.Triggers.EdgeSwiped.prototype.OnLostSoftCapture, 939));
                this._element = null;
            }
        };

        I.OnPointBodyPositionChanged = function(position)
        {
            this.Progress((position / 200.0));
        };

        I.OnLostSoftCapture = function(sender, args)
        {
            this._down = -1;
        };

        I.OnPointerPressed = function(sender, args)
        {
            if (this.IsWithinSwipeBounds(args.PointCoord()))
            {
                this._down = args.PointIndex();
                this._startTime = Fuse.Time.FrameTime();
                this._pointBody1D.StopSimulation();
                args.SoftCapturePointer($DownCast(this._element, 33719));
                this._previousCoord.op_Assign(args.PointCoord());
                this._currentCoord.op_Assign(args.PointCoord());
                this._startCoord.op_Assign(args.PointCoord());
            }
        };

        I.OnPointerMoved = function(sender, args)
        {
            if (this._down != args.PointIndex())
            {
                return;
            }

            this._previousCoord.op_Assign(this._currentCoord);
            this._currentCoord.op_Assign(args.PointCoord());

            if (args.IsSoftCapturedTo($DownCast(this._element, 33719)))
            {
                var diff = Uno.Float2.op_Subtraction(this._currentCoord, this._startCoord);
                var withinBounds = false;

                switch (this.Edge())
                {
                    case 1:
                    case 0:
                    {
                        {
                            withinBounds = this._leftRightSwipe.IsWithinBounds(diff);
                        }

                        break;
                    }
                    case 2:
                    case 3:
                    {
                        {
                            withinBounds = this._upDownSwipe.IsWithinBounds(diff);
                        }

                        break;
                    }
                }

                if (withinBounds)
                {
                    args.HardCapturePointer($DownCast(this._element, 33719));
                }
            }

            if (args.IsHardCapturedTo($DownCast(this._element, 33719)))
            {
                this.CalcProgress();
                this._pointBody1D.Position(this.Progress() * 200.0);
            }
        };

        I.OnPointerReleased = function(sender, args)
        {
            if (this._down != args.PointIndex())
            {
                return;
            }

            if (args.IsSoftCapturedTo($DownCast(this._element, 33719)))
            {
                args.ReleaseSoftCapture($DownCast(this._element, 33719));
            }

            if (args.IsHardCapturedTo($DownCast(this._element, 33719)))
            {
                args.ReleaseHardCapture();
                this._pointBody1D.IsStatic(false);
                this._pointBody1D.StartSimulation();

                if (this._velocity > 0.0)
                {
                    this._pointBody1D.AttractionDestinatoin(200.0);
                }
                else
                {
                    this._pointBody1D.AttractionDestinatoin(-25.0);
                }
            }

            this._down = -1;
        };

        I.IsWithinSwipeBounds = function(absolutePointerCoord)
        {
            var c_125 = new Uno.Float2;
            var b_126 = new Uno.Float2;
            var coord_127 = new Uno.Float2;
            var bounds_128 = new Uno.Float2;

            if (this.Target() != null)
            {
                c_125.op_Assign(this.Target().FromAbsolute(absolutePointerCoord));
                b_126.op_Assign(this.Target().ActualSize());

                if ((((c_125.X >= 0.0) && (c_125.X <= b_126.X)) && (c_125.Y >= 0.0)) && (c_125.Y <= b_126.Y))
                {
                    return true;
                }
            }

            coord_127.op_Assign(this._element.FromAbsolute(absolutePointerCoord));
            bounds_128.op_Assign(this._element.ActualSize());
            var threshold = this.EdgeThreshold() * this._element.AbsoluteZoom();

            switch (this.Edge())
            {
                case 0:
                {
                    return (coord_127.X >= 0.0) && (coord_127.X <= threshold);
                }
                case 1:
                {
                    return (coord_127.X <= bounds_128.X) && (coord_127.X >= (bounds_128.X - threshold));
                }
                case 2:
                {
                    return (coord_127.Y >= 0.0) && (coord_127.Y <= threshold);
                }
                case 3:
                {
                    return (coord_127.Y <= bounds_128.Y) && (coord_127.Y >= (bounds_128.Y - threshold));
                }
            }

            return false;
        };

        I.CalcProgress = function()
        {
            var bounds_129 = new Uno.Float2;
            var ind_130 = this.Target();
            var t = (ind_130 != null) ? ind_130 : this._element;
            var delta = Uno.Float2.op_Division_1(Uno.Float2.op_Subtraction(this._currentCoord, this._previousCoord), t.AbsoluteZoom());
            bounds_129.op_Assign(t.ActualSize());
            var progress = Uno.Float2.op_Division(delta, bounds_129);
            var v = Uno.Float2.op_Subtraction(this._currentCoord, this._startCoord);
            this._velocity = v.Y / (Fuse.Time.FrameTime() - this._startTime);

            switch (this.Edge())
            {
                case 0:
                {
                    {
                        this.Progress(Uno.Math.Clamp(this.Progress() + progress.X, 0.0, 1.0));
                        this._velocity = delta.X / Fuse.Time.FrameInterval();
                    }

                    break;
                }
                case 1:
                {
                    {
                        this.Progress(Uno.Math.Clamp(this.Progress() + (progress.X * -1.0), 0.0, 1.0));
                        this._velocity = (delta.X / Fuse.Time.FrameInterval()) * -1.0;
                    }

                    break;
                }
                case 2:
                {
                    {
                        this.Progress(Uno.Math.Clamp(this.Progress() + progress.Y, 0.0, 1.0));
                        this._velocity = delta.Y / Fuse.Time.FrameInterval();
                    }

                    break;
                }
                case 3:
                {
                    {
                        this.Progress(Uno.Math.Clamp(this.Progress() + (progress.Y * -1.0), 0.0, 1.0));
                        this._velocity = (delta.Y / Fuse.Time.FrameInterval()) * -1.0;
                    }

                    break;
                }
            }
        };

    });
