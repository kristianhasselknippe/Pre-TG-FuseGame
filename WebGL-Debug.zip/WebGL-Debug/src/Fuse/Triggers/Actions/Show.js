Fuse.Triggers.Actions.Show = $CreateClass(
    function() {
        Fuse.Triggers.Actions.TriggerAction.call(this);
    },
    function(S) {
        var I = S.prototype = new Fuse.Triggers.Actions.TriggerAction;

        I.GetType = function()
        {
            return 775;
        };

        I.Perform = function(target)
        {
            if ($IsOp(target, 33542))
            {
                $DownCast(target, 33542)["Fuse.Triggers.Actions.IShow.Show"]();
            }
        };

    });
