Fuse.Triggers.Actions.Hide = $CreateClass(
    function() {
        Fuse.Triggers.Actions.TriggerAction.call(this);
    },
    function(S) {
        var I = S.prototype = new Fuse.Triggers.Actions.TriggerAction;

        I.GetType = function()
        {
            return 777;
        };

        I.Perform = function(target)
        {
            if ($IsOp(target, 33544))
            {
                $DownCast(target, 33544)["Fuse.Triggers.Actions.IHide.Hide"]();
            }
        };

    });
