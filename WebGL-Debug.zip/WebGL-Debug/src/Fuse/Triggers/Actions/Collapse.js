Fuse.Triggers.Actions.Collapse = $CreateClass(
    function() {
        Fuse.Triggers.Actions.TriggerAction.call(this);
    },
    function(S) {
        var I = S.prototype = new Fuse.Triggers.Actions.TriggerAction;

        I.GetType = function()
        {
            return 779;
        };

        I.Perform = function(target)
        {
            if ($IsOp(target, 33546))
            {
                $DownCast(target, 33546)["Fuse.Triggers.Actions.ICollapse.Collapse"]();
            }
        };

    });
