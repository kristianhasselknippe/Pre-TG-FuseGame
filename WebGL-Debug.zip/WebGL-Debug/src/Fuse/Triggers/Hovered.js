Fuse.Triggers.Hovered = $CreateClass(
    function() {
        Fuse.Triggers.Trigger.call(this);
        this._node_1 = null;
    },
    function(S) {
        var I = S.prototype = new Fuse.Triggers.Trigger;

        I.GetType = function()
        {
            return 782;
        };

        I.OnRooted = function(elm)
        {
            if (this._node_1 == null)
            {
                this._node_1 = elm;
                this._node_1.add_PointerEnter($CreateDelegate(this, Fuse.Triggers.Hovered.prototype.OnPointerEnter, 932));
                this._node_1.add_PointerLeave($CreateDelegate(this, Fuse.Triggers.Hovered.prototype.OnPointerLeave, 934));
            }

            Fuse.Triggers.Trigger.prototype.OnRooted.call(this, elm);
        };

        I.OnUnrooted = function(elm)
        {
            if (this._node_1 != null)
            {
                this._node_1.remove_PointerEnter($CreateDelegate(this, Fuse.Triggers.Hovered.prototype.OnPointerEnter, 932));
                this._node_1.remove_PointerLeave($CreateDelegate(this, Fuse.Triggers.Hovered.prototype.OnPointerLeave, 934));
                this._node_1 = null;
            }

            Fuse.Triggers.Trigger.prototype.OnUnrooted.call(this, elm);
        };

        I.OnPointerEnter = function(sender, args)
        {
            this.Activate(null);
        };

        I.OnPointerLeave = function(sender, args)
        {
            this.Deactivate();
        };

        I._ObjInit_2 = function()
        {
            Fuse.Triggers.Trigger.prototype._ObjInit_1.call(this);
        };

        Fuse.Triggers.Hovered.New_1 = function()
        {
            var inst = new Fuse.Triggers.Hovered;
            inst._ObjInit_2();
            return inst;
        };

    });
