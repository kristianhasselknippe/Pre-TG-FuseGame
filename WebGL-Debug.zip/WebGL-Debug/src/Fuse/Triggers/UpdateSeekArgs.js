Fuse.Triggers.UpdateSeekArgs = $CreateClass(
    function() {
        this._Delta = 0;
        this._Velocity = 0;
        this._Distance = 0;
    },
    function(S) {
        var I = S.prototype;

        I.GetType = function()
        {
            return 800;
        };

        I.Delta = function(value)
        {
            if (value !== undefined)
            {
                this._Delta = value;
            }
            else
            {
                return this._Delta;
            }
        };

        I.Velocity = function(value)
        {
            if (value !== undefined)
            {
                this._Velocity = value;
            }
            else
            {
                return this._Velocity;
            }
        };

        I.Distance = function(value)
        {
            if (value !== undefined)
            {
                this._Distance = value;
            }
            else
            {
                return this._Distance;
            }
        };

        I._ObjInit = function(delta, velocity, distance)
        {
            this.Delta(delta);
            this.Velocity(velocity);
            this.Distance(distance);
        };

        Fuse.Triggers.UpdateSeekArgs.New_1 = function(delta, velocity, distance)
        {
            var inst = new Fuse.Triggers.UpdateSeekArgs;
            inst._ObjInit(delta, velocity, distance);
            return inst;
        };

    });
