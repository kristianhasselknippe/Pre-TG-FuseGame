Fuse.Triggers.TappedArgs = $CreateClass(
    function() {
        Fuse.CustomPointerEventArgs.call(this);
    },
    function(S) {
        var I = S.prototype = new Fuse.CustomPointerEventArgs;

        I.GetType = function()
        {
            return 784;
        };

        I._ObjInit_4 = function(args)
        {
            Fuse.CustomPointerEventArgs.prototype._ObjInit_3.call(this, args);
        };

        Fuse.Triggers.TappedArgs.New_2 = function(args)
        {
            var inst = new Fuse.Triggers.TappedArgs;
            inst._ObjInit_4(args);
            return inst;
        };

    });
