Fuse.Triggers.EndSeekArgs = $CreateClass(
    function() {
        this._SnapTo = 0;
    },
    function(S) {
        var I = S.prototype;

        I.GetType = function()
        {
            return 802;
        };

        I.SnapTo = function(value)
        {
            if (value !== undefined)
            {
                this._SnapTo = value;
            }
            else
            {
                return this._SnapTo;
            }
        };

        I._ObjInit = function(snapTo)
        {
            this.SnapTo(snapTo);
        };

        Fuse.Triggers.EndSeekArgs.New_1 = function(snapTo)
        {
            var inst = new Fuse.Triggers.EndSeekArgs;
            inst._ObjInit(snapTo);
            return inst;
        };

    });
