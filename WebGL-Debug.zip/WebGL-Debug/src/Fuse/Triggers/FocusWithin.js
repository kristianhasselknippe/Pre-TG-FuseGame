Fuse.Triggers.FocusWithin = $CreateClass(
    function() {
        Fuse.Triggers.Trigger.call(this);
    },
    function(S) {
        var I = S.prototype = new Fuse.Triggers.Trigger;

        I.GetType = function()
        {
            return 781;
        };

        I.OnRooted = function(elm)
        {
            Fuse.Triggers.Trigger.prototype.OnRooted.call(this, elm);
            elm.add_GotFocus($CreateDelegate(this, Fuse.Triggers.FocusWithin.prototype.OnGotFocus, 445));
            elm.add_LostFocus($CreateDelegate(this, Fuse.Triggers.FocusWithin.prototype.OnLostFocus, 445));
        };

        I.OnUnrooted = function(elm)
        {
            elm.remove_GotFocus($CreateDelegate(this, Fuse.Triggers.FocusWithin.prototype.OnGotFocus, 445));
            elm.remove_LostFocus($CreateDelegate(this, Fuse.Triggers.FocusWithin.prototype.OnLostFocus, 445));
            Fuse.Triggers.Trigger.prototype.OnUnrooted.call(this, elm);
        };

        I.OnGotFocus = function(sender, args)
        {
            if (this.Node().IsFocusWithin())
            {
                this.Activate(null);
            }
        };

        I.OnLostFocus = function(sender, args)
        {
            this.Deactivate();
        };

        I._ObjInit_2 = function()
        {
            Fuse.Triggers.Trigger.prototype._ObjInit_1.call(this);
        };

        Fuse.Triggers.FocusWithin.New_1 = function()
        {
            var inst = new Fuse.Triggers.FocusWithin;
            inst._ObjInit_2();
            return inst;
        };

    });
