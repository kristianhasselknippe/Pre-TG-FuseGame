Fuse.Triggers.SwipeNavigate = $CreateClass(
    function() {
        Fuse.Behavior.call(this);
        this._currentNavigation = null;
        this._element = null;
        this._startCoord = new Uno.Float2;
        this._currentCoord = new Uno.Float2;
        this._previousCoord = new Uno.Float2;
        this._startTime = 0;
        this._horizontalGesture = null;
        this._verticalGesture = null;
        this._down = 0;
        this._SwipeDirection = 0;
        this._VelocityThreshold = 0;
    },
    function(S) {
        var I = S.prototype = new Fuse.Behavior;

        I.GetType = function()
        {
            return 804;
        };

        I.Navigation = function()
        {
            var elm = this._element;

            while (elm != null)
            {
                var navigation = Fuse.Controls.Navigation.TryFind(elm);

                if (navigation != null)
                {
                    return navigation;
                }
            }

            return null;
        };

        I.SwipeDirection = function(value)
        {
            if (value !== undefined)
            {
                this._SwipeDirection = value;
            }
            else
            {
                return this._SwipeDirection;
            }
        };

        I.VelocityThreshold = function(value)
        {
            if (value !== undefined)
            {
                this._VelocityThreshold = value;
            }
            else
            {
                return this._VelocityThreshold;
            }
        };

        I.DeltaX = function()
        {
            return ((this._previousCoord.X - this._currentCoord.X) / this._currentNavigation.Owner().ActualSize().X) / this._element.AbsoluteZoom();
        };

        I.DeltaY = function()
        {
            return ((this._previousCoord.Y - this._currentCoord.Y) / this._currentNavigation.Owner().ActualSize().Y) / this._element.AbsoluteZoom();
        };

        I.Distance = function()
        {
            return Uno.Float2.op_Subtraction(this._startCoord, this._currentCoord);
        };

        I.VelocityY = function()
        {
            return (this.Distance().Y / (Fuse.Time.FrameTime() - this._startTime));
        };

        I.VelocityX = function()
        {
            return (this.Distance().X / (Fuse.Time.FrameTime() - this._startTime));
        };

        I.OnRooted = function(elm)
        {
            if ($IsOp(elm, 991))
            {
                this._element = $AsOp(elm, 991);
                this._element.add_PointerPressed($CreateDelegate(this, Fuse.Triggers.SwipeNavigate.prototype.OnPointerPressed, 924));
                this._element.add_PointerMoved($CreateDelegate(this, Fuse.Triggers.SwipeNavigate.prototype.OnPointerMoved, 926));
                this._element.add_PointerReleased($CreateDelegate(this, Fuse.Triggers.SwipeNavigate.prototype.OnPointerReleased, 928));
                this._element.add_LostSoftCapture($CreateDelegate(this, Fuse.Triggers.SwipeNavigate.prototype.OnLostSoftCapture, 939));
            }
        };

        I.OnUnrooted = function(elm)
        {
            if ($IsOp(elm, 991))
            {
                this._element.remove_PointerPressed($CreateDelegate(this, Fuse.Triggers.SwipeNavigate.prototype.OnPointerPressed, 924));
                this._element.remove_PointerMoved($CreateDelegate(this, Fuse.Triggers.SwipeNavigate.prototype.OnPointerMoved, 926));
                this._element.remove_PointerReleased($CreateDelegate(this, Fuse.Triggers.SwipeNavigate.prototype.OnPointerReleased, 928));
                this._element.remove_LostSoftCapture($CreateDelegate(this, Fuse.Triggers.SwipeNavigate.prototype.OnLostSoftCapture, 939));
                this._element = null;
            }
        };

        I.OnLostSoftCapture = function(sender, args)
        {
            this._down = -1;

            if (this._currentNavigation != null)
            {
                this._currentNavigation.EndSeek(Fuse.Triggers.EndSeekArgs.New_1(1));
                this._currentNavigation = null;
            }
        };

        I.OnPointerPressed = function(sender, args)
        {
            args.SoftCapturePointer($DownCast(this._element, 33719));
            this._down = args.PointIndex();
            this._startCoord.op_Assign((this._currentCoord.op_Assign((this._previousCoord.op_Assign(args.PointCoord()), this._previousCoord)), this._currentCoord));
            this._startTime = Fuse.Time.FrameTime();
            this._currentNavigation = this.Navigation();
        };

        I.OnPointerMoved = function(sender, args)
        {
            if (this._down != args.PointIndex())
            {
                return;
            }

            if (this._currentNavigation == null)
            {
                return;
            }

            this._previousCoord.op_Assign(this._currentCoord);
            this._currentCoord.op_Assign(args.PointCoord());

            if (args.IsHardCapturedTo($DownCast(this._element, 33719)))
            {
                this._currentNavigation.Seek(this.GetNavigationArgs());
            }
            else if (!args.IsPointerHardCaptured())
            {
                var diff = Uno.Float2.op_Subtraction(this._currentCoord, this._startCoord);
                var withinBounds = (this.SwipeDirection() == 0) ? this._horizontalGesture.IsWithinBounds(diff) : this._verticalGesture.IsWithinBounds(diff);

                if (withinBounds)
                {
                    args.HardCapturePointer($DownCast(this._element, 33719));
                    this._currentNavigation.BeginSeek();
                }
            }
        };

        I.OnPointerReleased = function(sender, args)
        {
            this._previousCoord.op_Assign(this._currentCoord);
            this._currentCoord.op_Assign(args.PointCoord());
            this._down = -1;

            if (this._currentNavigation == null)
            {
                return;
            }

            if (args.IsHardCapturedTo($DownCast(this._element, 33719)))
            {
                this._currentNavigation.EndSeek(Fuse.Triggers.EndSeekArgs.New_1(this.DeterminSnap()));
                args.ReleaseHardCapture();
            }
            else
            {
                if (args.IsSoftCapturedTo($DownCast(this._element, 33719)))
                {
                    args.ReleaseSoftCapture($DownCast(this._element, 33719));
                }
            }

            this._currentNavigation = null;
        };

        I.GetNavigationArgs = function()
        {
            if (this.SwipeDirection() == 0)
            {
                return Fuse.Triggers.UpdateSeekArgs.New_1(this.DeltaX(), this.VelocityX(), this.Distance().X);
            }
            else
            {
                return Fuse.Triggers.UpdateSeekArgs.New_1(this.DeltaY(), this.VelocityY(), this.Distance().Y);
            }
        };

        I.DeterminSnap = function()
        {
            if (this.SwipeDirection() == 0)
            {
                if (this.VelocityX() > 0.0)
                {
                    return (this.VelocityX() > this.VelocityThreshold()) ? 2 : 1;
                }
                else
                {
                    return (this.VelocityX() < (this.VelocityThreshold() * -1.0)) ? 0 : 1;
                }
            }
            else
            {
                if (this.VelocityY() > 0.0)
                {
                    return (this.VelocityY() > this.VelocityThreshold()) ? 2 : 1;
                }
                else
                {
                    return (this.VelocityY() < (this.VelocityThreshold() * -1.0)) ? 0 : 1;
                }
            }

            return 1;
        };

    });
