Fuse.Triggers.Enter = $CreateClass(
    function() {
        Fuse.Triggers.ElementTrigger.call(this);
        this._Direction = 0;
        this._Element = null;
    },
    function(S) {
        var I = S.prototype = new Fuse.Triggers.ElementTrigger;

        I.GetType = function()
        {
            return 796;
        };

        I.Direction = function(value)
        {
            if (value !== undefined)
            {
                this._Direction = value;
            }
            else
            {
                return this._Direction;
            }
        };

        I.Element = function(value)
        {
            if (value !== undefined)
            {
                this._Element = value;
            }
            else
            {
                return this._Element;
            }
        };

        I.OnRooted_1 = function(elm)
        {
            this.Element(elm);
            this.Element().add_ActivationStateChanged($CreateDelegate(this, Fuse.Triggers.Enter.prototype.OnActivationStateChanged, 993));
        };

        I.OnUnrooted_1 = function(elm)
        {
            this.Element().remove_ActivationStateChanged($CreateDelegate(this, Fuse.Triggers.Enter.prototype.OnActivationStateChanged, 993));
            this.Element(null);
        };

        I.OnActivationStateChanged = function(sender, state)
        {
            if ((this.Direction() == state.Direction()) || (this.Direction() == 0))
            {
                if (state.Progress() <= 0.0)
                {
                    this.Seek(state.Progress() * -1.0);
                }
                else
                {
                    this.Deactivate();
                }
            }
            else
            {
                this.Deactivate();
            }
        };

        I._ObjInit_3 = function()
        {
            Fuse.Triggers.ElementTrigger.prototype._ObjInit_2.call(this);
            this.Direction(0);
        };

        Fuse.Triggers.Enter.New_1 = function()
        {
            var inst = new Fuse.Triggers.Enter;
            inst._ObjInit_3();
            return inst;
        };

    });
