Fuse.Triggers.Disabled = $CreateClass(
    function() {
        Fuse.Triggers.Trigger.call(this);
    },
    function(S) {
        var I = S.prototype = new Fuse.Triggers.Trigger;

        I.GetType = function()
        {
            return 780;
        };

        I.OnRooted = function(elm)
        {
            Fuse.Triggers.Trigger.prototype.OnRooted.call(this, elm);
            elm.add_IsEnabledChanged($CreateDelegate(this, Fuse.Triggers.Disabled.prototype.OnIsEnabledChanged, 445));
            elm.add_Update($CreateDelegate(this, Fuse.Triggers.Disabled.prototype.OnFirstUpdate, 445));
        };

        I.OnFirstUpdate = function(sender, args)
        {
            var elm = $AsOp(sender, 978);
            elm.remove_Update($CreateDelegate(this, Fuse.Triggers.Disabled.prototype.OnFirstUpdate, 445));

            if (!elm.IsEnabled())
            {
                this.BypassActivate();
            }
        };

        I.OnUnrooted = function(elm)
        {
            elm.remove_IsEnabledChanged($CreateDelegate(this, Fuse.Triggers.Disabled.prototype.OnIsEnabledChanged, 445));
            Fuse.Triggers.Trigger.prototype.OnUnrooted.call(this, elm);
        };

        I.OnIsEnabledChanged = function(sender, args)
        {
            if ($IsOp(sender, 978))
            {
                var n = $AsOp(sender, 978);

                if (!n.IsEnabled())
                {
                    this.Activate(null);
                }
                else
                {
                    this.Deactivate();
                }
            }
        };

        I._ObjInit_2 = function()
        {
            Fuse.Triggers.Trigger.prototype._ObjInit_1.call(this);
        };

        Fuse.Triggers.Disabled.New_1 = function()
        {
            var inst = new Fuse.Triggers.Disabled;
            inst._ObjInit_2();
            return inst;
        };

    });
