Fuse.Triggers.Pressed = $CreateClass(
    function() {
        Fuse.Triggers.Trigger.call(this);
    },
    function(S) {
        var I = S.prototype = new Fuse.Triggers.Trigger;

        I.GetType = function()
        {
            return 783;
        };

        I.OnRooted = function(elm)
        {
            Fuse.Triggers.Trigger.prototype.OnRooted.call(this, elm);
            this.Node().add_PointerPressed($CreateDelegate(this, Fuse.Triggers.Pressed.prototype.OnPointerPressed, 924));
            this.Node().add_PointerReleased($CreateDelegate(this, Fuse.Triggers.Pressed.prototype.OnPointerReleased, 928));
            this.Node().add_LostSoftCapture($CreateDelegate(this, Fuse.Triggers.Pressed.prototype.OnLostSoftCapture, 939));
        };

        I.OnUnrooted = function(elm)
        {
            this.Node().remove_PointerPressed($CreateDelegate(this, Fuse.Triggers.Pressed.prototype.OnPointerPressed, 924));
            this.Node().remove_PointerReleased($CreateDelegate(this, Fuse.Triggers.Pressed.prototype.OnPointerReleased, 928));
            this.Node().remove_LostSoftCapture($CreateDelegate(this, Fuse.Triggers.Pressed.prototype.OnLostSoftCapture, 939));
            Fuse.Triggers.Trigger.prototype.OnUnrooted.call(this, elm);
        };

        I.OnPointerPressed = function(sender, args)
        {
            if (!args.IsSoftCapturedTo($AsOp(sender, 33719)))
            {
                args.SoftCapturePointer($AsOp(sender, 33719));
            }

            this.Activate(null);
        };

        I.OnLostSoftCapture = function(sender, args)
        {
            this.Deactivate();
        };

        I.OnPointerReleased = function(sender, args)
        {
            if (!args.IsHandled())
            {
                args.ReleaseSoftCapture($AsOp(sender, 33719));
                this.Deactivate();
            }
        };

        I._ObjInit_2 = function()
        {
            Fuse.Triggers.Trigger.prototype._ObjInit_1.call(this);
        };

        Fuse.Triggers.Pressed.New_1 = function()
        {
            var inst = new Fuse.Triggers.Pressed;
            inst._ObjInit_2();
            return inst;
        };

    });
