Fuse.Triggers.ContainsText = $CreateClass(
    function() {
        Fuse.Triggers.ElementTrigger.call(this);
        this._textInput = null;
        this._state = false;
    },
    function(S) {
        var I = S.prototype = new Fuse.Triggers.ElementTrigger;

        I.GetType = function()
        {
            return 798;
        };

        I.OnRooted_1 = function(elm)
        {
            this._textInput = $AsOp(elm, 898);

            if (this._textInput != null)
            {
                this._state = !Uno.String.IsNullOrEmpty(this._textInput.Text());
                this.ApplyState();
                this._textInput.add_TextChanged($CreateDelegate(this, Fuse.Triggers.ContainsText.prototype.OnTextChanged, 445));
            }
        };

        I.OnUnrooted_1 = function(elm)
        {
            if (this._textInput != null)
            {
                this._textInput.remove_TextChanged($CreateDelegate(this, Fuse.Triggers.ContainsText.prototype.OnTextChanged, 445));
            }

            this._textInput = null;
        };

        I.OnTextChanged = function(sender, args)
        {
            var newState = !Uno.String.IsNullOrEmpty(this._textInput.Text());

            if (newState != this._state)
            {
                this._state = newState;
                this.ApplyState();
            }
        };

        I.ApplyState = function()
        {
            if (this._state)
            {
                this.Activate(null);
            }
            else
            {
                this.Deactivate();
            }
        };

    });
