Fuse.Triggers.ElementTrigger = $CreateClass(
    function() {
        Fuse.Triggers.Trigger.call(this);
    },
    function(S) {
        var I = S.prototype = new Fuse.Triggers.Trigger;

        I.GetType = function()
        {
            return 793;
        };

        I.OnRooted = function(elm)
        {
            Fuse.Triggers.Trigger.prototype.OnRooted.call(this, elm);

            if ($IsOp(elm, 991))
            {
                this.OnRooted_1($AsOp(elm, 991));
            }
        };

        I.OnUnrooted = function(elm)
        {
            if ($IsOp(elm, 991))
            {
                this.OnUnrooted_1($AsOp(elm, 991));
            }

            Fuse.Triggers.Trigger.prototype.OnUnrooted.call(this, elm);
        };

        I._ObjInit_2 = function()
        {
            Fuse.Triggers.Trigger.prototype._ObjInit_1.call(this);
        };

    });
