Fuse.Triggers.Placed = $CreateClass(
    function() {
        Fuse.Triggers.ElementTrigger.call(this);
        this._element = null;
        this._t = null;
    },
    function(S) {
        var I = S.prototype = new Fuse.Triggers.ElementTrigger;

        I.GetType = function()
        {
            return 797;
        };

        I.OnRooted_1 = function(elm)
        {
            this._element = elm;
            this._element.add_Placed($CreateDelegate(this, Fuse.Triggers.Placed.prototype.OnPlaced, 998));
        };

        I.OnUnrooted_1 = function(elm)
        {
            this._element.remove_Placed($CreateDelegate(this, Fuse.Triggers.Placed.prototype.OnPlaced, 998));
            this._element = null;
        };

        I.Cleanup = function()
        {
            if (this._t != null)
            {
                this._element.Transforms()["Uno.Collections.ICollection__Fuse_Transform.Remove"](this._t);
                this._t = null;
                this._element.remove_Update($CreateDelegate(this, Fuse.Triggers.Placed.prototype.OnUpdate, 445));
            }
        };

        I.OnPlaced = function(sender, args)
        {
            if (!args.HasOldPosition())
            {
                return;
            }

            if (this._t == null)
            {
                this._t = Fuse.Translation.New_1();
                this._element.Transforms()["Uno.Collections.ICollection__Fuse_Transform.Add"](this._t);
                this._element.add_Update($CreateDelegate(this, Fuse.Triggers.Placed.prototype.OnUpdate, 445));
                this.Activate(null);
            }

            this._t.Vector(Uno.Float3.op_Addition(this._t.Vector(), Uno.Float3.New_3(Uno.Float2.op_Subtraction(args.OldPosition(), args.NewPosition()), 0.0)));
        };

        I.OnUpdate = function(sender, args)
        {
            var len = Uno.Vector.Length_1(this._t.Vector());

            if (len < 3.0)
            {
                this.Cleanup();
                this.Deactivate();
            }
            else
            {
                this._t.Vector(Uno.Float3.op_Subtraction(this._t.Vector(), Uno.Float3.op_Multiply(Uno.Float3.op_Multiply(Uno.Float3.op_Multiply(Uno.Vector.Normalize_1(this._t.Vector()), Uno.Math.Sqrt_1(len) + 1.0), Uno.Application.Current().FrameInterval()), 100.0)));
            }
        };

    });
