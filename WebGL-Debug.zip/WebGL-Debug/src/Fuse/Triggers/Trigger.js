Fuse.Triggers.Trigger = $CreateClass(
    function() {
        Fuse.Behavior.call(this);
        this._animation = null;
        this._actions = null;
        this._nodes = null;
        this._isActive = false;
        this._node = null;
    },
    function(S) {
        var I = S.prototype = new Fuse.Behavior;

        I.GetType = function()
        {
            return 788;
        };

        I.Animation = function()
        {
            if (this._animation == null)
            {
                this._animation = Fuse.Animations.TriggerAnimation.New_1();
            }

            return this._animation;
        };

        I.IsReversedAnimationVariant = function()
        {
            return false;
        };

        I.OnDirection = function()
        {
            return this.IsReversedAnimationVariant() ? 1 : 0;
        };

        I.Animators = function()
        {
            return this.Animation().Animators();
        };

        I.HasAnimators = function()
        {
            return (this._animation != null) && this._animation.HasAnimators();
        };

        I.HasActions = function()
        {
            return (this._actions != null) && (this._actions.Count() > 0);
        };

        I.Node = function()
        {
            return this._node;
        };

        I.PerformActions = function(target)
        {
            if (this._actions != null)
            {
                for (var i = 0; i < this._actions.Count(); i++)
                {
                    this._actions.Item(i).Perform(target);
                }
            }
        };

        I.AddNodes = function(target)
        {
            var iarc = $AsOp(target, 33555);

            if ((this._nodes != null) && (iarc != null))
            {
                for (var enum_123 = this._nodes.GetEnumerator(); enum_123.MoveNext(); )
                {
                    var c = enum_123.Current();
                    iarc["Fuse.Triggers.IAddRemoveChild.AddChild"](c);
                }
            }
        };

        I.RemoveNodes = function(target)
        {
            var iarc = $AsOp(target, 33555);

            if ((this._nodes != null) && (iarc != null))
            {
                for (var enum_124 = this._nodes.GetEnumerator(); enum_124.MoveNext(); )
                {
                    var c = enum_124.Current();
                    iarc["Fuse.Triggers.IAddRemoveChild.RemoveChild"](c);
                }
            }
        };

        I.OnStarted = function(compat)
        {
            this.AddNodes((compat != null) ? compat : this._node);
            this.PerformActions((compat != null) ? compat : this._node);
        };

        I.OnStopped = function(compat)
        {
            this.RemoveNodes((compat != null) ? compat : this._node);
        };

        I.OnStoppedAction = function()
        {
            this.OnStopped(null);
        };

        I.Activate = function(done)
        {
            if (this._isActive)
            {
                return;
            }

            this._isActive = true;

            if (this.HasAnimators())
            {
                var p = this.Animation().GetPlayer(this.OnDirection());
                p["Fuse.Animations.IPlayer.DoneCallback"](done);
                p["Fuse.Animations.IPlayer.PlayToEnd"]();
            }

            this.OnStarted(null);
        };

        I.BypassActivate = function()
        {
            if (this._isActive)
            {
                return;
            }

            this._isActive = true;
            this.OnStarted(null);
        };

        I.Deactivate = function()
        {
            if (!this._isActive)
            {
                return;
            }

            this._isActive = false;
            this.PlayEnd(false, $CreateDelegate(this, Fuse.Triggers.Trigger.prototype.OnStoppedAction, 436));
        };

        I.Pulse = function()
        {
            this.Activate($CreateDelegate(this, Fuse.Triggers.Trigger.prototype.Deactivate, 436));
        };

        I.PlayEnd = function(on, done)
        {
            if (this.HasAnimators())
            {
                this.Animation().PlayEnd(on != this.IsReversedAnimationVariant(), done);
            }
        };

        I.OnUnrooted = function(elm)
        {
            if (this._animation != null)
            {
                this._animation.Disable();
                this._animation = null;
            }

            this._node = null;
        };

        I.OnRooted = function(elm)
        {
            this._node = elm;
            this._isActive = false;

            if (this.HasAnimators())
            {
                this.Animation().Attach(elm);
            }
        };

        I.Seek = function(progress)
        {
            this.Seek_1(progress, this.OnDirection());
        };

        I.Seek_1 = function(progress, direction)
        {
            if (this.HasAnimators())
            {
                this.Animation().SeekProgress(progress, direction);
            }

            if (progress > 0.0)
            {
                if (!this._isActive)
                {
                    this.OnStarted(null);
                    this._isActive = true;
                }
            }
            else
            {
                if (this._isActive)
                {
                    this._isActive = false;
                    this.OnStopped(null);
                }
            }
        };

        I._ObjInit_1 = function()
        {
            Fuse.Behavior.prototype._ObjInit.call(this);
        };

    });
