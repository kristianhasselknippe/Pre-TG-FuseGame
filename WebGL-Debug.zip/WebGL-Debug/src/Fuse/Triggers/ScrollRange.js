Fuse.Triggers.ScrollRange = $CreateClass(
    function() {
        Fuse.Triggers.ElementTrigger.call(this);
        this._scrollViewer = null;
        this._ScrollDirections = 0;
        this._From = 0;
        this._To = 0;
    },
    function(S) {
        var I = S.prototype = new Fuse.Triggers.ElementTrigger;

        I.GetType = function()
        {
            return 799;
        };

        I.ScrollDirections = function(value)
        {
            if (value !== undefined)
            {
                this._ScrollDirections = value;
            }
            else
            {
                return this._ScrollDirections;
            }
        };

        I.From = function(value)
        {
            if (value !== undefined)
            {
                this._From = value;
            }
            else
            {
                return this._From;
            }
        };

        I.To = function(value)
        {
            if (value !== undefined)
            {
                this._To = value;
            }
            else
            {
                return this._To;
            }
        };

        I.Progress = function()
        {
            var range = (this.To() > this.From()) ? (this.To() - this.From()) : (this.From() - this.To());

            if (this.ScrollDirections() == 1)
            {
                var x = this._scrollViewer.ScrollPosition().X - this.From();
                var scrollPos = Uno.Math.Clamp_1(x, (this.To() > this.From()) ? 0.0 : (range * -1.0), (this.To() > this.From()) ? range : 0.0);
                return (Uno.Math.Abs_1(scrollPos) / range);
            }

            if (this.ScrollDirections() == 2)
            {
                var y = this._scrollViewer.ScrollPosition().Y - this.From();
                var scrollPos = Uno.Math.Clamp_1(y, (this.To() > this.From()) ? 0.0 : (range * -1.0), (this.To() > this.From()) ? range : 0.0);
                return (Uno.Math.Abs_1(scrollPos) / range);
            }

            return 0.0;
        };

        I.OnRooted_1 = function(elm)
        {
            if ($IsOp(elm, 893))
            {
                this._scrollViewer = $DownCast(elm, 893);
                this._scrollViewer.add_ScrollPositionChanged($CreateDelegate(this, Fuse.Triggers.ScrollRange.prototype.OnScrollPositionChanged, 445));
            }
        };

        I.OnUnrooted_1 = function(elm)
        {
            if ($IsOp(elm, 893))
            {
                this._scrollViewer.remove_ScrollPositionChanged($CreateDelegate(this, Fuse.Triggers.ScrollRange.prototype.OnScrollPositionChanged, 445));
                this._scrollViewer = null;
            }
        };

        I.OnScrollPositionChanged = function(sender, args)
        {
            this.Seek(this.Progress());
        };

    });
