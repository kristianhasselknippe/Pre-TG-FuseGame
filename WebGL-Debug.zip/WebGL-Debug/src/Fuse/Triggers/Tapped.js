Fuse.Triggers.Tapped = $CreateClass(
    function() {
        Fuse.Triggers.Trigger.call(this);
        this._maxTapDistanceMoved = 0;
        this._maxTapTimeHeld = 0;
        this._node_1 = null;
        this._tappedEventHandler = null;
        this._startCoord = new Uno.Float2;
        this._startTime = 0;
        this.Handler = null;
    },
    function(S) {
        var I = S.prototype = new Fuse.Triggers.Trigger;

        Fuse.Triggers.Tapped._subscribers = null;

        I.GetType = function()
        {
            return 786;
        };

        I.OnRooted = function(elm)
        {
            Fuse.Triggers.Trigger.prototype.OnRooted.call(this, elm);

            if (elm != null)
            {
                this._node_1 = elm;
                this._node_1.add_PointerPressed($CreateDelegate(this, Fuse.Triggers.Tapped.prototype.OnPointerPressed, 924));
                this._node_1.add_PointerReleased($CreateDelegate(this, Fuse.Triggers.Tapped.prototype.OnPointerReleased, 928));
                this._node_1.add_LostSoftCapture($CreateDelegate(this, Fuse.Triggers.Tapped.prototype.OnLostSoftCapture, 939));
            }
        };

        I.OnUnrooted = function(elm)
        {
            if (this._node_1 != null)
            {
                this._node_1.remove_PointerPressed($CreateDelegate(this, Fuse.Triggers.Tapped.prototype.OnPointerPressed, 924));
                this._node_1.remove_PointerReleased($CreateDelegate(this, Fuse.Triggers.Tapped.prototype.OnPointerReleased, 928));
                this._node_1.remove_LostSoftCapture($CreateDelegate(this, Fuse.Triggers.Tapped.prototype.OnLostSoftCapture, 939));
                this._node_1 = null;
            }

            Fuse.Triggers.Trigger.prototype.OnUnrooted.call(this, elm);
        };

        Fuse.Triggers.Tapped.AddSubscriber = function(node, handler)
        {
            if (!Fuse.Triggers.Tapped._subscribers.ContainsKey(node))
            {
                Fuse.Triggers.Tapped._subscribers.Add(node, Uno.Collections.List__Fuse_Triggers_Tapped.New_1());
            }

            var tappedTrigger = Fuse.Triggers.Tapped.New_2(handler);
            Fuse.Triggers.Tapped._subscribers.Item(node).Add(tappedTrigger);
            node.Behaviors()["Uno.Collections.ICollection__Fuse_Behavior.Add"](tappedTrigger);
        };

        Fuse.Triggers.Tapped.RemoveSubscriber = function(node, handler)
        {
            if (Fuse.Triggers.Tapped._subscribers.ContainsKey(node))
            {
                var triggers = Fuse.Triggers.Tapped._subscribers.Item(node);

                for (var i = triggers.Count() - 1; i >= 0; i--)
                {
                    if (handler.Equals(triggers.Item(i)._tappedEventHandler))
                    {
                        node.Behaviors()["Uno.Collections.ICollection__Fuse_Behavior.Remove"](triggers.Item(i));
                        triggers.RemoveAt(i);
                        break;
                    }
                }

                if (triggers.Count() == 0)
                {
                    Fuse.Triggers.Tapped._subscribers.Remove(node);
                }
            }
        };

        I.OnPointerPressed = function(sender, args)
        {
            args.SoftCapturePointer($DownCast(this._node_1, 33719));
            this._startCoord.op_Assign(args.PointCoord());
            this._startTime = Fuse.Time.FrameTimeDouble();
        };

        I.OnPointerReleased = function(sender, args)
        {
            args.ReleaseSoftCapture($DownCast(this._node_1, 33719));
            var distance = Uno.Vector.Length(Uno.Float2.op_Subtraction(args.PointCoord(), this._startCoord));
            var deltaTime = Fuse.Time.FrameTimeDouble() - this._startTime;

            if ((distance <= this._maxTapDistanceMoved) && (deltaTime <= this._maxTapTimeHeld))
            {
                if (Uno.Delegate.op_Inequality(this.Handler, null))
                {
                    this.Handler.Invoke(this._node_1, Fuse.Triggers.TappedArgs.New_2(args));
                }

                if (this.HasAnimators() || this.HasActions())
                {
                    this.RaisePointerTapped(args);
                }

                if (Uno.Delegate.op_Inequality(this._tappedEventHandler, null))
                {
                    this._tappedEventHandler.Invoke(this._node_1, Fuse.Triggers.TappedArgs.New_2(args));
                }
            }

            this.Reset();
        };

        I.OnLostSoftCapture = function(sender, args)
        {
            this.Reset();
        };

        I.Reset = function()
        {
            this._startCoord = Uno.Float2.New_1(0.0);
            this._startTime = 0.0;
        };

        I.RaisePointerTapped = function(args)
        {
            this.Pulse();
        };

        Fuse.Triggers.Tapped._TypeInit = function()
        {
            Fuse.Triggers.Tapped._subscribers = Uno.Collections.Dictionary__Fuse_Node__Uno_Collections_List_Fuse_Triggers_Tapped_.New_1();
        };

        I._ObjInit_3 = function(tappedEventHandler)
        {
            this._maxTapDistanceMoved = 25.0;
            this._maxTapTimeHeld = 0.3;
            this._startCoord = Uno.Float2.New_1(0.0);
            Fuse.Triggers.Trigger.prototype._ObjInit_1.call(this);
            this._tappedEventHandler = tappedEventHandler;
        };

        Fuse.Triggers.Tapped.New_2 = function(tappedEventHandler)
        {
            var inst = new Fuse.Triggers.Tapped;
            inst._ObjInit_3(tappedEventHandler);
            return inst;
        };

    });
