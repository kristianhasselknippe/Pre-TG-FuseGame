Fuse.Effects.Mask = $CreateClass(
    function() {
        Fuse.Effects.Effect.call(this);
        this._mask = null;
        this._mode = 0;
        this.Render_VertexData_87c0b03e_7_2_1 = null;
        this.Render_WorldTransform_87c0b03e_4_8_2 = new Uno.Float4x4;
        this.Render_WorldTransform_87c0b03e_4_8_3 = new Uno.Float4x4;
        this.Render_WorldTransform_87c0b03e_4_8_4 = new Uno.Float4x4;
        this.Render_VertexData_87c1249d_7_2_1 = null;
        this.Render_VertexData_87c198fc_7_2_1 = null;
        this._draw_87c0b03e = new Uno.Runtime.Implementation.ShaderBackends.OpenGL.GLDrawCall;
        this._draw_87c1249d = new Uno.Runtime.Implementation.ShaderBackends.OpenGL.GLDrawCall;
        this._draw_87c198fc = new Uno.Runtime.Implementation.ShaderBackends.OpenGL.GLDrawCall;
    },
    function(S) {
        var I = S.prototype = new Fuse.Effects.Effect;

        I.GetType = function()
        {
            return 833;
        };

        I.Texture = function(value)
        {
            if (value !== undefined)
            {
                if (this._mask != value)
                {
                    this._mask = value;
                    this.OnRenderingChanged();
                }
            }
            else
            {
                return this._mask;
            }
        };

        I.Render = function(dc)
        {
            var compositMatrix_123 = new Uno.Float4x4;
            var elementRect_124 = new Uno.Recti;
            compositMatrix_123.op_Assign(this.GetCompositMatrix(dc));
            elementRect_124.op_Assign(this.GetLocalElementRect());

            if ((elementRect_124.Size().X > Uno.Graphics.Texture2D.MaxSize()) || (elementRect_124.Size().Y > Uno.Graphics.Texture2D.MaxSize()))
            {
                Uno.Diagnostics.Debug.Log(Uno.String.op_Addition_1(Uno.String.op_Addition(Uno.String.op_Addition_1("Mask-effect bigger than maximum texture size, dropping rendering (size: ", $CopyStruct(elementRect_124.Size())), ", max-size: "), $CreateBox(Uno.Graphics.Texture2D.MaxSize(), 425)), 1, "/Users/vegard/RealtimeStudio/Uno/Packages/Fuse.Effects/0.1.0/Mask.uno", 61);
                return;
            }

            var original = this.Element().CaptureRegion(dc, elementRect_124, Uno.Int2.New_1(0), Uno.Matrix.Invert(compositMatrix_123));

            switch (this._mode)
            {
                case 0:
                {
                    {
                        this._draw_87c0b03e.BlendEnabled(true);
                        this._draw_87c0b03e.BlendSrcRgb(2);
                        this._draw_87c0b03e.BlendDstRgb(3);
                        this._draw_87c0b03e.BlendDstAlpha(3);
                        this._draw_87c0b03e.DepthTestEnabled(false);
                        this._draw_87c0b03e.Use();
                        this._draw_87c0b03e.Attrib_1(0, 2, this.Render_VertexData_87c0b03e_7_2_1, 8, 0);
                        this._draw_87c0b03e.Uniform_8(1, dc.VirtualResolution().X);
                        this._draw_87c0b03e.Uniform_8(2, dc.VirtualResolution().Y);
                        this._draw_87c0b03e.Uniform_14(3, Uno.Matrix.Mul_11(Uno.Matrix.Mul_7(this.Render_WorldTransform_87c0b03e_4_8_2, Uno.Matrix.Scaling_1(Uno.Float2.op_Implicit(elementRect_124.Size()).X, Uno.Float2.op_Implicit(elementRect_124.Size()).Y, 1.0), this.Render_WorldTransform_87c0b03e_4_8_3, this.Render_WorldTransform_87c0b03e_4_8_4), compositMatrix_123));
                        this._draw_87c0b03e.Sampler_2(4, original.ColorBuffer());
                        this._draw_87c0b03e.Sampler_3(5, this.Texture(), Uno.Graphics.SamplerState.LinearClamp());
                        this._draw_87c0b03e.DrawArrays(6);
                    }

                    break;
                }
                case 1:
                {
                    {
                        this._draw_87c1249d.BlendEnabled(true);
                        this._draw_87c1249d.BlendSrcRgb(2);
                        this._draw_87c1249d.BlendDstRgb(3);
                        this._draw_87c1249d.BlendDstAlpha(3);
                        this._draw_87c1249d.DepthTestEnabled(false);
                        this._draw_87c1249d.Use();
                        this._draw_87c1249d.Attrib_1(0, 2, this.Render_VertexData_87c1249d_7_2_1, 8, 0);
                        this._draw_87c1249d.Uniform_8(1, dc.VirtualResolution().X);
                        this._draw_87c1249d.Uniform_8(2, dc.VirtualResolution().Y);
                        this._draw_87c1249d.Uniform_14(3, Uno.Matrix.Mul_11(Uno.Matrix.Mul_7(this.Render_WorldTransform_87c0b03e_4_8_2, Uno.Matrix.Scaling_1(Uno.Float2.op_Implicit(elementRect_124.Size()).X, Uno.Float2.op_Implicit(elementRect_124.Size()).Y, 1.0), this.Render_WorldTransform_87c0b03e_4_8_3, this.Render_WorldTransform_87c0b03e_4_8_4), compositMatrix_123));
                        this._draw_87c1249d.Sampler_2(4, original.ColorBuffer());
                        this._draw_87c1249d.Sampler_3(5, this.Texture(), Uno.Graphics.SamplerState.LinearClamp());
                        this._draw_87c1249d.DrawArrays(6);
                    }

                    break;
                }
                case 2:
                {
                    {
                        this._draw_87c198fc.BlendEnabled(true);
                        this._draw_87c198fc.BlendSrcRgb(2);
                        this._draw_87c198fc.BlendDstRgb(3);
                        this._draw_87c198fc.BlendDstAlpha(3);
                        this._draw_87c198fc.DepthTestEnabled(false);
                        this._draw_87c198fc.Use();
                        this._draw_87c198fc.Attrib_1(0, 2, this.Render_VertexData_87c198fc_7_2_1, 8, 0);
                        this._draw_87c198fc.Uniform_8(1, dc.VirtualResolution().X);
                        this._draw_87c198fc.Uniform_8(2, dc.VirtualResolution().Y);
                        this._draw_87c198fc.Uniform_14(3, Uno.Matrix.Mul_11(Uno.Matrix.Mul_7(this.Render_WorldTransform_87c0b03e_4_8_2, Uno.Matrix.Scaling_1(Uno.Float2.op_Implicit(elementRect_124.Size()).X, Uno.Float2.op_Implicit(elementRect_124.Size()).Y, 1.0), this.Render_WorldTransform_87c0b03e_4_8_3, this.Render_WorldTransform_87c0b03e_4_8_4), compositMatrix_123));
                        this._draw_87c198fc.Sampler_2(4, original.ColorBuffer());
                        this._draw_87c198fc.Sampler_3(5, this.Texture(), Uno.Graphics.SamplerState.LinearClamp());
                        this._draw_87c198fc.DrawArrays(6);
                    }

                    break;
                }
            }

            Fuse.FramebufferPool.Release(original);
        };

    });
