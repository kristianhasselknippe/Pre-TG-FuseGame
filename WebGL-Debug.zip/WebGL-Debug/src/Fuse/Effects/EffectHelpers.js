Fuse.Effects.EffectHelpers = $CreateClass(
    function() {
        this.DirectionalBlur_VertexData_2aa48ed6_2_5_2 = null;
        this.DirectionalBlur_VertexData_2aa48ed6_2_5_3 = null;
        this.Pad_v_fd3653dc_1_2_1 = null;
        this.Pad_vertices_fd3653dc_1_0_5 = null;
        this.Blit_Coord_83e56892_1_2_1 = null;
        this._draw_2aa48ed6 = new Uno.Runtime.Implementation.ShaderBackends.OpenGL.GLDrawCall;
        this._draw_fd3653dc = new Uno.Runtime.Implementation.ShaderBackends.OpenGL.GLDrawCall;
        this._draw_83e56892 = new Uno.Runtime.Implementation.ShaderBackends.OpenGL.GLDrawCall;
    },
    function(S) {
        var I = S.prototype;

        I.GetType = function()
        {
            return 832;
        };

        I.Blur = function(original, dc, zoom, amount)
        {
            var b1 = this.BlurHorizontal(dc, original, Uno.Math.Max_1(1.0, (2.0 * zoom) * amount), amount);
            var b2 = this.BlurVertical(dc, b1.ColorBuffer(), Uno.Math.Max_1(1.0, (2.0 * zoom) * amount), amount);
            Fuse.FramebufferPool.Release(b1);
            var b3 = this.BlurHorizontal(dc, b2.ColorBuffer(), 1.0, amount);
            Fuse.FramebufferPool.Release(b2);
            var b4 = this.BlurVertical(dc, b3.ColorBuffer(), 1.0, amount);
            Fuse.FramebufferPool.Release(b3);
            var b5 = this.BlurHorizontal(dc, b4.ColorBuffer(), Uno.Math.Max_1(1.0, 3.0 * amount), amount);
            Fuse.FramebufferPool.Release(b4);
            var b6 = this.BlurVertical(dc, b5.ColorBuffer(), Uno.Math.Max_1(1.0, 3.0 * amount), amount);
            Fuse.FramebufferPool.Release(b5);
            var b7 = this.BlurHorizontal(dc, b6.ColorBuffer(), 1.0, amount);
            Fuse.FramebufferPool.Release(b6);
            var blur = this.BlurVertical(dc, b7.ColorBuffer(), 1.0, amount);
            Fuse.FramebufferPool.Release(b7);
            return blur;
        };

        I.BlurHorizontal = function(dc, tex, h, amount)
        {
            var nw = (tex.Size().X / h) | 0;
            var nh = tex.Size().Y;
            var fb = Fuse.FramebufferPool.Lock_1(nw, nh, 3, false);
            dc.PushRenderTarget(fb, true);
            dc.Clear(Uno.Float4.New_1(0.0), 1.0);
            this.DirectionalBlur(tex, Uno.Float2.New_2(1.0, 0.0), amount);
            dc.PopRenderTarget();
            return fb;
        };

        I.BlurVertical = function(dc, tex, h, amount)
        {
            var nw = tex.Size().X;
            var nh = (tex.Size().Y / h) | 0;
            var fb = Fuse.FramebufferPool.Lock_1(nw, nh, 3, false);
            dc.PushRenderTarget(fb, true);
            dc.Clear(Uno.Float4.New_1(0.0), 1.0);
            this.DirectionalBlur(tex, Uno.Float2.New_2(0.0, 1.0), amount);
            dc.PopRenderTarget();
            return fb;
        };

        I.DirectionalBlur = function(tex, dir, amount)
        {
            var dir_123 = new Uno.Float2;
            dir_123.op_Assign(dir);
            var delta_2aa48ed6_3_3_6 = Uno.Float2.op_Multiply(Uno.Float2.New_2(dir_123.X / tex.Size().X, dir_123.Y / tex.Size().Y), Uno.Math.Sqrt_1(amount));
            {
                this._draw_2aa48ed6.DepthTestEnabled(false);
                this._draw_2aa48ed6.Use();
                this._draw_2aa48ed6.Attrib_1(0, 2, this.DirectionalBlur_VertexData_2aa48ed6_2_5_3, 8, 0);
                this._draw_2aa48ed6.Uniform_9(1, Uno.Float2.op_Multiply(delta_2aa48ed6_3_3_6, 1.407333));
                this._draw_2aa48ed6.Uniform_9(2, Uno.Float2.op_Multiply(delta_2aa48ed6_3_3_6, 3.294215));
                this._draw_2aa48ed6.Sampler_3(3, tex, Uno.Graphics.SamplerState.LinearClamp());
                this._draw_2aa48ed6.Draw(6, 2, this.DirectionalBlur_VertexData_2aa48ed6_2_5_2);
            }
        };

        I.Blit = function(dc, t, size, position, compositMatrix, color, colorize)
        {
            var color_129 = new Uno.Float4;
            color_129.op_Assign(color);
            {
                this._draw_83e56892.BlendEnabled(true);
                this._draw_83e56892.BlendSrcRgb(2);
                this._draw_83e56892.BlendDstRgb(3);
                this._draw_83e56892.BlendDstAlpha(3);
                this._draw_83e56892.DepthTestEnabled(false);
                this._draw_83e56892.CullFace(0);
                this._draw_83e56892.Const(0, colorize);
                this._draw_83e56892.Use();
                this._draw_83e56892.Attrib_1(1, 2, this.Blit_Coord_83e56892_1_2_1, 8, 0);
                this._draw_83e56892.Uniform_9(2, size);
                this._draw_83e56892.Uniform_9(3, position);
                this._draw_83e56892.Uniform_14(4, compositMatrix);
                this._draw_83e56892.Uniform_9(5, dc.VirtualResolution());
                this._draw_83e56892.Uniform_8(6, color_129.W);
                this._draw_83e56892.Uniform_10(7, Uno.Float3.New_2(color_129.X, color_129.Y, color_129.Z));
                this._draw_83e56892.Uniform_11(8, color_129);
                this._draw_83e56892.Sampler_2(9, t);
                this._draw_83e56892.DrawArrays(this.Pad_vertices_fd3653dc_1_0_5.length);
            }
        };

        I.init_DrawCalls = function()
        {
            this.DirectionalBlur_VertexData_2aa48ed6_2_5_2 = Uno.Graphics.IndexBuffer.New_3(Uno.Runtime.Implementation.Internal.BufferConverters.ToBuffer_6(Array.Init([0, 1, 2, 2, 3, 0], 424)), 0);
            this.DirectionalBlur_VertexData_2aa48ed6_2_5_3 = Uno.Graphics.VertexBuffer.New_3(Uno.Runtime.Implementation.Internal.BufferConverters.ToBuffer_1(Array.Init([Uno.Float2.New_2(0.0, 0.0), Uno.Float2.New_2(1.0, 0.0), Uno.Float2.New_2(1.0, 1.0), Uno.Float2.New_2(0.0, 1.0)], 430)), 0);
            var vertices_fd3653dc_1_0_0 = Array.Init([Uno.Float2.New_2(0.0, 0.0), Uno.Float2.New_2(1.0, 0.0), Uno.Float2.New_2(1.0, 1.0), Uno.Float2.New_2(0.0, 0.0), Uno.Float2.New_2(1.0, 1.0), Uno.Float2.New_2(0.0, 1.0)], 430);
            this.Pad_v_fd3653dc_1_2_1 = Uno.Graphics.VertexBuffer.New_3(Uno.Runtime.Implementation.Internal.BufferConverters.ToBuffer_1(vertices_fd3653dc_1_0_0), 0);
            this.Pad_vertices_fd3653dc_1_0_5 = vertices_fd3653dc_1_0_0;
            this.Blit_Coord_83e56892_1_2_1 = Uno.Graphics.VertexBuffer.New_3(Uno.Runtime.Implementation.Internal.BufferConverters.ToBuffer_1(vertices_fd3653dc_1_0_0), 0);
            this._draw_2aa48ed6 = Uno.Runtime.Implementation.ShaderBackends.OpenGL.GLDrawCall.New_1($DownCast(Uno.Runtime.Implementation.Internal.BundleRegistry.Get(31), 383));
            this._draw_fd3653dc = Uno.Runtime.Implementation.ShaderBackends.OpenGL.GLDrawCall.New_1($DownCast(Uno.Runtime.Implementation.Internal.BundleRegistry.Get(32), 383));
            this._draw_83e56892 = Uno.Runtime.Implementation.ShaderBackends.OpenGL.GLDrawCall.New_1($DownCast(Uno.Runtime.Implementation.Internal.BundleRegistry.Get(33), 383));
        };

        I._ObjInit = function()
        {
            this.init_DrawCalls();
        };

        Fuse.Effects.EffectHelpers.New_1 = function()
        {
            var inst = new Fuse.Effects.EffectHelpers;
            inst._ObjInit();
            return inst;
        };

    });
