Fuse.Effects.DropShadow = $CreateClass(
    function() {
        Fuse.Effects.Effect.call(this);
        this._softness = 0;
        this._offset = new Uno.Float2;
        this._multiplier = 0;
        this._color = new Uno.Float4;
        this._helpers = null;
    },
    function(S) {
        var I = S.prototype = new Fuse.Effects.Effect;

        I.GetType = function()
        {
            return 831;
        };

        I.Softness = function(value)
        {
            if (value !== undefined)
            {
                if (this._softness != value)
                {
                    this._softness = value;

                    if (this.Active())
                    {
                        this.OnRenderingChanged();
                    }
                }
            }
            else
            {
                return this._softness;
            }
        };

        I.Offset = function(value)
        {
            if (value !== undefined)
            {
                if (Uno.Float2.op_Inequality(this._offset, value))
                {
                    this._offset.op_Assign(value);

                    if (this.Active())
                    {
                        this.OnRenderingChanged();
                    }
                }
            }
            else
            {
                return this._offset;
            }
        };

        I.Multiplier = function(value)
        {
            if (value !== undefined)
            {
                if (this._multiplier != value)
                {
                    var wasActive = this.Active();
                    this._multiplier = value;

                    if (wasActive || this.Active())
                    {
                        this.OnRenderingChanged();
                    }
                }
            }
            else
            {
                return this._multiplier;
            }
        };

        I.Color = function(value)
        {
            if (value !== undefined)
            {
                if (Uno.Float4.op_Inequality(this._color, value))
                {
                    var wasActive = this.Active();
                    this._color.op_Assign(value);

                    if (wasActive || this.Active())
                    {
                        this.OnRenderingChanged();
                    }
                }
            }
            else
            {
                return this._color;
            }
        };

        I.Padding = function()
        {
            return (Uno.Math.Sqrt_1(this.Softness()) * 10.0) * this.Element().AbsoluteZoom();
        };

        I.ExtendsRenderBounds = function()
        {
            return true;
        };

        I.RenderBounds = function()
        {
            return Uno.Rect.Translate(Uno.Rect.Inflate_1(this.Element().RenderBounds(), this.Padding()), this.Offset());
        };

        I.Active = function()
        {
            return (this.Color().W * this.Multiplier()) > 0.0;
        };

        I.Render = function(dc)
        {
            var elementRect_123 = new Uno.Recti;
            var compositMatrix_124 = new Uno.Float4x4;
            var ind_127;
            var softness = Uno.Math.Sqrt_1(this.Softness()) * 10.0;
            var padding = Uno.Math.Ceil_1(this.Padding()) | 0;
            elementRect_123.op_Assign(this.GetLocalElementRect());

            if (((elementRect_123.Size().X + (2 * padding)) > Uno.Graphics.Texture2D.MaxSize()) || ((elementRect_123.Size().Y + (2 * padding)) > Uno.Graphics.Texture2D.MaxSize()))
            {
                Uno.Diagnostics.Debug.Log(Uno.String.op_Addition_1(Uno.String.op_Addition(Uno.String.op_Addition_1("DropShadow-effect bigger than maximum texture size, dropping rendering (size: ", $CopyStruct(Uno.Int2.op_Addition_1(elementRect_123.Size(), padding * 2))), ", max-size: "), $CreateBox(Uno.Graphics.Texture2D.MaxSize(), 425)), 1, "/Users/vegard/RealtimeStudio/Uno/Packages/Fuse.Effects/0.1.0/DropShadow.uno", 120);
                return;
            }

            compositMatrix_124.op_Assign(this.GetCompositMatrix(dc));
            var temp = this.Element().CaptureRegion(dc, elementRect_123, Uno.Int2.New_1(padding), Uno.Matrix.Invert(compositMatrix_124));
            var blur = this._helpers.Blur(temp.ColorBuffer(), dc, this.Element().AbsoluteZoom(), softness * 0.016);
            var blitOffset = Uno.Float2.op_Subtraction_1(this.Offset(), padding / this.Element().AbsoluteZoom());
            this._helpers.Blit(dc, blur.ColorBuffer(), Uno.Float2.op_Implicit(Uno.Int2.op_Explicit(Uno.Float2.op_Division_1(Uno.Float2.op_Implicit(temp.Size()), this.Element().AbsoluteZoom()))), blitOffset, compositMatrix_124, Uno.Float4.New_7((ind_127 = this.Color(), Uno.Float3.New_2(ind_127.X, ind_127.Y, ind_127.Z)), this.Color().W * this.Multiplier()), true);
            Fuse.FramebufferPool.Release(blur);
            Fuse.FramebufferPool.Release(temp);
        };

        I._ObjInit_1 = function()
        {
            this._helpers = Fuse.Effects.EffectHelpers.New_1();
            Fuse.Effects.Effect.prototype._ObjInit.call(this, 0);
            this.Softness(2.0);
            this.Color(Uno.Float4.New_2(0.0, 0.0, 0.0, 1.0));
            this.Multiplier(1.0);
        };

        Fuse.Effects.DropShadow.New_1 = function()
        {
            var inst = new Fuse.Effects.DropShadow;
            inst._ObjInit_1();
            return inst;
        };

    });
