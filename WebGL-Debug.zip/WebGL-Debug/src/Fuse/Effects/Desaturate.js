Fuse.Effects.Desaturate = $CreateClass(
    function() {
        Fuse.Effects.Effect.call(this);
        this._amount = 0;
        this.Render_VertexData_1aeb5d3a_7_2_1 = null;
        this.Render_WorldTransform_1aeb5d3a_4_8_2 = new Uno.Float4x4;
        this.Render_WorldTransform_1aeb5d3a_4_8_3 = new Uno.Float4x4;
        this.Render_WorldTransform_1aeb5d3a_4_8_4 = new Uno.Float4x4;
        this._draw_1aeb5d3a = new Uno.Runtime.Implementation.ShaderBackends.OpenGL.GLDrawCall;
    },
    function(S) {
        var I = S.prototype = new Fuse.Effects.Effect;

        I.GetType = function()
        {
            return 830;
        };

        I.Amount = function(value)
        {
            if (value !== undefined)
            {
                if (this._amount != value)
                {
                    this._amount = value;
                    this.OnRenderingChanged();
                }
            }
            else
            {
                return this._amount;
            }
        };

        I.Render = function(dc)
        {
            var compositMatrix_123 = new Uno.Float4x4;
            var elementRect_124 = new Uno.Recti;
            compositMatrix_123.op_Assign(this.GetCompositMatrix(dc));
            elementRect_124.op_Assign(this.GetLocalElementRect());

            if ((elementRect_124.Size().X > Uno.Graphics.Texture2D.MaxSize()) || (elementRect_124.Size().Y > Uno.Graphics.Texture2D.MaxSize()))
            {
                Uno.Diagnostics.Debug.Log(Uno.String.op_Addition_1(Uno.String.op_Addition(Uno.String.op_Addition_1("Desaturate-effect bigger than maximum texture size, dropping rendering (size: ", $CopyStruct(elementRect_124.Size())), ", max-size: "), $CreateBox(Uno.Graphics.Texture2D.MaxSize(), 425)), 1, "/Users/vegard/RealtimeStudio/Uno/Packages/Fuse.Effects/0.1.0/Desaturate.uno", 37);
                return;
            }

            var original = this.Element().CaptureRegion(dc, elementRect_124, Uno.Int2.New_1(0), Uno.Matrix.Invert(compositMatrix_123));
            {
                this._draw_1aeb5d3a.BlendEnabled(true);
                this._draw_1aeb5d3a.BlendSrcRgb(2);
                this._draw_1aeb5d3a.BlendDstRgb(3);
                this._draw_1aeb5d3a.BlendDstAlpha(3);
                this._draw_1aeb5d3a.DepthTestEnabled(false);
                this._draw_1aeb5d3a.Use();
                this._draw_1aeb5d3a.Attrib_1(0, 2, this.Render_VertexData_1aeb5d3a_7_2_1, 8, 0);
                this._draw_1aeb5d3a.Uniform_8(1, dc.VirtualResolution().X);
                this._draw_1aeb5d3a.Uniform_8(2, dc.VirtualResolution().Y);
                this._draw_1aeb5d3a.Uniform_8(3, this.Amount());
                this._draw_1aeb5d3a.Uniform_14(4, Uno.Matrix.Mul_11(Uno.Matrix.Mul_7(this.Render_WorldTransform_1aeb5d3a_4_8_2, Uno.Matrix.Scaling_1(Uno.Float2.op_Implicit(elementRect_124.Size()).X, Uno.Float2.op_Implicit(elementRect_124.Size()).Y, 1.0), this.Render_WorldTransform_1aeb5d3a_4_8_3, this.Render_WorldTransform_1aeb5d3a_4_8_4), compositMatrix_123));
                this._draw_1aeb5d3a.Sampler_2(5, original.ColorBuffer());
                this._draw_1aeb5d3a.DrawArrays(6);
            }

            Fuse.FramebufferPool.Release(original);
        };

    });
