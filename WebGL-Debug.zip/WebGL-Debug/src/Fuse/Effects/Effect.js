Fuse.Effects.Effect = $CreateClass(
    function() {
        this._effectType = 0;
        this.AddedByStyle = false;
        this._isRooted = false;
        this.RenderingChanged = null;
        this._Element = null;
    },
    function(S) {
        var I = S.prototype;

        I.GetType = function()
        {
            return 829;
        };

        I.Type = function()
        {
            return this._effectType;
        };

        I.Element = function(value)
        {
            if (value !== undefined)
            {
                this._Element = value;
            }
            else
            {
                return this._Element;
            }
        };

        I.ExtendsRenderBounds = function()
        {
            return false;
        };

        I.Active = function()
        {
            return true;
        };

        I.RenderBounds = function()
        {
            return this.Element().RenderBounds();
        };

        I.OnRooted = function()
        {
        };

        I.OnUnrooted = function()
        {
        };

        I.Rooted = function()
        {
            if (this._isRooted)
            {
                return;
            }

            this._isRooted = true;
            this.OnRooted();
        };

        I.Unrooted = function()
        {
            if (!this._isRooted)
            {
                return;
            }

            this._isRooted = false;
            this.OnUnrooted();
        };

        I.Added = function(elm)
        {
            this.Element(elm);

            if (elm.IsRooted())
            {
                this.Rooted();
            }
        };

        I.Removed = function(elm)
        {
            if (elm.IsRooted())
            {
                this.Unrooted();
            }

            this.Element(null);
        };

        I.OnRenderingChanged = function()
        {
            if (Uno.Delegate.op_Inequality(this.RenderingChanged, null))
            {
                this.RenderingChanged.Invoke(this);
            }
        };

        Fuse.Effects.Effect.ConservativelySnapToCoveringIntegers = function(r)
        {
            var r_123 = new Uno.Rect;
            r_123.op_Assign(r);
            var origin = Uno.Int2.op_Explicit(Uno.Math.Floor_2(r_123.LeftTop()));
            var size = Uno.Int2.op_Explicit(Uno.Math.Ceil_2(Uno.Float2.op_Addition_1(Uno.Float2.op_Subtraction(r_123.RightBottom(), r_123.LeftTop()), 0.01)));
            return Uno.Recti.New_1(origin.X, origin.Y, (origin.X + size.X) + 1, (origin.Y + size.Y) + 1);
        };

        I.GetLocalElementRect = function()
        {
            return Fuse.Effects.Effect.ConservativelySnapToCoveringIntegers(Uno.Rect.Scale_1(this.Element().RenderBounds(), this.Element().AbsoluteZoom()));
        };

        I.GetCompositMatrix = function(dc)
        {
            var translation = Uno.Matrix.Translation_1(Uno.Math.Floor_1(this.Element().RenderBounds().Left), Uno.Math.Floor_1(this.Element().RenderBounds().Top), 0.0);
            return Uno.Matrix.Mul_11(translation, this.Element().GetDrawMatrix(dc));
        };

        I._ObjInit = function(effectType)
        {
            this._effectType = effectType;
        };

        I.add_RenderingChanged = function(value)
        {
            this.RenderingChanged = $DownCast(Uno.Delegate.Combine(this.RenderingChanged, value), 479);
        };

        I.remove_RenderingChanged = function(value)
        {
            this.RenderingChanged = $DownCast(Uno.Delegate.Remove(this.RenderingChanged, value), 479);
        };

    });
