Fuse.ChangedFocusArgs = $CreateClass(
    function() {
        Uno.EventArgs.call(this);
        this._OldObject = null;
        this._NewObject = null;
    },
    function(S) {
        var I = S.prototype = new Uno.EventArgs;

        I.GetType = function()
        {
            return 945;
        };

        I.OldObject = function(value)
        {
            if (value !== undefined)
            {
                this._OldObject = value;
            }
            else
            {
                return this._OldObject;
            }
        };

        I.NewObject = function(value)
        {
            if (value !== undefined)
            {
                this._NewObject = value;
            }
            else
            {
                return this._NewObject;
            }
        };

        I._ObjInit_1 = function(oldObject, newObject)
        {
            Uno.EventArgs.prototype._ObjInit.call(this);
            this.OldObject(newObject);
            this.NewObject(newObject);
        };

        Fuse.ChangedFocusArgs.New_2 = function(oldObject, newObject)
        {
            var inst = new Fuse.ChangedFocusArgs;
            inst._ObjInit_1(oldObject, newObject);
            return inst;
        };

    });
