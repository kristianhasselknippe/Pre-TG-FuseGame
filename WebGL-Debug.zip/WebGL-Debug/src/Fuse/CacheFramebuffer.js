Fuse.CacheFramebuffer = $CreateClass(
    function() {
        this._isPinned = false;
        this._fb = null;
        this._isContentValid = false;
        this._lastFrameUsed = 0;
        this._Width = 0;
        this._Height = 0;
        this._Format = 0;
        this._Flags = 0;
    },
    function(S) {
        var I = S.prototype;

        I.GetType = function()
        {
            return 914;
        };

        I.IsPinned = function()
        {
            return this._isPinned;
        };

        I.Framebuffer = function()
        {
            this.EnsurePinned();
            return this._fb;
        };

        I.IsContentValid = function()
        {
            this.EnsurePinned();
            return this._isContentValid;
        };

        I.FramesSinceLastUse = function()
        {
            return Fuse.FramebufferPool.Frame() - this._lastFrameUsed;
        };

        I.Width = function(value)
        {
            if (value !== undefined)
            {
                this._Width = value;
            }
            else
            {
                return this._Width;
            }
        };

        I.Height = function(value)
        {
            if (value !== undefined)
            {
                this._Height = value;
            }
            else
            {
                return this._Height;
            }
        };

        I.Format = function(value)
        {
            if (value !== undefined)
            {
                this._Format = value;
            }
            else
            {
                return this._Format;
            }
        };

        I.Flags = function(value)
        {
            if (value !== undefined)
            {
                this._Flags = value;
            }
            else
            {
                return this._Flags;
            }
        };

        I.EnsurePinned = function()
        {
            if (!this.IsPinned())
            {
                throw new $Error(Uno.Exception.New_1("Cannot access unpinned CacheFramebuffer"));
            }
        };

        I.Collect = function()
        {
            if (this._fb != null)
            {
                Fuse.FramebufferPool.Release(this._fb);
            }

            this._fb = null;
            this._isContentValid = false;
        };

        I.Dispose = function()
        {
            this.Collect();
            Fuse.FramebufferPool.UnRegister(this);
        };

        I.Pin = function()
        {
            this._isPinned = true;
            this._lastFrameUsed = Fuse.FramebufferPool.Frame();

            if (this._fb == null)
            {
                this._fb = Fuse.FramebufferPool.Lock_1(this.Width(), this.Height(), this.Format(), (this.Flags() & 1) == 1);
                Fuse.FramebufferPool.Register(this);
            }
        };

        I.Unpin = function(validate)
        {
            this.EnsurePinned();
            this._isPinned = false;

            if (validate)
            {
                this._isContentValid = true;
            }

            this._lastFrameUsed = Fuse.FramebufferPool.Frame();
        };

        I._ObjInit = function(width, height, format, flags)
        {
            this.Width(width);
            this.Height(height);
            this.Format(format);
            this.Flags(flags);
        };

        Fuse.CacheFramebuffer.New_1 = function(width, height, format, flags)
        {
            var inst = new Fuse.CacheFramebuffer;
            inst._ObjInit(width, height, format, flags);
            return inst;
        };

    });
