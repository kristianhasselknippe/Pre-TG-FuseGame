Fuse.HitTestResult = $CreateClass(
    function() {
        this._Viewport = new Uno.Recti;
        this._Camera = null;
        this._HasHitDistance = false;
        this._HitDistance = 0;
        this._HitObject = null;
        this._Context = null;
    },
    function(S) {
        var I = S.prototype;

        I.GetType = function()
        {
            return 949;
        };

        I.Viewport = function(value)
        {
            if (value !== undefined)
            {
                this._Viewport.op_Assign(value);
            }
            else
            {
                return this._Viewport;
            }
        };

        I.Camera = function(value)
        {
            if (value !== undefined)
            {
                this._Camera = value;
            }
            else
            {
                return this._Camera;
            }
        };

        I.HasHitDistance = function(value)
        {
            if (value !== undefined)
            {
                this._HasHitDistance = value;
            }
            else
            {
                return this._HasHitDistance;
            }
        };

        I.HitDistance = function(value)
        {
            if (value !== undefined)
            {
                this._HitDistance = value;
            }
            else
            {
                return this._HitDistance;
            }
        };

        I.HitObject = function(value)
        {
            if (value !== undefined)
            {
                this._HitObject = value;
            }
            else
            {
                return this._HitObject;
            }
        };

        I.Context = function(value)
        {
            if (value !== undefined)
            {
                this._Context = value;
            }
            else
            {
                return this._Context;
            }
        };

        I._ObjInit = function(context)
        {
            this.Context(context);
        };

        Fuse.HitTestResult.New_1 = function(context)
        {
            var inst = new Fuse.HitTestResult;
            inst._ObjInit(context);
            return inst;
        };

    });
