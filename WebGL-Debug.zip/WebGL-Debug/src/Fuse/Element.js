Fuse.Element = $CreateClass(
    function() {
        Fuse.Node.call(this);
        this._renderBounds = new Uno.Rect;
        this._cachingMode = 0;
        this._effects = null;
        this._compositionEffects = 0;
        this._cache = null;
        this._hitTestMode = 0;
        this._hitTestOpacityThreshold = 0;
        this._layoutPropertyBits = 0;
        this._width = 0;
        this._height = 0;
        this._layoutBackingBits = 0;
        this._margin = new Uno.Float4;
        this._padding = new Uno.Float4;
        this._actualPosition = new Uno.Float2;
        this._actualPositionCache = new Uno.Float2;
        this._haveActualPositionCache = false;
        this._actualSize = new Uno.Float2;
        this._cachedIsKeyboardVisible = false;
        this._cachedRenderTargetSize = new Uno.Float2;
        this._autoKeyboardCompensation = false;
        this._gmsCount = 0;
        this._gmsAt = 0;
        this._gmsCache = null;
        this._positionCache = new Uno.Float2;
        this._arrangeSizeCache = new Uno.Float2;
        this._marginCache = new Uno.Float2;
        this._arrangeAvailSetCache = 0;
        this._placedBefore = false;
        this._sizedBefore = false;
        this._parentElement = null;
        this._isAddedAsPreUpdate = false;
        this._stylingPropertyBits = 0;
        this._opacity = 0;
        this._textColor = new Uno.Float4;
        this._font = null;
        this._fontSize = 0;
        this._textAlignment = 0;
        this._transformOrigin = 0;
        this._layoutDirty = false;
        this._visualDirty = false;
        this._renderBoundsDirty = false;
        this.ActivationStateChanged = null;
        this.Placed = null;
        this.Resized = null;
        this.RequestBringIntoView = null;
        this._WidthUnit = 0;
        this._HeightUnit = 0;
        this._MinWidthUnit = 0;
        this._MinHeightUnit = 0;
        this._MaxWidthUnit = 0;
        this._MaxHeightUnit = 0;
        this._AddedByStyle = false;
    },
    function(S) {
        var I = S.prototype = new Fuse.Node;

        Fuse.Element._minWidthHandle = null;
        Fuse.Element._minHeightHandle = null;
        Fuse.Element._maxWidthHandle = null;
        Fuse.Element._maxHeightHandle = null;
        Fuse.Element._autoStatusBarCompensation = false;
        Fuse.Element._performingLayout = false;

        I.GetType = function()
        {
            return 991;
        };

        I.$II = function(id)
        {
            return [774, 776, 778, 982, 951].indexOf(id) != -1;
        };

        I.RenderBoundsWithEffects = function()
        {
            var r_181 = new Uno.Rect;
            r_181.op_Assign(this.RenderBounds());

            if (this.HasActiveEffects())
            {
                for (var i = 0; i < this.Effects()["Uno.Collections.ICollection__Fuse_Effects_Effect.Count"](); i++)
                {
                    if (this.Effects()["Uno.Collections.IList__Fuse_Effects_Effect.Item"](i).ExtendsRenderBounds() && this.Effects()["Uno.Collections.IList__Fuse_Effects_Effect.Item"](i).Active())
                    {
                        r_181 = Uno.Rect.Union(r_181, this.Effects()["Uno.Collections.IList__Fuse_Effects_Effect.Item"](i).RenderBounds());
                    }
                }
            }

            return r_181;
        };

        I.NeedsClipping = function()
        {
            return this.ClipToBounds();
        };

        I.RenderBounds = function()
        {
            if (this.IsRenderBoundsInvalid())
            {
                this._renderBounds.op_Assign(this.CalcRenderBounds());

                if (this.ClipToBounds())
                {
                    this._renderBounds = Uno.Rect.Intersect(this._renderBounds, this.Bounds());
                }

                this._renderBoundsDirty = false;
            }

            return this._renderBounds;
        };

        I.Bounds = function()
        {
            var a_182 = new Uno.Float2;
            a_182.op_Assign(this.ActualSize());
            return Uno.Rect.New_1(0.0, 0.0, a_182.X, a_182.Y);
        };

        I.IsRedrawCheap = function()
        {
            return true;
        };

        I.CachingMode = function(value)
        {
            if (value !== undefined)
            {
                if (this._cachingMode != value)
                {
                    this._cachingMode = value;
                    this.InvalidateVisual();
                }
            }
            else
            {
                return this._cachingMode;
            }
        };

        I.Effects = function()
        {
            if (this._effects == null)
            {
                this._effects = Uno.Collections.ObservableList__Fuse_Effects_Effect.New_1($CreateDelegate(this, Fuse.Element.prototype.OnEffectAdded, 479), $CreateDelegate(this, Fuse.Element.prototype.OnEffectRemoved, 479));
            }

            return $DownCast(this._effects, 32922);
        };

        I.HasEffects = function()
        {
            return (this._effects != null) && (this._effects.Count() > 0);
        };

        I.HasActiveEffects = function()
        {
            if (this.HasEffects())
            {
                for (var enum_123 = this._effects.GetEnumerator(); enum_123["Uno.Collections.IEnumerator.MoveNext"](); )
                {
                    var e = enum_123["Uno.Collections.IEnumerator__Fuse_Effects_Effect.Current"]();

                    if (e.Active())
                    {
                        return true;
                    }
                }
            }

            return false;
        };

        I.HasCompositionEffect = function()
        {
            return this._compositionEffects > 0;
        };

        I.Cache = function()
        {
            var ind_196 = this._cache;
            return (ind_196 != null) ? ind_196 : (this._cache = Fuse.Cache.New_1(this));
        };

        I.HitTestMode = function(value)
        {
            if (value !== undefined)
            {
                this._hitTestMode = value;
            }
            else
            {
                return this._hitTestMode;
            }
        };

        I.HitTestOpacityThreshold = function(value)
        {
            if (value !== undefined)
            {
                this._hitTestOpacityThreshold = value;
            }
            else
            {
                return this._hitTestOpacityThreshold;
            }
        };

        I.Width = function(value)
        {
            if (value !== undefined)
            {
                if (this.HasNoValue(0) || (this._width != value))
                {
                    this._width = value;
                    this.GiveLocalValue(0);
                    this.OnWidthChanged();
                }
            }
            else
            {
                return this._width;
            }
        };

        I.HasWidth = function()
        {
            return this.HasValue(0);
        };

        I.WidthUnit = function(value)
        {
            if (value !== undefined)
            {
                this._WidthUnit = value;
            }
            else
            {
                return this._WidthUnit;
            }
        };

        I.Height = function(value)
        {
            if (value !== undefined)
            {
                if (this.HasNoValue(1) || (this._height != value))
                {
                    this._height = value;
                    this.GiveLocalValue(1);
                    this.OnHeightChanged();
                }
            }
            else
            {
                return this._height;
            }
        };

        I.HasHeight = function()
        {
            return this.HasValue(1);
        };

        I.HeightUnit = function(value)
        {
            if (value !== undefined)
            {
                this._HeightUnit = value;
            }
            else
            {
                return this._HeightUnit;
            }
        };

        I.MinWidth = function(value)
        {
            if (value !== undefined)
            {
                if (this.HasNoValue(2) || ($DownCast(this.GetValue(Fuse.Element._minWidthHandle), 429) != value))
                {
                    this.SetValue(Fuse.Element._minWidthHandle, $CreateBox(value, 429));
                    this.GiveLocalValue(2);
                    this.OnMinWidthChanged();
                }
            }
            else
            {
                return this.HasNoValue(2) ? 0.0 : $DownCast(this.GetValue(Fuse.Element._minWidthHandle), 429);
            }
        };

        I.HasMinWidth = function()
        {
            return this.HasValue(2);
        };

        I.MinWidthUnit = function(value)
        {
            if (value !== undefined)
            {
                this._MinWidthUnit = value;
            }
            else
            {
                return this._MinWidthUnit;
            }
        };

        I.MinHeight = function(value)
        {
            if (value !== undefined)
            {
                if (this.HasNoValue(3) || ($DownCast(this.GetValue(Fuse.Element._minHeightHandle), 429) != value))
                {
                    this.SetValue(Fuse.Element._minHeightHandle, $CreateBox(value, 429));
                    this.GiveLocalValue(3);
                    this.OnMinHeightChanged();
                }
            }
            else
            {
                return this.HasNoValue(3) ? 0.0 : $DownCast(this.GetValue(Fuse.Element._minHeightHandle), 429);
            }
        };

        I.HasMinHeight = function()
        {
            return this.HasValue(3);
        };

        I.MinHeightUnit = function(value)
        {
            if (value !== undefined)
            {
                this._MinHeightUnit = value;
            }
            else
            {
                return this._MinHeightUnit;
            }
        };

        I.MaxWidth = function(value)
        {
            if (value !== undefined)
            {
                if (this.HasNoValue(4) || ($DownCast(this.GetValue(Fuse.Element._maxWidthHandle), 429) != value))
                {
                    this.SetValue(Fuse.Element._maxWidthHandle, $CreateBox(value, 429));
                    this.GiveLocalValue(4);
                    this.OnMaxWidthChanged();
                }
            }
            else
            {
                return this.HasNoValue(4) ? 0.0 : $DownCast(this.GetValue(Fuse.Element._maxWidthHandle), 429);
            }
        };

        I.MaxWidthUnit = function(value)
        {
            if (value !== undefined)
            {
                this._MaxWidthUnit = value;
            }
            else
            {
                return this._MaxWidthUnit;
            }
        };

        I.MaxHeight = function(value)
        {
            if (value !== undefined)
            {
                if (this.HasNoValue(5) || ($DownCast(this.GetValue(Fuse.Element._maxHeightHandle), 429) != value))
                {
                    this.SetValue(Fuse.Element._maxHeightHandle, $CreateBox(value, 429));
                    this.GiveLocalValue(5);
                    this.OnMaxHeightChanged();
                }
            }
            else
            {
                return this.HasNoValue(5) ? 0.0 : $DownCast(this.GetValue(Fuse.Element._maxHeightHandle), 429);
            }
        };

        I.MaxHeightUnit = function(value)
        {
            if (value !== undefined)
            {
                this._MaxHeightUnit = value;
            }
            else
            {
                return this._MaxHeightUnit;
            }
        };

        I.Alignment = function(value)
        {
            if (value !== undefined)
            {
                if (this.HasNoValue(6) || (this.Alignment() != value))
                {
                    this.SetLayoutValue(15, 0, value);

                    if (value != this.Alignment())
                    {
                        throw new $Error(Uno.Exception.New_2());
                    }

                    this.GiveLocalValue(6);
                    this.OnAlignChanged();
                }
            }
            else
            {
                return (this._layoutBackingBits >> 0) & 15;
            }
        };

        I.HasAlignment = function()
        {
            return this.HasValue(6);
        };

        I.Visibility = function(value)
        {
            if (value !== undefined)
            {
                if (this.HasNoValue(7) || (this.Visibility() != value))
                {
                    this.SetLayoutValue(3, 4, value);
                    this.GiveLocalValue(7);
                    this.OnVisibilityChanged();
                }
            }
            else
            {
                return (this._layoutBackingBits >> 4) & 3;
            }
        };

        I.Margin = function(value)
        {
            if (value !== undefined)
            {
                if (this.HasNoValue(8) || !Fuse.SpeedHelpers.FastEquals(this._margin, value))
                {
                    this._margin.op_Assign(value);
                    this.GiveLocalValue(8);
                    this.OnMarginChanged();
                }
            }
            else
            {
                return this._margin;
            }
        };

        I.Padding = function(value)
        {
            if (value !== undefined)
            {
                if (this.HasNoValue(9) || !Fuse.SpeedHelpers.FastEquals(this._padding, value))
                {
                    this._padding.op_Assign(value);
                    this.GiveLocalValue(9);
                    this.OnPaddingChanged();
                }
            }
            else
            {
                return this._padding;
            }
        };

        I.DefaultSnapToPixels = function()
        {
            return true;
        };

        I.SnapToPixelStore = function(value)
        {
            if (value !== undefined)
            {
                if (value)
                {
                    this._layoutBackingBits = this._layoutBackingBits | 64;
                }
                else
                {
                    this._layoutBackingBits = this._layoutBackingBits & -65;
                }
            }
            else
            {
                return ((this._layoutBackingBits >> 6) & 1) != 0;
            }
        };

        I.SnapToPixels = function(value)
        {
            if (value !== undefined)
            {
                if (this.HasNoValue(10) || (this.SnapToPixelStore() != value))
                {
                    this.SnapToPixelStore(value);
                    this.GiveLocalValue(10);
                    this.OnSnapToPixelsChanged();
                }
            }
            else
            {
                return this.HasNoValue(10) ? this.DefaultSnapToPixels() : this.SnapToPixelStore();
            }
        };

        I.DefaultClipToBounds = function()
        {
            return false;
        };

        I.ClipToBoundsStore = function(value)
        {
            if (value !== undefined)
            {
                if (value)
                {
                    this._layoutBackingBits = this._layoutBackingBits | 128;
                }
                else
                {
                    this._layoutBackingBits = this._layoutBackingBits & -129;
                }
            }
            else
            {
                return ((this._layoutBackingBits >> 7) & 1) != 0;
            }
        };

        I.ClipToBounds = function(value)
        {
            if (value !== undefined)
            {
                if (this.HasNoValue(11) || (this.ClipToBoundsStore() != value))
                {
                    this.ClipToBoundsStore(value);
                    this.GiveLocalValue(11);
                    this.OnClipToBoundsChanged();
                }
            }
            else
            {
                return this.HasNoValue(11) ? this.DefaultClipToBounds() : this.ClipToBoundsStore();
            }
        };

        I.AbsoluteLayoutPosition = function()
        {
            var p_185 = new Uno.Float2;
            p_185.op_Assign(this.ActualPosition());

            if (this.ParentElement() != null)
            {
                p_185 = Uno.Float2.op_Addition(p_185, this.ParentElement().AbsoluteLayoutPosition());
            }

            return p_185;
        };

        I.ActualPosition = function()
        {
            if (this._haveActualPositionCache)
            {
                return this._actualPositionCache;
            }

            if (!this.SnapToPixels())
            {
                return this._actualPosition;
            }

            var parentP = Uno.Float2.New_1(0.0);

            if (this.ParentElement() != null)
            {
                parentP = this.ParentElement().AbsoluteLayoutPosition();
            }

            var p = Uno.Float2.op_Addition(parentP, this._actualPosition);
            p = this.Snap(p);
            p = Uno.Float2.op_Subtraction(p, parentP);
            this._actualPositionCache.op_Assign(p);
            this._haveActualPositionCache = true;
            return p;
        };

        I.ActualSize = function()
        {
            if (this.SnapToPixels())
            {
                return this.Snap(this._actualSize);
            }

            return this._actualSize;
        };

        I["Fuse.IActualSize.ActualSize"] = function()
        {
            return Uno.Float3.New_3(this.ActualSize(), 0.0);
        };

        I.AutoKeyboardCompensation = function(value)
        {
            if (value !== undefined)
            {
                if (this._autoKeyboardCompensation != value)
                {
                    this._autoKeyboardCompensation = value;

                    if (Fuse.Environment.IsOnscreenKeyboardVisible())
                    {
                        this.InvalidateLayout();
                    }
                }
            }
            else
            {
                return this._autoKeyboardCompensation;
            }
        };

        Fuse.Element.AutoStatusBarCompensation = function(value)
        {
            if (value !== undefined)
            {
                Fuse.Element._autoStatusBarCompensation = value;
            }
            else
            {
                return Fuse.Element._autoStatusBarCompensation;
            }
        };

        I.ClientSize = function()
        {
            return Uno.Application.Current().Window().ClientSize();
        };

        I.IsElementRoot = function()
        {
            return this.ParentElement() == null;
        };

        I.AbsoluteZoom = function()
        {
            return Fuse.Environment.ScreenPPIZoomMultiplier();
        };

        I.AddedByStyle = function(value)
        {
            if (value !== undefined)
            {
                this._AddedByStyle = value;
            }
            else
            {
                return this._AddedByStyle;
            }
        };

        I.ParentElement = function()
        {
            return this._parentElement;
        };

        I.IsVisible = function()
        {
            return this.Visibility() == 0;
        };

        I.SubNodeCount = function()
        {
            return this.SubElementCount();
        };

        I.SubElementCount = function()
        {
            return 0;
        };

        I.Opacity = function(value)
        {
            if (value !== undefined)
            {
                if (this._opacity != value)
                {
                    this._opacity = value;
                    this.GiveLocalValue_1(0);
                    this.OnOpacityChanged();
                }
            }
            else
            {
                return this._opacity;
            }
        };

        I.TextColor = function(value)
        {
            if (value !== undefined)
            {
                if (this.HasNoValue_1(1) || !Fuse.SpeedHelpers.FastEquals(this._textColor, value))
                {
                    this._textColor.op_Assign(value);
                    this.GiveLocalValue_1(1);
                    this.OnTextColorChanged();
                }
            }
            else
            {
                return !this.HasNoValue_1(1) ? this._textColor : ((this.ParentElement() != null) ? this.ParentElement().TextColor() : Uno.Float4.New_2(0.0, 0.0, 0.0, 1.0));
            }
        };

        I.Font = function(value)
        {
            if (value !== undefined)
            {
                if (this.HasNoValue_1(2) || (this._font != value))
                {
                    this._font = value;
                    this.GiveLocalValue_1(2);
                    this.OnFontChanged();
                }
            }
            else
            {
                return !this.HasNoValue_1(2) ? this._font : ((this.ParentElement() != null) ? this.ParentElement().Font() : Fuse.Font.Default());
            }
        };

        I.FontSize = function(value)
        {
            if (value !== undefined)
            {
                if (this.HasNoValue_1(3) || (this._fontSize != value))
                {
                    this._fontSize = value;
                    this.GiveLocalValue_1(3);
                    this.OnFontSizeChanged();
                }
            }
            else
            {
                return !this.HasNoValue_1(3) ? this._fontSize : ((this.ParentElement() != null) ? this.ParentElement().FontSize() : 16.0);
            }
        };

        I.TextAlignment = function(value)
        {
            if (value !== undefined)
            {
                if (this.HasNoValue_1(4) || (this._textAlignment != value))
                {
                    this._textAlignment = value;
                    this.GiveLocalValue_1(4);
                    this.OnTextAlignmentChanged();
                }
            }
            else
            {
                return !this.HasNoValue_1(4) ? this._textAlignment : ((this.ParentElement() != null) ? this.ParentElement().TextAlignment() : 0);
            }
        };

        I.TransformOrigin = function(value)
        {
            if (value !== undefined)
            {
                if (this._transformOrigin != value)
                {
                    this._transformOrigin = value;
                    this.InvalidateLocalTransform();
                }
            }
            else
            {
                return this._transformOrigin;
            }
        };

        I.DrawNextFrame = function()
        {
            return this._visualDirty || this._layoutDirty;
        };

        I.IsVisualInvalid = function()
        {
            return this._visualDirty;
        };

        I.IsRenderBoundsInvalid = function()
        {
            return this._renderBoundsDirty;
        };

        I["Fuse.Triggers.Actions.IShow.Show"] = function()
        {
            this.Visibility(0);
        };

        I["Fuse.Triggers.Actions.ICollapse.Collapse"] = function()
        {
            this.Visibility(1);
        };

        I["Fuse.Triggers.Actions.IHide.Hide"] = function()
        {
            this.Visibility(2);
        };

        I.NotifyActivationState = function(state)
        {
            var handler = this.ActivationStateChanged;

            if (Uno.Delegate.op_Inequality(handler, null))
            {
                handler.Invoke(this, state);
            }
        };

        I.CalcRenderBounds = function()
        {
            return this.Bounds();
        };

        I.GetScreenRect = function(dc)
        {
            var transformMatrix_133 = new Uno.Float4x4;
            var elementScreenRegion_134 = new Uno.Rect;
            transformMatrix_133.op_Assign(this.GetDrawMatrix(dc));
            elementScreenRegion_134.op_Assign(Uno.Rect.Transform(this.RenderBounds(), transformMatrix_133));
            return Uno.Rect.Scale_1(elementScreenRegion_134, this.AbsoluteZoom());
        };

        I.GetVisibleScreenRect = function(dc)
        {
            return Uno.Recti.Intersect(dc.Scissor(), Fuse.Element.SnapToCoveringIntegers(this.GetScreenRect(dc)));
        };

        Fuse.Element.SnapToCoveringIntegers = function(r)
        {
            var r_135 = new Uno.Rect;
            r_135.op_Assign(r);
            return Uno.Recti.New_1(Uno.Math.Floor_1(r_135.Left) | 0, Uno.Math.Floor_1(r_135.Top) | 0, Uno.Math.Ceil_1(r_135.Right) | 0, Uno.Math.Ceil_1(r_135.Bottom) | 0);
        };

        I.CaptureRegion = function(dc, region, padding, rootMatrix)
        {
            var region_136 = new Uno.Recti;
            var padding_137 = new Uno.Int2;
            region_136.op_Assign(region);
            padding_137.op_Assign(padding);
            var fb = Fuse.FramebufferPool.Lock(Uno.Int2.op_Addition(region_136.Size(), Uno.Int2.op_Multiply_1(padding_137, 2)), 3, false);
            var translationMatrix = Uno.Matrix.Translation_1((padding_137.X - region_136.Left) / this.AbsoluteZoom(), (padding_137.Y - region_136.Top) / this.AbsoluteZoom(), 0.0);
            var newRootMatrix = Uno.Matrix.Mul_11(Uno.Matrix.Mul_11(dc.RootTransform().Matrix(), rootMatrix), translationMatrix);
            dc.PushRenderTarget(fb, true);
            dc.Clear(Uno.Float4.New_1(0.0), 1.0);
            dc.PushRootTransform(Fuse.FastMatrix.FromFloat4x4(newRootMatrix));
            dc.PushScissor(Uno.Recti.New_2(padding_137, region_136.Size()));
            this.OnDraw(dc);
            dc.PopScissor();
            dc.PopRootTransform();
            dc.PopRenderTarget();
            return fb;
        };

        I.Draw = function(dc)
        {
            var visibleRect_139 = new Uno.Recti;
            var struct_140 = new Uno.Recti;

            if (this.Visibility() != 0)
            {
                return;
            }

            {
                Fuse.Profiling.Context.PushNode(this);
            }

            visibleRect_139.op_Assign(this.GetVisibleScreenRect(dc));

            if (!(struct_140.op_Assign(dc.Viewport()), struct_140).Intersects(visibleRect_139))
            {
                {
                    Fuse.Profiling.Context.PopNode();
                }

                return;
            }

            if (this.NeedsClipping())
            {
                dc.PushScissor(visibleRect_139);
                this.Composit(dc);
                dc.PopScissor();
            }
            else
            {
                this.Composit(dc);
            }

            {
                Fuse.Profiling.Context.PopNode();
            }
        };

        I.DoDraw = function(dc)
        {
            this._visualDirty = false;
            this.OnDraw(dc);
        };

        I.AddStyleEffect = function(e)
        {
            e.AddedByStyle = true;
            this.Effects()["Uno.Collections.ICollection__Fuse_Effects_Effect.Add"](e);
        };

        I.OnEffectAdded = function(e)
        {
            if (e.Type() == 1)
            {
                this._compositionEffects++;
            }

            e.Added(this);
            e.add_RenderingChanged($CreateDelegate(this, Fuse.Element.prototype.OnEffectRenderingChanged, 479));
            this.InvalidateVisual();
        };

        I.OnEffectRemoved = function(e)
        {
            if (e.Type() == 1)
            {
                this._compositionEffects--;
            }

            e.Removed(this);
            e.remove_RenderingChanged($CreateDelegate(this, Fuse.Element.prototype.OnEffectRenderingChanged, 479));
            this.InvalidateVisual();
            e.AddedByStyle = false;
        };

        I.OnEffectRenderingChanged = function(e)
        {
            this.InvalidateVisual();
        };

        I.Composit = function(dc)
        {
            if (((this.Opacity() <= 0.0) || (this.RenderBoundsWithEffects().Size().X < 1.0)) || (this.RenderBoundsWithEffects().Size().Y < 1.0))
            {
                return;
            }

            if (this.Opacity() >= 1.0)
            {
                this.Cache().DrawHeuristically(dc);
                return;
            }

            this.Cache().PinAndValidate(dc);
            this.Cache().Blit(dc, this.Opacity());
            this.Cache().Unpin();
        };

        I.CompositEffects = function(dc)
        {
            var hasActiveEffects = this.HasActiveEffects();

            if (hasActiveEffects)
            {
                for (var enum_124 = this._effects.GetEnumerator(); enum_124["Uno.Collections.IEnumerator.MoveNext"](); )
                {
                    var e = enum_124["Uno.Collections.IEnumerator__Fuse_Effects_Effect.Current"]();

                    if ((e.Type() == 0) && e.Active())
                    {
                        e.Render(dc);
                    }
                }
            }

            if (this.HasCompositionEffect())
            {
                for (var enum_125 = this._effects.GetEnumerator(); enum_125["Uno.Collections.IEnumerator.MoveNext"](); )
                {
                    var e = enum_125["Uno.Collections.IEnumerator__Fuse_Effects_Effect.Current"]();

                    if ((e.Type() == 1) && e.Active())
                    {
                        e.Render(dc);
                    }
                }
            }
            else
            {
                this.DoDraw(dc);
            }

            if (hasActiveEffects)
            {
                for (var enum_126 = this._effects.GetEnumerator(); enum_126["Uno.Collections.IEnumerator.MoveNext"](); )
                {
                    var e = enum_126["Uno.Collections.IEnumerator__Fuse_Effects_Effect.Current"]();

                    if ((e.Type() == 2) && e.Active())
                    {
                        e.Render(dc);
                    }
                }
            }
        };

        I.OnIsEnabledChanged = function()
        {
            Fuse.Node.prototype.OnIsEnabledChanged.call(this);
            this.InvalidateVisual();
        };

        I.IsPointInside = function(localPoint)
        {
            var localPoint_141 = new Uno.Float2;
            localPoint_141.op_Assign(localPoint);
            return !((((localPoint_141.X < 0.0) || (localPoint_141.Y < 0.0)) || (localPoint_141.X > this.ActualSize().X)) || (localPoint_141.Y > this.ActualSize().Y));
        };

        I.OnHitTest = function(htc)
        {
            if ((this.Visibility() != 0) || (this.Opacity() <= this.HitTestOpacityThreshold()))
            {
                return;
            }

            if (this.HitTestMode() == 0)
            {
                this.OnHitTestVisual(htc);
            }
            else if (this.HitTestMode() == 1)
            {
                if (this.IsPointInside(htc.LocalPoint()))
                {
                    htc.Hit($DownCast(this, 33719));
                }
            }
        };

        I.OnHitTestVisual = function(htc)
        {
        };

        I.HasNoValue = function(ep)
        {
            return (this._layoutPropertyBits & (3 << (ep * 2))) == 0;
        };

        I.HasValue = function(ep)
        {
            return (this._layoutPropertyBits & (3 << (ep * 2))) != 0;
        };

        I.HasStyleValue = function(ep)
        {
            return ((this._layoutPropertyBits >> (ep * 2)) & 3) == 1;
        };

        I.GiveLocalValue = function(ep)
        {
            this._layoutPropertyBits = this._layoutPropertyBits & ~(3 << (ep * 2));
            this._layoutPropertyBits = this._layoutPropertyBits | (2 << (ep * 2));
        };

        I.GiveStyleValue = function(ep)
        {
            this._layoutPropertyBits = this._layoutPropertyBits & ~(3 << (ep * 2));
            this._layoutPropertyBits = this._layoutPropertyBits | (1 << (ep * 2));
        };

        I.ClearValue_1 = function(ep)
        {
            this._layoutPropertyBits = this._layoutPropertyBits & ~(3 << (ep * 2));
        };

        I.OnWidthChanged = function()
        {
            this.InvalidateLayout();
        };

        I.ResetWidth = function()
        {
            if (!this.HasNoValue(0))
            {
                this._width = 0.0;
                this.WidthUnit(0);
                this.ClearValue_1(0);
                this.OnWidthChanged();
            }
        };

        I.SetStyleWidth = function(val)
        {
            if (this.HasNoValue(0))
            {
                this._width = val;
                this.GiveStyleValue(0);
                this.OnWidthChanged();
            }
        };

        I.OnHeightChanged = function()
        {
            this.InvalidateLayout();
        };

        I.ResetHeight = function()
        {
            if (!this.HasNoValue(1))
            {
                this._height = 0.0;
                this.HeightUnit(0);
                this.ClearValue_1(1);
                this.OnHeightChanged();
            }
        };

        I.SetStyleHeight = function(val)
        {
            if (this.HasNoValue(1))
            {
                this._height = val;
                this.GiveStyleValue(1);
                this.OnHeightChanged();
            }
        };

        I.OnMinWidthChanged = function()
        {
            this.InvalidateLayout();
        };

        I.ResetMinWidth = function()
        {
            if (!this.HasNoValue(2))
            {
                this.MinWidthUnit(0);
                this.ClearValue(Fuse.Element._minWidthHandle);
                this.ClearValue_1(2);
                this.OnMinWidthChanged();
            }
        };

        I.SetStyleMinWidth_1 = function(val, unit)
        {
            if (this.HasNoValue(2))
            {
                this.MinWidthUnit(unit);
                this.SetValue(Fuse.Element._minWidthHandle, $CreateBox(val, 429));
                this.GiveStyleValue(2);
                this.OnMinWidthChanged();
            }
        };

        I.OnMinHeightChanged = function()
        {
            this.InvalidateLayout();
        };

        I.ResetMinHeight = function()
        {
            if (!this.HasNoValue(3))
            {
                this.MinHeightUnit(0);
                this.ClearValue(Fuse.Element._minHeightHandle);
                this.ClearValue_1(3);
                this.OnMinHeightChanged();
            }
        };

        I.SetStyleMinHeight_1 = function(val, unit)
        {
            if (this.HasNoValue(3))
            {
                this.MinHeightUnit(unit);
                this.SetValue(Fuse.Element._minHeightHandle, $CreateBox(val, 429));
                this.GiveStyleValue(3);
                this.OnMinHeightChanged();
            }
        };

        I.OnMaxWidthChanged = function()
        {
            this.InvalidateLayout();
        };

        I.ResetMaxWidth = function()
        {
            if (!this.HasNoValue(4))
            {
                this.MaxWidthUnit(0);
                this.ClearValue(Fuse.Element._maxWidthHandle);
                this.ClearValue_1(4);
                this.OnMaxWidthChanged();
            }
        };

        I.OnMaxHeightChanged = function()
        {
            this.InvalidateLayout();
        };

        I.ResetMaxHeight = function()
        {
            if (!this.HasNoValue(5))
            {
                this.MaxHeightUnit(0);
                this.ClearValue(Fuse.Element._maxHeightHandle);
                this.ClearValue_1(5);
                this.OnMaxHeightChanged();
            }
        };

        I.SetLayoutValue = function(mask, bit, val)
        {
            this._layoutBackingBits = (this._layoutBackingBits & ~(mask << bit)) | (val << bit);
        };

        I.OnAlignChanged = function()
        {
            this.InvalidateLayout();
        };

        I.ResetAlignment = function()
        {
            if (!this.HasNoValue(6))
            {
                this.SetLayoutValue(15, 0, 0);
                this.ClearValue_1(6);
                this.OnAlignChanged();
            }
        };

        I.SetStyleAlignment = function(val)
        {
            if (this.HasNoValue(6))
            {
                this.SetLayoutValue(15, 0, val);
                this.GiveStyleValue(6);
                this.OnAlignChanged();
            }
        };

        I.OnVisibilityChanged = function()
        {
            this.InvalidateLayout();
            this.InvalidateVisual();
        };

        I.ResetVisibility = function()
        {
            if (!this.HasNoValue(7))
            {
                this.SetLayoutValue(3, 4, 0);
                this.ClearValue_1(7);
                this.OnVisibilityChanged();
            }
        };

        I.OnMarginChanged = function()
        {
            this.InvalidateLayout();
        };

        I.ResetMargin = function()
        {
            if (!this.HasNoValue(8))
            {
                this._margin = Uno.Float4.New_1(0.0);
                this.ClearValue_1(8);
                this.OnMarginChanged();
            }
        };

        I.SetStyleMargin = function(margin)
        {
            if (this.HasNoValue(8))
            {
                this._margin.op_Assign(margin);
                this.GiveStyleValue(8);
                this.OnMarginChanged();
            }
        };

        I.OnPaddingChanged = function()
        {
            this.InvalidateLayout();
            this.InvalidateVisual();
        };

        I.ResetPadding = function()
        {
            if (!this.HasNoValue(9))
            {
                this._padding = Uno.Float4.New_1(0.0);
                this.ClearValue_1(9);
                this.OnPaddingChanged();
            }
        };

        I.SetStylePadding = function(padding)
        {
            if (this.HasNoValue(9))
            {
                this._padding.op_Assign(padding);
                this.GiveStyleValue(9);
                this.OnPaddingChanged();
            }
        };

        I.OnSnapToPixelsChanged = function()
        {
            this.InvalidateLayout();
        };

        I.ResetSnapToPixels = function()
        {
            if (!this.HasNoValue(10))
            {
                this.SnapToPixelStore(false);
                this.ClearValue_1(10);
                this.OnSnapToPixelsChanged();
            }
        };

        I.OnClipToBoundsChanged = function()
        {
            this.InvalidateVisual();
        };

        I.ResetClipToBounds = function()
        {
            if (!this.HasNoValue(11))
            {
                this.ClipToBoundsStore(false);
                this.ClearValue_1(11);
                this.OnClipToBoundsChanged();
            }
        };

        I.OnBringIntoView = function(elm)
        {
            if (Uno.Delegate.op_Inequality(this.RequestBringIntoView, null))
            {
                this.RequestBringIntoView.Invoke(this, Fuse.RequestBringIntoViewArgs.New_2(elm));
            }

            if (this.ParentElement() != null)
            {
                this.ParentElement().OnBringIntoView(elm);
            }
        };

        I.BringIntoView = function()
        {
            this.OnBringIntoView(this);
        };

        I.PerformLayout = function()
        {
            this.PerformLayout_1(this.ClientSize());
        };

        I.PerformLayout_1 = function(clientSize)
        {
            var clientSize_145 = new Uno.Int2;
            clientSize_145.op_Assign(clientSize);

            if (((this._cachedRenderTargetSize.X != clientSize_145.X) || (this._cachedRenderTargetSize.Y != clientSize_145.Y)) || (this._cachedIsKeyboardVisible != Fuse.Environment.IsOnscreenKeyboardVisible()))
            {
                this._cachedRenderTargetSize = Uno.Float2.op_Implicit(clientSize_145);
                this._cachedIsKeyboardVisible = Fuse.Environment.IsOnscreenKeyboardVisible();
                this.InvalidateLayout();
            }

            if (this._layoutDirty)
            {
                Fuse.Element._performingLayout = true;
                var availableSize = Uno.Float2.op_Implicit(clientSize_145);
                var offset = Uno.Float2.New_1(0.0);

                if (Fuse.Element.AutoStatusBarCompensation() && false)
                {
                    offset = Uno.Float2.New_2(0.0, Fuse.Environment.StatusbarSize().Y);
                    availableSize = Uno.Float2.op_Subtraction(availableSize, offset);
                }

                offset = Uno.Float2.op_Division_1(offset, this.AbsoluteZoom());
                availableSize = Uno.Float2.op_Division_1(availableSize, this.AbsoluteZoom());
                this.ArrangeMarginBox(offset, availableSize, 3);
                Fuse.Element._performingLayout = false;
            }
        };

        I.UnitSize = function(scalar, unit, fill, secondary, known)
        {
            known(true);

            if (unit == 0)
            {
                return scalar;
            }

            if (secondary)
            {
                return (scalar * fill) / 100.0;
            }

            known(false);
            return 0.0;
        };

        I.ApplyFixedPaddingBox = function(sz, fillSize, fillSet, fixedSize)
        {
            var sz_146 = new Uno.Float2;
            var fillSize_147 = new Uno.Float2;
            sz_146.op_Assign(sz);
            fillSize_147.op_Assign(fillSize);
            var halign = Fuse.AlignmentHelpers.GetHorizontalAlign(this.Alignment());
            var valign = Fuse.AlignmentHelpers.GetVerticalAlign(this.Alignment());
            var origFillSet = fillSet();
            var known = false;

            if (this.HasWidth())
            {
                sz_146.X = this.UnitSize(this.Width(), this.WidthUnit(), fillSize_147.X, (fillSet() & 1) == 1, $CreateRef(function(){return known}, function($){known=$}, this));
            }
            else if (((fillSet() & 1) == 1) && (halign == 0))
            {
                sz_146.X = fillSize_147.X;
                known = true;
            }

            if (known)
            {
                fillSet(fillSet() | 1);
            }
            else
            {
                fillSet(fillSet() & -2);
            }

            fixedSize(known);
            known = false;

            if (this.HasHeight())
            {
                sz_146.Y = this.UnitSize(this.Height(), this.HeightUnit(), fillSize_147.Y, (fillSet() & 2) == 2, $CreateRef(function(){return known}, function($){known=$}, this));
            }
            else if (((fillSet() & 2) == 2) && (valign == 0))
            {
                sz_146.Y = fillSize_147.Y;
                known = true;
            }

            if (known)
            {
                fillSet(fillSet() | 2);
            }
            else
            {
                fillSet(fillSet() & -3);
            }

            fixedSize(fixedSize() && known);
            sz_146.op_Assign(this.ConstrainMinMax(sz_146, fillSize_147, origFillSet));
            return sz_146;
        };

        I.ConstrainMinMax = function(sz, fillSize, fillSet)
        {
            var sz_148 = new Uno.Float2;
            var fillSize_149 = new Uno.Float2;
            sz_148.op_Assign(sz);
            fillSize_149.op_Assign(fillSize);
            var known;

            if (this.HasValue(4))
            {
                var mx = this.UnitSize(this.MaxWidth(), this.MaxWidthUnit(), fillSize_149.X, (fillSet & 1) == 1, $CreateRef(function(){return known}, function($){known=$}, this));

                if (known)
                {
                    sz_148.X = Uno.Math.Min_1(mx, sz_148.X);
                }
            }

            if (this.HasValue(5))
            {
                var mx = this.UnitSize(this.MaxHeight(), this.MaxHeightUnit(), fillSize_149.Y, (fillSet & 2) == 2, $CreateRef(function(){return known}, function($){known=$}, this));

                if (known)
                {
                    sz_148.Y = Uno.Math.Min_1(mx, sz_148.Y);
                }
            }

            if (this.HasValue(2))
            {
                var mn = this.UnitSize(this.MinWidth(), this.MinWidthUnit(), fillSize_149.X, (fillSet & 1) == 1, $CreateRef(function(){return known}, function($){known=$}, this));

                if (known)
                {
                    sz_148.X = Uno.Math.Max_1(mn, sz_148.X);
                }
            }

            if (this.HasValue(3))
            {
                var mn = this.UnitSize(this.MinHeight(), this.MinHeightUnit(), fillSize_149.Y, (fillSet & 2) == 2, $CreateRef(function(){return known}, function($){known=$}, this));
                sz_148.Y = Uno.Math.Max_1(this.MinHeight(), sz_148.Y);
            }

            return sz_148;
        };

        I.LimitPaddingBoxSize = function(sz, fillSize, fillSet)
        {
            var sz_150 = new Uno.Float2;
            sz_150.op_Assign(sz);
            var fixedSize;
            sz_150 = this.ApplyFixedPaddingBox(sz_150, fillSize, $CreateRef(function(){return fillSet}, function($){fillSet=$}, this), $CreateRef(function(){return fixedSize}, function($){fixedSize=$}, this));

            if (this.SnapToPixels())
            {
                sz_150 = this.SnapUp(sz_150);
            }

            return sz_150;
        };

        I.GMSReset = function()
        {
            this._gmsCount = 0;
            this._gmsAt = 0;
        };

        I.GetMarginSize = function(fillSize, fillSet)
        {
            var g_153 = new Fuse.Element_GMSCacheItem;
            var collection_127 = new Fuse.Element_GMSCacheItem;

            for (var i = 0; i < this._gmsCount; ++i)
            {
                g_153.op_Assign(this._gmsCache[i]);

                if ((fillSet == g_153.fillSet) && Uno.Float2.op_Equality(fillSize, g_153.fillSize))
                {
                    return g_153.result;
                }
            }

            var sz = this.CalcMarginSize(fillSize, fillSet);
            var n = (this._gmsAt++) % 2;
            this._gmsCount = Uno.Math.Min_8(2, this._gmsCount + 1);
            this._gmsCache[n].op_Assign((collection_127 = new Fuse.Element_GMSCacheItem, collection_127.fillSize.op_Assign(fillSize), collection_127.fillSize, collection_127.fillSet = fillSet, collection_127.result.op_Assign(sz), collection_127.result, collection_127));
            return sz;
        };

        I.GetPaddingSize = function(padFill, fillSet)
        {
            var padFill_154 = new Uno.Float2;
            var ind_187;
            var ind_188;
            var ind_189;
            var ind_190;
            padFill_154.op_Assign(padFill);

            if (this.HasValue(9))
            {
                padFill_154 = Uno.Float2.op_Subtraction(padFill_154, Uno.Float2.op_Addition((ind_187 = this.Padding(), Uno.Float2.New_2(ind_187.X, ind_187.Y)), (ind_188 = this.Padding(), Uno.Float2.New_2(ind_188.Z, ind_188.W))));
            }

            var sz = this.GetContentSize(padFill_154, fillSet);

            if (this.HasValue(9))
            {
                sz = Uno.Float2.op_Addition(sz, Uno.Float2.op_Addition((ind_189 = this.Padding(), Uno.Float2.New_2(ind_189.X, ind_189.Y)), (ind_190 = this.Padding(), Uno.Float2.New_2(ind_190.Z, ind_190.W))));
            }

            return sz;
        };

        I.CalcMarginSize = function(fillSize, fillSet)
        {
            var fillSize_155 = new Uno.Float2;
            var ind_191;
            var ind_192;
            var ind_193;
            var ind_194;
            fillSize_155.op_Assign(fillSize);

            if (this.HasValue(8))
            {
                fillSize_155 = Uno.Float2.op_Subtraction(fillSize_155, Uno.Float2.op_Addition((ind_191 = this.Margin(), Uno.Float2.New_2(ind_191.X, ind_191.Y)), (ind_192 = this.Margin(), Uno.Float2.New_2(ind_192.Z, ind_192.W))));
            }

            if (this.AutoKeyboardCompensation())
            {
                fillSize_155 = Uno.Float2.op_Subtraction(fillSize_155, Uno.Float2.New_2(0.0, Fuse.Environment.OnscreenKeyboardSize().Y / this.AbsoluteZoom()));
            }

            if (this.Visibility() == 1)
            {
                return Uno.Float2.New_1(0.0);
            }

            var childFixedSize;
            var childFillSet = fillSet;
            var childPadFill = this.ApplyFixedPaddingBox(fillSize_155, fillSize_155, $CreateRef(function(){return childFillSet}, function($){childFillSet=$}, this), $CreateRef(function(){return childFixedSize}, function($){childFixedSize=$}, this));
            var sz = new Uno.Float2;

            if (!childFixedSize)
            {
                sz = this.GetPaddingSize(childPadFill, childFillSet);
            }
            else
            {
                sz.op_Assign(childPadFill);
            }

            var lsz = this.LimitPaddingBoxSize(sz, fillSize_155, fillSet);
            var nfs = fillSet;
            var needResize = false;

            if ((lsz.X < sz.X) && !((childFillSet & 1) == 1))
            {
                nfs = nfs | 1;
                needResize = true;
            }

            if ((lsz.Y < sz.Y) && !((childFillSet & 2) == 2))
            {
                nfs = nfs | 2;
                needResize = true;
            }

            if (needResize)
            {
                sz = this.GetPaddingSize(lsz, nfs);
                sz = this.LimitPaddingBoxSize(sz, fillSize_155, fillSet);
            }
            else
            {
                sz.op_Assign(lsz);
            }

            if (this.HasValue(8))
            {
                sz = Uno.Float2.op_Addition(sz, Uno.Float2.op_Addition((ind_193 = this.Margin(), Uno.Float2.New_2(ind_193.X, ind_193.Y)), (ind_194 = this.Margin(), Uno.Float2.New_2(ind_194.Z, ind_194.W))));
            }

            if (this.AutoKeyboardCompensation())
            {
                sz = Uno.Float2.op_Addition(sz, Uno.Float2.New_2(0.0, Fuse.Environment.OnscreenKeyboardSize().Y / this.AbsoluteZoom()));
            }

            return sz;
        };

        I.GetContentSize = function(fillSize, fillSet)
        {
            return Uno.Float2.New_1(0.0);
        };

        I.ArrangeMarginBox = function(position, availableSize, availSet)
        {
            var position_157 = new Uno.Float2;
            var availableSize_158 = new Uno.Float2;
            var margin_159 = new Uno.Float4;
            var marginBox_160 = new Uno.Float2;
            var p_161 = new Uno.Float2;
            position_157.op_Assign(position);
            availableSize_158.op_Assign(availableSize);

            if (((((!this._layoutDirty && (position_157.X == this._positionCache.X)) && (position_157.Y == this._positionCache.Y)) && (availableSize_158.X == this._arrangeSizeCache.X)) && (availableSize_158.Y == this._arrangeSizeCache.Y)) && (availSet == this._arrangeAvailSetCache))
            {
                return this._marginCache;
            }

            margin_159.op_Assign(this.Margin());
            var avSize = Uno.Math.Max_3(Uno.Float2.New_1(0.0), availableSize_158);
            marginBox_160.op_Assign(this.GetMarginSize(avSize, availSet));
            var paddingBox = Uno.Float2.op_Subtraction(Uno.Float2.op_Subtraction(marginBox_160, Uno.Float2.New_2(margin_159.X, margin_159.Y)), Uno.Float2.New_2(margin_159.Z, margin_159.W));
            avSize = Uno.Float2.op_Subtraction(avSize, Uno.Float2.op_Addition(Uno.Float2.New_2(margin_159.X, margin_159.Y), Uno.Float2.New_2(margin_159.Z, margin_159.W)));
            avSize = Uno.Math.Max_3(Uno.Float2.New_1(0.0), avSize);
            paddingBox = Uno.Math.Max_3(Uno.Float2.New_1(0.0), paddingBox);
            var s = Uno.Float2.New_1(0.0);

            if (this.Visibility() != 1)
            {
                this.ArrangePaddingBox(paddingBox);
                s.op_Assign(paddingBox);
            }

            p_161.op_Assign(position_157);
            var halign = Fuse.AlignmentHelpers.GetHorizontalAlign(this.Alignment());
            var valign = Fuse.AlignmentHelpers.GetVerticalAlign(this.Alignment());
            p_161.X = p_161.X + margin_159.X;

            if ((availSet & 1) == 1)
            {
                switch (halign)
                {
                    case 0:
                    case 2:
                    {
                        p_161.X = p_161.X + ((avSize.X - s.X) * 0.5);
                        break;
                    }
                    case 3:
                    {
                        p_161.X = p_161.X + (avSize.X - s.X);
                        break;
                    }
                }
            }

            p_161.Y = p_161.Y + margin_159.Y;

            if ((availSet & 2) == 2)
            {
                switch (valign)
                {
                    case 0:
                    case 8:
                    {
                        p_161.Y = p_161.Y + ((avSize.Y - s.Y) * 0.5);
                        break;
                    }
                    case 12:
                    {
                        p_161.Y = p_161.Y + (avSize.Y - s.Y);
                        break;
                    }
                }
            }

            this.PerformPlacement(p_161, s);
            this._layoutDirty = false;
            this._marginCache.op_Assign(marginBox_160);
            this._positionCache.op_Assign(position_157);
            this._arrangeSizeCache.op_Assign(availableSize_158);
            this._arrangeAvailSetCache = availSet;
            this._haveActualPositionCache = false;
            return marginBox_160;
        };

        I.OnPlaced = function(oldPosition)
        {
            if (Uno.Delegate.op_Inequality(this.Placed, null))
            {
                var args = Fuse.PlacedArgs.New_2(this._placedBefore, oldPosition, this._actualPosition);
                this.Placed.Invoke(this, args);
            }

            this._placedBefore = true;
            this.InvalidateVisualComposition();
            this.InvalidateLocalTransform();
        };

        I.OnResized = function(oldSize)
        {
            if (Uno.Delegate.op_Inequality(this.Resized, null))
            {
                var args = Fuse.ResizedArgs.New_2(this._sizedBefore, oldSize, this._actualSize);
                this.Resized.Invoke(this, args);
            }

            this._sizedBefore = true;
            this.InvalidateVisual();
            this.InvalidateRenderBounds();
        };

        I.PerformPlacement = function(position, size)
        {
            var position_164 = new Uno.Float2;
            var oldSize_166 = new Uno.Float2;
            var oldPosition_167 = new Uno.Float2;
            position_164.op_Assign(position);
            var s = Uno.Math.Max_3(size, Uno.Float2.New_1(0.0));

            if ((!this._sizedBefore || (this._actualSize.X != s.X)) || (this._actualSize.Y != s.Y))
            {
                oldSize_166.op_Assign(this._actualSize);
                this._actualSize.op_Assign(s);
                this.OnResized(oldSize_166);
            }

            if ((!this._placedBefore || (this._actualPosition.X != position_164.X)) || (this._actualPosition.Y != position_164.Y))
            {
                oldPosition_167.op_Assign(this._actualPosition);
                this._actualPosition.op_Assign(position_164);
                this.OnPlaced(oldPosition_167);
            }
        };

        I.ArrangePaddingBox = function(avsize)
        {
        };

        I.Snap = function(p)
        {
            var s = Uno.Float2.op_Division_1(Uno.Math.Round_2(Uno.Float2.op_Multiply(p, this.AbsoluteZoom())), this.AbsoluteZoom());
            return s;
        };

        I.SnapUp = function(p)
        {
            var s = Uno.Float2.op_Division_1(Uno.Math.Ceil_2(Uno.Float2.op_Multiply(p, this.AbsoluteZoom())), this.AbsoluteZoom());
            return s;
        };

        I.OnRooted = function()
        {
            if (this.ParentElement() == null)
            {
                Fuse.UpdateManager.AddAction($CreateDelegate(this, Fuse.Element.prototype.PerformLayout, 436), 2);
                this._isAddedAsPreUpdate = true;
            }

            if (this.HasEffects())
            {
                for (var enum_128 = this.Effects()["Uno.Collections.IEnumerable__Fuse_Effects_Effect.GetEnumerator"](); enum_128["Uno.Collections.IEnumerator.MoveNext"](); )
                {
                    var e = enum_128["Uno.Collections.IEnumerator__Fuse_Effects_Effect.Current"]();
                    e.Rooted();
                }
            }

            Fuse.Node.prototype.OnRooted.call(this);
        };

        I.RemovePerformLayout = function()
        {
            if (this._isAddedAsPreUpdate)
            {
                Fuse.UpdateManager.RemoveAction($CreateDelegate(this, Fuse.Element.prototype.PerformLayout, 436), 2);
                this._isAddedAsPreUpdate = false;
            }
        };

        I.OnUnrooted = function()
        {
            this.RemovePerformLayout();

            if (this.HasEffects())
            {
                for (var enum_129 = this.Effects()["Uno.Collections.IEnumerable__Fuse_Effects_Effect.GetEnumerator"](); enum_129["Uno.Collections.IEnumerator.MoveNext"](); )
                {
                    var e = enum_129["Uno.Collections.IEnumerator__Fuse_Effects_Effect.Current"]();
                    e.Unrooted();
                }
            }

            Fuse.Node.prototype.OnUnrooted.call(this);
        };

        I.OnAdded = function(parent)
        {
            Fuse.Node.prototype.OnAdded.call(this, parent);
            this._parentElement = $AsOp(parent, 991);

            if (this.ParentElement() != null)
            {
                this.RemovePerformLayout();
            }

            this.InvalidateLocalTransform();
            this.InvalidateLayout();
            this.InvalidateVisual();
        };

        I.OnRemoved = function(parent)
        {
            Fuse.Node.prototype.OnRemoved.call(this, parent);
            this._parentElement = null;
        };

        I.GetSubNode = function(index)
        {
            return this.GetSubElement(index);
        };

        I.GetSubElement = function(index)
        {
            throw new $Error(Uno.Exception.New_2());
        };

        I.ParentToLocal = function(parentPoint)
        {
            var parentPoint_171 = new Uno.Float2;
            parentPoint_171.op_Assign(parentPoint);

            if (this.IsElementRoot())
            {
                parentPoint_171 = Uno.Float2.op_Division_1(parentPoint_171, this.AbsoluteZoom());
            }

            return Uno.Vector.TransformCoordinate_1(parentPoint_171, this.LocalTransformInverse());
        };

        I.LocalToParent = function(localPoint)
        {
            var localPoint_172 = new Uno.Float2;
            localPoint_172.op_Assign(localPoint);
            localPoint_172.op_Assign(Uno.Vector.TransformCoordinate_1(localPoint_172, this.LocalTransform()));

            if (this.IsElementRoot())
            {
                localPoint_172 = Uno.Float2.op_Multiply(localPoint_172, this.AbsoluteZoom());
            }

            return localPoint_172;
        };

        I.FromAbsolute = function(pointCoord)
        {
            var pointCoord_174 = new Uno.Float2;
            pointCoord_174.op_Assign(pointCoord);

            if (this.ParentElement() != null)
            {
                pointCoord_174.op_Assign(this.ParentElement().FromAbsolute(pointCoord_174));
            }

            return this.ParentToLocal(pointCoord_174);
        };

        I.GetLocalTransformInternal = function()
        {
            return this.LocalTransformInternal();
        };

        Fuse.Element.ExpandToContain_1 = function(baseRect, child)
        {
            var ind_195;
            var struct_176 = new Uno.Float4x4;
            var childRect = child.RenderBoundsWithEffects();
            var fastMatrix = child.GetLocalTransformInternal();
            var childRectInParentSpace = new Uno.Rect;

            if (fastMatrix._hasNonTranslation)
            {
                childRectInParentSpace.op_Assign(Uno.Rect.Transform(childRect, child.LocalTransform()));
            }
            else
            {
                childRectInParentSpace = Uno.Rect.Translate(childRect, (ind_195 = (struct_176.op_Assign(child.LocalTransform()), struct_176).Item(3), Uno.Float2.New_2(ind_195.X, ind_195.Y)));
            }

            return Uno.Rect.Union(baseRect, childRectInParentSpace);
        };

        I.OnResetStyle = function()
        {
            if (this.HasStyleValue_1(0))
            {
                this.ResetOpacity();
            }

            if (this.HasStyleValue_1(1))
            {
                this.ResetTextColor();
            }

            if (this.HasStyleValue_1(2))
            {
                this.ResetFont();
            }

            if (this.HasStyleValue_1(3))
            {
                this.ResetFontSize();
            }

            if (this.HasStyleValue_1(4))
            {
                this.ResetTextAlignment();
            }

            if (this.HasStyleValue(0))
            {
                this.ResetWidth();
            }

            if (this.HasStyleValue(1))
            {
                this.ResetHeight();
            }

            if (this.HasStyleValue(2))
            {
                this.ResetMinWidth();
            }

            if (this.HasStyleValue(3))
            {
                this.ResetMinHeight();
            }

            if (this.HasStyleValue(4))
            {
                this.ResetMaxWidth();
            }

            if (this.HasStyleValue(5))
            {
                this.ResetMaxHeight();
            }

            if (this.HasStyleValue(6))
            {
                this.ResetAlignment();
            }

            if (this.HasStyleValue(7))
            {
                this.ResetVisibility();
            }

            if (this.HasStyleValue(8))
            {
                this.ResetMargin();
            }

            if (this.HasStyleValue(9))
            {
                this.ResetPadding();
            }

            if (this.HasStyleValue(10))
            {
                this.ResetSnapToPixels();
            }

            if (this.HasStyleValue(11))
            {
                this.ResetClipToBounds();
            }

            if (this._effects != null)
            {
                for (var i = 0; i < this._effects.Count(); i++)
                {
                    if (this._effects.Item(i).AddedByStyle)
                    {
                        this._effects.RemoveAt(i--);
                    }
                }
            }

            Fuse.Node.prototype.OnResetStyle.call(this);
        };

        I.HasNoValue_1 = function(ep)
        {
            return (this._stylingPropertyBits & (3 << (ep * 2))) == 0;
        };

        I.HasValue_1 = function(ep)
        {
            return (this._stylingPropertyBits & (3 << (ep * 2))) != 0;
        };

        I.HasStyleValue_1 = function(ep)
        {
            return (this._stylingPropertyBits & (1 << (ep * 2))) != 0;
        };

        I.GiveLocalValue_1 = function(ep)
        {
            this._stylingPropertyBits = this._stylingPropertyBits | (2 << (ep * 2));
        };

        I.GiveStyleValue_1 = function(ep)
        {
            this._stylingPropertyBits = this._stylingPropertyBits | (1 << (ep * 2));
        };

        I.ClearValue_2 = function(ep)
        {
            this._stylingPropertyBits = this._stylingPropertyBits & ~(3 << (ep * 2));
        };

        I.OnOpacityChanged = function()
        {
            this.InvalidateVisualComposition();
        };

        I.ResetOpacity = function()
        {
            if (!this.HasNoValue_1(0))
            {
                this._opacity = 1.0;
                this.OnOpacityChanged();
            }
        };

        I.OnTextColorChanged = function()
        {
            for (var i = 0; i < this.SubElementCount(); i++)
            {
                var e = this.GetSubElement(i);

                if (!e.HasValue_1(1))
                {
                    e.OnTextColorChanged();
                }
            }
        };

        I.ResetTextColor = function()
        {
            if (!this.HasNoValue_1(1))
            {
                this._textColor = Uno.Float4.New_1(0.0);
                this.ClearValue_2(1);
                this.OnTextColorChanged();
            }
        };

        I.SetStyleTextColor = function(color)
        {
            if (this.HasNoValue_1(1))
            {
                this._textColor.op_Assign(color);
                this.GiveStyleValue_1(1);
                this.OnTextColorChanged();
            }
        };

        I.OnFontChanged = function()
        {
            for (var i = 0; i < this.SubElementCount(); i++)
            {
                var e = this.GetSubElement(i);

                if (!e.HasValue_1(2))
                {
                    e.OnFontChanged();
                }
            }
        };

        I.ResetFont = function()
        {
            if (!this.HasNoValue_1(2))
            {
                this._font = null;
                this.ClearValue_2(2);
                this.OnFontChanged();
            }
        };

        I.OnFontSizeChanged = function()
        {
            for (var i = 0; i < this.SubElementCount(); i++)
            {
                var e = this.GetSubElement(i);

                if (!e.HasValue_1(3))
                {
                    e.OnFontSizeChanged();
                }
            }
        };

        I.ResetFontSize = function()
        {
            if (!this.HasNoValue_1(3))
            {
                this.ClearValue_2(3);
                this.OnFontSizeChanged();
            }
        };

        I.OnTextAlignmentChanged = function()
        {
            for (var i = 0; i < this.SubElementCount(); i++)
            {
                var e = this.GetSubElement(i);

                if (!e.HasValue_1(4))
                {
                    e.OnTextAlignmentChanged();
                }
            }
        };

        I.ResetTextAlignment = function()
        {
            if (!this.HasNoValue_1(4))
            {
                this._textAlignment = 0;
                this.ClearValue_2(4);
                this.OnTextAlignmentChanged();
            }
        };

        I.SetStyleTextAlignment = function(ta)
        {
            if (this.HasNoValue_1(4))
            {
                this._textAlignment = ta;
                this.GiveStyleValue_1(4);
                this.OnTextAlignmentChanged();
            }
        };

        I.PrependTransformOrigin = function(m)
        {
            var b_178 = new Uno.Float2;

            if (this.TransformOrigin() == 0)
            {
                b_178.op_Assign(this.Bounds().Center());
                m.PrependTranslation(b_178.X, b_178.Y, 0.0);
            }
        };

        I.PrependInverseTransformOrigin = function(m)
        {
            var b_179 = new Uno.Float2;

            if (this.TransformOrigin() == 0)
            {
                b_179.op_Assign(this.Bounds().Center());
                m.PrependTranslation(-b_179.X, -b_179.Y, 0.0);
            }
        };

        I.PrependImplicitTransform = function(m)
        {
            var actualPosition_180 = new Uno.Float2;
            actualPosition_180.op_Assign(this.ActualPosition());

            if ((actualPosition_180.X != 0.0) || (actualPosition_180.Y != 0.0))
            {
                m.PrependTranslation(actualPosition_180.X, actualPosition_180.Y, 0.0);
            }
        };

        I.InvalidateLocalTransform = function()
        {
            this.InvalidateVisualComposition();

            if (this.ParentElement() != null)
            {
                this.ParentElement().InvalidateRenderBounds();
            }

            Fuse.Node.prototype.InvalidateLocalTransform.call(this);
        };

        I.InvalidateVisual = function()
        {
            var p = this;

            while (p != null)
            {
                if (p.Cache() != null)
                {
                    p.Cache().Invalidate();
                }

                p._visualDirty = true;
                p = p.ParentElement();
            }
        };

        I.InvalidateVisualComposition = function()
        {
            if (this.ParentElement() != null)
            {
                this.ParentElement().InvalidateVisual();
            }
            else
            {
                this.InvalidateVisual();
            }
        };

        I.InvalidateLayout = function()
        {
            if (Fuse.Element._performingLayout)
            {
                throw new $Error(Uno.Exception.New_1("Layout was invalidated while performing layout"));
            }

            var p = this;

            while (p != null)
            {
                p._layoutDirty = true;
                p.GMSReset();
                p = p.ParentElement();
            }
        };

        I.InvalidateRenderBounds = function()
        {
            var p = this;

            while (p != null)
            {
                p._renderBoundsDirty = true;

                if (p.ClipToBounds())
                {
                    return;
                }

                p = p.ParentElement();
            }
        };

        Fuse.Element._TypeInit_1 = function()
        {
            Fuse.Element._minWidthHandle = Fuse.PropertyHandle.New_1();
            Fuse.Element._minHeightHandle = Fuse.PropertyHandle.New_1();
            Fuse.Element._maxWidthHandle = Fuse.PropertyHandle.New_1();
            Fuse.Element._maxHeightHandle = Fuse.PropertyHandle.New_1();
            Fuse.Element._autoStatusBarCompensation = true;
        };

        I._ObjInit_1 = function()
        {
            this._gmsCache = Array.Structs(2, Fuse.Element_GMSCacheItem, 1022);
            this._opacity = 1.0;
            this._layoutDirty = true;
            this._visualDirty = true;
            this._renderBoundsDirty = true;
            Fuse.Node.prototype._ObjInit.call(this);
        };

        I.add_ActivationStateChanged = function(value)
        {
            this.ActivationStateChanged = $DownCast(Uno.Delegate.Combine(this.ActivationStateChanged, value), 993);
        };

        I.remove_ActivationStateChanged = function(value)
        {
            this.ActivationStateChanged = $DownCast(Uno.Delegate.Remove(this.ActivationStateChanged, value), 993);
        };

        I.add_Placed = function(value)
        {
            this.Placed = $DownCast(Uno.Delegate.Combine(this.Placed, value), 998);
        };

        I.remove_Placed = function(value)
        {
            this.Placed = $DownCast(Uno.Delegate.Remove(this.Placed, value), 998);
        };

        I.add_Resized = function(value)
        {
            this.Resized = $DownCast(Uno.Delegate.Combine(this.Resized, value), 996);
        };

        I.remove_Resized = function(value)
        {
            this.Resized = $DownCast(Uno.Delegate.Remove(this.Resized, value), 996);
        };

        I.add_RequestBringIntoView = function(value)
        {
            this.RequestBringIntoView = $DownCast(Uno.Delegate.Combine(this.RequestBringIntoView, value), 1000);
        };

        I.remove_RequestBringIntoView = function(value)
        {
            this.RequestBringIntoView = $DownCast(Uno.Delegate.Remove(this.RequestBringIntoView, value), 1000);
        };

    });
