Fuse.InputEventArgs = $CreateClass(
    function() {
        Uno.EventArgs.call(this);
        this._IsHandled = false;
    },
    function(S) {
        var I = S.prototype = new Uno.EventArgs;

        I.GetType = function()
        {
            return 920;
        };

        I.IsHandled = function(value)
        {
            if (value !== undefined)
            {
                this._IsHandled = value;
            }
            else
            {
                return this._IsHandled;
            }
        };

        I._ObjInit_1 = function()
        {
            Uno.EventArgs.prototype._ObjInit.call(this);
        };

    });
