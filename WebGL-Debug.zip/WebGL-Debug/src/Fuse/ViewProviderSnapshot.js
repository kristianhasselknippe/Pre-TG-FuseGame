Fuse.ViewProviderSnapshot = $CreateClass(
    function() {
        Fuse.ViewProvider.call(this);
        this._camera = null;
        this._viewport = new Uno.Recti;
    },
    function(S) {
        var I = S.prototype = new Fuse.ViewProvider;

        I.GetType = function()
        {
            return 966;
        };

        I.Camera = function()
        {
            return this._camera;
        };

        I._ObjInit_1 = function(camera, viewport)
        {
            Fuse.ViewProvider.prototype._ObjInit.call(this);
            this._camera = camera;
            this._viewport.op_Assign(viewport);
        };

        Fuse.ViewProviderSnapshot.New_1 = function(camera, viewport)
        {
            var inst = new Fuse.ViewProviderSnapshot;
            inst._ObjInit_1(camera, viewport);
            return inst;
        };

    });
