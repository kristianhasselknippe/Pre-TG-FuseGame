Fuse.KeyPressedArgs = $CreateClass(
    function() {
        Fuse.KeyEventArgs.call(this);
    },
    function(S) {
        var I = S.prototype = new Fuse.KeyEventArgs;

        I.GetType = function()
        {
            return 973;
        };

        I._ObjInit_3 = function(key)
        {
            Fuse.KeyEventArgs.prototype._ObjInit_2.call(this, key);
        };

        Fuse.KeyPressedArgs.New_2 = function(key)
        {
            var inst = new Fuse.KeyPressedArgs;
            inst._ObjInit_3(key);
            return inst;
        };

    });
