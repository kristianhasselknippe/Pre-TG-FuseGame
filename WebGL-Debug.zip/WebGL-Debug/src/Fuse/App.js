Fuse.App = $CreateClass(
    function() {
        Uno.Application.call(this);
        this._resources = null;
        this._style = null;
        this._root = null;
        this.windowSizeCache = new Uno.Int2;
    },
    function(S) {
        var I = S.prototype = new Uno.Application;

        I.GetType = function()
        {
            return 913;
        };

        I.$II = function(id)
        {
            return [951].indexOf(id) != -1;
        };

        I.Style = function(value)
        {
            if (value !== undefined)
            {
                if (this._style != value)
                {
                    this._style = value;
                    this.OnResetStyle();
                }
            }
            else
            {
                return this._style;
            }
        };

        I["Fuse.INode.Parent"] = function()
        {
            return null;
        };

        I["Fuse.INode.IsRooted"] = function(value)
        {
            if (value !== undefined)
            {
            }
            else
            {
                return true;
            }
        };

        I["Fuse.INode.IsEnabled"] = function(value)
        {
            if (value !== undefined)
            {
            }
            else
            {
                return true;
            }
        };

        I["Fuse.INode.IsFocusable"] = function(value)
        {
            if (value !== undefined)
            {
            }
            else
            {
                return true;
            }
        };

        I["Fuse.INode.DrawNextFrame"] = function()
        {
            return this.RootNode()["Fuse.INode.DrawNextFrame"]();
        };

        I.RootNode = function(value)
        {
            if (value !== undefined)
            {
                if (this._root != value)
                {
                    if (this._root != null)
                    {
                        this._root["Fuse.INode.OnRemoved"]($DownCast(this, 33719));
                    }

                    this._root = value;

                    if (this._root != null)
                    {
                        this._root["Fuse.INode.OnAdded"]($DownCast(this, 33719));
                    }
                }
            }
            else
            {
                return this._root;
            }
        };

        I.GetResource = function(key)
        {
            if (this._resources != null)
            {
                var res = this._resources.Item(key);

                if (res != null)
                {
                    return res;
                }
            }

            return null;
        };

        I["Fuse.INode.OnAdded"] = function(parent)
        {
        };

        I["Fuse.INode.OnRemoved"] = function(parent)
        {
        };

        I["Fuse.INode.ApplyStyle"] = function(target)
        {
            if (this.Style() != null)
            {
                this.Style().Apply(target);
            }
        };

        I["Fuse.INode.ResetStyle"] = function()
        {
            this.OnResetStyle();
        };

        I.OnResetStyle = function()
        {
            if (this.RootNode() != null)
            {
                this.RootNode()["Fuse.INode.ResetStyle"]();
            }
        };

        I.PredictFocus = function(direction)
        {
            var ind_125;
            return (this.RootNode() == null) ? $DownCast(this, 33719) : (ind_125 = this.RootNode()["Fuse.INode.PredictFocus"](direction), ((ind_125 != null) ? ind_125 : $DownCast(this, 33719)));
        };

        I["Fuse.INode.Draw"] = function(dc)
        {
            if (this.RootNode() != null)
            {
                this.RootNode()["Fuse.INode.Draw"](dc);
            }
        };

        I["Fuse.INode.HitTest"] = function(htc)
        {
            if (this.RootNode() != null)
            {
                this.RootNode()["Fuse.INode.HitTest"](htc);
            }
        };

        I["Fuse.INode.RaiseEvent"] = function(args)
        {
        };

        I.OnNeedsInvalidate = function(sender, args)
        {
            if (this.RootNode() != null)
            {
            }
        };

        I.OnPointerPressed = function(sender, args)
        {
            if (this.RootNode() != null)
            {
                args.Handled(Fuse.Input.RaisePointerPressed(this.RootNode(), Fuse.PointerEventData.New_1(args.FingerId(), args.Position(), args.WheelDelta(), args.WheelDeltaMode(), args.IsPrimary(), Fuse.ViewProvider.Default(), args.PointerType())).IsHandled());
            }
        };

        I.OnPointerReleased = function(sender, args)
        {
            if (this.RootNode() != null)
            {
                args.Handled(Fuse.Input.RaisePointerReleased(this.RootNode(), Fuse.PointerEventData.New_1(args.FingerId(), args.Position(), args.WheelDelta(), args.WheelDeltaMode(), args.IsPrimary(), Fuse.ViewProvider.Default(), args.PointerType())).IsHandled());
            }
        };

        I.OnPointerMoved = function(sender, args)
        {
            if (this.RootNode() != null)
            {
                args.Handled(Fuse.Input.RaisePointerMoved(this.RootNode(), Fuse.PointerEventData.New_1(args.FingerId(), args.Position(), args.WheelDelta(), args.WheelDeltaMode(), args.IsPrimary(), Fuse.ViewProvider.Default(), args.PointerType())).IsHandled());
            }
        };

        I.OnPointerWheelChanged = function(sender, args)
        {
            if (this.RootNode() != null)
            {
                args.Handled(Fuse.Input.RaisePointerWheelChanged(this.RootNode(), Fuse.PointerEventData.New_1(args.FingerId(), args.Position(), args.WheelDelta(), args.WheelDeltaMode(), args.IsPrimary(), Fuse.ViewProvider.Default(), args.PointerType())).IsHandled());
            }
        };

        I.OnPointerLeft = function(sender, args)
        {
            if (this.RootNode() != null)
            {
                args.Handled(Fuse.Input.RaisePointerLeft(this.RootNode(), Fuse.PointerEventData.New_1(args.FingerId(), args.Position(), args.WheelDelta(), args.WheelDeltaMode(), args.IsPrimary(), Fuse.ViewProvider.Default(), args.PointerType())).IsHandled());
            }
        };

        I.OnKeyPressed = function(sender, args)
        {
            if (!args.Handled() && (args.Key() == 9))
            {
                Fuse.FocusManager.Move(args.IsShiftKeyPressed() ? 0 : 1);
            }
        };

        I.OnTextInput = function(sender, args)
        {
            args.Handled(Fuse.Input.RaiseTextInput(args.Text()).IsHandled());
        };

        I.OnGotFocus = function(sender, args)
        {
            Fuse.FocusManager.OnWindowGotFocus(sender, args);
        };

        I.OnLostFocus = function(sender, args)
        {
            Fuse.FocusManager.OnWindowLostFocus(sender, args);
        };

        I.Draw = function()
        {
            this.OnDraw();
            var dc = Fuse.DrawContext.New_1();
            dc.MakeCurrent();

            if (this.RootNode() != null)
            {
                this.RootNode()["Fuse.INode.Draw"](dc);
            }

            dc.Flush();
            Fuse.UpdateManager.IncreaseFrameIndex();
            Fuse.Profiling.Context.Clear();
        };

        I.OnDraw = function()
        {
        };

        I.Update = function()
        {
            this.OnUpdate();
            Fuse.UpdateManager.Update();

            if (this.RootNode() == null)
            {
                return;
            }

            var d = this.RootNode()["Fuse.INode.DrawNextFrame"]();

            if (Uno.Int2.op_Inequality(this.windowSizeCache, this.Window().ClientSize()))
            {
                d = true;
                this.windowSizeCache.op_Assign(this.Window().ClientSize());
            }

            if (this.DrawNextFrame() != d)
            {
                this.DrawNextFrame(d);
            }
        };

        I.OnUpdate = function()
        {
        };

        I._ObjInit_1 = function()
        {
            Uno.Application.prototype._ObjInit.call(this);
            this.ClearColor(Uno.Float4.New_1(1.0));
            this.Window().add_PointerPressed($CreateDelegate(this, Fuse.App.prototype.OnPointerPressed, 492));
            this.Window().add_PointerReleased($CreateDelegate(this, Fuse.App.prototype.OnPointerReleased, 492));
            this.Window().add_PointerMoved($CreateDelegate(this, Fuse.App.prototype.OnPointerMoved, 492));
            this.Window().add_PointerWheelChanged($CreateDelegate(this, Fuse.App.prototype.OnPointerWheelChanged, 492));
            this.Window().add_KeyPressed($CreateDelegate(this, Fuse.App.prototype.OnKeyPressed, 493));
            this.Window().add_TextInput($CreateDelegate(this, Fuse.App.prototype.OnTextInput, 494));
            this.Window().add_PointerLeft($CreateDelegate(this, Fuse.App.prototype.OnPointerLeft, 492));
            this.Window().add_AppEnteredForeground($CreateDelegate(this, Fuse.App.prototype.OnNeedsInvalidate, 445));
            this.Window().add_Resized($CreateDelegate(this, Fuse.App.prototype.OnNeedsInvalidate, 445));
            this.Window().add_GotFocus($CreateDelegate(this, Fuse.App.prototype.OnGotFocus, 445));
            this.Window().add_LostFocus($CreateDelegate(this, Fuse.App.prototype.OnLostFocus, 445));
        };

        I["Fuse.INode.GetResource"] = I.GetResource;
        I["Fuse.INode.PredictFocus"] = I.PredictFocus;

    });
