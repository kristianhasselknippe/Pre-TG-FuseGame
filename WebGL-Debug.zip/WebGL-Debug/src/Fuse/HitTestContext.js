Fuse.HitTestContext = $CreateClass(
    function() {
        Fuse.TraverseContext.call(this);
        this._localPoints = null;
        this._localPoint = new Uno.Float2;
        this._callback = null;
        this.viewports = null;
        this._PointCoord = new Uno.Float2;
    },
    function(S) {
        var I = S.prototype = new Fuse.TraverseContext;

        I.GetType = function()
        {
            return 950;
        };

        I.PointCoord = function(value)
        {
            if (value !== undefined)
            {
                this._PointCoord.op_Assign(value);
            }
            else
            {
                return this._PointCoord;
            }
        };

        I.LocalPoint = function()
        {
            return this._localPoint;
        };

        I.Callback = function()
        {
            return this._callback;
        };

        I.Viewport = function()
        {
            if (this.viewports.Count() > 0)
            {
                return Uno.Collections.EnumerableExtensions.Last__Uno_Recti($DownCast(this.viewports, 32842));
            }
            else
            {
                return Uno.Recti.New_2(Uno.Int2.New_2(0, 0), Uno.Application.Current().GraphicsContext().Backbuffer().Size());
            }
        };

        I.PushLocalPoint = function(lp)
        {
            this._localPoints.Add(this._localPoint);
            this._localPoint.op_Assign(lp);
        };

        I.PopLocalPoint = function()
        {
            this._localPoint.op_Assign(this._localPoints.Item(this._localPoints.Count() - 1));
            Uno.Collections.IListExtensions.RemoveLast__float2($DownCast(this._localPoints, 32917));
        };

        I.Hit = function(obj)
        {
            var ind_131;
            var ind_132;
            var collection_123;

            if (Uno.Delegate.op_Inequality(this.Callback(), null))
            {
                this.Callback().Invoke((collection_123 = Fuse.HitTestResult.New_1(this), ind_131 = this.Viewport(), collection_123.Viewport(ind_131), ind_131, ind_132 = this.Camera(), collection_123.Camera(ind_132), ind_132, collection_123.HitObject(obj), obj, collection_123));
            }
        };

        I.Dispose = function()
        {
            this._callback = null;
        };

        I._ObjInit_2 = function(pointCoord, callback)
        {
            this._localPoints = Uno.Collections.List__float2.New_1();
            this.viewports = Uno.Collections.List__Uno_Recti.New_1();
            Fuse.TraverseContext.prototype._ObjInit_1.call(this, null);
            this.PointCoord(pointCoord);
            this._localPoint.op_Assign(pointCoord);
            this._callback = callback;
        };

        Fuse.HitTestContext.New_1 = function(pointCoord, callback)
        {
            var inst = new Fuse.HitTestContext;
            inst._ObjInit_2(pointCoord, callback);
            return inst;
        };

    });
