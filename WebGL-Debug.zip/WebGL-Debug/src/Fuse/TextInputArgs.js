Fuse.TextInputArgs = $CreateClass(
    function() {
        Fuse.InputEventArgs.call(this);
        this._Text = null;
    },
    function(S) {
        var I = S.prototype = new Fuse.InputEventArgs;

        I.GetType = function()
        {
            return 935;
        };

        I.Text = function(value)
        {
            if (value !== undefined)
            {
                this._Text = value;
            }
            else
            {
                return this._Text;
            }
        };

        I._ObjInit_2 = function(text)
        {
            Fuse.InputEventArgs.prototype._ObjInit_1.call(this);
            this.Text(text);
        };

        Fuse.TextInputArgs.New_2 = function(text)
        {
            var inst = new Fuse.TextInputArgs;
            inst._ObjInit_2(text);
            return inst;
        };

    });
