Fuse.LostFocusArgs = $CreateClass(
    function() {
        Uno.EventArgs.call(this);
    },
    function(S) {
        var I = S.prototype = new Uno.EventArgs;

        I.GetType = function()
        {
            return 938;
        };

        I._ObjInit_1 = function()
        {
            Uno.EventArgs.prototype._ObjInit.call(this);
        };

        Fuse.LostFocusArgs.New_2 = function()
        {
            var inst = new Fuse.LostFocusArgs;
            inst._ObjInit_1();
            return inst;
        };

    });
