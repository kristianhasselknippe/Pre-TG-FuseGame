Fuse.Node = $CreateClass(
    function() {
        this._behaviors = null;
        this._nodebits = 0;
        this._extrinsicList = null;
        this._focusable = false;
        this._transforms = null;
        this._absoluteTransformInverse = null;
        this._absoluteTransform = null;
        this._absoluteTransformTimestamp = 0;
        this._localTransform = null;
        this._localTransformInverse = null;
        this._parent = null;
        this._updateListeners = null;
        this._localIsRooted = false;
    },
    function(S) {
        var I = S.prototype;

        Fuse.Node._isEnabledChangedHandle = null;
        Fuse.Node._manipulationCancelledHandle = null;
        Fuse.Node._gotFocusHandle = null;
        Fuse.Node._lostFocusHandle = null;
        Fuse.Node._lostSoftCaptureHandle = null;
        Fuse.Node._pointerPressedHandle = null;
        Fuse.Node._pointerReleasedHandle = null;
        Fuse.Node._pointerWheelChangedHandle = null;
        Fuse.Node._pointerMovedHandle = null;
        Fuse.Node._pointerEnterHandle = null;
        Fuse.Node._pointerLeaveHandle = null;
        Fuse.Node._textInputHandle = null;
        Fuse.Node._handleHandle = null;
        Fuse.Node._resourcesHandle = null;
        Fuse.Node._styleHandle = null;
        Fuse.Node._addedHandle = null;
        Fuse.Node._removedHandle = null;
        Fuse.Node._rootedHandle = null;
        Fuse.Node._unrootedHandle = null;

        I.GetType = function()
        {
            return 978;
        };

        I.$II = function(id)
        {
            return [951].indexOf(id) != -1;
        };

        I.Behaviors = function()
        {
            if (this._behaviors == null)
            {
                this._behaviors = Uno.Collections.ObservableList__Fuse_Behavior.New_1($CreateDelegate(this, Fuse.Node.prototype.OnBehaviorAdded, 483), $CreateDelegate(this, Fuse.Node.prototype.OnBehaviorRemoved, 483));
            }

            return $DownCast(this._behaviors, 32920);
        };

        I.IsEnabled = function(value)
        {
            if (value !== undefined)
            {
                if (this.HasBit(2) == value)
                {
                    if (!value)
                    {
                        this.SetBit(2);
                    }
                    else
                    {
                        this.ClearBit(2);
                    }

                    this.OnIsEnabledChanged();
                }
            }
            else
            {
                if (!this.HasBit(2))
                {
                    if (this.Parent() != null)
                    {
                        return this.Parent()["Fuse.INode.IsEnabled"]();
                    }
                    else
                    {
                        return true;
                    }
                }
                else
                {
                    return false;
                }
            }
        };

        I.RaiseHandledEvents = function()
        {
            return false;
        };

        I.IsVisible = function()
        {
            return true;
        };

        I.IsFocusable = function(value)
        {
            if (value !== undefined)
            {
                this._focusable = value;
            }
            else
            {
                return this._focusable;
            }
        };

        I.IsFocused = function()
        {
            return Fuse.FocusManager.FocusedObject() == this;
        };

        I.IsFocusWithin = function()
        {
            return this.IsEqualToSelf(Fuse.FocusManager.FocusedObject()) || (Fuse.Node.FindParent(Fuse.FocusManager.FocusedObject(), $CreateDelegate(this, Fuse.Node.prototype.IsEqualToSelf, 504)) != null);
        };

        I.Resources = function(value)
        {
            if (value !== undefined)
            {
                if (value != this.Resources())
                {
                    if (this.Resources() != null)
                    {
                        this.Resources().NotifyOwnerChanged();
                    }

                    if (value != null)
                    {
                        this.SetValue(Fuse.Node._resourcesHandle, value);
                        this.SetBit(1);
                        this.Resources().NotifyOwnerChanged();
                    }
                    else
                    {
                        this.ClearValue(Fuse.Node._resourcesHandle);
                        this.ClearBit(1);
                    }
                }
            }
            else
            {
                if (this.HasBit(1))
                {
                    return $DownCast(this.GetValue(Fuse.Node._resourcesHandle), 561);
                }

                return null;
            }
        };

        I.Style = function(value)
        {
            if (value !== undefined)
            {
                if (!this.HasBit(4) || (this.Style() != value))
                {
                    if (value != null)
                    {
                        this.SetValue(Fuse.Node._styleHandle, value);
                        this.SetBit(4);
                    }
                    else
                    {
                        this.ClearValue(Fuse.Node._styleHandle);
                        this.ClearBit(4);
                    }

                    this.ResetStyle();
                }
            }
            else
            {
                if (this.HasBit(4))
                {
                    return $DownCast(this.GetValue(Fuse.Node._styleHandle), 960);
                }

                return null;
            }
        };

        I.Transforms = function()
        {
            if (this._transforms == null)
            {
                this._transforms = Uno.Collections.ObservableList__Fuse_Transform.New_1($CreateDelegate(this, Fuse.Node.prototype.OnTransformAdded, 477), $CreateDelegate(this, Fuse.Node.prototype.OnTransformRemoved, 477));
            }

            return $DownCast(this._transforms, 32921);
        };

        I.HasExplicitTransforms = function()
        {
            return (this._transforms != null) && (this._transforms.Count() > 0);
        };

        I.AbsoluteTransform = function()
        {
            return this.AbsoluteTransformInternal().Matrix();
        };

        I.AbsoluteTransformInternal = function()
        {
            if (!this.IsAbsoluteMatrixValid())
            {
                this._absoluteTransform = this.CalcAbsoluteTransform();
                this._absoluteTransformTimestamp = Fuse.UpdateManager.FrameIndex();
                this._absoluteTransformInverse = null;
            }

            return this._absoluteTransform;
        };

        I.LocalTransform = function()
        {
            return this.LocalTransformInternal().Matrix();
        };

        I.LocalTransformInternal = function()
        {
            if (this._localTransform == null)
            {
                this._localTransform = Fuse.FastMatrix.Identity();
                this.PrependLocalTransform(this._localTransform);
            }

            return this._localTransform;
        };

        I.LocalTransformInverse = function()
        {
            if (this._localTransformInverse == null)
            {
                this._localTransformInverse = Fuse.FastMatrix.FromFloat4x4(this.LocalTransform());
                this._localTransformInverse.Invert();
            }

            return this._localTransformInverse.Matrix();
        };

        I.Parent = function()
        {
            return this._parent;
        };

        I.IsRooted = function()
        {
            return (this.Parent() != null) && this.Parent()["Fuse.INode.IsRooted"]();
        };

        I.SubNodeCount = function()
        {
            return 0;
        };

        I.DrawNextFrame = function()
        {
            return true;
        };

        I.AddStyleBehavior = function(b)
        {
            b.AddedByStyle = true;
            this.Behaviors()["Uno.Collections.ICollection__Fuse_Behavior.Add"](b);
        };

        I.OnBehaviorAdded = function(b)
        {
            if (this.IsRooted())
            {
                b.Rooted(this);
            }
        };

        I.OnBehaviorRemoved = function(b)
        {
            if (this.IsRooted())
            {
                b.Unrooted(this);
                b.AddedByStyle = false;
            }
        };

        I.RootBehaviors = function()
        {
            if (this._behaviors != null)
            {
                for (var i = 0; i < this._behaviors.Count(); i++)
                {
                    this._behaviors.Item(i).Rooted(this);
                }
            }
        };

        I.UnrootBehaviors = function()
        {
            if (this._behaviors != null)
            {
                for (var i = 0; i < this._behaviors.Count(); i++)
                {
                    this._behaviors.Item(i).Unrooted(this);
                }
            }
        };

        I.HasBit = function(nb)
        {
            return (this._nodebits & (1 << nb)) != 0;
        };

        I.SetBit = function(nb)
        {
            this._nodebits = this._nodebits | (1 << nb);
        };

        I.ClearBit = function(nb)
        {
            this._nodebits = this._nodebits & ~(1 << nb);
        };

        I.RaiseEvent = function(ph, ne)
        {
            if (this.HasBit(ne))
            {
                this.ForeachInList(ph, $CreateDelegate(this, Fuse.Node.prototype.InvokeEventHandler, 488), Uno.EventArgs.Empty);
            }
        };

        I.InvokeEventHandler = function(obj, args)
        {
            $DownCast(obj, 445).Invoke(this, $DownCast(args, 444));
        };

        I.AddEventHandler = function(ph, ne, handler)
        {
            this.AddToList(ph, handler);
            this.SetBit(ne);
        };

        I.RemoveEventHandler = function(ph, ne, handler)
        {
            if (!this.RemoveFromList(ph, handler))
            {
                this.ClearBit(ne);
            }
        };

        I.OnIsEnabledChanged = function()
        {
            this.RaiseEvent(Fuse.Node._isEnabledChangedHandle, 5);
        };

        I.HitTest = function(htc)
        {
            if (!this.IsVisible())
            {
                return;
            }

            htc.PushLocalPoint(this.ParentToLocal(htc.LocalPoint()));
            this.OnHitTest(htc);
            htc.PopLocalPoint();
        };

        I.OnHitTest = function(htc)
        {
        };

        I.CancelManipulation = function()
        {
            this.OnManipulationCancelled();
        };

        I.OnManipulationCancelled = function()
        {
            this.RaiseEvent(Fuse.Node._manipulationCancelledHandle, 10);

            if ($IsOp(this.Parent(), 978))
            {
                $AsOp(this.Parent(), 978).OnManipulationCancelled();
            }
        };

        I.RaiseEvent_1 = function(args)
        {
            var iea = $AsOp(args, 920);

            if (!this.IsEnabled() || (((iea != null) && iea.IsHandled()) && !this.RaiseHandledEvents()))
            {
                this.BubbleEvent(args);
                return;
            }

            var pma = $AsOp(args, 925);

            if (pma != null)
            {
                this.OnPointerMoved(pma);
                return;
            }

            var pda = $AsOp(args, 923);

            if (pda != null)
            {
                this.OnPointerPressed(pda);
                return;
            }

            var pua = $AsOp(args, 927);

            if (pua != null)
            {
                this.OnPointerReleased(pua);
                return;
            }

            var lsc = $AsOp(args, 940);

            if (lsc != null)
            {
                this.OnLostSoftCapture(lsc);
                return;
            }

            var pwc = $AsOp(args, 931);

            if (pwc != null)
            {
                this.OnPointerWheelChanged(pwc);
                return;
            }

            var pea = $AsOp(args, 929);

            if (pea != null)
            {
                this.OnPointerEnter(pea);
                return;
            }

            var pla = $AsOp(args, 933);

            if (pla != null)
            {
                this.OnPointerLeave(pla);
                return;
            }

            var tia = $AsOp(args, 935);

            if (tia != null)
            {
                this.OnTextInput(tia);
                return;
            }

            var gfa = $AsOp(args, 937);

            if (gfa != null)
            {
                this.OnGotFocus(gfa);
                return;
            }

            var lfa = $AsOp(args, 938);

            if (lfa != null)
            {
                this.OnLostFocus(lfa);
                return;
            }

            this.OnUnknownEvent(args);
        };

        I.BubbleEvent = function(args)
        {
            if (this.Parent() != null)
            {
                this.Parent()["Fuse.INode.RaiseEvent"](args);
            }
        };

        I.OnUnknownEvent = function(args)
        {
            this.BubbleEvent(args);
        };

        I.OnPointerPressed = function(args)
        {
            if (this.HasBit(14))
            {
                this.ForeachInList(Fuse.Node._pointerPressedHandle, $CreateDelegate(this, Fuse.Node.prototype.InvokePointerPressedHandler, 488), args);
            }

            this.BubbleEvent(args);
        };

        I.InvokePointerPressedHandler = function(handler, args)
        {
            $DownCast(handler, 924).Invoke(this, $DownCast(args, 923));
        };

        I.OnPointerMoved = function(args)
        {
            if (this.HasBit(15))
            {
                this.ForeachInList(Fuse.Node._pointerMovedHandle, $CreateDelegate(this, Fuse.Node.prototype.InvokePointerMovedHandler, 488), args);
            }

            this.BubbleEvent(args);
        };

        I.InvokePointerMovedHandler = function(handler, args)
        {
            $DownCast(handler, 926).Invoke(this, $DownCast(args, 925));
        };

        I.OnPointerReleased = function(args)
        {
            if (this.HasBit(16))
            {
                this.ForeachInList(Fuse.Node._pointerReleasedHandle, $CreateDelegate(this, Fuse.Node.prototype.InvokePointerReleasedHandler, 488), args);
            }

            this.BubbleEvent(args);
        };

        I.InvokePointerReleasedHandler = function(handler, args)
        {
            $DownCast(handler, 928).Invoke(this, $DownCast(args, 927));
        };

        I.OnPointerWheelChanged = function(args)
        {
            if (this.HasBit(17))
            {
                this.ForeachInList(Fuse.Node._pointerWheelChangedHandle, $CreateDelegate(this, Fuse.Node.prototype.InvokePointerWheelChangedHandler, 488), args);
            }

            this.BubbleEvent(args);
        };

        I.InvokePointerWheelChangedHandler = function(handler, args)
        {
            $DownCast(handler, 930).Invoke(this, $DownCast(args, 931));
        };

        I.OnPointerEnter = function(args)
        {
            if (this.HasBit(18))
            {
                this.ForeachInList(Fuse.Node._pointerEnterHandle, $CreateDelegate(this, Fuse.Node.prototype.InvokePointerEnterHandler, 488), args);
            }
        };

        I.InvokePointerEnterHandler = function(handler, args)
        {
            $DownCast(handler, 932).Invoke(this, $DownCast(args, 929));
        };

        I.OnPointerLeave = function(args)
        {
            if (this.HasBit(19))
            {
                this.ForeachInList(Fuse.Node._pointerLeaveHandle, $CreateDelegate(this, Fuse.Node.prototype.InvokePointerLeaveHandler, 488), args);
            }
        };

        I.InvokePointerLeaveHandler = function(handler, args)
        {
            $DownCast(handler, 934).Invoke(this, $DownCast(args, 933));
        };

        I.OnLostSoftCapture = function(args)
        {
            if (this.HasBit(11))
            {
                this.ForeachInList(Fuse.Node._lostSoftCaptureHandle, $CreateDelegate(this, Fuse.Node.prototype.InvokeLostSoftCaptureHandler, 488), args);
            }
        };

        I.InvokeLostSoftCaptureHandler = function(handler, args)
        {
            $DownCast(handler, 939).Invoke(this, $DownCast(args, 940));
        };

        I.OnTextInput = function(args)
        {
            if (this.IsFocused() && this.HasBit(20))
            {
                this.ForeachInList(Fuse.Node._textInputHandle, $CreateDelegate(this, Fuse.Node.prototype.InvokeTextInputHandler, 488), args);
            }

            this.BubbleEvent(args);
        };

        I.InvokeTextInputHandler = function(handler, args)
        {
            $DownCast(handler, 936).Invoke(this, $DownCast(args, 935));
        };

        I.OnGotFocus = function(args)
        {
            this.RaiseEvent(Fuse.Node._gotFocusHandle, 12);
            this.BubbleEvent(args);
        };

        I.OnLostFocus = function(args)
        {
            this.RaiseEvent(Fuse.Node._lostFocusHandle, 13);
            this.BubbleEvent(args);
        };

        I.AddToList = function(ph, v)
        {
            var obj;
            this.TryGetValue(ph, $CreateRef(function(){return obj}, function($){obj=$}, this));

            if (obj == null)
            {
                this.SetValue(ph, v);
            }
            else if ($IsOp(obj, 172))
            {
                $AsOp(obj, 172).Add(v);
            }
            else
            {
                var list = Uno.Collections.List__object.New_1();
                list.Add(obj);
                list.Add(v);
                this.SetValue(ph, list);
            }
        };

        I.RemoveFromList = function(ph, v)
        {
            var obj;
            this.TryGetValue(ph, $CreateRef(function(){return obj}, function($){obj=$}, this));

            if (obj == null)
            {
                throw new $Error(Uno.Exception.New_2());
            }

            if ($IsOp(obj, 172))
            {
                var list = $AsOp(obj, 172);
                list.Remove(v);

                if (list.Count() == 1)
                {
                    this.SetValue(ph, list.Item(0));
                }

                return true;
            }
            else
            {
                this.ClearValue(ph);
                return false;
            }
        };

        I.ForeachInList = function(ph, action, state)
        {
            var obj;
            this.TryGetValue(ph, $CreateRef(function(){return obj}, function($){obj=$}, this));
            var list = $AsOp(obj, 172);

            if (list != null)
            {
                for (var i = 0; i < list.Count(); i++)
                {
                    action.Invoke(list.Item(i), state);
                }
            }
            else if (obj != null)
            {
                action.Invoke(obj, state);
            }
        };

        I.ForeachInList_1 = function(ph, action, state)
        {
            var obj;
            this.TryGetValue(ph, $CreateRef(function(){return obj}, function($){obj=$}, this));
            var list = $AsOp(obj, 172);

            if (list != null)
            {
                for (var i = 0; i < list.Count(); i++)
                {
                    action.Invoke(list.Item(i), state);
                }
            }
            else if (obj != null)
            {
                action.Invoke(obj, state);
            }
        };

        I.Find = function(h)
        {
            var e = this._extrinsicList;

            while (e != null)
            {
                if (e.Handle == h)
                {
                    return e;
                }

                e = e.Next;
            }

            return null;
        };

        I.SetValue = function(prop, val)
        {
            var e = this.Find(prop.Handle);

            if (e != null)
            {
                e.Value = val;
            }
            else
            {
                this._extrinsicList = Fuse.ExtrinsicItem.New_1(prop.Handle, val, this._extrinsicList);
            }
        };

        I.GetValue = function(prop)
        {
            return this.Find(prop.Handle).Value;
        };

        I.TryGetValue = function(prop, val)
        {
            var e = this.Find(prop.Handle);

            if (e == null)
            {
                val(null);
                return false;
            }

            val(e.Value);
            return true;
        };

        I.ClearValue = function(prop)
        {
            if (this._extrinsicList == null)
            {
                return;
            }

            if (this._extrinsicList.Handle == prop.Handle)
            {
                this._extrinsicList = this._extrinsicList.Next;
            }
            else
            {
                var e = this._extrinsicList;

                while (e.Next != null)
                {
                    if (e.Next.Handle == prop.Handle)
                    {
                        e.Next = e.Next.Next;
                        return;
                    }

                    e = e.Next;
                }
            }
        };

        I.IsEqualToSelf = function(node)
        {
            return this == node;
        };

        I.PredictFocus = function(direction)
        {
            var node = null;

            if (direction == 1)
            {
                node = Fuse.Node.FindNextChild($DownCast(this, 33719), $CreateDelegate(null, Fuse.FocusManager.CanSetFocus, 504));
            }
            else if (direction == 0)
            {
                node = Fuse.Node.FindPreviousChild($DownCast(this, 33719), $CreateDelegate(null, Fuse.FocusManager.CanSetFocus, 504));
            }

            if (node == null)
            {
                var root = Fuse.Node.FindRoot($DownCast(this, 33719));

                if (root != null)
                {
                    return root["Fuse.INode.PredictFocus"](direction);
                }
            }

            return node;
        };

        I.Focus = function()
        {
            Fuse.FocusManager.FocusedObject($DownCast(this, 33719));
        };

        Fuse.Node.FindNextChild = function(node, filter)
        {
            var someNode = $AsOp(node, 978);

            if (someNode != null)
            {
                for (var i = 0; i < someNode.SubNodeCount(); i++)
                {
                    var child = someNode.GetSubNode(i);

                    if (filter.Invoke($DownCast(child, 33719)))
                    {
                        return $DownCast(child, 33719);
                    }

                    return Fuse.Node.FindNextChild($DownCast(child, 33719), filter);
                }
            }

            var sibling = Fuse.Node.FindNextSibling(node);

            if (sibling != null)
            {
                if (filter.Invoke(sibling))
                {
                    return sibling;
                }

                return Fuse.Node.FindNextChild(sibling, filter);
            }

            return null;
        };

        Fuse.Node.FindPreviousChild = function(node, filter)
        {
            var someNode = $AsOp(node, 978);

            if (someNode != null)
            {
                for (var i = someNode.SubNodeCount(); i >= 0; i--)
                {
                    var child = someNode.GetSubNode(i);

                    if (filter.Invoke($DownCast(child, 33719)))
                    {
                        return $DownCast(child, 33719);
                    }

                    return Fuse.Node.FindPreviousChild($DownCast(child, 33719), filter);
                }
            }

            var sibling = Fuse.Node.FindPreviousSibling(node);

            if (sibling != null)
            {
                if (filter.Invoke(sibling))
                {
                    return sibling;
                }

                return Fuse.Node.FindPreviousChild(sibling, filter);
            }

            return null;
        };

        Fuse.Node.FindNextSibling = function(node)
        {
            if (node == null)
            {
                return null;
            }

            var parent = node["Fuse.INode.Parent"]();

            if (parent == null)
            {
                return null;
            }

            var child = Fuse.Node.FindNextChild_1($AsOp(parent, 978), node);

            if (child != null)
            {
                return child;
            }

            return Fuse.Node.FindNextSibling(parent);
        };

        Fuse.Node.FindPreviousSibling = function(node)
        {
            if (node == null)
            {
                return null;
            }

            var parent = node["Fuse.INode.Parent"]();

            if (parent == null)
            {
                return null;
            }

            var child = Fuse.Node.FindPreviousChild_1($AsOp(parent, 978), node);

            if (child != null)
            {
                return child;
            }

            return Fuse.Node.FindPreviousSibling(parent);
        };

        Fuse.Node.FindNextChild_1 = function(node, currentChild)
        {
            if (((node != null) && (currentChild != null)) && (node.SubNodeCount() > 0))
            {
                for (var i = 0; i < node.SubNodeCount(); i++)
                {
                    if (node.GetSubNode(i) == currentChild)
                    {
                        if ((i + 1) < node.SubNodeCount())
                        {
                            return $DownCast(node.GetSubNode(i + 1), 33719);
                        }
                    }
                }
            }

            return null;
        };

        Fuse.Node.FindPreviousChild_1 = function(node, currentChild)
        {
            if (((node != null) && (currentChild != null)) && (node.SubNodeCount() > 0))
            {
                for (var i = 0; i < node.SubNodeCount(); i++)
                {
                    if (node.GetSubNode(i) == currentChild)
                    {
                        if ((i - 1) >= 0)
                        {
                            return $DownCast(node.GetSubNode(i - 1), 33719);
                        }
                    }
                }
            }

            return null;
        };

        Fuse.Node.FindRoot = function(n)
        {
            var o = null;

            for (; n != null; n = n["Fuse.INode.Parent"]())
            {
                o = n;
            }

            return o;
        };

        Fuse.Node.FindParent = function(n, criteria)
        {
            var o = null;

            for (; (n != null) && !criteria.Invoke(n); n = n["Fuse.INode.Parent"]())
            {
                o = n;
            }

            return o;
        };

        I.GetResource = function(key)
        {
            if (this.HasBit(1))
            {
                var res = this.Resources().Item(key);

                if (res != null)
                {
                    return res;
                }
            }

            if (this.Style() != null)
            {
                return this.Style().GetResource(key);
            }

            if (this.Parent() != null)
            {
                return this.Parent()["Fuse.INode.GetResource"](key);
            }

            return null;
        };

        I.ApplyStyle = function()
        {
            this.ApplyStyle_1(this);
        };

        I.ResetStyle = function()
        {
            if (this.HasBit(0))
            {
                this.OnResetStyle();
                this.ApplyStyle();
            }

            for (var i = 0; i < this.SubNodeCount(); i++)
            {
                this.GetSubNode(i).ResetStyle();
            }
        };

        I.OnResetStyle = function()
        {
            if (this._behaviors != null)
            {
                for (var i = 0; i < this._behaviors.Count(); i++)
                {
                    if (this._behaviors.Item(i).AddedByStyle)
                    {
                        this._behaviors.RemoveAt(i--);
                    }
                }
            }

            if (this._transforms != null)
            {
                for (var i = 0; i < this._transforms.Count(); i++)
                {
                    if (this._transforms.Item(i).AddedByStyle)
                    {
                        this._transforms.RemoveAt(i--);
                    }
                }
            }
        };

        I.ApplyStyle_1 = function(target)
        {
            this.OnApplyStyle(target);
        };

        I.OnApplyStyle = function(target)
        {
            if (this.Style() != null)
            {
                if (!this.Style().Apply(target))
                {
                    return;
                }
            }

            if (this.Parent() != null)
            {
                this.Parent()["Fuse.INode.ApplyStyle"](target);
            }
        };

        I.PrependImplicitTransform = function(m)
        {
        };

        I.PrependTransformOrigin = function(m)
        {
        };

        I.PrependInverseTransformOrigin = function(m)
        {
        };

        I.OnTransformAdded = function(t)
        {
            t.Added(this);
            t.add_MatrixChanged($CreateDelegate(this, Fuse.Node.prototype.OnMatrixChanged, 477));
            this.OnMatrixChanged(t);
        };

        I.OnTransformRemoved = function(t)
        {
            t.Removed(this);
            t.remove_MatrixChanged($CreateDelegate(this, Fuse.Node.prototype.OnMatrixChanged, 477));
            this.OnMatrixChanged(t);
            t.AddedByStyle = false;
        };

        I.OnMatrixChanged = function(t)
        {
            this.InvalidateLocalTransform();
        };

        I.InvalidateLocalTransform = function()
        {
            this._localTransform = null;
            this._localTransformInverse = null;
            this.InvalidateTransform();
        };

        I.InvalidateTransform = function()
        {
            this._absoluteTransform = null;
            this._absoluteTransformInverse = null;
        };

        I.IsAbsoluteMatrixValid = function()
        {
            var parentNode = $AsOp(this.Parent(), 978);

            if ((parentNode != null) && ((parentNode._absoluteTransformTimestamp > this._absoluteTransformTimestamp) || !parentNode.IsAbsoluteMatrixValid()))
            {
                return false;
            }

            return this._absoluteTransform != null;
        };

        I.GetDrawMatrix = function(dc)
        {
            var m = this.AbsoluteTransformInternal();

            if (!dc.IsRootTransformIdentity())
            {
                m = m.Mul(dc.RootTransform());
            }

            return m.Matrix();
        };

        I.CalcAbsoluteTransform = function()
        {
            var m = this.LocalTransformInternal();
            var pn = $AsOp(this.Parent(), 978);

            if (pn != null)
            {
                m = m.Mul(pn.AbsoluteTransformInternal());
            }

            return m;
        };

        I.PrependLocalTransform = function(m)
        {
            this.PrependImplicitTransform(m);
            this.PrependExplicitTransforms(m);
        };

        I.PrependExplicitTransforms = function(m)
        {
            if (this.HasExplicitTransforms())
            {
                this.PrependTransformOrigin(m);

                for (var i = 0; i < this._transforms.Count(); i++)
                {
                    this._transforms.Item(i).PrependTo(m);
                }

                this.PrependInverseTransformOrigin(m);
            }
        };

        I.OnAdded = function(parent)
        {
            if (this._parent != null)
            {
                throw new $Error(Uno.Exception.New_1(Uno.String.op_Addition(Uno.String.op_Addition(this.ToString(), " already has a parent"), (parent != this._parent) ? Uno.String.op_Addition(Uno.String.op_Addition(" (", parent.ToString()), ")") : "")));
            }

            this.RaiseEvent(Fuse.Node._addedHandle, 6);
            this._parent = parent;

            if (parent["Fuse.INode.IsRooted"]())
            {
                this.MarkRooted();
            }
        };

        I.OnRemoved = function(parent)
        {
            if (this._parent == parent)
            {
                this.RaiseEvent(Fuse.Node._removedHandle, 7);
                this._parent = null;

                if (parent["Fuse.INode.IsRooted"]())
                {
                    this.MarkUnrooted();
                }
            }
            else
            {
                throw new $Error(Uno.Exception.New_2());
            }
        };

        I["Fuse.INode.OnAdded"] = function(parent)
        {
            this.OnAdded(parent);
        };

        I["Fuse.INode.OnRemoved"] = function(parent)
        {
            this.OnRemoved(parent);
        };

        I.DoUpdate = function()
        {
            if (this._updateListeners != null)
            {
                var u = this._updateListeners.ToArray();

                for (var i = 0; i < u.length; i++)
                {
                    u[i].Invoke(this, Uno.EventArgs.Empty);
                }
            }
        };

        I.MarkRooted = function()
        {
            if (this._localIsRooted)
            {
                return;
            }

            this._localIsRooted = true;
            this.RootBehaviors();
            this.EnsureInitialized();
            this.RaiseEvent(Fuse.Node._rootedHandle, 8);

            if (this._updateListeners != null)
            {
                Fuse.UpdateManager.AddAction($CreateDelegate(this, Fuse.Node.prototype.DoUpdate, 436), 0);
            }

            for (var i = 0; i < this.SubNodeCount(); i++)
            {
                this.GetSubNode(i).MarkRooted();
            }

            this.OnRooted();
        };

        I.OnRooted = function()
        {
        };

        I.MarkUnrooted = function()
        {
            if (!this._localIsRooted)
            {
                return;
            }

            this._localIsRooted = false;
            this.RaiseEvent(Fuse.Node._unrootedHandle, 9);

            if (this._updateListeners != null)
            {
                Fuse.UpdateManager.RemoveAction($CreateDelegate(this, Fuse.Node.prototype.DoUpdate, 436), 0);
            }

            this.UnrootBehaviors();
            this.SoftDispose();

            for (var i = 0; i < this.SubNodeCount(); i++)
            {
                this.GetSubNode(i).MarkUnrooted();
            }

            this.OnUnrooted();
        };

        I.OnUnrooted = function()
        {
        };

        I.SoftDispose = function()
        {
        };

        I.EnsureInitialized = function()
        {
            if (!this.HasBit(0))
            {
                this.OnInitialize();
                this.ApplyStyle();
                this.SetBit(0);
            }
            else
            {
                this.ResetStyle();
            }
        };

        I.OnInitialize = function()
        {
        };

        I.GetSubNode = function(index)
        {
            throw new $Error(Uno.Exception.New_2());
        };

        Fuse.Node._TypeInit = function()
        {
            Fuse.Node._isEnabledChangedHandle = Fuse.PropertyHandle.New_1();
            Fuse.Node._manipulationCancelledHandle = Fuse.PropertyHandle.New_1();
            Fuse.Node._gotFocusHandle = Fuse.PropertyHandle.New_1();
            Fuse.Node._lostFocusHandle = Fuse.PropertyHandle.New_1();
            Fuse.Node._lostSoftCaptureHandle = Fuse.PropertyHandle.New_1();
            Fuse.Node._pointerPressedHandle = Fuse.PropertyHandle.New_1();
            Fuse.Node._pointerReleasedHandle = Fuse.PropertyHandle.New_1();
            Fuse.Node._pointerWheelChangedHandle = Fuse.PropertyHandle.New_1();
            Fuse.Node._pointerMovedHandle = Fuse.PropertyHandle.New_1();
            Fuse.Node._pointerEnterHandle = Fuse.PropertyHandle.New_1();
            Fuse.Node._pointerLeaveHandle = Fuse.PropertyHandle.New_1();
            Fuse.Node._textInputHandle = Fuse.PropertyHandle.New_1();
            Fuse.Node._handleHandle = Fuse.PropertyHandle.New_1();
            Fuse.Node._resourcesHandle = Fuse.PropertyHandle.New_1();
            Fuse.Node._styleHandle = Fuse.PropertyHandle.New_1();
            Fuse.Node._addedHandle = Fuse.PropertyHandle.New_1();
            Fuse.Node._removedHandle = Fuse.PropertyHandle.New_1();
            Fuse.Node._rootedHandle = Fuse.PropertyHandle.New_1();
            Fuse.Node._unrootedHandle = Fuse.PropertyHandle.New_1();
        };

        I._ObjInit = function()
        {
        };

        I.add_Update = function(value)
        {
            if (this._updateListeners == null)
            {
                this._updateListeners = Uno.Collections.List__Uno_EventHandler.New_1();

                if (this.IsRooted())
                {
                    Fuse.UpdateManager.AddAction($CreateDelegate(this, Fuse.Node.prototype.DoUpdate, 436), 0);
                }
            }

            this._updateListeners.Add(value);
        };

        I.remove_Update = function(value)
        {
            this._updateListeners.Remove(value);

            if (this._updateListeners.Count() == 0)
            {
                this._updateListeners = null;

                if (this.IsRooted())
                {
                    Fuse.UpdateManager.RemoveAction($CreateDelegate(this, Fuse.Node.prototype.DoUpdate, 436), 0);
                }
            }
        };

        I.add_IsEnabledChanged = function(value)
        {
            this.AddEventHandler(Fuse.Node._isEnabledChangedHandle, 5, value);
        };

        I.remove_IsEnabledChanged = function(value)
        {
            this.RemoveEventHandler(Fuse.Node._isEnabledChangedHandle, 5, value);
        };

        I.add_GotFocus = function(value)
        {
            this.AddEventHandler(Fuse.Node._gotFocusHandle, 12, value);
        };

        I.remove_GotFocus = function(value)
        {
            this.RemoveEventHandler(Fuse.Node._gotFocusHandle, 12, value);
        };

        I.add_LostFocus = function(value)
        {
            this.AddEventHandler(Fuse.Node._lostFocusHandle, 13, value);
        };

        I.remove_LostFocus = function(value)
        {
            this.RemoveEventHandler(Fuse.Node._lostFocusHandle, 13, value);
        };

        I.add_PointerEnter = function(value)
        {
            this.AddEventHandler(Fuse.Node._pointerEnterHandle, 18, value);
        };

        I.remove_PointerEnter = function(value)
        {
            this.RemoveEventHandler(Fuse.Node._pointerEnterHandle, 18, value);
        };

        I.add_PointerLeave = function(value)
        {
            this.AddEventHandler(Fuse.Node._pointerLeaveHandle, 19, value);
        };

        I.remove_PointerLeave = function(value)
        {
            this.RemoveEventHandler(Fuse.Node._pointerLeaveHandle, 19, value);
        };

        I.add_PointerPressed = function(value)
        {
            this.AddEventHandler(Fuse.Node._pointerPressedHandle, 14, value);
        };

        I.remove_PointerPressed = function(value)
        {
            this.RemoveEventHandler(Fuse.Node._pointerPressedHandle, 14, value);
        };

        I.add_PointerReleased = function(value)
        {
            this.AddEventHandler(Fuse.Node._pointerReleasedHandle, 16, value);
        };

        I.remove_PointerReleased = function(value)
        {
            this.RemoveEventHandler(Fuse.Node._pointerReleasedHandle, 16, value);
        };

        I.add_LostSoftCapture = function(value)
        {
            this.AddEventHandler(Fuse.Node._lostSoftCaptureHandle, 11, value);
        };

        I.remove_LostSoftCapture = function(value)
        {
            this.RemoveEventHandler(Fuse.Node._lostSoftCaptureHandle, 11, value);
        };

        I.add_PointerMoved = function(value)
        {
            this.AddEventHandler(Fuse.Node._pointerMovedHandle, 15, value);
        };

        I.remove_PointerMoved = function(value)
        {
            this.RemoveEventHandler(Fuse.Node._pointerMovedHandle, 15, value);
        };

        I.add_ManipulationCancelled = function(value)
        {
            this.AddEventHandler(Fuse.Node._manipulationCancelledHandle, 10, value);
        };

        I.remove_ManipulationCancelled = function(value)
        {
            this.RemoveEventHandler(Fuse.Node._manipulationCancelledHandle, 10, value);
        };

        I["Fuse.INode.GetResource"] = I.GetResource;
        I["Fuse.INode.ResetStyle"] = I.ResetStyle;
        I["Fuse.INode.ApplyStyle"] = I.ApplyStyle_1;
        I["Fuse.INode.PredictFocus"] = I.PredictFocus;
        I["Fuse.INode.Draw"] = function() { this.Draw.apply(this, arguments); };
        I["Fuse.INode.HitTest"] = I.HitTest;
        I["Fuse.INode.RaiseEvent"] = I.RaiseEvent_1;
        I["Fuse.INode.Parent"] = I.Parent;
        I["Fuse.INode.IsRooted"] = I.IsRooted;
        I["Fuse.INode.IsEnabled"] = I.IsEnabled;
        I["Fuse.INode.IsFocusable"] = function() { return this.IsFocusable.apply(this, arguments); };
        I["Fuse.INode.DrawNextFrame"] = function() { return this.DrawNextFrame.apply(this, arguments); };

    });
