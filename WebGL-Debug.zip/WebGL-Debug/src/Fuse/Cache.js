Fuse.Cache = $CreateClass(
    function() {
        this._isValid = false;
        this._element = null;
        this._cacheRect = new Uno.Recti;
        this._cacheTiles = null;
    },
    function(S) {
        var I = S.prototype;

        Fuse.Cache.IsCaching = false;
        Fuse.Cache.cacheHelper = null;

        I.GetType = function()
        {
            return 988;
        };

        I.CacheTiles = function()
        {
            return this._cacheTiles;
        };

        I.MaxTileSize = function()
        {
            return Uno.Graphics.Texture2D.MaxSize();
        };

        I.GetCachePreference = function(dc)
        {
            var cachingRect_126 = new Uno.Recti;

            switch (this._element.CachingMode())
            {
                case 2:
                {
                    return false;
                }
                case 1:
                {
                    return true;
                }
            }

            if (this._isValid && !this._element.IsVisualInvalid())
            {
                return true;
            }

            if (this._element.HasActiveEffects() && !this._element.IsVisualInvalid())
            {
                return true;
            }

            cachingRect_126.op_Assign(this.GetCachingRect(dc));

            if ((cachingRect_126.Size().X > (dc.RenderTarget().Size().X * 1.2)) || (cachingRect_126.Size().Y > (dc.RenderTarget().Size().Y * 1.2)))
            {
                return false;
            }

            if (this._element.Parent() == null)
            {
            }
            else if (this._element.ParentElement() == null)
            {
                return this.GetCachePreferenceCore(dc);
            }
            else
            {
                if (!this._element.IsRedrawCheap())
                {
                    return this.GetCachePreferenceCore(dc);
                }
            }

            return false;
        };

        I.GetCachePreferenceCore = function(dc)
        {
            if (!this._element.IsVisualInvalid())
            {
                if (!Fuse.Cache.IsCaching)
                {
                    return true;
                }
            }

            return false;
        };

        I.Invalidate = function()
        {
            this._isValid = false;
        };

        I.DrawHeuristically = function(dc)
        {
            if (this.GetCachePreference(dc))
            {
                this.PinAndValidate(dc);
                this.Blit(dc, this._element.Opacity());
                this.Unpin();
            }
            else
            {
                this._element.CompositEffects(dc);
            }
        };

        Fuse.Cache.ConservativelySnapToCoveringIntegers = function(r)
        {
            var r_127 = new Uno.Rect;
            r_127.op_Assign(r);
            var origin = Uno.Int2.op_Explicit(Uno.Math.Floor_2(r_127.LeftTop()));
            var size = Uno.Int2.op_Explicit(Uno.Math.Ceil_2(Uno.Float2.op_Addition_1(Uno.Float2.op_Subtraction(r_127.RightBottom(), r_127.LeftTop()), 0.01)));
            return Uno.Recti.New_1(origin.X, origin.Y, (origin.X + size.X) + 1, (origin.Y + size.Y) + 1);
        };

        I.GetCachingRect = function(dc)
        {
            return Uno.Recti.Inflate_1(Fuse.Cache.ConservativelySnapToCoveringIntegers(Uno.Rect.Scale_1(this._element.RenderBoundsWithEffects(), this._element.AbsoluteZoom())), 1);
        };

        I.CalculateCompositMatrix = function(dc, cachingRect)
        {
            var cachingRect_128 = new Uno.Recti;
            cachingRect_128.op_Assign(cachingRect);
            var translation = Uno.Matrix.Translation_1(cachingRect_128.Left / this._element.AbsoluteZoom(), cachingRect_128.Top / this._element.AbsoluteZoom(), 0.0);
            return Uno.Matrix.Mul_11(translation, this._element.GetDrawMatrix(dc));
        };

        I.PinAndValidate = function(dc)
        {
            var cacheRect_129 = new Uno.Recti;
            cacheRect_129.op_Assign(this.GetCachingRect(dc));

            if (!Uno.Recti.Equals_2(cacheRect_129, this._cacheRect))
            {
                var numTilesX = (((cacheRect_129.Size().X + this.MaxTileSize()) - 1) / this.MaxTileSize()) | 0;
                var numTilesY = (((cacheRect_129.Size().Y + this.MaxTileSize()) - 1) / this.MaxTileSize()) | 0;
                var numTiles = numTilesX * numTilesY;

                if ((this._cacheTiles == null) || (numTiles != this._cacheTiles.length))
                {
                    this._cacheTiles = Array.Structs(numTiles, Fuse.CacheTile, 989);
                }

                for (var y = 0; y < numTilesY; ++y)
                {
                    for (var x = 0; x < numTilesX; ++x)
                    {
                        var tile = x + (y * numTilesX);
                        var Position = Uno.Int2.New_2(x * this.MaxTileSize(), y * this.MaxTileSize());
                        this._cacheTiles[tile]._rect = Uno.Recti.New_1(cacheRect_129.Left + Position.X, cacheRect_129.Top + Position.Y, (cacheRect_129.Left + Position.X) + Uno.Math.Min_8(cacheRect_129.Size().X - Position.X, this.MaxTileSize()), (cacheRect_129.Top + Position.Y) + Uno.Math.Min_8(cacheRect_129.Size().Y - Position.Y, this.MaxTileSize()));
                    }
                }
            }

            for (var i = 0; i < this._cacheTiles.length; ++i)
            {
                this._cacheTiles[i].EnsureHasFramebuffer();
                this._cacheTiles[i]._compositMatrix.op_Assign(this.CalculateCompositMatrix(dc, this._cacheTiles[i]._rect));
                this._cacheTiles[i]._framebuffer.Pin();

                if (!this._cacheTiles[i]._framebuffer.IsContentValid() || !this._isValid)
                {
                    this.Repaint(dc, this._cacheTiles[i]);
                }
            }

            this._isValid = true;
        };

        I.Unpin = function()
        {
            var tile_130 = new Fuse.CacheTile;
            var array_123;
            var index_124;
            var length_125;

            for (array_123 = this._cacheTiles, index_124 = 0, length_125 = array_123.length; index_124 < length_125; ++index_124)
            {
                tile_130.op_Assign(array_123[index_124]);
                tile_130._framebuffer.Unpin(true);
            }
        };

        I.Repaint = function(dc, tile)
        {
            var tile_131 = new Fuse.CacheTile;
            tile_131.op_Assign(tile);
            var newRootMatrix = Uno.Matrix.Mul_11(dc.RootTransform().Matrix(), Uno.Matrix.Invert(tile_131._compositMatrix));
            var oldIsCaching = Fuse.Cache.IsCaching;
            Fuse.Cache.IsCaching = true;
            dc.PushRenderTarget(tile_131._framebuffer.Framebuffer(), true);
            dc.Clear(Uno.Float4.New_1(0.0), 1.0);
            dc.PushRootTransform(Fuse.FastMatrix.FromFloat4x4(newRootMatrix));
            this._element.CompositEffects(dc);
            dc.PopRootTransform();
            dc.PopRenderTarget();
            Fuse.Cache.IsCaching = oldIsCaching;
        };

        I.Blit = function(dc, opacity)
        {
            Fuse.Cache.cacheHelper.Blit(dc, this, opacity);
        };

        Fuse.Cache._TypeInit = function()
        {
            Fuse.Cache.cacheHelper = Fuse.CacheHelper.New_1();
        };

        I._ObjInit = function(elm)
        {
            this._element = elm;
        };

        Fuse.Cache.New_1 = function(elm)
        {
            var inst = new Fuse.Cache;
            inst._ObjInit(elm);
            return inst;
        };

    });
