Fuse.Font = $CreateClass(
    function() {
        this._fontFace = null;
        this._textRenderer = null;
    },
    function(S) {
        var I = S.prototype;

        Fuse.Font._Default = null;

        I.GetType = function()
        {
            return 1010;
        };

        Fuse.Font.Default = function(value)
        {
            if (value !== undefined)
            {
                Fuse.Font._Default = value;
            }
            else
            {
                return Fuse.Font._Default;
            }
        };

        I.IsDefault = function(value)
        {
            if (value !== undefined)
            {
                if (Fuse.Font.Default() != null)
                {
                    Uno.Diagnostics.Debug.Log("Multiple default fonts provided", 1, "/Users/vegard/RealtimeStudio/Uno/Packages/Fuse.Elements/0.1.0/Font.uno", 23);
                }

                Fuse.Font.Default(this);
            }
            else
            {
                return Fuse.Font.Default() == this;
            }
        };

        I.FontFace = function(value)
        {
            if (value !== undefined)
            {
                if (value == null)
                {
                    return;
                }

                if (this._fontFace != value)
                {
                    this._fontFace = value;
                    this._textRenderer = Fuse.Internal.DefaultTextRenderer.New_2(this.FontFace());
                }
            }
            else
            {
                return this._fontFace;
            }
        };

        I.GetTextRenderer = function()
        {
            if (this.FontFace() == null)
            {
                if ((Fuse.Font.Default() != null) && (Fuse.Font.Default() != this))
                {
                    return Fuse.Font.Default().GetTextRenderer();
                }
                else
                {
                    throw new $Error(Uno.Exception.New_1("Font has no faces"));
                }
            }

            if (this._textRenderer == null)
            {
                this._textRenderer = Fuse.Internal.DefaultTextRenderer.New_2(this.FontFace());
            }

            return $DownCast(this._textRenderer, 33580);
        };

        I._ObjInit_1 = function()
        {
        };

        Fuse.Font.New_2 = function()
        {
            var inst = new Fuse.Font;
            inst._ObjInit_1();
            return inst;
        };

    });
