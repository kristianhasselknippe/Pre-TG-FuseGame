Fuse.TraverseContext = $CreateClass(
    function() {
        Fuse.ViewProvider.call(this);
        this._cameras = null;
        this._camera = null;
    },
    function(S) {
        var I = S.prototype = new Fuse.ViewProvider;

        I.GetType = function()
        {
            return 967;
        };

        I.Camera = function()
        {
            return this._camera;
        };

        I.Flush = function()
        {
        };

        I.PushCamera = function(c)
        {
            this.Flush();
            this._cameras.Add(this._camera);
            this._camera = c;
        };

        I.PopCamera = function()
        {
            this.Flush();
            var res = this._camera;
            this._camera = Uno.Collections.IListExtensions.RemoveLast__Fuse_ICamera($DownCast(this._cameras, 32928));
            return res;
        };

        I._ObjInit_1 = function(defaultCamera)
        {
            this._cameras = Uno.Collections.List__Fuse_ICamera.New_1();
            Fuse.ViewProvider.prototype._ObjInit.call(this);
            this._camera = defaultCamera;
        };

    });
