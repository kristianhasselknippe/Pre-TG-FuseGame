Fuse.ResizedArgs = $CreateClass(
    function() {
        Uno.EventArgs.call(this);
        this._HasOldSize = false;
        this._OldSize = new Uno.Float2;
        this._NewSize = new Uno.Float2;
    },
    function(S) {
        var I = S.prototype = new Uno.EventArgs;

        I.GetType = function()
        {
            return 995;
        };

        I.HasOldSize = function(value)
        {
            if (value !== undefined)
            {
                this._HasOldSize = value;
            }
            else
            {
                return this._HasOldSize;
            }
        };

        I.OldSize = function(value)
        {
            if (value !== undefined)
            {
                this._OldSize.op_Assign(value);
            }
            else
            {
                return this._OldSize;
            }
        };

        I.NewSize = function(value)
        {
            if (value !== undefined)
            {
                this._NewSize.op_Assign(value);
            }
            else
            {
                return this._NewSize;
            }
        };

        I._ObjInit_1 = function(hasOldSize, newSize, oldSize)
        {
            Uno.EventArgs.prototype._ObjInit.call(this);
            this.HasOldSize(hasOldSize);
            this.OldSize(oldSize);
            this.NewSize(newSize);
        };

        Fuse.ResizedArgs.New_2 = function(hasOldSize, newSize, oldSize)
        {
            var inst = new Fuse.ResizedArgs;
            inst._ObjInit_1(hasOldSize, newSize, oldSize);
            return inst;
        };

    });
