Fuse.PointerReleasedArgs = $CreateClass(
    function() {
        Fuse.PointerEventArgs.call(this);
    },
    function(S) {
        var I = S.prototype = new Fuse.PointerEventArgs;

        I.GetType = function()
        {
            return 927;
        };

        I._ObjInit_3 = function(data)
        {
            Fuse.PointerEventArgs.prototype._ObjInit_2.call(this, data);
        };

        Fuse.PointerReleasedArgs.New_2 = function(data)
        {
            var inst = new Fuse.PointerReleasedArgs;
            inst._ObjInit_3(data);
            return inst;
        };

    });
