Fuse.FakeTime = $CreateClass(
    function() {
        this.FrameTime = 0;
        this.FrameInterval = 0;
    },
    function(S) {
        var I = S.prototype;

        I.GetType = function()
        {
            return 962;
        };

    });
