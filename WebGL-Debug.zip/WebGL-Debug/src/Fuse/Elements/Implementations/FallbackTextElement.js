Fuse.Elements.Implementations.FallbackTextElement = $CreateClass(
    function() {
        Fuse.Elements.TextElement.call(this);
        this._textWindow = null;
        this._lineCache = null;
        this._wrapInfo = null;
        this._wrapInfoWidth = 0;
        this._wrapInfoHaveWidth = false;
    },
    function(S) {
        var I = S.prototype = new Fuse.Elements.TextElement;

        I.GetType = function()
        {
            return 835;
        };

        I.GetFontOrThrow = function()
        {
            if (this.Font() == null)
            {
                throw new $Error(Uno.Exception.New_1("Font property was not set. Did you provide a custom style with no font?"));
            }

            return this.Font();
        };

        I.OnTextChanged = function()
        {
            this._lineCache.Text(this.Text());
            this.InvalidateLayout();
            this.InvalidateVisual_1();
            Fuse.Elements.TextElement.prototype.OnTextChanged.call(this);
        };

        I.OnIsMultilineChanged = function()
        {
            this._lineCache.IsMultiline(this.IsMultiline());
            this.InvalidateLayout();
            this.InvalidateVisual_1();
            Fuse.Elements.TextElement.prototype.OnIsMultilineChanged.call(this);
        };

        I.OnTextWrappingChanged = function()
        {
            this.InvalidateLayout();
            this.InvalidateVisual_1();
        };

        I.OnTextAlignmentChanged = function()
        {
            Fuse.Element.prototype.OnTextAlignmentChanged.call(this);
            this.InvalidateVisual_1();
        };

        I.OnFontSizeChanged = function()
        {
            Fuse.Element.prototype.OnFontSizeChanged.call(this);
            this.InvalidateLayout();
            this.InvalidateVisual_1();
        };

        I.OnFontChanged = function()
        {
            Fuse.Element.prototype.OnFontChanged.call(this);
            this.InvalidateLayout();
            this.InvalidateVisual_1();
        };

        I.OnTextColorChanged = function()
        {
            Fuse.Element.prototype.OnTextColorChanged.call(this);
            this.InvalidateVisual_1();
        };

        I.GetContentSize = function(fillSize, fillSet)
        {
            var fillSize_123 = new Uno.Float2;
            fillSize_123.op_Assign(fillSize);

            if (this.Font() == null)
            {
                return Uno.Float2.New_1(0.0);
            }

            var wrapWidth = Uno.Math.Max_1(fillSize_123.X, 0.0);
            this.CreateWrapInfo(wrapWidth, (fillSet & 1) == 1);
            var r = Uno.Float2.op_Addition_1(Uno.Math.Ceil_2(this.GetTextBoundsSize(this._wrapInfo)), 1.0);

            if ((fillSet & 1) == 1)
            {
                r.X = Uno.Math.Min_1(r.X, fillSize_123.X);
            }

            return r;
        };

        I.ArrangePaddingBox = function(size)
        {
            var ind_126;
            var ind_127;
            var ind_128;
            this._textWindow.ArrangeMarginBox((ind_126 = this.Padding(), Uno.Float2.New_2(ind_126.X, ind_126.Y)), Uno.Float2.op_Subtraction(Uno.Float2.op_Subtraction(size, (ind_127 = this.Padding(), Uno.Float2.New_2(ind_127.X, ind_127.Y))), (ind_128 = this.Padding(), Uno.Float2.New_2(ind_128.Z, ind_128.W))), 3);
        };

        I.InvalidateVisual_1 = function()
        {
            this._textWindow.InvalidateVisual();
            Fuse.Element.prototype.InvalidateVisual.call(this);
        };

        I.OnDraw = function(dc)
        {
            var textBoundsSize_125 = new Uno.Float2;
            this.GetFontOrThrow();
            var width = (this.ActualSize().X - this.Padding().X) - this.Padding().Z;
            this.CreateWrapInfo(width, true);
            textBoundsSize_125.op_Assign(this.GetClampedTextBoundsSize(this._wrapInfo));

            if (!Uno.String.IsNullOrEmpty(this.Text()))
            {
                this._textWindow.Draw_1(this._wrapInfo, null, this.TextColor(), Uno.Float4.New_1(0.0), this.Text().length, this.TextAlignment(), textBoundsSize_125, Uno.Float2.New_1(0.0), dc);
            }
        };

        I.CreateWrapInfo = function(wrapWidth, haveWidth)
        {
            if (((this._wrapInfo != null) && (this._wrapInfoWidth == wrapWidth)) && (this._wrapInfoHaveWidth == haveWidth))
            {
                return;
            }

            this._wrapInfoWidth = wrapWidth;
            this._wrapInfoHaveWidth = haveWidth;
            var renderer = this.GetFontOrThrow().GetTextRenderer();
            var fontSize = this.FontSize();
            this._wrapInfo = Fuse.Internal.WordWrapInfo.New_1(renderer, this.TextWrapping() == 1, haveWidth ? wrapWidth : (1./0.), fontSize, renderer["Fuse.Internal.ITextRenderer.GetLineHeight"](fontSize), this.AbsoluteZoom());
        };

        I.GetTextBoundsSize = function(wrapInfo)
        {
            return this._lineCache.GetBoundsSize(wrapInfo);
        };

        I.GetClampedTextBoundsSize = function(wrapInfo)
        {
            return Uno.Math.Max_3(this.GetTextBoundsSize(wrapInfo), this.GetWindowSize());
        };

        I.GetWindowSize = function()
        {
            return Uno.Float2.New_2(Uno.Math.Max_1(this.ActualSize().X - (this.Padding().X + this.Padding().Z), 0.0), Uno.Math.Max_1(this.ActualSize().Y - (this.Padding().Y + this.Padding().W), 0.0));
        };

        I._ObjInit_3 = function()
        {
            Fuse.Elements.TextElement.prototype._ObjInit_2.call(this);
            this._lineCache = Fuse.Internal.LineCache.New_1($CreateDelegate(this, Fuse.Elements.Implementations.FallbackTextElement.prototype.OnTextChanged, 436), $CreateDelegate(this, Fuse.Element.prototype.InvalidateLayout, 436));
            this._textWindow = Fuse.Internal.TextWindow.New_1(this, this._lineCache);
        };

    });
