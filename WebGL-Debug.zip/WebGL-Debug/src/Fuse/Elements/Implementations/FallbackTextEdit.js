Fuse.Elements.Implementations.FallbackTextEdit = $CreateClass(
    function() {
        Fuse.Elements.TextEdit.call(this);
        this._visualTextTransform = 0;
        this._passwordTransform = null;
        this.RevealTime = 0;
        this._revealEnd = 0;
        this._wrapInfo = null;
        this._lineCache = null;
        this._textWindow = null;
        this._windowPos = new Uno.Float2;
        this._caretPosition = null;
        this._interactionSelectionStartPos = null;
        this._selection = null;
        this._caretBlinkTime = 0;
        this._focusable_1 = false;
    },
    function(S) {
        var I = S.prototype = new Fuse.Elements.TextEdit;

        I.GetType = function()
        {
            return 837;
        };

        I.VisualTextTransform = function(value)
        {
            if (value !== undefined)
            {
                if (value != this._visualTextTransform)
                {
                    this._visualTextTransform = value;

                    if (this._passwordTransform != null)
                    {
                        this._passwordTransform = null;
                        this.remove_Update($CreateDelegate(this, Fuse.Elements.Implementations.FallbackTextEdit.prototype.TransformUpdate, 445));
                    }

                    if (value == 1)
                    {
                        this._passwordTransform = Fuse.Internal.LineCachePasswordTransform.New_1();
                        this._lineCache.Transform($DownCast(this._passwordTransform, 33583));
                        this.add_Update($CreateDelegate(this, Fuse.Elements.Implementations.FallbackTextEdit.prototype.TransformUpdate, 445));
                    }

                    this.InvalidateVisual();
                }
            }
            else
            {
                return this._visualTextTransform;
            }
        };

        I.IsWordWrapEnabled = function()
        {
            return this.TextWrapping() == 1;
        };

        I.SubElementCount = function()
        {
            return 1;
        };

        I.IsFocusable = function(value)
        {
            if (value !== undefined)
            {
                this._focusable_1 = value;
            }
            else
            {
                return this._focusable_1;
            }
        };

        I.OnIsPasswordChanged = function()
        {
            if (this.IsPassword())
            {
                this.VisualTextTransform(1);
            }
            else
            {
                this.VisualTextTransform(0);
            }
        };

        I.OnFontChanged = function()
        {
            Fuse.Element.prototype.OnFontChanged.call(this);
            this.InvalidateLayout();
            this.InvalidateVisual();
        };

        I.OnFontSizeChanged = function()
        {
            Fuse.Element.prototype.OnFontSizeChanged.call(this);
            this.InvalidateLayout();
            this.InvalidateVisual();
        };

        I.OnTextColorChanged = function()
        {
            Fuse.Element.prototype.OnTextColorChanged.call(this);
            this.InvalidateVisual();
        };

        I.OnTextAlignmentChanged = function()
        {
            Fuse.Element.prototype.OnTextAlignmentChanged.call(this);
            this.InvalidateVisual();
            this._textWindow.InvalidateVisual();
        };

        I.OnInputHintChanged = function()
        {
            if (this.IsFocused())
            {
                Uno.Application.Current().Window().EndTextInput();
                Uno.Application.Current().Window().BeginTextInput(this.InputHint());
            }

            Fuse.Elements.TextEdit.prototype.OnInputHintChanged.call(this);
        };

        I.OnIsMultilineChanged = function()
        {
            this._lineCache.IsMultiline(this.IsMultiline());
            this.InvalidateLayout();
            this.InvalidateVisual();
            this._textWindow.InvalidateVisual();
            Fuse.Elements.TextElement.prototype.OnIsMultilineChanged.call(this);
        };

        I.OnTextWrappingChanged = function()
        {
            this.InvalidateLayout();
            this.InvalidateVisual();
            this._textWindow.InvalidateVisual();
            Fuse.Elements.TextElement.prototype.OnTextWrappingChanged.call(this);
        };

        I.OnTextChanged = function()
        {
            this._lineCache.Text(this.Text());
            this.InvalidateLayout();
            this.InvalidateVisual();
            this._textWindow.InvalidateVisual();
            this._caretPosition = this.IsFocused() ? this._lineCache.GetLastTextPos() : Fuse.Internal.TextPosition.New_1(0, 0);
            this._selection = null;
            Fuse.Elements.TextElement.prototype.OnTextChanged.call(this);
        };

        I.OnCaretColorChanged = function()
        {
            this.InvalidateVisual();
            Fuse.Elements.TextEdit.prototype.OnCaretColorChanged.call(this);
        };

        I.OnSelectionColorChanged = function()
        {
            this.InvalidateVisual();
            Fuse.Elements.TextEdit.prototype.OnCaretColorChanged.call(this);
        };

        I.GetSubElement = function(index)
        {
            return this._textWindow;
        };

        I.GetContentSize = function(fillSize, fillSet)
        {
            var fillSize_126 = new Uno.Float2;
            fillSize_126.op_Assign(fillSize);

            if (this.Font() == null)
            {
                return Uno.Float2.New_1(0.0);
            }

            var wrapWidth = Uno.Math.Max_1(fillSize_126.X, 0.0);
            this._wrapInfo = this.CreateWrapInfo(wrapWidth, (fillSet & 1) == 1);
            var r = Uno.Float2.op_Addition_1(Uno.Math.Ceil_2(this.GetTextBoundsSize(this._wrapInfo)), 1.0);

            if ((fillSet & 1) == 1)
            {
                r.X = Uno.Math.Min_1(r.X, fillSize_126.X);
            }

            return r;
        };

        I.CreateWrapInfo = function(wrapWidth, haveWidth)
        {
            var renderer = this.GetFontOrThrow().GetTextRenderer();
            var fontSize = this.FontSize();
            return Fuse.Internal.WordWrapInfo.New_1(renderer, haveWidth && this.IsWordWrapEnabled(), wrapWidth, fontSize, renderer["Fuse.Internal.ITextRenderer.GetLineHeight"](fontSize), this.AbsoluteZoom());
        };

        I.ArrangePaddingBox = function(size)
        {
            var ind_138;
            var ind_139;
            var ind_140;
            this._textWindow.ArrangeMarginBox((ind_138 = this.Padding(), Uno.Float2.New_2(ind_138.X, ind_138.Y)), Uno.Float2.op_Subtraction(Uno.Float2.op_Subtraction(size, (ind_139 = this.Padding(), Uno.Float2.New_2(ind_139.X, ind_139.Y))), (ind_140 = this.Padding(), Uno.Float2.New_2(ind_140.Z, ind_140.W))), 3);
            Fuse.Element.prototype.ArrangePaddingBox.call(this, size);
        };

        I.GetFontOrThrow = function()
        {
            if (this.Font() == null)
            {
                throw new $Error(Uno.Exception.New_1("Font property was not set. Did you provide a custom style with no font?"));
            }

            return this.Font();
        };

        I.OnDraw = function(dc)
        {
            var textBoundsSize_128 = new Uno.Float2;
            this.GetFontOrThrow();

            if (this._wrapInfo == null)
            {
                this._wrapInfo = this.CreateWrapInfo(this.ActualSize().X, true);
            }

            textBoundsSize_128.op_Assign(this.GetClampedTextBoundsSize(this._wrapInfo));
            var textBoundsWidth = textBoundsSize_128.X;
            this.BringCaretIntoView(this._wrapInfo, textBoundsWidth);

            if (!Uno.String.IsNullOrEmpty(this.Text()))
            {
                this._textWindow.Draw_1(this._wrapInfo, this._selection, this.TextColor(), this.SelectionColor(), this.Text().length, this.TextAlignment(), textBoundsSize_128, Uno.Float2.op_UnaryNegation(this._windowPos), dc);
            }

            if (this.IsFocused())
            {
                this.DrawCaret(this._wrapInfo, textBoundsWidth, dc);
                this.InvalidateVisual();
            }
        };

        I.DrawCaret = function(wrapInfo, textBoundsWidth, dc)
        {
            var pos_129 = new Uno.Float2;
            var caretRect = this.GetCaretRect(wrapInfo, textBoundsWidth);
            pos_129.op_Assign(this.TextBoundsToControl(caretRect.Position()));
            var blink = (Uno.Math.Cos_1(((Uno.Application.Current().FrameTime() - this._caretBlinkTime) * 2.0) * 3.14159274) * 0.5) + 0.5;
            blink = 1.0 - Uno.Math.Pow_1(1.0 - blink, 4.3);
            Fuse.Internal.Drawing.RoundedRectangle.Draw(dc, Uno.Math.Floor_2(pos_129), this.GetDrawMatrix(dc), Uno.Float2.New_2(1.0, caretRect.Size().Y), Uno.Float4.New_7(this.CaretColor(), blink), 1.0);
        };

        I.GetClampedTextBoundsRect = function(wrapInfo)
        {
            return Uno.Rect.New_2(Uno.Float2.New_1(0.0), this.GetClampedTextBoundsSize(wrapInfo));
        };

        I.GetClampedTextBoundsSize = function(wrapInfo)
        {
            return Uno.Math.Max_3(this.GetTextBoundsSize(wrapInfo), this.GetWindowSize());
        };

        I.GetTextBoundsSize = function(wrapInfo)
        {
            return this._lineCache.GetBoundsSize(wrapInfo);
        };

        I.SetWindowPos = function(p)
        {
            if (Uno.Float2.op_Inequality(p, this._windowPos))
            {
                this._textWindow.InvalidateVisual();
            }

            this._windowPos.op_Assign(p);
        };

        I.ResetWindowPosition = function()
        {
            this.SetWindowPos(Uno.Float2.New_1(0.0));
        };

        I.GetWindowSize = function()
        {
            return Uno.Float2.New_2(Uno.Math.Max_1(this.ActualSize().X - (this.Padding().X + this.Padding().Z), 0.0), Uno.Math.Max_1(this.ActualSize().Y - (this.Padding().Y + this.Padding().W), 0.0));
        };

        I.GetWindowRect = function()
        {
            return Uno.Rect.New_2(this._windowPos, this.GetWindowSize());
        };

        I.ResetCaretBlink = function()
        {
            this._caretBlinkTime = Uno.Application.Current().FrameTime();
        };

        I.SetCaretPos = function(p)
        {
            var wrapWidth = this.GetWindowSize().X;
            var wrapInfo = this.CreateWrapInfo(wrapWidth, true);
            var textBoundsWidth = this.GetClampedTextBoundsSize(wrapInfo).X;
            this._caretPosition = this._lineCache.BoundsToTextPos(wrapInfo, this.TextAlignment(), textBoundsWidth, this.ControlToTextBounds(p));
            this.BringCaretIntoView(wrapInfo, textBoundsWidth);
            this.ResetCaretBlink();
        };

        I.BringCaretIntoView = function(wrapInfo, textBoundsWidth)
        {
            var windowRect = this.GetWindowRect();
            var caretRect = this.GetCaretRect(wrapInfo, textBoundsWidth);
            var textRect = this.GetClampedTextBoundsRect(wrapInfo);
            var caretVisibleRect = Fuse.Internal.RectExtensions.MoveRectToContainRect(windowRect, caretRect);
            var clampedRect = Fuse.Internal.RectExtensions.MoveRectInsideRect(caretVisibleRect, textRect);
            this.SetWindowPos(clampedRect.Position());
        };

        I.GetCaretRect = function(wrapInfo, textBoundsWidth)
        {
            var pos = this._lineCache.TextPosToBounds(wrapInfo, this.TextAlignment(), textBoundsWidth, this._caretPosition);
            var width = 2.0;
            return Uno.Rect.New_2(pos, Uno.Float2.New_2(width, wrapInfo.LineHeight));
        };

        I.DeleteSelection = function()
        {
            if (Fuse.Internal.TextSpan.op_Equality(this._selection, null))
            {
                return;
            }

            this._caretPosition = this._lineCache.DeleteSpan(this._selection);
            this._selection = null;
            this._interactionSelectionStartPos = null;
        };

        I.ControlToWindow = function(p)
        {
            var ind_141;
            return Uno.Float2.op_Subtraction(p, (ind_141 = this.Padding(), Uno.Float2.New_2(ind_141.X, ind_141.Y)));
        };

        I.WindowToControl = function(p)
        {
            var ind_142;
            return Uno.Float2.op_Addition(p, (ind_142 = this.Padding(), Uno.Float2.New_2(ind_142.X, ind_142.Y)));
        };

        I.WindowToTextBounds = function(p)
        {
            return Uno.Float2.op_Addition(p, this._windowPos);
        };

        I.TextBoundsToWindow = function(p)
        {
            return Uno.Float2.op_Subtraction(p, this._windowPos);
        };

        I.ControlToTextBounds = function(p)
        {
            return this.WindowToTextBounds(this.ControlToWindow(p));
        };

        I.TextBoundsToControl = function(p)
        {
            return this.WindowToControl(this.TextBoundsToWindow(p));
        };

        I.OnGotFocus = function(args)
        {
            Fuse.Node.prototype.OnGotFocus.call(this, args);
            Uno.Application.Current().Window().BeginTextInput(this.InputHint());
            this.InvalidateLayout();
            this.InvalidateVisual();
            this._selection = null;

            if (this.AutoBringIntoView())
            {
                Fuse.Timer.Wait(0.30000001192092896, $CreateDelegate(this, Fuse.Element.prototype.BringIntoView, 436));
            }
        };

        I.OnLostFocus = function(args)
        {
            Fuse.Node.prototype.OnLostFocus.call(this, args);
            Uno.Application.Current().Window().EndTextInput();
            this.ResetWindowPosition();
            this.InvalidateVisual();
            this.InvalidateLayout();
            this._selection = null;
        };

        I.OnPointerPressed = function(c)
        {
            var isMouse = c.PointerType() == 1;

            if (this.IsFocused() || isMouse)
            {
                c.HardCapturePointer($DownCast(this, 33719));
                c.IsHandled(true);
                this.SetCaretPos(this.FromAbsolute(c.PointCoord()));
                this.ResetCaretBlink();
                this._selection = null;
                this._interactionSelectionStartPos = this._caretPosition;

                if (isMouse)
                {
                    this.Focus();
                }
            }

            this.ClearPasswordReveal();
            Fuse.Node.prototype.OnPointerPressed.call(this, c);
        };

        I.OnPointerReleased = function(c)
        {
            if (c.IsHardCapturedTo($DownCast(this, 33719)))
            {
                c.ReleaseHardCapture();
                c.IsHandled(true);
            }

            Fuse.Node.prototype.OnPointerReleased.call(this, c);
        };

        I.OnRooted = function()
        {
            Fuse.Triggers.Tapped.AddSubscriber(this, $CreateDelegate(this, Fuse.Elements.Implementations.FallbackTextEdit.prototype.OnPointerTapped, 785));
            Fuse.Keyboard.AddKeyPressedHandler(this, $CreateDelegate(this, Fuse.Elements.Implementations.FallbackTextEdit.prototype.OnKeyPressed, 974));
            Fuse.Element.prototype.OnRooted.call(this);
        };

        I.OnUnrooted = function()
        {
            Fuse.Triggers.Tapped.RemoveSubscriber(this, $CreateDelegate(this, Fuse.Elements.Implementations.FallbackTextEdit.prototype.OnPointerTapped, 785));
            Fuse.Keyboard.AddKeyPressedHandler(this, $CreateDelegate(this, Fuse.Elements.Implementations.FallbackTextEdit.prototype.OnKeyPressed, 974));
            Fuse.Element.prototype.OnUnrooted.call(this);
        };

        I.OnPointerTapped = function(sender, c)
        {
            if (c.PointerType() != 1)
            {
                this.Focus();
            }

            this._selection = null;
        };

        I.OnPointerMoved = function(c)
        {
            if (c.IsHardCapturedTo($DownCast(this, 33719)))
            {
                c.IsHandled(true);
                this.CancelManipulation();
                this.SetCaretPos(this.FromAbsolute(c.PointCoord()));

                if (Fuse.Internal.TextPosition.op_Equality(this._interactionSelectionStartPos, null))
                {
                    this._interactionSelectionStartPos = this._caretPosition;
                }

                this._selection = Fuse.Internal.TextPosition.op_Inequality(this._interactionSelectionStartPos, this._caretPosition) ? Fuse.Internal.TextSpan.New_1(this._interactionSelectionStartPos, this._caretPosition) : null;
            }

            Fuse.Node.prototype.OnPointerMoved.call(this, c);
        };

        I.OnTextInput = function(args)
        {
            var array_123;
            var index_124;
            var length_125;
            Fuse.Node.prototype.OnTextInput.call(this, args);
            this.DeleteSelection();

            for (array_123 = args.Text(), index_124 = 0, length_125 = array_123.length; index_124 < length_125; ++index_124)
            {
                var character = array_123.charCodeAt(index_124);

                if (((character == 10) || (character == 13)) || (character < 32))
                {
                    continue;
                }

                this._caretPosition = this._lineCache.InsertChar(this._caretPosition, character);

                if (this._passwordTransform != null)
                {
                    this._passwordTransform.SetReveal(this._caretPosition.Char - 1);
                    this._revealEnd = Uno.Application.Current().FrameTime() + this.RevealTime;
                }

                var wrapWidth = this.GetWindowSize().X;
                var wrapInfo = this.CreateWrapInfo(wrapWidth, true);
                var textBoundsWidth = this.GetClampedTextBoundsSize(wrapInfo).X;
                this.BringCaretIntoView(wrapInfo, textBoundsWidth);
                this.ResetCaretBlink();
                args.IsHandled(true);
            }
        };

        I.ClearPasswordReveal = function()
        {
            if (this._passwordTransform != null)
            {
                if (this._passwordTransform.SetReveal(-1))
                {
                    this._lineCache.InvalidateVisual();
                }
            }
        };

        I.OnKeyPressed = function(sender, args)
        {
            var recognizedKey = true;
            var wrapWidth = this.GetWindowSize().X;
            var wrapInfo = this.CreateWrapInfo(wrapWidth, true);
            var textBoundsWidth = this.GetClampedTextBoundsSize(wrapInfo).X;
            this.ClearPasswordReveal();

            switch (args.Key())
            {
                case 13:
                {
                    if (this.IsMultiline())
                    {
                        this.DeleteSelection();
                        this._caretPosition = this._lineCache.InsertNewline(this._caretPosition);
                    }
                    else if (Uno.Application.Current().Window().IsTextInputActive())
                    {
                        Fuse.FocusManager.Move(1);
                    }

                    break;
                }
                case 46:
                {
                    if (Fuse.Internal.TextSpan.op_Equality(this._selection, null))
                    {
                        this._caretPosition = this._lineCache.TryDelete(this._caretPosition);
                    }
                    else
                    {
                        this.DeleteSelection();
                    }

                    break;
                }
                case 8:
                {
                    if (Fuse.Internal.TextSpan.op_Equality(this._selection, null))
                    {
                        this._caretPosition = this._lineCache.TryBackspace(this._caretPosition);
                    }
                    else
                    {
                        this.DeleteSelection();
                    }

                    break;
                }
                case 37:
                {
                    this._selection = null;
                    this._caretPosition = this._lineCache.TryMoveLeft(this._caretPosition);
                    break;
                }
                case 39:
                {
                    this._selection = null;
                    this._caretPosition = this._lineCache.TryMoveRight(this._caretPosition);
                    break;
                }
                case 38:
                {
                    this._selection = null;
                    this._caretPosition = this._lineCache.TryMoveUp(wrapInfo, this.TextAlignment(), textBoundsWidth, this._caretPosition);
                    break;
                }
                case 40:
                {
                    this._selection = null;
                    this._caretPosition = this._lineCache.TryMoveDown(wrapInfo, this.TextAlignment(), textBoundsWidth, this._caretPosition);
                    break;
                }
                case 36:
                {
                    this._selection = null;
                    this._caretPosition = this._lineCache.Home(wrapInfo, this._caretPosition);
                    break;
                }
                case 35:
                {
                    this._selection = null;
                    this._caretPosition = this._lineCache.End(wrapInfo, this._caretPosition);
                    break;
                }
                default:
                {
                    recognizedKey = false;
                    break;
                }
            }

            if (recognizedKey)
            {
                this.ResetCaretBlink();
                args.IsHandled(true);
            }
        };

        I.OnHitTestVisual = function(htc)
        {
            if (this.IsPointInside(htc.LocalPoint()))
            {
                htc.Hit($DownCast(this, 33719));
            }
        };

        I.TransformUpdate = function(s, a)
        {
            if ((this._passwordTransform == null) || (Uno.Application.Current().FrameTime() < this._revealEnd))
            {
                return;
            }

            if (this._passwordTransform.SetReveal(-1))
            {
                this._lineCache.InvalidateVisual();
            }
        };

    });
