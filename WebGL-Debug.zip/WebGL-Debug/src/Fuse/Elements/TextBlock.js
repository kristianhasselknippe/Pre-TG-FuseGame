Fuse.Elements.TextBlock = $CreateClass(
    function() {
        Fuse.Elements.Implementations.FallbackTextElement.call(this);
    },
    function(S) {
        var I = S.prototype = new Fuse.Elements.Implementations.FallbackTextElement;

        I.GetType = function()
        {
            return 838;
        };

        I._ObjInit_4 = function()
        {
            Fuse.Elements.Implementations.FallbackTextElement.prototype._ObjInit_3.call(this);
        };

        Fuse.Elements.TextBlock.New_2 = function()
        {
            var inst = new Fuse.Elements.TextBlock;
            inst._ObjInit_4();
            return inst;
        };

    });
