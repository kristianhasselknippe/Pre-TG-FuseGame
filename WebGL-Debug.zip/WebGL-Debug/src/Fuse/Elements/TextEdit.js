Fuse.Elements.TextEdit = $CreateClass(
    function() {
        Fuse.Elements.TextElement.call(this);
        this._isPassword = false;
        this._inputHint = 0;
        this._caretColor = new Uno.Float3;
        this._selectionColor = new Uno.Float4;
        this._AutoBringIntoView = false;
    },
    function(S) {
        var I = S.prototype = new Fuse.Elements.TextElement;

        I.GetType = function()
        {
            return 840;
        };

        I.IsPassword = function(value)
        {
            if (value !== undefined)
            {
                if (this._isPassword != value)
                {
                    this._isPassword = value;
                    this.OnIsPasswordChanged();
                }
            }
            else
            {
                return this._isPassword;
            }
        };

        I.InputHint = function(value)
        {
            if (value !== undefined)
            {
                if (this._inputHint != value)
                {
                    this._inputHint = value;
                    this.OnInputHintChanged();
                }
            }
            else
            {
                return this._inputHint;
            }
        };

        I.AutoBringIntoView = function(value)
        {
            if (value !== undefined)
            {
                this._AutoBringIntoView = value;
            }
            else
            {
                return this._AutoBringIntoView;
            }
        };

        I.CaretColor = function(value)
        {
            if (value !== undefined)
            {
                if (Uno.Float3.op_Inequality(this._caretColor, value))
                {
                    this._caretColor.op_Assign(value);
                    this.OnCaretColorChanged();
                }
            }
            else
            {
                return this._caretColor;
            }
        };

        I.SelectionColor = function(value)
        {
            if (value !== undefined)
            {
                if (Uno.Float4.op_Inequality(this._selectionColor, value))
                {
                    this._selectionColor.op_Assign(value);
                    this.OnSelectionColorChanged();
                }
            }
            else
            {
                return this._selectionColor;
            }
        };

        I.IsFocusable = function(value)
        {
            if (value !== undefined)
            {
                throw new $Error(Uno.NotImplementedException.New_3());
            }
            else
            {
                return true;
            }
        };

        I.OnIsPasswordChanged = function()
        {
        };

        I.OnInputHintChanged = function()
        {
        };

        I.OnCaretColorChanged = function()
        {
        };

        I.OnSelectionColorChanged = function()
        {
        };

    });
