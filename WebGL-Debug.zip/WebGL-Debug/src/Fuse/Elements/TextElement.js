Fuse.Elements.TextElement = $CreateClass(
    function() {
        Fuse.Element.call(this);
        this._text = null;
        this._isMultiline = false;
        this._textWrapping = 0;
        this.TextChanged = null;
    },
    function(S) {
        var I = S.prototype = new Fuse.Element;

        I.GetType = function()
        {
            return 839;
        };

        I.Text = function(value)
        {
            if (value !== undefined)
            {
                if (Uno.String.op_Inequality(this._text, value))
                {
                    this._text = value;
                    this.OnTextChanged();
                }
            }
            else
            {
                return this._text;
            }
        };

        I.IsMultiline = function(value)
        {
            if (value !== undefined)
            {
                if (this._isMultiline != value)
                {
                    this._isMultiline = value;
                    this.OnIsMultilineChanged();
                }
            }
            else
            {
                return this._isMultiline;
            }
        };

        I.TextWrapping = function(value)
        {
            if (value !== undefined)
            {
                if (value == this._textWrapping)
                {
                    return;
                }

                this._textWrapping = value;
                this.OnTextWrappingChanged();
            }
            else
            {
                return this._textWrapping;
            }
        };

        I.OnTextChanged = function()
        {
            if (Uno.Delegate.op_Inequality(this.TextChanged, null))
            {
                this.TextChanged.Invoke(this, Uno.EventArgs.Empty);
            }
        };

        I.OnIsMultilineChanged = function()
        {
        };

        I.OnTextWrappingChanged = function()
        {
        };

        I.OnHitTestVisual = function(htc)
        {
            if (this.IsPointInside(htc.LocalPoint()))
            {
                htc.Hit($DownCast(this, 33719));
            }
        };

        I._ObjInit_2 = function()
        {
            Fuse.Element.prototype._ObjInit_1.call(this);
        };

        I.add_TextChanged = function(value)
        {
            this.TextChanged = $DownCast(Uno.Delegate.Combine(this.TextChanged, value), 445);
        };

        I.remove_TextChanged = function(value)
        {
            this.TextChanged = $DownCast(Uno.Delegate.Remove(this.TextChanged, value), 445);
        };

    });
