Fuse.Time = $CreateClass(
    function() {
    },
    function(S) {
        Fuse.Time.FakeTime = null;

        Fuse.Time.FrameTime = function()
        {
            return Fuse.Time.GetFrameTime();
        };

        Fuse.Time.FrameInterval = function()
        {
            return Fuse.Time.GetFrameInterval();
        };

        Fuse.Time.FrameTimeDouble = function()
        {
            return Fuse.Time.GetFrameTime();
        };

        Fuse.Time.GetFrameTime = function()
        {
            return (Fuse.Time.FakeTime == null) ? Uno.Application.Current().FrameTime() : Fuse.Time.FakeTime.FrameTime;
        };

        Fuse.Time.GetFrameInterval = function()
        {
            return (Fuse.Time.FakeTime == null) ? Uno.Application.Current().FrameInterval() : Fuse.Time.FakeTime.FrameInterval;
        };

    });
