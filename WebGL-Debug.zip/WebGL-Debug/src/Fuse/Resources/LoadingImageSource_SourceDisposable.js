Fuse.Resources.LoadingImageSource_SourceDisposable = $CreateClass(
    function() {
        Fuse.Resources.PolicyAutoDisposable.call(this);
        this._source = null;
    },
    function(S) {
        var I = S.prototype = new Fuse.Resources.PolicyAutoDisposable;

        I.GetType = function()
        {
            return 579;
        };

        I.ShouldDispose = function()
        {
            return !this._source.IsPinned() && Fuse.Resources.PolicyAutoDisposable.prototype.ShouldDispose.call(this);
        };

        I.Dispose = function()
        {
            this._source.Dispose();
        };

        I._ObjInit_1 = function()
        {
            Fuse.Resources.PolicyAutoDisposable.prototype._ObjInit.call(this);
        };

        Fuse.Resources.LoadingImageSource_SourceDisposable.New_1 = function()
        {
            var inst = new Fuse.Resources.LoadingImageSource_SourceDisposable;
            inst._ObjInit_1();
            return inst;
        };

    });
