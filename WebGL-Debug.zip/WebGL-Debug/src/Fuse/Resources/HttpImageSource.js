Fuse.Resources.HttpImageSource = $CreateClass(
    function() {
        Fuse.Resources.ImageSource.call(this);
        this._proxy = null;
    },
    function(S) {
        var I = S.prototype = new Fuse.Resources.ImageSource;

        I.GetType = function()
        {
            return 568;
        };

        I.Size = function()
        {
            return this._proxy.Size();
        };

        I.OnPinChanged = function()
        {
            this._proxy.OnPinChanged();
        };

        I.GetTexture = function()
        {
            return this._proxy.GetTexture();
        };

    });
