Fuse.Resources.LoadingImageSource = $CreateClass(
    function() {
        Fuse.Resources.ImageSource.call(this);
        this._disposable = null;
        this._policy = null;
        this._texture = null;
        this._textureSize = new Uno.Int2;
        this._loading = false;
        this._failed = false;
        this._haveAction = false;
        this._density = 0;
    },
    function(S) {
        var I = S.prototype = new Fuse.Resources.ImageSource;

        I.GetType = function()
        {
            return 576;
        };

        I.Size = function()
        {
            var ts_123 = new Uno.Int2;
            ts_123.op_Assign(this.PixelSize());
            return Uno.Float2.op_Division_1(Uno.Float2.New_2(ts_123.X, ts_123.Y), this._density);
        };

        I.PixelSize = function()
        {
            if (this._texture == null)
            {
                this.LoadTexture();
            }

            if (this._disposable != null)
            {
                this._disposable.MarkUsed();
            }

            return this._textureSize;
        };

        I.GetTexture = function()
        {
            if (this._texture != null)
            {
                if (this._disposable != null)
                {
                    this._disposable.MarkUsed();
                }

                return this._texture;
            }

            this.LoadTexture();
            return null;
        };

        I.LoadTexture = function()
        {
            if (this._loading || this._failed)
            {
                return;
            }

            if (!this._haveAction)
            {
                Fuse.UpdateManager.AddOnceAction($CreateDelegate(this, Fuse.Resources.LoadingImageSource.prototype.AsyncLoadTexture, 436), 0);
                this._haveAction = true;
            }
        };

        I.AsyncLoadTexture = function()
        {
            this._haveAction = false;

            if (this._loading || this._failed)
            {
                return;
            }

            this.AttemptLoad();
        };

        I.Dispose = function()
        {
            this.Cleanup(false);
        };

        I.Cleanup = function(failed)
        {
            if (this._texture != null)
            {
                this._texture.Dispose();
                this._texture = null;
            }

            this._textureSize = Uno.Int2.New_1(0);
            this._loading = false;
            this._failed = failed;

            if (this._disposable != null)
            {
                Fuse.Resources.DisposalManager.Remove($DownCast(this._disposable, 33339));
            }

            this._disposable = null;
            this.OnChanged();
        };

        I.SetTexture = function(texture)
        {
            this._texture = texture;
            this._textureSize.op_Assign(texture.Size());

            if (this._disposable == null)
            {
                this._disposable = Fuse.Resources.LoadingImageSource_SourceDisposable.New_1();
                this._disposable._source = this;
                this._disposable.Policy = this._policy;
                Fuse.Resources.DisposalManager.Add($DownCast(this._disposable, 33339));
            }

            this._disposable.MarkUsed();
            this.OnChanged();
        };

        I.OnPinChanged = function()
        {
            Fuse.Resources.ImageSource.prototype.OnPinChanged.call(this);

            if (this._disposable != null)
            {
                this._disposable.MarkUsed();
            }
        };

    });
