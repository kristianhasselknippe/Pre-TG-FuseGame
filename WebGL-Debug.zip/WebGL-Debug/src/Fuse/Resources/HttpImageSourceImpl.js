Fuse.Resources.HttpImageSourceImpl = $CreateClass(
    function() {
        Fuse.Resources.LoadingImageSource.call(this);
        this._httpClient = null;
        this._url = null;
        this._contentType = null;
    },
    function(S) {
        var I = S.prototype = new Fuse.Resources.LoadingImageSource;

        I.GetType = function()
        {
            return 570;
        };

        I.Url = function()
        {
            return this._url;
        };

        I.AttemptLoad = function()
        {
            if (this._httpClient == null)
            {
                this._httpClient = Experimental.Net.Http.HttpClient.New_2();
                this._httpClient.add_OnError($CreateDelegate(this, Fuse.Resources.HttpImageSourceImpl.prototype.LoadFailed, 470));
            }

            try
            {
                this._httpClient.SendAsync__Experimental_Net_Http_HttpBufferContent(Experimental.Net.Http.HttpRequest.New_2(0, this.Url()), $CreateDelegate(this, Fuse.Resources.HttpImageSourceImpl.prototype.HttpCallback, 485));
                this._loading = true;
                this.OnChanged();
            }

            catch ($js_exception)
            {
                $uno_exception = $ConvertNativeException($js_exception);
                if ($uno_exception instanceof Uno.Exception)
                {
                    var e = $uno_exception;
                    this.Cleanup(true);
                    this.OnError("HttpImageSource-failed-request", e);
                }

                else
                {
                    throw $js_exception
                }
            }
        };

        I.HttpCallback = function(response)
        {
            this._contentType = "x-missing";

            if (response.Headers().Contains("Content-Type"))
            {
                for (var enum_123 = response.Headers().Item("Content-Type")["Uno.Collections.IEnumerable__string.GetEnumerator"](); enum_123["Uno.Collections.IEnumerator.MoveNext"](); )
                {
                    var ct = enum_123["Uno.Collections.IEnumerator__string.Current"]();
                    this._contentType = ct;
                }
            }

            response.Content().ReadAsBufferAsync($CreateDelegate(this, Fuse.Resources.HttpImageSourceImpl.prototype.Loaded, 473));
        };

        I.Loaded = function(data)
        {
            this._loading = false;
            try
            {
                Experimental.TextureLoader.TextureLoader.ByteArrayToTexture2DContentType(data, this._contentType, $CreateDelegate(this, Fuse.Resources.LoadingImageSource.prototype.SetTexture, 475));
                this.OnChanged();
            }

            catch ($js_exception)
            {
                $uno_exception = $ConvertNativeException($js_exception);
                if ($uno_exception instanceof Uno.Exception)
                {
                    var e = $uno_exception;
                    this.Cleanup(true);
                    this.OnError("HttpImageSource-failed-converson", e);
                }

                else
                {
                    throw $js_exception
                }
            }
        };

        I.LoadFailed = function(reason)
        {
            this.Cleanup(true);
            this.OnError(Uno.String.op_Addition("HttpImageSource-protocol-failure: ", reason), null);
        };

    });
