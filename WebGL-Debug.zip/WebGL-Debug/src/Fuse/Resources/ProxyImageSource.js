Fuse.Resources.ProxyImageSource = $CreateClass(
    function() {
        this._outer = null;
        this._impl = null;
        this._density = 0;
    },
    function(S) {
        var I = S.prototype;

        I.GetType = function()
        {
            return 577;
        };

        I.Size = function()
        {
            var ps_123 = new Uno.Int2;

            if (this._impl == null)
            {
                return Uno.Float2.New_1(0.0);
            }

            ps_123.op_Assign(this._impl.PixelSize());
            return Uno.Float2.op_Division_1(Uno.Float2.New_2(ps_123.X, ps_123.Y), this._density);
        };

        I.OnPinChanged = function()
        {
            if (this._impl == null)
            {
                return;
            }

            if (this._outer.IsPinned())
            {
                this._impl.Pin();
            }
            else
            {
                this._impl.Unpin();
            }
        };

        I.GetTexture = function()
        {
            return (this._impl == null) ? null : this._impl.GetTexture();
        };

    });
