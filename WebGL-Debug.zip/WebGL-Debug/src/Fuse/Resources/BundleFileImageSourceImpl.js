Fuse.Resources.BundleFileImageSourceImpl = $CreateClass(
    function() {
        Fuse.Resources.LoadingImageSource.call(this);
        this._bundleFile = null;
    },
    function(S) {
        var I = S.prototype = new Fuse.Resources.LoadingImageSource;

        I.GetType = function()
        {
            return 564;
        };

        I.AttemptLoad = function()
        {
            try
            {
                var data = this._bundleFile.ReadAllBytes();
                Experimental.TextureLoader.TextureLoader.ByteArrayToTexture2DFilename(Uno.Buffer.New_2(data), this._bundleFile.Name(), $CreateDelegate(this, Fuse.Resources.LoadingImageSource.prototype.SetTexture, 475));
                this.OnChanged();
            }

            catch ($js_exception)
            {
                $uno_exception = $ConvertNativeException($js_exception);
                if ($uno_exception instanceof Uno.Exception)
                {
                    var e = $uno_exception;
                    this.Cleanup(true);
                    this.OnError("BundleFileImageSource-failed-conversion", e);
                }

                else
                {
                    throw $js_exception
                }
            }
        };

    });
