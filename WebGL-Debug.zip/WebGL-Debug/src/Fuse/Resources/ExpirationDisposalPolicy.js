Fuse.Resources.ExpirationDisposalPolicy = $CreateClass(
    function() {
        Fuse.Resources.DisposalPolicy.call(this);
        this.lastUsedFrameTime = 0;
        this._Timeout = 0;
    },
    function(S) {
        var I = S.prototype = new Fuse.Resources.DisposalPolicy;

        I.GetType = function()
        {
            return 567;
        };

        I.Timeout = function(value)
        {
            if (value !== undefined)
            {
                this._Timeout = value;
            }
            else
            {
                return this._Timeout;
            }
        };

        I.ShouldDispose = function()
        {
            if (this.Timeout() > 0.0)
            {
                var elapsed = Uno.Application.Current().FrameTime() - this.lastUsedFrameTime;

                if (elapsed > this.Timeout())
                {
                    return true;
                }
            }

            return false;
        };

        I.MarkUsed = function()
        {
            this.lastUsedFrameTime = Uno.Application.Current().FrameTime();
        };

    });
