Fuse.Resources.DisposalManager = $CreateClass(
    function() {
    },
    function(S) {
        Fuse.Resources.DisposalManager._items = null;
        Fuse.Resources.DisposalManager._actionAdded = false;

        Fuse.Resources.DisposalManager.Add = function(item)
        {
            Fuse.Resources.DisposalManager._items.Add(item);
            Fuse.Resources.DisposalManager.VerifyAttach();
        };

        Fuse.Resources.DisposalManager.Remove = function(item)
        {
            Fuse.Resources.DisposalManager._items.Remove(item);
            Fuse.Resources.DisposalManager.VerifyAttach();
        };

        Fuse.Resources.DisposalManager.VerifyAttach = function()
        {
            var on = Fuse.Resources.DisposalManager._items.Count() > 0;

            if (on == Fuse.Resources.DisposalManager._actionAdded)
            {
                return;
            }

            if (on)
            {
                Fuse.UpdateManager.AddAction($CreateDelegate(null, Fuse.Resources.DisposalManager.Update, 436), 0);
            }
            else
            {
                Fuse.UpdateManager.RemoveAction($CreateDelegate(null, Fuse.Resources.DisposalManager.Update, 436), 0);
            }

            Fuse.Resources.DisposalManager._actionAdded = on;
        };

        Fuse.Resources.DisposalManager.Update = function()
        {
            for (var i = Fuse.Resources.DisposalManager._items.Count() - 1; i >= 0; --i)
            {
                var item = Fuse.Resources.DisposalManager._items.Item(i);

                if (!item["Fuse.Resources.IAutoDisposable.ShouldDispose"]())
                {
                    continue;
                }

                Fuse.Resources.DisposalManager._items.RemoveAt(i);
                item["Uno.IDisposable.Dispose"]();
                break;
            }
        };

        Fuse.Resources.DisposalManager._TypeInit = function()
        {
            Fuse.Resources.DisposalManager._items = Uno.Collections.List__Fuse_Resources_IAutoDisposable.New_1();
        };

    });
