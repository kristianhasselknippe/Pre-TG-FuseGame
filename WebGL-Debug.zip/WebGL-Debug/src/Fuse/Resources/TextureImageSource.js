Fuse.Resources.TextureImageSource = $CreateClass(
    function() {
        Fuse.Resources.ImageSource.call(this);
        this._texture = null;
        this._density = 0;
    },
    function(S) {
        var I = S.prototype = new Fuse.Resources.ImageSource;

        I.GetType = function()
        {
            return 578;
        };

        I.Texture = function(value)
        {
            if (value !== undefined)
            {
                if (this._texture != value)
                {
                    this._texture = value;
                    this.OnChanged();
                }
            }
            else
            {
                return this._texture;
            }
        };

        I.Size = function()
        {
            if (this._texture != null)
            {
                return Uno.Float2.op_Division_1(Uno.Float2.New_2(this._texture.Size().X, this._texture.Size().Y), this._density);
            }

            return Uno.Float2.New_1(0.0);
        };

        I.GetTexture = function()
        {
            return this._texture;
        };

        I._ObjInit_1 = function()
        {
            this._density = 1.0;
            Fuse.Resources.ImageSource.prototype._ObjInit.call(this);
        };

        Fuse.Resources.TextureImageSource.New_1 = function()
        {
            var inst = new Fuse.Resources.TextureImageSource;
            inst._ObjInit_1();
            return inst;
        };

    });
