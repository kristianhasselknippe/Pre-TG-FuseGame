Fuse.Resources.ResourceBinding__float2 = $CreateClass(
    function() {
        Fuse.Behavior.call(this);
        this._key = null;
        this._target = null;
        this._n = null;
    },
    function(S) {
        var I = S.prototype = new Fuse.Behavior;

        I.GetType = function()
        {
            return 580;
        };

        I.$II = function(id)
        {
            return [558].indexOf(id) != -1;
        };

        I.Target = function(value)
        {
            if (value !== undefined)
            {
                if (this._target != value)
                {
                    this._target = value;
                    this.Update();
                }
            }
            else
            {
                return this._target;
            }
        };

        I["Fuse.Resources.IResourceConsumer.NotifyResourceChanged"] = function(key)
        {
            if (Uno.String.op_Equality(key, this._key))
            {
                this.Update();
            }
        };

        I.Update = function()
        {
            if (((this._n != null) && (this.Target() != null)) && Uno.String.op_Inequality(this._key, null))
            {
                var val = this._n.GetResource(this._key);

                if ($IsOp(val, 430))
                {
                    this.Target().SetRestState($DownCast(val, 430));
                }
            }
        };

        I.OnRooted = function(e)
        {
            this._n = e;

            if (Uno.String.op_Inequality(this._key, null))
            {
                Fuse.Resources.Resources.AddResourceChangedListener(this._key, $DownCast(this, 33326));
            }

            this.Update();
        };

        I.OnUnrooted = function(e)
        {
            this._n = null;

            if (Uno.String.op_Inequality(this._key, null))
            {
                Fuse.Resources.Resources.RemoveResourceChangedListener(this._key, $DownCast(this, 33326));
            }
        };

    });
