Fuse.Resources.ResourceList = $CreateClass(
    function() {
        this._list = null;
        this._resources = null;
    },
    function(S) {
        var I = S.prototype;

        I.GetType = function()
        {
            return 560;
        };

        I.$II = function(id)
        {
            return [144, 59].indexOf(id) != -1;
        };

        I.Item_1 = function(key)
        {
            var res;

            if (this._resources.TryGetValue(key, $CreateRef(function(){return res}, function($){res=$}, this)))
            {
                return res.Object;
            }
            else
            {
                return null;
            }
        };

        I.GetEnumerator = function()
        {
            return $CopyStruct(this._list.GetEnumerator());
        };

        I["Uno.Collections.IEnumerable__object.GetEnumerator"] = I.GetEnumerator;

    });
