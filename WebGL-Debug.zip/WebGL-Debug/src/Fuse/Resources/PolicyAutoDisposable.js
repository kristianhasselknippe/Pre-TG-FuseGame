Fuse.Resources.PolicyAutoDisposable = $CreateClass(
    function() {
        this.Policy = null;
    },
    function(S) {
        var I = S.prototype;

        I.GetType = function()
        {
            return 572;
        };

        I.$II = function(id)
        {
            return [571, 418].indexOf(id) != -1;
        };

        I.ShouldDispose = function()
        {
            if (this.Policy != null)
            {
                return this.Policy.ShouldDispose();
            }

            return true;
        };

        I.MarkUsed = function()
        {
            if (this.Policy != null)
            {
                this.Policy.MarkUsed();
            }
        };

        I._ObjInit = function()
        {
        };

        I["Fuse.Resources.IAutoDisposable.ShouldDispose"] = function() { return this.ShouldDispose.apply(this, arguments); };
        I["Uno.IDisposable.Dispose"] = function() { this.Dispose.apply(this, arguments); };

    });
