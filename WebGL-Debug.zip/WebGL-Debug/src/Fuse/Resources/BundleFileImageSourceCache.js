Fuse.Resources.BundleFileImageSourceCache = $CreateClass(
    function() {
    },
    function(S) {
        Fuse.Resources.BundleFileImageSourceCache._cache = null;

        Fuse.Resources.BundleFileImageSourceCache._TypeInit = function()
        {
            Fuse.Resources.BundleFileImageSourceCache._cache = Uno.Collections.Dictionary__Uno_BundleFile__Uno_WeakReference_Fuse_Resources_BundleFileImageSourceImpl_.New_1();
        };

    });
