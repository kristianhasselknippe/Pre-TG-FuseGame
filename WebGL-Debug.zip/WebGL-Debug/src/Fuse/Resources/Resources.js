Fuse.Resources.Resources = $CreateClass(
    function() {
        this._list = null;
    },
    function(S) {
        var I = S.prototype;

        Fuse.Resources.Resources._keys = null;
        Fuse.Resources.Resources._subscribers = null;

        I.GetType = function()
        {
            return 561;
        };

        I.Content = function()
        {
            return $DownCast(this._list, 32912);
        };

        I.Item = function(key)
        {
            return this._list.Item_1(key);
        };

        Fuse.Resources.Resources.GetKey = function(res)
        {
            if (Fuse.Resources.Resources._keys.ContainsKey(res))
            {
                return Fuse.Resources.Resources._keys.Item(res);
            }

            return null;
        };

        I.NotifyOwnerChanged = function()
        {
            for (var enum_123 = this.Content()["Uno.Collections.IEnumerable__object.GetEnumerator"](); enum_123["Uno.Collections.IEnumerator.MoveNext"](); )
            {
                var r = enum_123["Uno.Collections.IEnumerator__object.Current"]();
                Fuse.Resources.Resources.NotifyResourceChanged(Fuse.Resources.Resources.GetKey(r));
            }
        };

        Fuse.Resources.Resources.NotifyResourceChanged = function(key)
        {
            if (Fuse.Resources.Resources._subscribers.ContainsKey(key))
            {
                for (var enum_124 = Fuse.Resources.Resources._subscribers.Item(key).GetEnumerator(); enum_124.MoveNext(); )
                {
                    var c = enum_124.Current();
                    c["Fuse.Resources.IResourceConsumer.NotifyResourceChanged"](key);
                }
            }
        };

        Fuse.Resources.Resources.AddResourceChangedListener = function(key, consumer)
        {
            if (!Fuse.Resources.Resources._subscribers.ContainsKey(key))
            {
                Fuse.Resources.Resources._subscribers.Add(key, Uno.Collections.List__Fuse_Resources_IResourceConsumer.New_1());
            }

            Fuse.Resources.Resources._subscribers.Item(key).Add(consumer);
        };

        Fuse.Resources.Resources.RemoveResourceChangedListener = function(key, consumer)
        {
            if (!Fuse.Resources.Resources._subscribers.ContainsKey(key))
            {
                throw new $Error(Uno.Exception.New_2());
            }

            Fuse.Resources.Resources._subscribers.Item(key).Remove(consumer);
        };

        Fuse.Resources.Resources._TypeInit = function()
        {
            Fuse.Resources.Resources._keys = Uno.Collections.Dictionary__object__string.New_1();
            Fuse.Resources.Resources._subscribers = Uno.Collections.Dictionary__string__Uno_Collections_List_Fuse_Resources_IResourceConsumer_.New_1();
        };

    });
