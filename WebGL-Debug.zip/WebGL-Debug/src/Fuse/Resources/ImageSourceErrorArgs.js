Fuse.Resources.ImageSourceErrorArgs = $CreateClass(
    function() {
        Uno.EventArgs.call(this);
        this.Reason = null;
        this.ExceptionCause = null;
    },
    function(S) {
        var I = S.prototype = new Uno.EventArgs;

        I.GetType = function()
        {
            return 573;
        };

        I._ObjInit_1 = function()
        {
            Uno.EventArgs.prototype._ObjInit.call(this);
        };

        Fuse.Resources.ImageSourceErrorArgs.New_2 = function()
        {
            var inst = new Fuse.Resources.ImageSourceErrorArgs;
            inst._ObjInit_1();
            return inst;
        };

    });
