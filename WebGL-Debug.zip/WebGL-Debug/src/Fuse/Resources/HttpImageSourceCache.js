Fuse.Resources.HttpImageSourceCache = $CreateClass(
    function() {
    },
    function(S) {
        Fuse.Resources.HttpImageSourceCache._cache = null;

        Fuse.Resources.HttpImageSourceCache._TypeInit = function()
        {
            Fuse.Resources.HttpImageSourceCache._cache = Uno.Collections.Dictionary__string__Uno_WeakReference_Fuse_Resources_HttpImageSourceImpl_.New_1();
        };

    });
