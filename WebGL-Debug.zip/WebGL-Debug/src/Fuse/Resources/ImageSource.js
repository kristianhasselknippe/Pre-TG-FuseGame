Fuse.Resources.ImageSource = $CreateClass(
    function() {
        this._pinCount = 0;
        this.Changed = null;
        this.Error = null;
    },
    function(S) {
        var I = S.prototype;

        I.GetType = function()
        {
            return 575;
        };

        I.IsPinned = function()
        {
            return this._pinCount > 0;
        };

        I.OnChanged = function()
        {
            if (Uno.Delegate.op_Inequality(this.Changed, null))
            {
                this.Changed.Invoke(this, Uno.EventArgs.Empty);
            }
        };

        I.OnError = function(msg, e)
        {
            if (Uno.Delegate.op_Inequality(this.Error, null))
            {
                var sa = Fuse.Resources.ImageSourceErrorArgs.New_2();
                sa.Reason = msg;
                sa.ExceptionCause = e;
                this.Error.Invoke(this, sa);
            }
        };

        I.Pin = function()
        {
            this._pinCount++;

            if (this._pinCount == 1)
            {
                this.OnPinChanged();
            }
        };

        I.Unpin = function()
        {
            this._pinCount--;

            if (this._pinCount == 0)
            {
                this.OnPinChanged();
            }
        };

        I.OnPinChanged = function()
        {
        };

        I._ObjInit = function()
        {
        };

        I.add_Changed = function(value)
        {
            this.Changed = $DownCast(Uno.Delegate.Combine(this.Changed, value), 445);
        };

        I.remove_Changed = function(value)
        {
            this.Changed = $DownCast(Uno.Delegate.Remove(this.Changed, value), 445);
        };

    });
