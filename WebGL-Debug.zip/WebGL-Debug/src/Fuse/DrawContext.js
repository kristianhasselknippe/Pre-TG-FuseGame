Fuse.DrawContext = $CreateClass(
    function() {
        Fuse.TraverseContext.call(this);
        this._rootTransform = null;
        this._rootTransformStack = null;
        this.scissors = null;
        this.flushSet = null;
        this.passes = null;
    },
    function(S) {
        var I = S.prototype = new Fuse.TraverseContext;

        Fuse.DrawContext._current = null;
        Fuse.DrawContext.renderTargets = null;
        Fuse.DrawContext._scissors = null;

        I.GetType = function()
        {
            return 917;
        };

        I.IsRootTransformIdentity = function()
        {
            return this._rootTransformStack.Count() == 0;
        };

        I.RootTransform = function()
        {
            return this._rootTransform;
        };

        Fuse.DrawContext.Current = function()
        {
            return Fuse.DrawContext._current;
        };

        I.Aspect = function()
        {
            var struct_133 = new Uno.Recti;

            if ((this.Camera() != null) && this.Camera()["Fuse.ICamera.HasExplicitAspect"]())
            {
                return this.Camera()["Fuse.ICamera.ExplicitAspect"]();
            }
            else if (Fuse.DrawContext.renderTargets.Count() > 0)
            {
                return Fuse.DrawContext.renderTargets.Item(Fuse.DrawContext.renderTargets.Count() - 1).Aspect;
            }
            else
            {
                return (struct_133.op_Assign(this.Viewport()), struct_133).Size().Ratio();
            }
        };

        I.RenderTarget = function()
        {
            return Uno.Application.Current().GraphicsContext().RenderTarget();
        };

        I.Viewport = function()
        {
            return Uno.Application.Current().GraphicsContext().Viewport();
        };

        I.Scissor = function()
        {
            return Uno.Application.Current().GraphicsContext().Scissor();
        };

        I.VirtualResolution = function()
        {
            return Fuse.Spaces.VirtualResolution();
        };

        I.ResolutionMultiplier = function()
        {
            return Fuse.Environment.ScreenPPIZoomMultiplier();
        };

        I.PushRootTransform = function(m)
        {
            this._rootTransformStack.Add(this._rootTransform);
            this._rootTransform = m;
        };

        I.PopRootTransform = function()
        {
            this._rootTransform = Uno.Collections.IListExtensions.RemoveLast__Fuse_FastMatrix($DownCast(this._rootTransformStack, 32929));
        };

        I.MakeCurrent = function()
        {
            Fuse.DrawContext._current = this;
        };

        I.Flush = function()
        {
            if (this.flushSet != null)
            {
                for (var enum_123 = this.flushSet.GetEnumerator(); enum_123.MoveNext(); )
                {
                    var f = enum_123.Current();
                    f["Fuse.IFlush.Flush"](this);
                }

                this.flushSet.Clear();
                this.flushSet = null;
            }
        };

        I.PushScissor = function(scissor)
        {
            this.Flush();
            Fuse.DrawContext._scissors.Add(Uno.Application.Current().GraphicsContext().Scissor());
            Uno.Application.Current().GraphicsContext().Scissor(scissor);
        };

        I.PopScissor = function()
        {
            var last_125 = new Uno.Recti;
            var lastIndex = Fuse.DrawContext._scissors.Count() - 1;
            last_125.op_Assign(Fuse.DrawContext._scissors.Item(lastIndex));
            Uno.Application.Current().GraphicsContext().Scissor(last_125);
            Fuse.DrawContext._scissors.RemoveAt(lastIndex);
        };

        I.PushRenderTarget = function(fb, keepPreviousAspect)
        {
            this.PushRenderTarget_1(fb.RenderTarget(), keepPreviousAspect);
        };

        I.PushRenderTarget_1 = function(fb, keepPreviousAspect)
        {
            var struct_126 = new Uno.Int2;
            this.Flush();
            Fuse.DrawContext.renderTargets.Add(Fuse.RenderTargetEntry.New_2(Uno.Application.Current().GraphicsContext().RenderTarget(), keepPreviousAspect ? this.Aspect() : (struct_126.op_Assign(fb.Size()), struct_126).Ratio(), $CopyStruct(this.Viewport()), $CopyStruct(this.Scissor())));
            Uno.Application.Current().GraphicsContext().SetRenderTarget(fb);
        };

        I.PopRenderTarget = function()
        {
            this.Flush();
            var res = Uno.Application.Current().GraphicsContext().RenderTarget();
            var k = Uno.Collections.IListExtensions.RemoveLast__Fuse_RenderTargetEntry($DownCast(Fuse.DrawContext.renderTargets, 32930));
            Uno.Application.Current().GraphicsContext().SetRenderTarget_1(k.RenderTarget, $DownCast(k.Viewport, 463), $DownCast(k.Scissor, 463));
            return res;
        };

        I.Clear = function(color, depth)
        {
            Uno.Application.Current().GraphicsContext().Clear(color, depth);
        };

        Fuse.DrawContext._TypeInit = function()
        {
            Fuse.DrawContext._current = Fuse.DrawContext.New_1();
            Fuse.DrawContext.renderTargets = Uno.Collections.List__Fuse_RenderTargetEntry.New_1();
            Fuse.DrawContext._scissors = Uno.Collections.List__Uno_Recti.New_1();
        };

        I._ObjInit_2 = function()
        {
            this._rootTransform = Fuse.FastMatrix.Identity();
            this._rootTransformStack = Uno.Collections.List__Fuse_FastMatrix.New_1();
            this.scissors = Uno.Collections.List__Uno_Recti.New_1();
            this.passes = Uno.Collections.List__Fuse_Pass.New_1();
            Fuse.TraverseContext.prototype._ObjInit_1.call(this, null);
        };

        Fuse.DrawContext.New_1 = function()
        {
            var inst = new Fuse.DrawContext;
            inst._ObjInit_2();
            return inst;
        };

    });
