Fuse.PlacedArgs = $CreateClass(
    function() {
        Uno.EventArgs.call(this);
        this._HasOldPosition = false;
        this._OldPosition = new Uno.Float2;
        this._NewPosition = new Uno.Float2;
    },
    function(S) {
        var I = S.prototype = new Uno.EventArgs;

        I.GetType = function()
        {
            return 997;
        };

        I.HasOldPosition = function(value)
        {
            if (value !== undefined)
            {
                this._HasOldPosition = value;
            }
            else
            {
                return this._HasOldPosition;
            }
        };

        I.OldPosition = function(value)
        {
            if (value !== undefined)
            {
                this._OldPosition.op_Assign(value);
            }
            else
            {
                return this._OldPosition;
            }
        };

        I.NewPosition = function(value)
        {
            if (value !== undefined)
            {
                this._NewPosition.op_Assign(value);
            }
            else
            {
                return this._NewPosition;
            }
        };

        I._ObjInit_1 = function(hasOldPosition, oldPos, newPos)
        {
            Uno.EventArgs.prototype._ObjInit.call(this);
            this.HasOldPosition(hasOldPosition);
            this.OldPosition(oldPos);
            this.NewPosition(newPos);
        };

        Fuse.PlacedArgs.New_2 = function(hasOldPosition, oldPos, newPos)
        {
            var inst = new Fuse.PlacedArgs;
            inst._ObjInit_1(hasOldPosition, oldPos, newPos);
            return inst;
        };

    });
