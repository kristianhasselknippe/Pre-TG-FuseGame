Fuse.FramebufferPoolImpl = $CreateClass(
    function() {
        this.frame = 0;
        this.framebufferPool = null;
        this.lastFrameUsed = null;
        this.lockedFramebuffers = null;
        this.cacheFramebuffers = null;
        this.framebuffersProvidedSinceLastCollect = 0;
        this.pixelsProvidedSinceLastCollect = 0;
        this._liveBuffers = 0;
        this._liveMemory = 0;
    },
    function(S) {
        var I = S.prototype;

        I.GetType = function()
        {
            return 947;
        };

        I.FindBuffer = function(width, height, format, flags)
        {
            {
                Fuse.Profiling.Context.PushNode(Uno.String.op_Addition_1(Uno.String.op_Addition(Uno.String.op_Addition_1("Allocating framebuffer: ", $CreateBox(width, 425)), "x"), $CreateBox(height, 425)));
            }

            width = Uno.Math.Max_8(1, width);
            height = Uno.Math.Max_8(1, height);

            for (var i = 0; i < this.framebufferPool.Count(); i++)
            {
                var fb = this.framebufferPool.Item(i);

                if (fb.Size().X != width)
                {
                    continue;
                }

                if (fb.Size().Y != height)
                {
                    continue;
                }

                if (fb.Format() != format)
                {
                    continue;
                }

                if (fb.HasDepth() != ((flags & 1) == 1))
                {
                    continue;
                }

                if (fb.SupportsMipmap() != ((flags & 2) == 2))
                {
                    continue;
                }

                this.framebufferPool.RemoveAt(i);
                this.lockedFramebuffers.Add(fb);
                this.lastFrameUsed.Item(fb, this.frame);
                {
                    Fuse.Profiling.Context.PopNode();
                }

                return fb;
            }

            {
                Fuse.Profiling.Context.PushNode(Uno.String.op_Addition_1(Uno.String.op_Addition(Uno.String.op_Addition_1("Allocating framebuffer: ", $CreateBox(width, 425)), "x"), $CreateBox(height, 425)));
            }

            var maxSize = Uno.Graphics.Texture2D.MaxSize();

            if ((width > maxSize) || (height > maxSize))
            {
                throw new $Error(Uno.Exception.New_1(Uno.String.op_Addition_1(Uno.String.op_Addition(Uno.String.op_Addition_1(Uno.String.op_Addition(Uno.String.op_Addition_1(Uno.String.op_Addition(Uno.String.op_Addition_1("Attempted to allocate ", $CreateBox(width, 425)), "x"), $CreateBox(height, 425)), " framebuffer, max is "), $CreateBox(maxSize, 425)), "x"), $CreateBox(maxSize, 425))));
            }

            var buffer = Uno.Graphics.Framebuffer.New_1(Uno.Int2.New_2(width, height), format, flags);
            this.LogNew(buffer);
            {
                Fuse.Profiling.Context.PopNode();
                Fuse.Profiling.Context.PopNode();
            }

            return buffer;
        };

        I.Register = function(cfb)
        {
            this.framebuffersProvidedSinceLastCollect = this.framebuffersProvidedSinceLastCollect + 1;
            this.pixelsProvidedSinceLastCollect = this.pixelsProvidedSinceLastCollect + (cfb.Width() * cfb.Height());
            this.cacheFramebuffers.Add(cfb);

            if (this.pixelsProvidedSinceLastCollect > 10000000)
            {
                this.CollectCacheFramebuffers();
            }
            else if (this.framebuffersProvidedSinceLastCollect > 50)
            {
                this.CollectCacheFramebuffers();
            }
        };

        I.UnRegister = function(cfb)
        {
            this.framebuffersProvidedSinceLastCollect = 0;
            this.pixelsProvidedSinceLastCollect = this.pixelsProvidedSinceLastCollect - (cfb.Width() * cfb.Height());
            this.cacheFramebuffers.Remove(cfb);
        };

        I.CollectCacheFramebuffers = function()
        {
            if (this.cacheFramebuffers.Count() < 3)
            {
                return;
            }

            var sum = 0;

            for (var enum_123 = this.cacheFramebuffers.GetEnumerator(); enum_123.MoveNext(); )
            {
                var cfb = enum_123.Current();
                sum = sum + cfb.FramesSinceLastUse();
            }

            var avg = (sum / this.cacheFramebuffers.Count()) | 0;
            var limit = avg + 3;

            for (var i = 0; i < this.cacheFramebuffers.Count(); i++)
            {
                var c = this.cacheFramebuffers.Item(i);

                if (!c.IsPinned() && (c.FramesSinceLastUse() >= limit))
                {
                    c.Collect();
                    this.cacheFramebuffers.RemoveAt(i--);
                }
            }

            this.framebuffersProvidedSinceLastCollect = 0;
            this.pixelsProvidedSinceLastCollect = 0;
        };

        I.Lock = function(width, height, format, depth)
        {
            var fb = this.FindBuffer(width, height, format, depth ? 1 : 0);
            this.lastFrameUsed.Item(fb, this.frame);
            this.lockedFramebuffers.Add(fb);
            return fb;
        };

        I.Release = function(fb)
        {
            if (this.lockedFramebuffers.Contains(fb))
            {
                this.lockedFramebuffers.Remove(fb);
                this.lastFrameUsed.Item(fb, this.frame);
                this.framebufferPool.Add(fb);
            }
        };

        I.Update = function()
        {
            this.frame++;

            for (var i = 0; i < this.framebufferPool.Count(); i++)
            {
                var fb = this.framebufferPool.Item(i);
                var framesSinceUse;
                this.lastFrameUsed.TryGetValue(fb, $CreateRef(function(){return framesSinceUse}, function($){framesSinceUse=$}, this));
                framesSinceUse = this.frame - framesSinceUse;

                if (framesSinceUse < 0)
                {
                    throw new $Error(Uno.Exception.New_1("Pool is leaking"));
                }

                if (framesSinceUse > 1)
                {
                    this.LogFree(fb);
                    fb.Dispose();
                    this.framebufferPool.RemoveAt(i--);
                    this.lastFrameUsed.Remove(fb);
                }
            }
        };

        I.LogNew = function(fb)
        {
            this._liveBuffers = this._liveBuffers + 1;
            this._liveMemory = this._liveMemory + this.SizeOf(fb);
            this.LogStatus();
        };

        I.LogFree = function(fb)
        {
            this._liveBuffers = this._liveBuffers - 1;
            this._liveMemory = this._liveMemory - this.SizeOf(fb);
            this.LogStatus();
        };

        I.LogStatus = function()
        {
        };

        I.SizeOf = function(buffer)
        {
            return ((buffer.ColorBuffer().Size().X * buffer.ColorBuffer().Size().Y) * 4) * (buffer.HasDepth() ? 2 : 1);
        };

        I._ObjInit = function()
        {
            this.framebufferPool = Uno.Collections.List__framebuffer.New_1();
            this.lastFrameUsed = Uno.Collections.Dictionary__framebuffer__int.New_1();
            this.lockedFramebuffers = Uno.Collections.HashSet__framebuffer.New_1();
            this.cacheFramebuffers = Uno.Collections.List__Fuse_CacheFramebuffer.New_1();
            Fuse.UpdateManager.AddAction($CreateDelegate(this, Fuse.FramebufferPoolImpl.prototype.Update, 436), 0);
        };

        Fuse.FramebufferPoolImpl.New_1 = function()
        {
            var inst = new Fuse.FramebufferPoolImpl;
            inst._ObjInit();
            return inst;
        };

    });
