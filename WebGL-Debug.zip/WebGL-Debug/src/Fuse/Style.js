Fuse.Style = $CreateClass(
    function() {
        this._templates = null;
        this._Resources = null;
    },
    function(S) {
        var I = S.prototype;

        I.GetType = function()
        {
            return 960;
        };

        I.$II = function(id)
        {
            return [393].indexOf(id) != -1;
        };

        I.Templates = function()
        {
            var ind_123 = this._templates;
            return (ind_123 != null) ? ind_123 : (this._templates = $DownCast(Uno.Collections.List__Uno_UX_ITemplate.New_1(), 32914));
        };

        I.Resources = function(value)
        {
            if (value !== undefined)
            {
                this._Resources = value;
            }
            else
            {
                return this._Resources;
            }
        };

        I.Apply = function(target)
        {
            if (this._templates != null)
            {
                for (var i = 0; i < this._templates["Uno.Collections.ICollection__Uno_UX_ITemplate.Count"](); i++)
                {
                    if (!this._templates["Uno.Collections.IList__Uno_UX_ITemplate.Item"](i)["Uno.UX.ITemplate.Apply"](target))
                    {
                        return false;
                    }
                }
            }

            return true;
        };

        I.GetResource = function(key)
        {
            if (this.Resources() != null)
            {
                var res = this.Resources().Item(key);

                if (res != null)
                {
                    return res;
                }
            }

            return null;
        };

        I._ObjInit = function()
        {
        };

        I["Uno.UX.ITemplate.Apply"] = I.Apply;

    });
