Fuse.Keyboard = $CreateClass(
    function() {
    },
    function(S) {
        Fuse.Keyboard._keysDown = null;
        Fuse.Keyboard._KeyPressedTriggers = null;
        Fuse.Keyboard._KeyReleasedTriggers = null;
        Fuse.Keyboard._keyboardHandle = null;
        Fuse.Keyboard._initialized = false;

        Fuse.Keyboard.EnsureInitialized = function()
        {
            if (!Fuse.Keyboard._initialized)
            {
                Uno.Application.Current().Window().add_KeyPressed($CreateDelegate(null, Fuse.Keyboard.PlatformKeyPressed, 493));
                Uno.Application.Current().Window().add_KeyReleased($CreateDelegate(null, Fuse.Keyboard.PlatformKeyReleased, 493));
                Fuse.UpdateManager.AddAction($CreateDelegate(null, Fuse.Keyboard.Update, 436), 0);
                Fuse.Keyboard._initialized = true;
            }
        };

        Fuse.Keyboard.Update = function()
        {
            Fuse.Keyboard._KeyPressedTriggers.Clear();
            Fuse.Keyboard._KeyReleasedTriggers.Clear();
        };

        Fuse.Keyboard.PlatformKeyPressed = function(sender, e)
        {
            e.Handled(Fuse.Keyboard.RaiseKeyPressed(e.Key()).IsHandled());
        };

        Fuse.Keyboard.PlatformKeyReleased = function(sender, e)
        {
            e.Handled(Fuse.Keyboard.RaiseKeyReleased(e.Key()).IsHandled());
        };

        Fuse.Keyboard.AddKeyPressedHandler = function(node, handler)
        {
            Fuse.Keyboard.EnsureInitialized();
            node.AddToList(Fuse.Keyboard._keyboardHandle, handler);
        };

        Fuse.Keyboard.RaiseKeyPressed = function(key)
        {
            Fuse.Keyboard.EnsureInitialized();
            var args = Fuse.KeyPressedArgs.New_2(key);
            Fuse.Keyboard._keysDown.Add(args);
            Fuse.Keyboard._KeyPressedTriggers.Add(args);
            return Fuse.Keyboard.BubbleEvent($AsOp(Fuse.FocusManager.FocusedObject(), 978), args);
        };

        Fuse.Keyboard.BubbleEvent = function(node, args)
        {
            if (node == null)
            {
                return args;
            }

            node.ForeachInList_1(Fuse.Keyboard._keyboardHandle, $CreateDelegate(null, Fuse.Keyboard.RaiseKeyPressedEvent, 489), Array.Init([node, args], 413));
            return Fuse.Keyboard.BubbleEvent($AsOp(node.Parent(), 978), args);
        };

        Fuse.Keyboard.RaiseKeyPressedEvent = function(handler, state)
        {
            if ($IsOp(handler, 974))
            {
                $DownCast(handler, 974).Invoke($DownCast(state[0], 978), $DownCast(state[1], 973));
            }
        };

        Fuse.Keyboard.RaiseKeyReleased = function(key)
        {
            Fuse.Keyboard.EnsureInitialized();
            var args = Fuse.KeyReleasedArgs.New_2(key);

            for (var i = 0; i < Fuse.Keyboard._keysDown.Count(); i++)
            {
                if (Fuse.Keyboard._keysDown.Item(i).Key() == args.Key())
                {
                    Fuse.Keyboard._keysDown.RemoveAt(i--);
                }
            }

            Fuse.Keyboard._KeyReleasedTriggers.Add(args);
            return Fuse.Keyboard.BubbleEvent_1($AsOp(Fuse.FocusManager.FocusedObject(), 978), args);
        };

        Fuse.Keyboard.BubbleEvent_1 = function(node, args)
        {
            if (node == null)
            {
                return args;
            }

            node.ForeachInList_1(Fuse.Keyboard._keyboardHandle, $CreateDelegate(null, Fuse.Keyboard.RaiseKeyReleasedEvent, 489), Array.Init([node, args], 413));
            return Fuse.Keyboard.BubbleEvent_1($AsOp(node.Parent(), 978), args);
        };

        Fuse.Keyboard.RaiseKeyReleasedEvent = function(handler, state)
        {
            if ($IsOp(handler, 976))
            {
                $DownCast(handler, 976).Invoke($DownCast(state[0], 978), $DownCast(state[1], 975));
            }
        };

        Fuse.Keyboard._TypeInit = function()
        {
            Fuse.Keyboard._keysDown = Uno.Collections.List__Fuse_KeyPressedArgs.New_1();
            Fuse.Keyboard._KeyPressedTriggers = Uno.Collections.List__Fuse_KeyPressedArgs.New_1();
            Fuse.Keyboard._KeyReleasedTriggers = Uno.Collections.List__Fuse_KeyReleasedArgs.New_1();
            Fuse.Keyboard._keyboardHandle = Fuse.PropertyHandle.New_1();
        };

    });
