Fuse.CustomPointerEventArgs = $CreateClass(
    function() {
        Fuse.PointerEventArgs.call(this);
    },
    function(S) {
        var I = S.prototype = new Fuse.PointerEventArgs;

        I.GetType = function()
        {
            return 922;
        };

        I._ObjInit_3 = function(args)
        {
            Fuse.PointerEventArgs.prototype._ObjInit_2.call(this, args.Data());
        };

    });
