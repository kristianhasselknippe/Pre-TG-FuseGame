Fuse.CanvasTextRenderer = $CreateClass(
    function() {
        this._fontFace = null;
        this._handle = null;
        this._tex = null;
        this._fontSize = 0;
        this._absoluteZoom = 0;
        this._bounds = new Uno.Float2;
        this._transform = new Uno.Float4x4;
        this._textColor = new Uno.Float4;
        this._w = 0;
        this._h = 0;
        this.EndRendering_Coord_7d102b09_1_1_1 = null;
        this.EndRendering_Vertices_7d102b09_1_0_5 = null;
        this._draw_7d102b09 = new Uno.Runtime.Implementation.ShaderBackends.OpenGL.GLDrawCall;
    },
    function(S) {
        var I = S.prototype;

        I.GetType = function()
        {
            return 1016;
        };

        I.$II = function(id)
        {
            return [812].indexOf(id) != -1;
        };

        I.GetLineHeight = function(fontSize)
        {
            return fontSize * 1.5;
        };

        I.MeasureString = function(fontSize, absoluteZoom, s)
        {
            if (Uno.String.op_Equality(s, null))
            {
                return Uno.Float2.New_1(0.0);
            }

            var fs = fontSize * absoluteZoom;
            Fuse.CanvasTextRendererImpl.UpdateFontSize(this._handle, fs);
            return Uno.Float2.New_2(Fuse.CanvasTextRendererImpl.MeasureStringVirtual(this._handle, s), this.GetLineHeight(fs));
        };

        I.MeasureStringVirtual = function(fontSize, absoluteZoom, s)
        {
            return Uno.Float2.op_Division_1(this.MeasureString(fontSize, absoluteZoom, s), absoluteZoom);
        };

        I.BeginRendering = function(fontSize, absoluteZoom, transform, bounds, textColor, maxTextLength)
        {
            this._fontSize = fontSize;
            this._absoluteZoom = absoluteZoom;
            this._transform = Uno.Float4x4.op_Multiply(transform, this._absoluteZoom);
            this._bounds = Uno.Float2.op_Multiply(bounds, this._absoluteZoom);
            this._textColor.op_Assign(textColor);
            this._w = Uno.Math.Max_8(Uno.Math.Ceil_1(this._bounds.X) | 0, 1);
            this._h = Uno.Math.Max_8(Uno.Math.Ceil_1(this._bounds.Y) | 0, 1);
            Fuse.CanvasTextRendererImpl.BeginRendering(this._handle, this._w, this._h, this._fontSize * this._absoluteZoom);
        };

        I.EndRendering = function(dc)
        {
            var ind_126;
            var bitmap = Fuse.CanvasTextRendererImpl.EndRendering(this._handle, this._w, this._h);

            if ((this._tex != null) && ((this._tex.Size().X != bitmap.Size().X) || (this._tex.Size().Y != bitmap.Size().Y)))
            {
                this._tex.Dispose();
            }

            this._tex = Uno.Graphics.Texture2D.New_2(bitmap.Size(), bitmap.Format(), false);
            this._tex.Update_1(bitmap.Buffer());
            {
                this._draw_7d102b09.BlendEnabled(true);
                this._draw_7d102b09.BlendSrcRgb(2);
                this._draw_7d102b09.BlendDstRgb(3);
                this._draw_7d102b09.BlendDstAlpha(3);
                this._draw_7d102b09.DepthTestEnabled(false);
                this._draw_7d102b09.CullFace(0);
                this._draw_7d102b09.Use();
                this._draw_7d102b09.Attrib_1(0, 2, this.EndRendering_Coord_7d102b09_1_1_1, 8, 0);
                this._draw_7d102b09.Uniform_9(1, Uno.Float2.New_2(this._w, this._h));
                this._draw_7d102b09.Uniform_14(2, this._transform);
                this._draw_7d102b09.Uniform_9(3, Fuse.Spaces.VirtualResolution());
                this._draw_7d102b09.Uniform_8(4, this._textColor.W);
                this._draw_7d102b09.Uniform_10(5, (ind_126 = this._textColor, Uno.Float3.New_2(ind_126.X, ind_126.Y, ind_126.Z)));
                this._draw_7d102b09.Sampler_2(6, this._tex);
                this._draw_7d102b09.DrawArrays(this.EndRendering_Vertices_7d102b09_1_0_5.length);
            }
        };

        I.DrawLine = function(dc, x, y, line)
        {
            var adjustedX = Uno.Math.Floor_1((x * dc.ResolutionMultiplier()) + 0.5);
            var adjustedY = Uno.Math.Floor_1((y + (this.GetLineHeight(this._fontSize) / 2.0)) * this._absoluteZoom);
            Fuse.CanvasTextRendererImpl.DrawText(this._handle, adjustedX, adjustedY, line);
        };

        I.init_DrawCalls = function()
        {
            var Vertices_7d102b09_1_0_0 = Array.Init([Uno.Float2.New_2(0.0, 0.0), Uno.Float2.New_2(0.0, 1.0), Uno.Float2.New_2(1.0, 1.0), Uno.Float2.New_2(0.0, 0.0), Uno.Float2.New_2(1.0, 1.0), Uno.Float2.New_2(1.0, 0.0)], 430);
            this.EndRendering_Coord_7d102b09_1_1_1 = Uno.Graphics.VertexBuffer.New_3(Uno.Runtime.Implementation.Internal.BufferConverters.ToBuffer_1(Vertices_7d102b09_1_0_0), 0);
            this.EndRendering_Vertices_7d102b09_1_0_5 = Vertices_7d102b09_1_0_0;
            this._draw_7d102b09 = Uno.Runtime.Implementation.ShaderBackends.OpenGL.GLDrawCall.New_1($DownCast(Uno.Runtime.Implementation.Internal.BundleRegistry.Get(46), 383));
        };

        I._ObjInit = function(fontFace)
        {
            this._fontFace = fontFace;
            this._handle = Fuse.CanvasTextRendererImpl.Create(this._fontFace.StyleName());
            this.init_DrawCalls();
        };

        Fuse.CanvasTextRenderer.New_1 = function(fontFace)
        {
            var inst = new Fuse.CanvasTextRenderer;
            inst._ObjInit(fontFace);
            return inst;
        };

        I["Fuse.Internal.ITextRenderer.GetLineHeight"] = I.GetLineHeight;
        I["Fuse.Internal.ITextRenderer.MeasureStringVirtual"] = I.MeasureStringVirtual;
        I["Fuse.Internal.ITextRenderer.BeginRendering"] = I.BeginRendering;
        I["Fuse.Internal.ITextRenderer.DrawLine"] = I.DrawLine;
        I["Fuse.Internal.ITextRenderer.EndRendering"] = I.EndRendering;

    });
