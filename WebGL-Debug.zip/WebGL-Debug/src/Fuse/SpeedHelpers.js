Fuse.SpeedHelpers = $CreateClass(
    function() {
    },
    function(S) {

        Fuse.SpeedHelpers.FastEquals = function(a, b)
        {
            var a_123 = new Uno.Float4;
            var b_124 = new Uno.Float4;
            a_123.op_Assign(a);
            b_124.op_Assign(b);
            return (((a_123.X == b_124.X) && (a_123.Y == b_124.Y)) && (a_123.Z == b_124.Z)) && (a_123.W == b_124.W);
        };

    });
