Fuse.Transform = $CreateClass(
    function() {
        this.AddedByStyle = false;
        this.MatrixChanged = null;
    },
    function(S) {
        var I = S.prototype;

        I.GetType = function()
        {
            return 912;
        };

        I.Added = function(n)
        {
            this.OnAdded(n);
        };

        I.Removed = function(n)
        {
            this.OnRemoved(n);
        };

        I.OnAdded = function(n)
        {
        };

        I.OnRemoved = function(n)
        {
        };

        I.OnMatrixChanged = function()
        {
            if (Uno.Delegate.op_Inequality(this.MatrixChanged, null))
            {
                this.MatrixChanged.Invoke(this);
            }
        };

        I._ObjInit = function()
        {
        };

        I.add_MatrixChanged = function(value)
        {
            this.MatrixChanged = $DownCast(Uno.Delegate.Combine(this.MatrixChanged, value), 477);
        };

        I.remove_MatrixChanged = function(value)
        {
            this.MatrixChanged = $DownCast(Uno.Delegate.Remove(this.MatrixChanged, value), 477);
        };

    });
