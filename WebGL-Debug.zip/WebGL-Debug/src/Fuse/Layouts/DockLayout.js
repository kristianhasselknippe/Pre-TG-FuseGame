Fuse.Layouts.DockLayout = $CreateClass(
    function() {
        Fuse.Layouts.Layout.call(this);
        this.lastChildFill = false;
        this._subscriber = null;
    },
    function(S) {
        var I = S.prototype = new Fuse.Layouts.Layout;

        Fuse.Layouts.DockLayout._dockProperty = null;

        I.GetType = function()
        {
            return 902;
        };

        I.LastChildFill = function(value)
        {
            if (value !== undefined)
            {
                if (this.lastChildFill != value)
                {
                    this.lastChildFill = value;

                    if (this._subscriber != null)
                    {
                        this._subscriber.InvalidateLayout();
                    }
                }
            }
            else
            {
                return this.lastChildFill;
            }
        };

        Fuse.Layouts.DockLayout.SetDock = function(elm, dock)
        {
            elm.SetValue(Fuse.Layouts.DockLayout._dockProperty, $CreateBox(dock, 901));
            elm.InvalidateLayout();
        };

        Fuse.Layouts.DockLayout.GetDock = function(elm)
        {
            var val;

            if (elm.TryGetValue(Fuse.Layouts.DockLayout._dockProperty, $CreateRef(function(){return val}, function($){val=$}, this)))
            {
                return $DownCast(val, 901);
            }

            return 0;
        };

        I.AddSubscriber = function(element)
        {
            this._subscriber = element;
        };

        I.RemoveSubscriber = function(element)
        {
            this._subscriber = null;
        };

        I.GetContentSize = function(elements, fillSize, fillSet)
        {
            return this.MeasureSubtree(elements, 0, fillSize, fillSet);
        };

        I.MeasureSubtree = function(elements, childIndex, fillSize, fillSet)
        {
            var fillSize_124 = new Uno.Float2;
            var cds_125 = new Uno.Float2;
            var subtree_126 = new Uno.Float2;
            var cds_127 = new Uno.Float2;
            var subtree_128 = new Uno.Float2;
            fillSize_124.op_Assign(fillSize);

            if (childIndex >= elements["Uno.Collections.ICollection__Fuse_Element.Count"]())
            {
                return Uno.Float2.New_1(0.0);
            }

            var c = elements["Uno.Collections.IList__Fuse_Element.Item"](childIndex);
            var isLastChild = childIndex == (elements["Uno.Collections.ICollection__Fuse_Element.Count"]() - 1);

            if (isLastChild && this.LastChildFill())
            {
                return c.GetMarginSize(fillSize_124, fillSet);
            }

            switch (Fuse.Layouts.DockLayout.GetDock(c))
            {
                case 0:
                case 1:
                {
                    {
                        cds_125.op_Assign(c.GetMarginSize(fillSize_124, fillSet & -2));
                        fillSize_124.X = fillSize_124.X - cds_125.X;
                        subtree_126.op_Assign(this.MeasureSubtree(elements, childIndex + 1, fillSize_124, fillSet));
                        return Uno.Float2.New_2(cds_125.X + subtree_126.X, Uno.Math.Max_1(cds_125.Y, subtree_126.Y));
                    }
                }
                case 2:
                case 3:
                {
                    {
                        cds_127.op_Assign(c.GetMarginSize(fillSize_124, fillSet & -3));
                        fillSize_124.Y = fillSize_124.Y - cds_127.Y;
                        subtree_128.op_Assign(this.MeasureSubtree(elements, childIndex + 1, fillSize_124, fillSet));
                        return Uno.Float2.New_2(Uno.Math.Max_1(cds_127.X, subtree_128.X), cds_127.Y + subtree_128.Y);
                    }
                }
                default:
                {
                    throw new $Error(Uno.Exception.New_1("Unknown dock mode"));
                }
            }
        };

        I.ArrangePaddingBox = function(elements, padding, finalSize)
        {
            var padding_129 = new Uno.Float4;
            var availablePosition_131 = new Uno.Float2;
            var desiredSize_132 = new Uno.Float2;
            padding_129.op_Assign(padding);
            availablePosition_131.op_Assign(Uno.Float2.New_2(padding_129.X, padding_129.Y));
            var availableSize = Uno.Float2.op_Subtraction(Uno.Float2.op_Subtraction(finalSize, Uno.Float2.New_2(padding_129.X, padding_129.Y)), Uno.Float2.New_2(padding_129.Z, padding_129.W));

            for (var i = 0; i < elements["Uno.Collections.ICollection__Fuse_Element.Count"](); i++)
            {
                var c = elements["Uno.Collections.IList__Fuse_Element.Item"](i);

                if (!this.LastChildFill() || (i < (elements["Uno.Collections.ICollection__Fuse_Element.Count"]() - 1)))
                {
                    var d = Fuse.Layouts.DockLayout.GetDock(c);
                    var sf = ((d == 0) || (d == 1)) ? 2 : 1;
                    desiredSize_132.op_Assign(c.GetMarginSize(availableSize, sf));

                    switch (d)
                    {
                        case 0:
                        {
                            desiredSize_132.Y = availableSize.Y;
                            c.ArrangeMarginBox(availablePosition_131, desiredSize_132, 3);
                            availablePosition_131.X = availablePosition_131.X + desiredSize_132.X;
                            availableSize.X = availableSize.X - desiredSize_132.X;
                            break;
                        }
                        case 1:
                        {
                            desiredSize_132.Y = availableSize.Y;
                            c.ArrangeMarginBox(Uno.Float2.New_2((availablePosition_131.X + availableSize.X) - desiredSize_132.X, availablePosition_131.Y), desiredSize_132, 3);
                            availableSize.X = availableSize.X - desiredSize_132.X;
                            break;
                        }
                        case 2:
                        {
                            desiredSize_132.X = availableSize.X;
                            c.ArrangeMarginBox(availablePosition_131, desiredSize_132, 3);
                            availablePosition_131.Y = availablePosition_131.Y + desiredSize_132.Y;
                            availableSize.Y = availableSize.Y - desiredSize_132.Y;
                            break;
                        }
                        case 3:
                        {
                            desiredSize_132.X = availableSize.X;
                            c.ArrangeMarginBox(Uno.Float2.New_2(availablePosition_131.X, (availablePosition_131.Y + availableSize.Y) - desiredSize_132.Y), desiredSize_132, 3);
                            availableSize.Y = availableSize.Y - desiredSize_132.Y;
                            break;
                        }
                    }
                }
                else
                {
                    c.ArrangeMarginBox(availablePosition_131, availableSize, 3);
                }

                availableSize = Uno.Math.Max_3(availableSize, Uno.Float2.New_1(0.0));
            }
        };

        Fuse.Layouts.DockLayout._TypeInit = function()
        {
            Fuse.Layouts.DockLayout._dockProperty = Fuse.PropertyHandle.New_1();
        };

        I._ObjInit_1 = function()
        {
            this.lastChildFill = true;
            Fuse.Layouts.Layout.prototype._ObjInit.call(this);
        };

        Fuse.Layouts.DockLayout.New_1 = function()
        {
            var inst = new Fuse.Layouts.DockLayout;
            inst._ObjInit_1();
            return inst;
        };

    });
