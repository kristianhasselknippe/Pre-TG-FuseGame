Fuse.Layouts.DefinitionBase = $CreateClass(
    function() {
        this._actualOffset = 0;
        this.Changed = null;
    },
    function(S) {
        var I = S.prototype;

        I.GetType = function()
        {
            return 903;
        };

        I.ActualOffset = function(value)
        {
            if (value !== undefined)
            {
                this._actualOffset = value;
            }
            else
            {
                return this._actualOffset;
            }
        };

        I.OnChanged = function()
        {
            if (Uno.Delegate.op_Inequality(this.Changed, null))
            {
                this.Changed.Invoke();
            }
        };

    });
