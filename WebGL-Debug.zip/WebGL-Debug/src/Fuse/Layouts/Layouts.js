Fuse.Layouts.Layouts = $CreateClass(
    function() {
    },
    function(S) {
        Fuse.Layouts.Layouts.Default = null;

        Fuse.Layouts.Layouts._TypeInit = function()
        {
            Fuse.Layouts.Layouts.Default = Fuse.Layouts.DefaultLayout.New_1();
        };

    });
