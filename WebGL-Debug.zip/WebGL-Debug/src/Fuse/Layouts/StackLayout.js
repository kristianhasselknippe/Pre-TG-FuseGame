Fuse.Layouts.StackLayout = $CreateClass(
    function() {
        Fuse.Layouts.Layout.call(this);
        this._orientation = 0;
        this._subscriber = null;
    },
    function(S) {
        var I = S.prototype = new Fuse.Layouts.Layout;

        I.GetType = function()
        {
            return 911;
        };

        I.Orientation = function(value)
        {
            if (value !== undefined)
            {
                if (this._orientation != value)
                {
                    this._orientation = value;
                    this.OnOrientationChanged();
                }
            }
            else
            {
                return this._orientation;
            }
        };

        I.OnOrientationChanged = function()
        {
            if (this._subscriber != null)
            {
                this._subscriber.InvalidateLayout();
                this._subscriber.InvalidateVisual();
            }
        };

        I.AddSubscriber = function(element)
        {
            this._subscriber = element;
        };

        I.RemoveSubscriber = function(element)
        {
            this._subscriber = null;
        };

        I.GetContentSize = function(elements, fillSize, fillSet)
        {
            var fillSize_123 = new Uno.Float2;
            fillSize_123.op_Assign(fillSize);
            var orientation = this.Orientation();

            if (orientation == 1)
            {
                fillSet = fillSet & -3;
            }
            else
            {
                fillSet = fillSet & -2;
            }

            var size = this.GetElementsSize(elements, fillSize_123, fillSet);
            var recalc = false;

            if (orientation == 1)
            {
                if (!((fillSet & 1) == 1))
                {
                    fillSize_123.X = size.X;
                    fillSet = fillSet | 1;
                    recalc = true;
                }
            }
            else
            {
                if (!((fillSet & 2) == 2))
                {
                    fillSize_123.Y = size.Y;
                    fillSet = fillSet | 2;
                    recalc = true;
                }
            }

            if (recalc)
            {
                size = this.GetElementsSize(elements, fillSize_123, fillSet);
            }

            return size;
        };

        I.GetElementsSize = function(elements, fillSize, fillSet)
        {
            var cds_125 = new Uno.Float2;
            var orientation = this.Orientation();
            var desiredSize = Uno.Float2.New_1(0.0);

            for (var i = 0; i < elements["Uno.Collections.ICollection__Fuse_Element.Count"](); i++)
            {
                var c = elements["Uno.Collections.IList__Fuse_Element.Item"](i);
                cds_125.op_Assign(c.GetMarginSize(fillSize, fillSet));

                if (orientation == 0)
                {
                    desiredSize.X = desiredSize.X + cds_125.X;
                    desiredSize.Y = Uno.Math.Max_1(desiredSize.Y, cds_125.Y);
                }
                else
                {
                    desiredSize.X = Uno.Math.Max_1(desiredSize.X, cds_125.X);
                    desiredSize.Y = desiredSize.Y + cds_125.Y;
                }
            }

            return desiredSize;
        };

        I.ArrangePaddingBox = function(elements, padding, availableSize)
        {
            var padding_126 = new Uno.Float4;
            var paddingOffset_128 = new Uno.Float2;
            var cds_129 = new Uno.Float2;
            var cds_130 = new Uno.Float2;
            padding_126.op_Assign(padding);
            var d = 0.0;
            var orientation = this.Orientation();
            paddingOffset_128.op_Assign(Uno.Float2.New_2(padding_126.X, padding_126.Y));
            var pad = Uno.Float2.op_Addition(Uno.Float2.New_2(padding_126.X, padding_126.Y), Uno.Float2.New_2(padding_126.Z, padding_126.W));
            var avs = Uno.Float2.op_Subtraction(availableSize, pad);
            var sf = (orientation == 1) ? 1 : 2;

            for (var i = 0; i < elements["Uno.Collections.ICollection__Fuse_Element.Count"](); i++)
            {
                var c = elements["Uno.Collections.IList__Fuse_Element.Item"](i);

                if (orientation == 0)
                {
                    cds_129.op_Assign(c.ArrangeMarginBox(Uno.Float2.op_Addition(Uno.Float2.New_2(d, 0.0), paddingOffset_128), avs, sf));
                    d = d + cds_129.X;
                }
                else
                {
                    cds_130.op_Assign(c.ArrangeMarginBox(Uno.Float2.op_Addition(Uno.Float2.New_2(0.0, d), paddingOffset_128), avs, sf));
                    d = d + cds_130.Y;
                }
            }
        };

    });
