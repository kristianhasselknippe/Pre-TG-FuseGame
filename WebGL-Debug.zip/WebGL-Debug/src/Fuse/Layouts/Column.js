Fuse.Layouts.Column = $CreateClass(
    function() {
        Fuse.Layouts.DefinitionBase.call(this);
        this._widthMetric = 0;
        this._width = 0;
        this._actualWidth = 0;
    },
    function(S) {
        var I = S.prototype = new Fuse.Layouts.DefinitionBase;

        I.GetType = function()
        {
            return 905;
        };

        I.WidthMetric = function(value)
        {
            if (value !== undefined)
            {
                if (this._widthMetric != value)
                {
                    this._widthMetric = value;
                    this.OnChanged();
                }
            }
            else
            {
                return this._widthMetric;
            }
        };

        I.Width = function(value)
        {
            if (value !== undefined)
            {
                if (this._width != value)
                {
                    this._width = Uno.Math.Max_1(0.0, value);
                    this.OnChanged();
                }
            }
            else
            {
                return this._width;
            }
        };

        I.ActualWidth = function(value)
        {
            if (value !== undefined)
            {
                this._actualWidth = value;
            }
            else
            {
                if (this.WidthMetric() == 0)
                {
                    return this._width;
                }
                else
                {
                    return this._actualWidth;
                }
            }
        };

    });
