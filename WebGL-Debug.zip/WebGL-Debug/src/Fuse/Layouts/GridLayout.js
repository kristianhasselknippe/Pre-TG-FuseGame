Fuse.Layouts.GridLayout = $CreateClass(
    function() {
        Fuse.Layouts.Layout.call(this);
        this._rows = null;
        this._columns = null;
        this._subscriber = null;
    },
    function(S) {
        var I = S.prototype = new Fuse.Layouts.Layout;

        Fuse.Layouts.GridLayout._rowProperty = null;
        Fuse.Layouts.GridLayout._rowSpanProperty = null;
        Fuse.Layouts.GridLayout._columnProperty = null;
        Fuse.Layouts.GridLayout._columnSpanProperty = null;

        I.GetType = function()
        {
            return 907;
        };

        I.Columns = function()
        {
            return $DownCast(this._columns, 32925);
        };

        I.GetActualRow = function(elm, index)
        {
            var v;

            if (elm.TryGetValue(Fuse.Layouts.GridLayout._rowProperty, $CreateRef(function(){return v}, function($){v=$}, this)))
            {
                return $DownCast(v, 425);
            }
            else
            {
                return (index / Uno.Math.Max_8(1, this.Columns()["Uno.Collections.ICollection__Fuse_Layouts_Column.Count"]())) | 0;
            }
        };

        Fuse.Layouts.GridLayout.GetRowSpan = function(elm)
        {
            var v;

            if (elm.TryGetValue(Fuse.Layouts.GridLayout._rowSpanProperty, $CreateRef(function(){return v}, function($){v=$}, this)))
            {
                return $DownCast(v, 425);
            }
            else
            {
                return 1;
            }
        };

        I.GetActualColumn = function(elm, index)
        {
            var v;

            if (elm.TryGetValue(Fuse.Layouts.GridLayout._columnProperty, $CreateRef(function(){return v}, function($){v=$}, this)))
            {
                return $DownCast(v, 425);
            }
            else
            {
                return index % Uno.Math.Max_8(1, this.Columns()["Uno.Collections.ICollection__Fuse_Layouts_Column.Count"]());
            }
        };

        Fuse.Layouts.GridLayout.GetColumnSpan = function(elm)
        {
            var v;

            if (elm.TryGetValue(Fuse.Layouts.GridLayout._columnSpanProperty, $CreateRef(function(){return v}, function($){v=$}, this)))
            {
                return $DownCast(v, 425);
            }
            else
            {
                return 1;
            }
        };

        I.AddSubscriber = function(element)
        {
            this._subscriber = element;
        };

        I.RemoveSubscriber = function(element)
        {
            this._subscriber = null;
        };

        I.GetContentSize = function(elements, fillSize, fillSet)
        {
            return this.Measure(elements, fillSize, fillSet);
        };

        I.Measure = function(elements, fillSize, fillSet)
        {
            var fillSize_124 = new Uno.Float2;
            var cds_125 = new Uno.Float2;
            var cds_126 = new Uno.Float2;
            fillSize_124.op_Assign(fillSize);
            var fillHorizontal = (fillSet & 1) == 1;
            var fillVertical = (fillSet & 2) == 2;
            var availableWidth = fillSize_124.X;
            var availableHeight = fillSize_124.Y;

            for (var i = 0; i < this._columns.Count(); i++)
            {
                var c = this._columns.Item(i);

                if (c.WidthMetric() == 0)
                {
                    c.ActualWidth(c.Width());
                    availableWidth = availableWidth - c.Width();
                }
                else
                {
                    c.ActualWidth(0.0);
                }
            }

            for (var i = 0; i < this._rows.Count(); i++)
            {
                var r = this._rows.Item(i);

                if (r.HeightMetric() == 0)
                {
                    r.ActualHeight(r.Height());
                    availableHeight = availableHeight - r.Height();
                }
                else
                {
                    r.ActualHeight(0.0);
                }
            }

            availableWidth = Uno.Math.Max_1(availableWidth, 0.0);
            availableHeight = Uno.Math.Max_1(availableHeight, 0.0);

            for (var n = 0; n < elements["Uno.Collections.ICollection__Fuse_Element.Count"](); n++)
            {
                var child = elements["Uno.Collections.IList__Fuse_Element.Item"](n);
                var x = this.GetActualColumn(child, n);
                var y = this.GetActualRow(child, n);
                var c = (((x >= 0) && (x < this._columns.Count())) && (this._columns.Item(x).WidthMetric() == 2)) ? this._columns.Item(x) : null;
                var r = (((y >= 0) && (y < this._rows.Count())) && (this._rows.Item(y).HeightMetric() == 2)) ? this._rows.Item(y) : null;

                if ((c == null) && (r == null))
                {
                    continue;
                }

                cds_125.op_Assign(child.GetMarginSize(Uno.Float2.New_1(0.0), 0));

                if (c != null)
                {
                    c.ActualWidth(Uno.Math.Max_1(c.ActualWidth(), cds_125.X));
                    availableWidth = availableWidth - c.ActualWidth();
                }

                if (r != null)
                {
                    r.ActualHeight(Uno.Math.Max_1(r.ActualHeight(), cds_125.Y));
                    availableHeight = availableHeight - r.ActualHeight();
                }
            }

            availableWidth = Uno.Math.Max_1(availableWidth, 0.0);
            availableHeight = Uno.Math.Max_1(availableHeight, 0.0);
            var widthProportion = 0.0;
            var heightProportion = 0.0;

            for (var i = 0; i < this._columns.Count(); i++)
            {
                var c = this._columns.Item(i);

                if (c.WidthMetric() == 1)
                {
                    widthProportion = widthProportion + c.Width();
                }
            }

            for (var i = 0; i < this._rows.Count(); i++)
            {
                var r = this._rows.Item(i);

                if (r.HeightMetric() == 1)
                {
                    heightProportion = heightProportion + r.Height();
                }
            }

            if (fillHorizontal)
            {
                for (var i = 0; i < this._columns.Count(); i++)
                {
                    var c = this._columns.Item(i);

                    if (c.WidthMetric() == 1)
                    {
                        c.ActualWidth((c.Width() * availableWidth) / widthProportion);
                    }
                }
            }

            if (fillVertical)
            {
                for (var i = 0; i < this._rows.Count(); i++)
                {
                    var r = this._rows.Item(i);

                    if (r.HeightMetric() == 1)
                    {
                        r.ActualHeight((r.Height() * availableHeight) / heightProportion);
                    }
                }
            }

            if (!fillHorizontal || !fillVertical)
            {
                for (var n = 0; n < elements["Uno.Collections.ICollection__Fuse_Element.Count"](); n++)
                {
                    var child = elements["Uno.Collections.IList__Fuse_Element.Item"](n);
                    var width = availableWidth;
                    var height = availableHeight;
                    var x = this.GetActualColumn(child, n);
                    var y = this.GetActualRow(child, n);
                    var c = (((x >= 0) && (x < this._columns.Count())) && (this._columns.Item(x).WidthMetric() == 1)) ? this._columns.Item(x) : null;
                    var r = (((y >= 0) && (y < this._rows.Count())) && (this._rows.Item(y).HeightMetric() == 1)) ? this._rows.Item(y) : null;

                    if (c != null)
                    {
                        width = c.ActualWidth();
                    }

                    if (r != null)
                    {
                        height = r.ActualHeight();
                    }

                    if ((c == null) && (r == null))
                    {
                        continue;
                    }

                    var sf = 0;

                    if (fillHorizontal)
                    {
                        sf = sf | 1;
                    }

                    if (fillVertical)
                    {
                        sf = sf | 2;
                    }

                    cds_126.op_Assign(child.GetMarginSize(Uno.Float2.New_2(width, height), sf));

                    if (c != null)
                    {
                        if (!fillHorizontal)
                        {
                            c.ActualWidth(Uno.Math.Max_1(c.ActualWidth(), cds_126.X));
                        }
                    }

                    if (r != null)
                    {
                        if (!fillVertical)
                        {
                            r.ActualHeight(Uno.Math.Max_1(r.ActualHeight(), cds_126.Y));
                        }
                    }
                }
            }

            var totalWidth = 0.0;
            var totalHeight = 0.0;

            for (var i = 0; i < this._columns.Count(); i++)
            {
                var c = this._columns.Item(i);
                c.ActualOffset(totalWidth);
                totalWidth = totalWidth + c.ActualWidth();
            }

            for (var i = 0; i < this._rows.Count(); i++)
            {
                var r = this._rows.Item(i);
                r.ActualOffset(totalHeight);
                totalHeight = totalHeight + r.ActualHeight();
            }

            return Uno.Float2.New_2(totalWidth, totalHeight);
        };

        I.ArrangePaddingBox = function(elements, padding, availableSize)
        {
            var padding_127 = new Uno.Float4;
            var availableSize_128 = new Uno.Float2;
            var paddingOffset_129 = new Uno.Float2;
            padding_127.op_Assign(padding);
            availableSize_128.op_Assign(availableSize);
            this.Measure(elements, Uno.Float2.op_Subtraction(Uno.Float2.op_Subtraction(availableSize_128, Uno.Float2.New_2(padding_127.X, padding_127.Y)), Uno.Float2.New_2(padding_127.Z, padding_127.W)), 3);
            paddingOffset_129.op_Assign(Uno.Float2.New_2(padding_127.X, padding_127.Y));

            for (var n = 0; n < elements["Uno.Collections.ICollection__Fuse_Element.Count"](); n++)
            {
                var child = elements["Uno.Collections.IList__Fuse_Element.Item"](n);
                var column = this.GetActualColumn(child, n);
                var row = this.GetActualRow(child, n);
                var rowSpan = Fuse.Layouts.GridLayout.GetRowSpan(child);
                var columnSpan = Fuse.Layouts.GridLayout.GetColumnSpan(child);
                var x = 0.0;
                var y = 0.0;
                var w = availableSize_128.X;
                var h = availableSize_128.Y;

                if ((column >= 0) && (column < this._columns.Count()))
                {
                    var c = this._columns.Item(column);
                    x = c.ActualOffset();
                    w = c.ActualWidth();

                    for (var s = column + 1; s < Uno.Math.Min_8(this._columns.Count(), column + columnSpan); ++s)
                    {
                        w = w + this._columns.Item(s).ActualWidth();
                    }
                }

                if ((row >= 0) && (row < this._rows.Count()))
                {
                    var r = this._rows.Item(row);
                    y = r.ActualOffset();
                    h = r.ActualHeight();

                    for (var s = row + 1; s < Uno.Math.Min_8(this._rows.Count(), row + rowSpan); ++s)
                    {
                        h = h + this._rows.Item(s).ActualHeight();
                    }
                }

                child.ArrangeMarginBox(Uno.Float2.op_Addition(paddingOffset_129, Uno.Float2.New_2(x, y)), Uno.Float2.New_2(w, h), 3);
            }
        };

        Fuse.Layouts.GridLayout._TypeInit = function()
        {
            Fuse.Layouts.GridLayout._rowProperty = Fuse.PropertyHandle.New_1();
            Fuse.Layouts.GridLayout._rowSpanProperty = Fuse.PropertyHandle.New_1();
            Fuse.Layouts.GridLayout._columnProperty = Fuse.PropertyHandle.New_1();
            Fuse.Layouts.GridLayout._columnSpanProperty = Fuse.PropertyHandle.New_1();
        };

    });
