Fuse.Layouts.Row = $CreateClass(
    function() {
        Fuse.Layouts.DefinitionBase.call(this);
        this._heightMetric = 0;
        this._height = 0;
        this._actualHeight = 0;
    },
    function(S) {
        var I = S.prototype = new Fuse.Layouts.DefinitionBase;

        I.GetType = function()
        {
            return 906;
        };

        I.HeightMetric = function(value)
        {
            if (value !== undefined)
            {
                if (this._heightMetric != value)
                {
                    this._heightMetric = value;
                    this.OnChanged();
                }
            }
            else
            {
                return this._heightMetric;
            }
        };

        I.Height = function(value)
        {
            if (value !== undefined)
            {
                if (this._height != value)
                {
                    this._height = Uno.Math.Max_1(0.0, value);
                    this.OnChanged();
                }
            }
            else
            {
                return this._height;
            }
        };

        I.ActualHeight = function(value)
        {
            if (value !== undefined)
            {
                this._actualHeight = value;
            }
            else
            {
                if (this.HeightMetric() == 0)
                {
                    return this._height;
                }
                else
                {
                    return this._actualHeight;
                }
            }
        };

    });
