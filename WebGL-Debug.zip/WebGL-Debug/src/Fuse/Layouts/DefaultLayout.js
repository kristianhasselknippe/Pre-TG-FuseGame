Fuse.Layouts.DefaultLayout = $CreateClass(
    function() {
        Fuse.Layouts.Layout.call(this);
    },
    function(S) {
        var I = S.prototype = new Fuse.Layouts.Layout;

        I.GetType = function()
        {
            return 900;
        };

        I.GetContentSize = function(elements, fillSize, fillSet)
        {
            var fillSize_123 = new Uno.Float2;
            fillSize_123.op_Assign(fillSize);
            var size = this.GetElementsSize(elements, fillSize_123, fillSet);
            var recalc = false;

            if (!((fillSet & 1) == 1))
            {
                fillSize_123.X = size.X;
                fillSet = fillSet | 1;
                recalc = true;
            }

            if (!((fillSet & 2) == 2))
            {
                fillSize_123.Y = size.Y;
                fillSet = fillSet | 2;
                recalc = true;
            }

            if (recalc)
            {
                size = this.GetElementsSize(elements, fillSize_123, fillSet);
            }

            return size;
        };

        I.GetElementsSize = function(elements, fillSize, fillSet)
        {
            var ds = Uno.Float2.New_1(0.0);

            for (var i = 0; i < elements["Uno.Collections.ICollection__Fuse_Element.Count"](); i++)
            {
                ds = Uno.Math.Max_3(ds, elements["Uno.Collections.IList__Fuse_Element.Item"](i).GetMarginSize(fillSize, fillSet));
            }

            return ds;
        };

        I.ArrangePaddingBox = function(elements, padding, availableSize)
        {
            var padding_125 = new Uno.Float4;
            padding_125.op_Assign(padding);

            for (var i = 0; i < elements["Uno.Collections.ICollection__Fuse_Element.Count"](); i++)
            {
                elements["Uno.Collections.IList__Fuse_Element.Item"](i).ArrangeMarginBox(Uno.Float2.New_2(padding_125.X, padding_125.Y), Uno.Float2.op_Subtraction(Uno.Float2.op_Subtraction(availableSize, Uno.Float2.New_2(padding_125.X, padding_125.Y)), Uno.Float2.New_2(padding_125.Z, padding_125.W)), 3);
            }
        };

        I._ObjInit_1 = function()
        {
            Fuse.Layouts.Layout.prototype._ObjInit.call(this);
        };

        Fuse.Layouts.DefaultLayout.New_1 = function()
        {
            var inst = new Fuse.Layouts.DefaultLayout;
            inst._ObjInit_1();
            return inst;
        };

    });
