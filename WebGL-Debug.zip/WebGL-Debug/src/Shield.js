Shield = $CreateClass(
    function() {
        Powerup.call(this);
    },
    function(S) {
        var I = S.prototype = new Powerup;

        I.GetType = function()
        {
            return 1041;
        };

        I.GetAppearance = function()
        {
            this.Width(15.0);
            this.Height(15.0);
            var pb = FuseGame.ParticleBatcher.New_3(20.0, 100);
            pb.ParticleSize = 8.0;
            pb.Color = Uno.Float4.New_2(0.7, 0.7, 1.0, 0.2);
            return pb;
        };

    });
