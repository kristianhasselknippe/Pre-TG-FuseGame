GameObject = $CreateClass(
    function() {
        Fuse.Controls.Panel.call(this);
        this.Acceleration = 0;
        this.RotationSpeed = 0;
        this._trans = null;
        this._rot = null;
        this._velocity = new Uno.Float2;
        this._isCollidable = false;
        this._DisableUpdate = false;
    },
    function(S) {
        var I = S.prototype = new Fuse.Controls.Panel;

        GameObject._Game = null;

        I.GetType = function()
        {
            return 1033;
        };

        GameObject.Game = function(value)
        {
            if (value !== undefined)
            {
                GameObject._Game = value;
            }
            else
            {
                return GameObject._Game;
            }
        };

        GameObject.ScreenSize = function()
        {
            return GameObject.Game().ActualSize();
        };

        I.DisableUpdate = function(value)
        {
            if (value !== undefined)
            {
                this._DisableUpdate = value;
            }
            else
            {
                return this._DisableUpdate;
            }
        };

        I.Position = function(value)
        {
            if (value !== undefined)
            {
                this._trans.Vector(Uno.Float3.New_3(value, 0.0));
            }
            else
            {
                var ind_125 = this._trans.Vector();
                return Uno.Float2.New_2(ind_125.X, ind_125.Y);
            }
        };

        I.Rotation = function(value)
        {
            if (value !== undefined)
            {
                this._rot.Degrees(value);
            }
            else
            {
                return this._rot.Degrees();
            }
        };

        I.Velocity = function(value)
        {
            if (value !== undefined)
            {
                this._velocity.op_Assign(value);
            }
            else
            {
                return this._velocity;
            }
        };

        I.BoundingBox = function()
        {
            return Uno.Rect.New_2(Uno.Float2.op_Subtraction(this.Position(), Uno.Float2.op_Multiply(this.ActualSize(), 0.5)), this.ActualSize());
        };

        I.IsCollidable = function(value)
        {
            if (value !== undefined)
            {
                this._isCollidable = value;
            }
            else
            {
                return this._isCollidable;
            }
        };

        GameObject.SetGame = function(g)
        {
            GameObject.Game(g);
        };

        GameObject.Instantiate = function(go)
        {
            GameObject.Game().Add(go);
            Uno.Diagnostics.Debug.Log(Uno.String.op_Addition_1(Uno.String.op_Addition(Uno.String.op_Addition_1("Instantiated: ", go), ", TotalObjects: "), $CreateBox(GameObject.Game().Children()["Uno.Collections.ICollection__Fuse_Element.Count"](), 425)), 1, "/Users/vegard/Pre-TG-FuseGame/Simulation/Simulation.uno", 30);
        };

        GameObject.Destroy = function(go)
        {
            if (GameObject.Game().Children()["Uno.Collections.ICollection__Fuse_Element.Contains"](go))
            {
                GameObject.Game().Remove(go);
                Uno.Diagnostics.Debug.Log(Uno.String.op_Addition_1(Uno.String.op_Addition(Uno.String.op_Addition_1("Destroyed: ", go), ", TotalObjects: "), $CreateBox(GameObject.Game().Children()["Uno.Collections.ICollection__Fuse_Element.Count"](), 425)), 1, "/Users/vegard/Pre-TG-FuseGame/Simulation/Simulation.uno", 38);
            }
        };

        I.OnBaseUpdate = function(sender, args)
        {
            if (this.DisableUpdate())
            {
                return;
            }

            var dt = Fuse.Time.FrameInterval();
            this.OnUpdate(dt);
            this.Position(Uno.Float2.op_Addition(this.Position(), this.Velocity()));
        };

        I.OnUpdate = function(dt)
        {
        };

        I._ObjInit_4 = function()
        {
            this.Acceleration = 5.0;
            this.RotationSpeed = 5.0;
            this._trans = Fuse.Translation.New_1();
            this._rot = Fuse.Rotation.New_1();
            this._isCollidable = true;
            Fuse.Controls.Panel.prototype._ObjInit_3.call(this);
            this.Transforms()["Uno.Collections.ICollection__Fuse_Transform.Add"](this._trans);
            this.Transforms()["Uno.Collections.ICollection__Fuse_Transform.Add"](this._rot);
            this.add_Update($CreateDelegate(this, GameObject.prototype.OnBaseUpdate, 445));
        };

    });
