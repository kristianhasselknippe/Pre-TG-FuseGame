Experimental.TextureLoader.TextureLoader = $CreateClass(
    function() {
    },
    function(S) {

        Experimental.TextureLoader.TextureLoader.JpegByteArrayToTexture2D = function(arr, callback)
        {
            Experimental.TextureLoader.TextureLoaderImpl.JpegByteArrayToTexture2D(arr, Experimental.TextureLoader.Callback.New_1(callback));
        };

        Experimental.TextureLoader.TextureLoader.PngByteArrayToTexture2D = function(arr, callback)
        {
            Experimental.TextureLoader.TextureLoaderImpl.PngByteArrayToTexture2D(arr, Experimental.TextureLoader.Callback.New_1(callback));
        };

        Experimental.TextureLoader.TextureLoader.ByteArrayToTexture2DFilename = function(arr, filename, callback)
        {
            filename = filename.ToLower();

            if (Experimental.TextureLoader.TextureLoader.EndsWith(filename, ".png"))
            {
                Experimental.TextureLoader.TextureLoader.PngByteArrayToTexture2D(arr, callback);
            }
            else if (Experimental.TextureLoader.TextureLoader.EndsWith(filename, ".jpg") || Experimental.TextureLoader.TextureLoader.EndsWith(filename, ".jpeg"))
            {
                Experimental.TextureLoader.TextureLoader.JpegByteArrayToTexture2D(arr, callback);
            }
            else
            {
                throw new $Error(Experimental.TextureLoader.InvalidContentTypeException.New_3(filename));
            }
        };

        Experimental.TextureLoader.TextureLoader.EndsWith = function(str, suffix)
        {
            var strAt = str.length - 1;
            var suffixAt = suffix.length - 1;

            while ((strAt >= 0) && (suffixAt >= 0))
            {
                if (str.charCodeAt(strAt) != suffix.charCodeAt(suffixAt))
                {
                    return false;
                }

                strAt--;
                suffixAt--;
            }

            return suffixAt < 0;
        };

        Experimental.TextureLoader.TextureLoader.ByteArrayToTexture2DContentType = function(arr, contentType, callback)
        {
            if (contentType.IndexOf_1("image/jpeg", 0) != -1)
            {
                Experimental.TextureLoader.TextureLoader.JpegByteArrayToTexture2D(arr, callback);
            }
            else if (contentType.IndexOf_1("image/png", 0) != -1)
            {
                Experimental.TextureLoader.TextureLoader.PngByteArrayToTexture2D(arr, callback);
            }
            else
            {
                throw new $Error(Experimental.TextureLoader.InvalidContentTypeException.New_3(contentType));
            }
        };

    });
