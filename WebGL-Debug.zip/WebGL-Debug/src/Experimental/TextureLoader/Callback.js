Experimental.TextureLoader.Callback = $CreateClass(
    function() {
        this._action = null;
    },
    function(S) {
        var I = S.prototype;

        I.GetType = function()
        {
            return 551;
        };

        I.Execute = function(arg)
        {
            this._action.Invoke(arg);
        };

        I._ObjInit = function(action)
        {
            this._action = action;
        };

        Experimental.TextureLoader.Callback.New_1 = function(action)
        {
            var inst = new Experimental.TextureLoader.Callback;
            inst._ObjInit(action);
            return inst;
        };

    });
