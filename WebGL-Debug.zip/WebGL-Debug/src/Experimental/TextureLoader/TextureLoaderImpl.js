Experimental.TextureLoader.TextureLoaderImpl = $CreateClass(
    function() {
    },
    function(S) {

        Experimental.TextureLoader.TextureLoaderImpl.JpegByteArrayToTexture2D = function(__arr, __callback)
        {
            var byteArray = Uno.Marshalling.JavaScript.TypedArrays.CreateUint8Array(__arr), mimeType = 'image/jpeg', callback = __callback;
            var blob = new Blob([byteArray], {'type': mimeType});
            var url = window.URL || window.webkitURL;
            var img = new Image();
            img.crossOrigin='anonymous'
            
            var CreateTexture2D = function(image) {
                var handle = gl.createTexture(),
                    target = 3553,
                    format = 6408,
                    w = image.width,
                    h = image.height,
                    mc = 1,
                    size = Uno.Int2.New_2(w, h);
            
                gl.bindTexture(target, handle);
            
                try
                {
                    gl.texImage2D(target, 0, format, format, 5121, image);
                }
                catch (e)
                {
                    document.body.style.background = "#FFF";
                    document.body.innerHTML = "<p>Uncaught error: " + e.message + "</p><p><strong>This is probably because you are trying to load textures into WebGL while running locally from a file:// URL. Remember to start Chrome with the '--allow-file-access-from-files' command line flag. Make sure Chrome is running before launching Build and Run in Realtime Studio.</strong></p>";         
                }
            
                if ((w == (w & -w)) && (h == (h & -h))) {
                    gl.generateMipmap(target);
                    while (w > 1 || h > 1) {
                        w >>= 1;
                        h >>= 1;
                        mc++;
                    }
                }
                gl.bindTexture(target, null);
                return Uno.Graphics.Texture2D.New_1(handle, size, mc, 0);
            };
            
            var imageLoadHandler = function() {
                url.revokeObjectURL(img.src);
                __callback.Execute(CreateTexture2D(img));
            };
            
            var imgLoaded = false;
            var loadImg = function() {
                if (imgLoaded || (img.width === 0 && img.height === 0)) return;
                imgLoaded = true;
                imageLoadHandler();
            };
            img.addEventListener("load", loadImg, false);
            img.src = url.createObjectURL(blob);
            img.style.display = 'block';
            
            if(img.complete) { loadImg(); }
        };

        Experimental.TextureLoader.TextureLoaderImpl.PngByteArrayToTexture2D = function(__arr, __callback)
        {
            var byteArray = Uno.Marshalling.JavaScript.TypedArrays.CreateUint8Array(__arr), mimeType = 'image/png', callback = __callback;
            var blob = new Blob([byteArray], {'type': mimeType});
            var url = window.URL || window.webkitURL;
            var img = new Image();
            img.crossOrigin='anonymous'
            
            var CreateTexture2D = function(image) {
                var handle = gl.createTexture(),
                    target = 3553,
                    format = 6408,
                    w = image.width,
                    h = image.height,
                    mc = 1,
                    size = Uno.Int2.New_2(w, h);
            
                gl.bindTexture(target, handle);
            
                try
                {
                    gl.texImage2D(target, 0, format, format, 5121, image);
                }
                catch (e)
                {
                    document.body.style.background = "#FFF";
                    document.body.innerHTML = "<p>Uncaught error: " + e.message + "</p><p><strong>This is probably because you are trying to load textures into WebGL while running locally from a file:// URL. Remember to start Chrome with the '--allow-file-access-from-files' command line flag. Make sure Chrome is running before launching Build and Run in Realtime Studio.</strong></p>";         
                }
            
                if ((w == (w & -w)) && (h == (h & -h))) {
                    gl.generateMipmap(target);
                    while (w > 1 || h > 1) {
                        w >>= 1;
                        h >>= 1;
                        mc++;
                    }    
                }
                gl.bindTexture(target, null);
                return Uno.Graphics.Texture2D.New_1(handle, size, mc, 0);
            };
            
            var imageLoadHandler = function() {
                url.revokeObjectURL(img.src);
                __callback.Execute(CreateTexture2D(img));
            };
            
            var imgLoaded = false;
            var loadImg = function() {
                if (imgLoaded || (img.width === 0 && img.height === 0)) return;
                imgLoaded = true;
                imageLoadHandler();
            };
            img.addEventListener("load", loadImg, false);
            img.src = url.createObjectURL(blob);
            img.style.display = 'block';
            
            if(img.complete) { loadImg(); }
        };

    });
