Experimental.TextureLoader.InvalidContentTypeException = $CreateClass(
    function() {
        Uno.Exception.call(this);
    },
    function(S) {
        var I = S.prototype = new Uno.Exception;

        I.GetType = function()
        {
            return 552;
        };

        I._ObjInit_2 = function(reason)
        {
            Uno.Exception.prototype._ObjInit.call(this, reason);
        };

        Experimental.TextureLoader.InvalidContentTypeException.New_3 = function(reason)
        {
            var inst = new Experimental.TextureLoader.InvalidContentTypeException;
            inst._ObjInit_2(reason);
            return inst;
        };

    });
