Experimental.ApiBindings.WebAudio.AudioContextImpl = $CreateClass(
    function() {
    },
    function(S) {
        var I = S.prototype;

        I.GetType = function()
        {
            return 510;
        };

        Experimental.ApiBindings.WebAudio.AudioContextImpl.Create = function()
        {
            var context = null;
                            try
                            {
                                window.AudioContext = window.AudioContext||window.webkitAudioContext;
                                context = new AudioContext();
                            }
                            catch (exp)
                            {
                                alert("Web Audio API is not supported in this browser")
                            }
                            return context;
        };

        Experimental.ApiBindings.WebAudio.AudioContextImpl.GetDestination = function(handle)
        {
            return Experimental.ApiBindings.WebAudio.AudioDestinationNode.New_3(Experimental.ApiBindings.WebAudio.AudioContextImpl.GetDestinationNodeHandle(handle));
        };

        Experimental.ApiBindings.WebAudio.AudioContextImpl.GetDestinationNodeHandle = function(__handle)
        {
            return __handle.destination;
        };

        Experimental.ApiBindings.WebAudio.AudioContextImpl.InvokeCreateAnalyserNode = function(handle)
        {
            return Experimental.ApiBindings.WebAudio.AnalyserNode.New_3(Experimental.ApiBindings.WebAudio.AudioContextImpl.InvokeCreateAnalyserNodeHandle(handle));
        };

        Experimental.ApiBindings.WebAudio.AudioContextImpl.InvokeCreateAnalyserNodeHandle = function(__handle)
        {
            return __handle.createAnalyser();
        };

        Experimental.ApiBindings.WebAudio.AudioContextImpl.InvokeCreateBufferSource = function(handle)
        {
            return Experimental.ApiBindings.WebAudio.AudioBufferSourceNode.New_4(Experimental.ApiBindings.WebAudio.AudioContextImpl.InvokeCreateBufferSourceNodeHandle(handle));
        };

        Experimental.ApiBindings.WebAudio.AudioContextImpl.InvokeCreateBufferSourceNodeHandle = function(__handle)
        {
            return __handle.createBufferSource();
        };

        Experimental.ApiBindings.WebAudio.AudioContextImpl.InvokeCreateAudioBuffer = function(handle, uri, onLoadedCallback, onFailedCallback)
        {
            var audioBuffer = Experimental.ApiBindings.WebAudio.AudioBuffer.New_3(onLoadedCallback, onFailedCallback);
            Experimental.ApiBindings.WebAudio.AudioContextImpl.InvokeCreateAudioBufferHandle(handle, uri, $CreateDelegate(audioBuffer, Experimental.ApiBindings.WebAudio.AudioBuffer.prototype.OnLoadedCallback, 471), $CreateDelegate(audioBuffer, Experimental.ApiBindings.WebAudio.AudioBuffer.prototype.OnFailedCallback, 470));
        };

        Experimental.ApiBindings.WebAudio.AudioContextImpl.InvokeCreateAudioBufferHandle = function(__handle, __uri, __onLoadedCallback, __onFailedCallback)
        {
            var request = new XMLHttpRequest();
            
            request.open("GET", __uri, true);
            request.responseType = "arraybuffer";
            
            request.onload = function()
            {
            	__handle.decodeAudioData(
            		request.response,
            		function(buffer) {
            				__onLoadedCallback.Invoke(buffer);
            			},
            		function(error) {
            				__onFailedCallback.Invoke(error);
            			}
            		);
            };
            request.send();
        };

    });
