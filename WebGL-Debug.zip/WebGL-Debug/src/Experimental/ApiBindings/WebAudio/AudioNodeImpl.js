Experimental.ApiBindings.WebAudio.AudioNodeImpl = $CreateClass(
    function() {
    },
    function(S) {
        var I = S.prototype;

        I.GetType = function()
        {
            return 515;
        };

        Experimental.ApiBindings.WebAudio.AudioNodeImpl.InvokeConnect = function(__target, __source)
        {
            __target.connect(__source);
        };

    });
