Experimental.ApiBindings.WebAudio.AudioNode = $CreateClass(
    function() {
        this._audioNodeHandle = null;
    },
    function(S) {
        var I = S.prototype;

        I.GetType = function()
        {
            return 516;
        };

        I.AudioNodeHandle = function(value)
        {
            if (value !== undefined)
            {
                this._audioNodeHandle = value;
            }
            else
            {
                return this._audioNodeHandle;
            }
        };

        I.Connect = function(node)
        {
            Experimental.ApiBindings.WebAudio.AudioNodeImpl.InvokeConnect(this.AudioNodeHandle(), node.AudioNodeHandle());
        };

        I._ObjInit_1 = function(handle)
        {
            this.AudioNodeHandle(handle);
        };

    });
