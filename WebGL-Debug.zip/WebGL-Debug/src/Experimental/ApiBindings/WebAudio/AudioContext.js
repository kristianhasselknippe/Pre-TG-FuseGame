Experimental.ApiBindings.WebAudio.AudioContext = $CreateClass(
    function() {
        this._contextHandle = null;
    },
    function(S) {
        var I = S.prototype;

        Experimental.ApiBindings.WebAudio.AudioContext.DEFAULT_NUMBER_OF_INPUTS = 0;
        Experimental.ApiBindings.WebAudio.AudioContext.DEFAULT_NUMBER_OF_OUTPUTS = 0;

        I.GetType = function()
        {
            return 511;
        };

        I.ContextHandle = function(value)
        {
            if (value !== undefined)
            {
                this._contextHandle = value;
            }
            else
            {
                return this._contextHandle;
            }
        };

        I.Destination = function()
        {
            return Experimental.ApiBindings.WebAudio.AudioContextImpl.GetDestination(this.ContextHandle());
        };

        I.CreateAudioBufferSourceNode = function()
        {
            return Experimental.ApiBindings.WebAudio.AudioContextImpl.InvokeCreateBufferSource(this.ContextHandle());
        };

        I.CreateAnalyserNode = function()
        {
            return Experimental.ApiBindings.WebAudio.AudioContextImpl.InvokeCreateAnalyserNode(this.ContextHandle());
        };

        I.CreateAudioBuffer = function(bundleFile, onLoadedCallback)
        {
            this.CreateAudioBuffer_3(Uno.String.op_Addition("data/", bundleFile.Name()), onLoadedCallback, null);
        };

        I.CreateAudioBuffer_3 = function(uri, onLoadedCallback, onFailedCallback)
        {
            Experimental.ApiBindings.WebAudio.AudioContextImpl.InvokeCreateAudioBuffer(this.ContextHandle(), uri, onLoadedCallback, onFailedCallback);
        };

        Experimental.ApiBindings.WebAudio.AudioContext._TypeInit = function()
        {
            Experimental.ApiBindings.WebAudio.AudioContext.DEFAULT_NUMBER_OF_INPUTS = 6;
            Experimental.ApiBindings.WebAudio.AudioContext.DEFAULT_NUMBER_OF_OUTPUTS = 6;
        };

        I._ObjInit = function()
        {
            this.ContextHandle(Experimental.ApiBindings.WebAudio.AudioContextImpl.Create());
        };

        Experimental.ApiBindings.WebAudio.AudioContext.New_1 = function()
        {
            var inst = new Experimental.ApiBindings.WebAudio.AudioContext;
            inst._ObjInit();
            return inst;
        };

    });
