Experimental.ApiBindings.WebAudio.AnalyserNodeImpl = $CreateClass(
    function() {
        Experimental.ApiBindings.WebAudio.AudioNodeImpl.call(this);
    },
    function(S) {
        var I = S.prototype = new Experimental.ApiBindings.WebAudio.AudioNodeImpl;

        I.GetType = function()
        {
            return 520;
        };

        Experimental.ApiBindings.WebAudio.AnalyserNodeImpl.GetFftSize = function(__handle)
        {
            return __handle.fftSize;
        };

        Experimental.ApiBindings.WebAudio.AnalyserNodeImpl.SetFftSize = function(__handle, __fftSize)
        {
            __handle.fftSize = __fftSize;
        };

        Experimental.ApiBindings.WebAudio.AnalyserNodeImpl.GetFrequencyBinCount = function(__handle)
        {
            return __handle.frequencyBinCount;
        };

        Experimental.ApiBindings.WebAudio.AnalyserNodeImpl.GetSmoothingTimeConstat = function(__handle)
        {
            return __handle.smoothingTimeConstant;
        };

        Experimental.ApiBindings.WebAudio.AnalyserNodeImpl.SetSmoothingTimeConstat = function(__handle, __val)
        {
            __handle.smoothingTimeConstant = __val;
        };

        Experimental.ApiBindings.WebAudio.AnalyserNodeImpl.InvokeGetByteFrequencyData = function(__handle, __target)
        {
            __handle.getByteFrequencyData(__target);
        };

    });
