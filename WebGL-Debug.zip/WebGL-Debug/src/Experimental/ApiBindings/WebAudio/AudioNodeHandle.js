Experimental.ApiBindings.WebAudio.AudioNodeHandle = $CreateClass(
    function() {
    },
    function(S) {
        var I = S.prototype;

        I.GetType = function()
        {
            return 514;
        };

    });
