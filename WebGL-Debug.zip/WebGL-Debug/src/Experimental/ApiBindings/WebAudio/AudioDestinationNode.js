Experimental.ApiBindings.WebAudio.AudioDestinationNode = $CreateClass(
    function() {
        Experimental.ApiBindings.WebAudio.AudioNode.call(this);
    },
    function(S) {
        var I = S.prototype = new Experimental.ApiBindings.WebAudio.AudioNode;

        I.GetType = function()
        {
            return 519;
        };

        I._ObjInit_2 = function(handle)
        {
            Experimental.ApiBindings.WebAudio.AudioNode.prototype._ObjInit_1.call(this, handle);
        };

        Experimental.ApiBindings.WebAudio.AudioDestinationNode.New_3 = function(handle)
        {
            var inst = new Experimental.ApiBindings.WebAudio.AudioDestinationNode;
            inst._ObjInit_2(handle);
            return inst;
        };

    });
