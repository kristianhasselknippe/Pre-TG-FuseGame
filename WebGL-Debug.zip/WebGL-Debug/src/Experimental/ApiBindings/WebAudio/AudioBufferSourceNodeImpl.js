Experimental.ApiBindings.WebAudio.AudioBufferSourceNodeImpl = $CreateClass(
    function() {
        Experimental.ApiBindings.WebAudio.AudioNodeImpl.call(this);
    },
    function(S) {
        var I = S.prototype = new Experimental.ApiBindings.WebAudio.AudioNodeImpl;

        I.GetType = function()
        {
            return 517;
        };

        Experimental.ApiBindings.WebAudio.AudioBufferSourceNodeImpl.GetBuffer = function(__handle)
        {
            return __handle.buffer;
        };

        Experimental.ApiBindings.WebAudio.AudioBufferSourceNodeImpl.SetBuffer = function(__handle, __value)
        {
            __handle.buffer = __value;
        };

        Experimental.ApiBindings.WebAudio.AudioBufferSourceNodeImpl.InvokeStart = function(__handle, __when, __offset)
        {
            __handle.start(__when,__offset);
        };

        Experimental.ApiBindings.WebAudio.AudioBufferSourceNodeImpl.RegisterOnEndedEvent = function(__handle, __callback)
        {
            __handle.onended = function(event) { __callback.Invoke(); };
        };

    });
