Experimental.ApiBindings.WebAudio.AudioBufferSourceNode = $CreateClass(
    function() {
        Experimental.ApiBindings.WebAudio.AudioNode.call(this);
        this.OnEnded = null;
    },
    function(S) {
        var I = S.prototype = new Experimental.ApiBindings.WebAudio.AudioNode;

        I.GetType = function()
        {
            return 518;
        };

        I.Buffer = function(value)
        {
            if (value !== undefined)
            {
                Experimental.ApiBindings.WebAudio.AudioBufferSourceNodeImpl.SetBuffer(this.AudioNodeHandle(), value.AudioBufferHandle());
            }
            else
            {
                return Experimental.ApiBindings.WebAudio.AudioBuffer.New_2(Experimental.ApiBindings.WebAudio.AudioBufferSourceNodeImpl.GetBuffer(this.AudioNodeHandle()));
            }
        };

        I.OnEndedHandler = function()
        {
            if (Uno.Delegate.op_Inequality(this.OnEnded, null))
            {
                this.OnEnded.Invoke(this, Uno.EventArgs.New_1());
            }
        };

        I.Start = function()
        {
            Experimental.ApiBindings.WebAudio.AudioBufferSourceNodeImpl.InvokeStart(this.AudioNodeHandle(), 0.0, 0.0);
        };

        I._ObjInit_3 = function(handle)
        {
            Experimental.ApiBindings.WebAudio.AudioNode.prototype._ObjInit_1.call(this, handle);
            Experimental.ApiBindings.WebAudio.AudioBufferSourceNodeImpl.RegisterOnEndedEvent(this.AudioNodeHandle(), $CreateDelegate(this, Experimental.ApiBindings.WebAudio.AudioBufferSourceNode.prototype.OnEndedHandler, 436));
        };

        Experimental.ApiBindings.WebAudio.AudioBufferSourceNode.New_4 = function(handle)
        {
            var inst = new Experimental.ApiBindings.WebAudio.AudioBufferSourceNode;
            inst._ObjInit_3(handle);
            return inst;
        };

    });
