Experimental.ApiBindings.WebAudio.AudioBuffer = $CreateClass(
    function() {
        this._audioBufferHandle = null;
        this._onLoadedCallback = null;
        this._onFailedCallback = null;
    },
    function(S) {
        var I = S.prototype;

        I.GetType = function()
        {
            return 513;
        };

        I.AudioBufferHandle = function(value)
        {
            if (value !== undefined)
            {
                this._audioBufferHandle = value;
            }
            else
            {
                return this._audioBufferHandle;
            }
        };

        I.OnLoadedCallback = function(handle)
        {
            this.AudioBufferHandle(handle);
            this._onLoadedCallback.Invoke(this);
        };

        I.OnFailedCallback = function(err)
        {
            this._onFailedCallback.Invoke(err);
        };

        I._ObjInit_1 = function(handle)
        {
            this.AudioBufferHandle(handle);
        };

        Experimental.ApiBindings.WebAudio.AudioBuffer.New_2 = function(handle)
        {
            var inst = new Experimental.ApiBindings.WebAudio.AudioBuffer;
            inst._ObjInit_1(handle);
            return inst;
        };

        I._ObjInit_2 = function(onLoadedCallback, onFailedCallback)
        {
            this._onLoadedCallback = onLoadedCallback;
            this._onFailedCallback = onFailedCallback;
        };

        Experimental.ApiBindings.WebAudio.AudioBuffer.New_3 = function(onLoadedCallback, onFailedCallback)
        {
            var inst = new Experimental.ApiBindings.WebAudio.AudioBuffer;
            inst._ObjInit_2(onLoadedCallback, onFailedCallback);
            return inst;
        };

    });
