Experimental.ApiBindings.WebAudio.AnalyserNode = $CreateClass(
    function() {
        Experimental.ApiBindings.WebAudio.AudioNode.call(this);
    },
    function(S) {
        var I = S.prototype = new Experimental.ApiBindings.WebAudio.AudioNode;

        I.GetType = function()
        {
            return 521;
        };

        I.FftSize = function(value)
        {
            if (value !== undefined)
            {
                Experimental.ApiBindings.WebAudio.AnalyserNodeImpl.SetFftSize(this.AudioNodeHandle(), value);
            }
            else
            {
                return Experimental.ApiBindings.WebAudio.AnalyserNodeImpl.GetFftSize(this.AudioNodeHandle());
            }
        };

        I.FrequencyBinCount = function()
        {
            return Experimental.ApiBindings.WebAudio.AnalyserNodeImpl.GetFrequencyBinCount(this.AudioNodeHandle());
        };

        I.SmoothingTimeConstat = function(value)
        {
            if (value !== undefined)
            {
                Experimental.ApiBindings.WebAudio.AnalyserNodeImpl.SetSmoothingTimeConstat(this.AudioNodeHandle(), value);
            }
            else
            {
                return Experimental.ApiBindings.WebAudio.AnalyserNodeImpl.GetSmoothingTimeConstat(this.AudioNodeHandle());
            }
        };

        I.GetByteFrequencyData = function(target)
        {
            Experimental.ApiBindings.WebAudio.AnalyserNodeImpl.InvokeGetByteFrequencyData(this.AudioNodeHandle(), target);
        };

        I._ObjInit_2 = function(handle)
        {
            Experimental.ApiBindings.WebAudio.AudioNode.prototype._ObjInit_1.call(this, handle);
        };

        Experimental.ApiBindings.WebAudio.AnalyserNode.New_3 = function(handle)
        {
            var inst = new Experimental.ApiBindings.WebAudio.AnalyserNode;
            inst._ObjInit_2(handle);
            return inst;
        };

    });
