Experimental.Net.Http.HttpResponse__Experimental_Net_Http_HttpBufferContent = $CreateClass(
    function() {
        this._StatusCode = 0;
        this._Headers = null;
        this._Content = null;
    },
    function(S) {
        var I = S.prototype;

        I.GetType = function()
        {
            return 549;
        };

        I.StatusCode = function(value)
        {
            if (value !== undefined)
            {
                this._StatusCode = value;
            }
            else
            {
                return this._StatusCode;
            }
        };

        I.Headers = function(value)
        {
            if (value !== undefined)
            {
                this._Headers = value;
            }
            else
            {
                return this._Headers;
            }
        };

        I.Content = function(value)
        {
            if (value !== undefined)
            {
                this._Content = value;
            }
            else
            {
                return this._Content;
            }
        };

        I._ObjInit = function()
        {
        };

        Experimental.Net.Http.HttpResponse__Experimental_Net_Http_HttpBufferContent.New_1 = function()
        {
            var inst = new Experimental.Net.Http.HttpResponse__Experimental_Net_Http_HttpBufferContent;
            inst._ObjInit();
            return inst;
        };

    });
