Experimental.Net.Http.HttpMessageHandlerRequest = $CreateClass(
    function() {
        this._isDisposed = false;
        this._isAborted = false;
        this._isErrored = false;
        this._isSent = false;
        this._requestHandle = null;
        this._state = 0;
        this._responseType = 0;
        this._method = null;
        this._url = null;
        this._optionalPayloadCache = null;
        this.Error = null;
        this.Done = null;
        this.Aborted = null;
        this.Timeout = null;
        this.StateChanged = null;
        this.Progress = null;
    },
    function(S) {
        var I = S.prototype;

        I.GetType = function()
        {
            return 536;
        };

        I.$II = function(id)
        {
            return [418].indexOf(id) != -1;
        };

        I.Method = function()
        {
            return this._method;
        };

        I.Handle = function()
        {
            return this._requestHandle;
        };

        I.State = function()
        {
            return this._state;
        };

        I.OnAborted = function()
        {
            this._state = 0;
            this._isAborted = true;
            this._isErrored = true;

            if (Uno.Delegate.op_Inequality(this.Aborted, null))
            {
                this.Aborted.Invoke(this);
            }
        };

        I.OnError = function(platformspesificErrorMessage)
        {
            this._isErrored = true;

            if (Uno.Delegate.op_Inequality(this.Error, null))
            {
                this.Error.Invoke(this, platformspesificErrorMessage);
            }
        };

        I.OnTimeout = function()
        {
            if (Uno.Delegate.op_Inequality(this.Timeout, null))
            {
                this.Timeout.Invoke(this);
            }
        };

        I.OnDone = function()
        {
            if (Uno.Delegate.op_Inequality(this.Done, null))
            {
                this.Done.Invoke(this);
            }
        };

        I.OnProgress = function(current, total, hasTotal)
        {
            if (Uno.Delegate.op_Inequality(this.Progress, null))
            {
                this.Progress.Invoke(this, current, total, hasTotal);
            }
        };

        I.OnStateChanged = function()
        {
            if (this._isAborted)
            {
                return;
            }

            this._state = this.GetState();

            if (Uno.Delegate.op_Inequality(this.StateChanged, null))
            {
                this.StateChanged.Invoke(this);
            }
        };

        I.GetState = function()
        {
            this.CheckDisposed();
            return this._state = Experimental.Net.Http.Implementation.HttpRequestImpl.GetState(this._requestHandle);
        };

        I.SetTimeout = function(timeoutInMilliseconds)
        {
            this.CheckDisposed();

            if (this.State() > 1)
            {
                throw new $Error(Experimental.Net.Http.InvalidStateException.New_3());
            }

            Experimental.Net.Http.Implementation.HttpRequestImpl.SetTimeout(this._requestHandle, timeoutInMilliseconds);
        };

        I.SetResponseType = function(responseType)
        {
            this.CheckDisposed();

            if (this.State() >= 4)
            {
                throw new $Error(Experimental.Net.Http.InvalidStateException.New_3());
            }

            this._responseType = responseType;

            if (responseType != -1)
            {
                Experimental.Net.Http.Implementation.HttpRequestImpl.SetResponseType(this._requestHandle, responseType);
            }
        };

        I.SendAsync = function(data)
        {
            this.CheckDisposed();

            if (this.State() != 1)
            {
                throw new $Error(Experimental.Net.Http.InvalidStateException.New_3());
            }

            if (this._isSent)
            {
                throw new $Error(Experimental.Net.Http.InvalidStateException.New_4("Message already sent"));
            }

            if (((Uno.String.op_Equality(this.Method(), "GET") || Uno.String.op_Equality(this.Method(), "HEAD")) || (data == null)) || (data == Array.Zeros(0, 421)))
            {
                Experimental.Net.Http.Implementation.HttpRequestImpl.SendAsync_2(this._requestHandle);
            }
            else
            {
                Experimental.Net.Http.Implementation.HttpRequestImpl.SendByteArrayAsync(this._requestHandle, data);
            }

            this._isSent = true;
        };

        I.SendAsync_1 = function(data)
        {
            this.CheckDisposed();

            if (this.State() != 1)
            {
                throw new $Error(Experimental.Net.Http.InvalidStateException.New_3());
            }

            if (this._isSent)
            {
                throw new $Error(Experimental.Net.Http.InvalidStateException.New_4("Message already sent"));
            }

            if (((Uno.String.op_Equality(this.Method(), "GET") || Uno.String.op_Equality(this.Method(), "HEAD")) || Uno.String.op_Equality(data, null)) || Uno.String.op_Equality(data, ""))
            {
                Experimental.Net.Http.Implementation.HttpRequestImpl.SendAsync_2(this._requestHandle);
            }
            else
            {
                Experimental.Net.Http.Implementation.HttpRequestImpl.SendStringAsync(this._requestHandle, data);
            }

            this._isSent = true;
        };

        I.GetResponseStatus = function()
        {
            this.CheckDisposed();

            if (this.State() < 3)
            {
                return 0;
            }

            if (this._isErrored)
            {
                return 0;
            }

            return Experimental.Net.Http.Implementation.HttpRequestImpl.GetResponseStatus(this._requestHandle);
        };

        I.GetResponseHeaders = function()
        {
            this.CheckDisposed();

            if (this._isErrored)
            {
                return "";
            }

            if (this.State() < 3)
            {
                return "";
            }

            return Experimental.Net.Http.Implementation.HttpRequestImpl.GetResponseHeaders(this._requestHandle);
        };

        I.GetResponseContentByteArray = function()
        {
            this.CheckDisposed();

            if (this.State() < 4)
            {
                return Array.Zeros(0, 421);
            }

            if (this._isErrored)
            {
                return Array.Zeros(0, 421);
            }

            if (this._responseType != 1)
            {
                throw new $Error(Experimental.Net.Http.InvalidResponseTypeException.New_3());
            }

            var ind_124 = Experimental.Net.Http.Implementation.HttpRequestImpl.GetResponseContentByteArray(this._requestHandle);
            return (ind_124 != null) ? ind_124 : Array.Zeros(0, 421);
        };

        I.CheckDisposed = function()
        {
            if (this._isDisposed)
            {
                throw new $Error(Experimental.Net.Http.ObjectDisposedException.New_4("HttpMessageHandlerRequest"));
            }
        };

        I.Dispose = function()
        {
            Experimental.Net.Http.Implementation.HttpRequestImpl.Dispose(this._requestHandle);
            this._optionalPayloadCache = null;
            this._isDisposed = true;
        };

        I._ObjInit = function(clientHandle, method, url)
        {
            this._responseType = -1;

            if (clientHandle == null)
            {
                throw new $Error(Uno.ArgumentNullException.New_5("clientHandle"));
            }

            if (Uno.String.op_Equality(method, null))
            {
                throw new $Error(Uno.ArgumentNullException.New_5("method"));
            }

            if (Uno.String.op_Equality(url, null))
            {
                throw new $Error(Uno.ArgumentNullException.New_5("url"));
            }

            this._method = method.ToUpper();

            if (((((Uno.String.op_Inequality(this._method, "DELETE") && Uno.String.op_Inequality(this._method, "GET")) && Uno.String.op_Inequality(this._method, "HEAD")) && Uno.String.op_Inequality(this._method, "POST")) && Uno.String.op_Inequality(this._method, "PUT")) && Uno.String.op_Inequality(this._method, "OPTIONS"))
            {
                throw new $Error(Uno.NotSupportedException.New_4("HTTP method not supported."));
            }

            this._url = url;
            this._requestHandle = Experimental.Net.Http.Implementation.HttpClientImpl.CreateRequest(clientHandle, this._method, this._url);
            this._state = this.GetState();
        };

        Experimental.Net.Http.HttpMessageHandlerRequest.New_1 = function(clientHandle, method, url)
        {
            var inst = new Experimental.Net.Http.HttpMessageHandlerRequest;
            inst._ObjInit(clientHandle, method, url);
            return inst;
        };

        I.add_Error = function(value)
        {
            this.Error = $DownCast(Uno.Delegate.Combine(this.Error, value), 487);
        };

        I.add_Done = function(value)
        {
            this.Done = $DownCast(Uno.Delegate.Combine(this.Done, value), 474);
        };

        I["Uno.IDisposable.Dispose"] = I.Dispose;

    });
