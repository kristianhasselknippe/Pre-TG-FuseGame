Experimental.Net.Http.InvalidResponseTypeException = $CreateClass(
    function() {
        Uno.Exception.call(this);
    },
    function(S) {
        var I = S.prototype = new Uno.Exception;

        I.GetType = function()
        {
            return 538;
        };

        I._ObjInit_2 = function()
        {
            Uno.Exception.prototype._ObjInit.call(this, "Response type is invalid.");
        };

        Experimental.Net.Http.InvalidResponseTypeException.New_3 = function()
        {
            var inst = new Experimental.Net.Http.InvalidResponseTypeException;
            inst._ObjInit_2();
            return inst;
        };

    });
