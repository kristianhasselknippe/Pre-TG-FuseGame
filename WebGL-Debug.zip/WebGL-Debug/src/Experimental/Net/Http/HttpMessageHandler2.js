Experimental.Net.Http.HttpMessageHandler2 = $CreateClass(
    function() {
        this._contentHandlers = null;
        this.OnError = null;
    },
    function(S) {
        var I = S.prototype;

        Experimental.Net.Http.HttpMessageHandler2._messageHandler = null;
        Experimental.Net.Http.HttpMessageHandler2.hack = null;

        I.GetType = function()
        {
            return 530;
        };

        I.OnErrorCallback = function(messageHandlerRequest, platformspesificErrorMessage)
        {
            if (Uno.Delegate.op_Inequality(this.OnError, null))
            {
                this.OnError.Invoke(platformspesificErrorMessage);
            }
        };

        I.RegisterContentHandler = function(httpContentHandler)
        {
            this._contentHandlers["Uno.Collections.ICollection__Experimental_Net_Http_HttpContent.Add"](httpContentHandler);
        };

        I.SendAsync__Experimental_Net_Http_HttpBufferContent = function(request, callback)
        {
            return Experimental.Net.Http.HttpMessageHandler2.SendAsync__Experimental_Net_Http_HttpBufferContent_1(Experimental.Net.Http.HttpMessageHandler2._messageHandler, request, callback, this._contentHandlers, $CreateDelegate(this, Experimental.Net.Http.HttpMessageHandler2.prototype.OnErrorCallback, 487));
        };

        Experimental.Net.Http.HttpMessageHandler2.SendAsync__Experimental_Net_Http_HttpBufferContent_1 = function(messageHandler, request, callback, contentHandlers, OnError)
        {
            var messageHandlerRequest = messageHandler.CreateRequest(Experimental.Net.Http.HttpMethodStringConverter.ToString(request.Method), request.Url);
            messageHandlerRequest.SetTimeout((request.Timeout() == 0) ? 100000 : request.Timeout());

            if ($IsOp(Experimental.Net.Http.HttpBufferContent.New_1(), 546))
            {
                messageHandlerRequest.SetResponseType(1);
            }
            else
            {
                messageHandlerRequest.SetResponseType(0);
            }

            var ab = Experimental.Net.Http.HttpMessageHandler2_ActionBridge__Experimental_Net_Http_HttpBufferContent.New_1(callback, contentHandlers);
            messageHandlerRequest.add_Error(OnError);
            messageHandlerRequest.add_Done($CreateDelegate(ab, Experimental.Net.Http.HttpMessageHandler2_ActionBridge__Experimental_Net_Http_HttpBufferContent.prototype.ExecuteCallback, 474));

            if ((request.Raw != null) && (request.Raw.length > 0))
            {
                messageHandlerRequest.SendAsync(request.Raw);
            }
            else
            {
                messageHandlerRequest.SendAsync_1(request.Content);
            }

            Experimental.Net.Http.HttpMessageHandler2.hack = ab;
            return request;
        };

        I._ObjInit = function()
        {
            Experimental.Net.Http.HttpMessageHandler2._messageHandler = Experimental.Net.Http.HttpMessageHandler.New_1();
            this._contentHandlers = $DownCast(Uno.Collections.List__Experimental_Net_Http_HttpContent.New_1(), 32915);
        };

        Experimental.Net.Http.HttpMessageHandler2.New_1 = function()
        {
            var inst = new Experimental.Net.Http.HttpMessageHandler2;
            inst._ObjInit();
            return inst;
        };

    });
