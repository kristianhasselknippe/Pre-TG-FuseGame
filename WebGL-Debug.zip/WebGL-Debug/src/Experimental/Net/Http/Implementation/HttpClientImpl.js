Experimental.Net.Http.Implementation.HttpClientImpl = $CreateClass(
    function() {
    },
    function(S) {

        Experimental.Net.Http.Implementation.HttpClientImpl.Create = function()
        {
            return {};
        };

        Experimental.Net.Http.Implementation.HttpClientImpl.Dispose = function(__handle)
        {
        };

        Experimental.Net.Http.Implementation.HttpClientImpl.Update = function(__handle)
        {
        };

        Experimental.Net.Http.Implementation.HttpClientImpl.CreateRequest = function(__handle, __method, __url)
        {
            var r = new XMLHttpRequest();
            r.onabort = function(e) { Experimental.Net.Http.Implementation.HttpRequestCallbacks.OnAborted(r); }
            r.onerror = function(e) { Experimental.Net.Http.Implementation.HttpRequestCallbacks.OnError(r, e); }
            r.ontimeout = function(e) { Experimental.Net.Http.Implementation.HttpRequestCallbacks.OnTimeout(r); }
            r.onload = function(e) { Experimental.Net.Http.Implementation.HttpRequestCallbacks.OnDone(r); }
            r.onreadystatechange = function(e) { Experimental.Net.Http.Implementation.HttpRequestCallbacks.OnStateChanged(r); }
            r.onprogress = function(e) { Experimental.Net.Http.Implementation.HttpRequestCallbacks.OnProgress(r, e.loaded, e.total, e.lengthComputable); }
            r.open(__method, __url, true);
            return r;
        };

    });
