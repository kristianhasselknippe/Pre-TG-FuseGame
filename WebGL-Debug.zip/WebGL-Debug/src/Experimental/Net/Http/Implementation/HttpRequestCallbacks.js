Experimental.Net.Http.Implementation.HttpRequestCallbacks = $CreateClass(
    function() {
    },
    function(S) {
        Experimental.Net.Http.Implementation.HttpRequestCallbacks.Aborted = null;
        Experimental.Net.Http.Implementation.HttpRequestCallbacks.Error = null;
        Experimental.Net.Http.Implementation.HttpRequestCallbacks.Timeout = null;
        Experimental.Net.Http.Implementation.HttpRequestCallbacks.Done = null;
        Experimental.Net.Http.Implementation.HttpRequestCallbacks.StateChanged = null;
        Experimental.Net.Http.Implementation.HttpRequestCallbacks.Progress = null;

        Experimental.Net.Http.Implementation.HttpRequestCallbacks.OnAborted = function(handle)
        {
            if (Uno.Delegate.op_Inequality(Experimental.Net.Http.Implementation.HttpRequestCallbacks.Aborted, null))
            {
                Experimental.Net.Http.Implementation.HttpRequestCallbacks.Aborted.Invoke(Experimental.Net.Http.Implementation.HttpRequestEventArgs.New_1(handle));
            }
        };

        Experimental.Net.Http.Implementation.HttpRequestCallbacks.OnError = function(handle, platformspesificErrorMessage)
        {
            if (Uno.Delegate.op_Inequality(Experimental.Net.Http.Implementation.HttpRequestCallbacks.Error, null))
            {
                Experimental.Net.Http.Implementation.HttpRequestCallbacks.Error.Invoke(Experimental.Net.Http.Implementation.HttpRequestEventArgs.New_1(handle), platformspesificErrorMessage);
            }
        };

        Experimental.Net.Http.Implementation.HttpRequestCallbacks.OnTimeout = function(handle)
        {
            if (Uno.Delegate.op_Inequality(Experimental.Net.Http.Implementation.HttpRequestCallbacks.Timeout, null))
            {
                Experimental.Net.Http.Implementation.HttpRequestCallbacks.Timeout.Invoke(Experimental.Net.Http.Implementation.HttpRequestEventArgs.New_1(handle));
            }
        };

        Experimental.Net.Http.Implementation.HttpRequestCallbacks.OnDone = function(handle)
        {
            if (Uno.Delegate.op_Inequality(Experimental.Net.Http.Implementation.HttpRequestCallbacks.Done, null))
            {
                Experimental.Net.Http.Implementation.HttpRequestCallbacks.Done.Invoke(Experimental.Net.Http.Implementation.HttpRequestEventArgs.New_1(handle));
            }
        };

        Experimental.Net.Http.Implementation.HttpRequestCallbacks.OnStateChanged = function(handle)
        {
            if (Uno.Delegate.op_Inequality(Experimental.Net.Http.Implementation.HttpRequestCallbacks.StateChanged, null))
            {
                Experimental.Net.Http.Implementation.HttpRequestCallbacks.StateChanged.Invoke(Experimental.Net.Http.Implementation.HttpRequestEventArgs.New_1(handle));
            }
        };

        Experimental.Net.Http.Implementation.HttpRequestCallbacks.OnProgress = function(handle, current, total, hasTotal)
        {
            if (Uno.Delegate.op_Inequality(Experimental.Net.Http.Implementation.HttpRequestCallbacks.Progress, null))
            {
                Experimental.Net.Http.Implementation.HttpRequestCallbacks.Progress.Invoke(Experimental.Net.Http.Implementation.HttpRequestEventArgs.New_1(handle), current, total, hasTotal);
            }
        };

        Experimental.Net.Http.Implementation.HttpRequestCallbacks.ClearState = function()
        {
        };

        Experimental.Net.Http.Implementation.HttpRequestCallbacks.add_Aborted = function(value)
        {
            Experimental.Net.Http.Implementation.HttpRequestCallbacks.Aborted = $DownCast(Uno.Delegate.Combine(Experimental.Net.Http.Implementation.HttpRequestCallbacks.Aborted, value), 472);
        };

        Experimental.Net.Http.Implementation.HttpRequestCallbacks.remove_Aborted = function(value)
        {
            Experimental.Net.Http.Implementation.HttpRequestCallbacks.Aborted = $DownCast(Uno.Delegate.Remove(Experimental.Net.Http.Implementation.HttpRequestCallbacks.Aborted, value), 472);
        };

        Experimental.Net.Http.Implementation.HttpRequestCallbacks.add_Error = function(value)
        {
            Experimental.Net.Http.Implementation.HttpRequestCallbacks.Error = $DownCast(Uno.Delegate.Combine(Experimental.Net.Http.Implementation.HttpRequestCallbacks.Error, value), 486);
        };

        Experimental.Net.Http.Implementation.HttpRequestCallbacks.remove_Error = function(value)
        {
            Experimental.Net.Http.Implementation.HttpRequestCallbacks.Error = $DownCast(Uno.Delegate.Remove(Experimental.Net.Http.Implementation.HttpRequestCallbacks.Error, value), 486);
        };

        Experimental.Net.Http.Implementation.HttpRequestCallbacks.add_Timeout = function(value)
        {
            Experimental.Net.Http.Implementation.HttpRequestCallbacks.Timeout = $DownCast(Uno.Delegate.Combine(Experimental.Net.Http.Implementation.HttpRequestCallbacks.Timeout, value), 472);
        };

        Experimental.Net.Http.Implementation.HttpRequestCallbacks.remove_Timeout = function(value)
        {
            Experimental.Net.Http.Implementation.HttpRequestCallbacks.Timeout = $DownCast(Uno.Delegate.Remove(Experimental.Net.Http.Implementation.HttpRequestCallbacks.Timeout, value), 472);
        };

        Experimental.Net.Http.Implementation.HttpRequestCallbacks.add_Done = function(value)
        {
            Experimental.Net.Http.Implementation.HttpRequestCallbacks.Done = $DownCast(Uno.Delegate.Combine(Experimental.Net.Http.Implementation.HttpRequestCallbacks.Done, value), 472);
        };

        Experimental.Net.Http.Implementation.HttpRequestCallbacks.remove_Done = function(value)
        {
            Experimental.Net.Http.Implementation.HttpRequestCallbacks.Done = $DownCast(Uno.Delegate.Remove(Experimental.Net.Http.Implementation.HttpRequestCallbacks.Done, value), 472);
        };

        Experimental.Net.Http.Implementation.HttpRequestCallbacks.add_StateChanged = function(value)
        {
            Experimental.Net.Http.Implementation.HttpRequestCallbacks.StateChanged = $DownCast(Uno.Delegate.Combine(Experimental.Net.Http.Implementation.HttpRequestCallbacks.StateChanged, value), 472);
        };

        Experimental.Net.Http.Implementation.HttpRequestCallbacks.remove_StateChanged = function(value)
        {
            Experimental.Net.Http.Implementation.HttpRequestCallbacks.StateChanged = $DownCast(Uno.Delegate.Remove(Experimental.Net.Http.Implementation.HttpRequestCallbacks.StateChanged, value), 472);
        };

        Experimental.Net.Http.Implementation.HttpRequestCallbacks.add_Progress = function(value)
        {
            Experimental.Net.Http.Implementation.HttpRequestCallbacks.Progress = $DownCast(Uno.Delegate.Combine(Experimental.Net.Http.Implementation.HttpRequestCallbacks.Progress, value), 490);
        };

        Experimental.Net.Http.Implementation.HttpRequestCallbacks.remove_Progress = function(value)
        {
            Experimental.Net.Http.Implementation.HttpRequestCallbacks.Progress = $DownCast(Uno.Delegate.Remove(Experimental.Net.Http.Implementation.HttpRequestCallbacks.Progress, value), 490);
        };

    });
