Experimental.Net.Http.Implementation.HttpRequestEventArgs = $CreateClass(
    function() {
        this.$struct = true;
        this.Handle = null;
    },
    function(S) {
        var I = S.prototype;

        I.GetType = function()
        {
            return 527;
        };

        I.op_Assign = function(value)
        {
            this.Handle = value.Handle;
        };

        I._ObjInit = function(handle)
        {
            this.Handle = handle;
        };

        Experimental.Net.Http.Implementation.HttpRequestEventArgs.New_1 = function(handle)
        {
            var inst = new Experimental.Net.Http.Implementation.HttpRequestEventArgs;
            inst._ObjInit(handle);
            return inst;
        };

    });
