Experimental.Net.Http.Implementation.HttpRequestImpl = $CreateClass(
    function() {
    },
    function(S) {

        Experimental.Net.Http.Implementation.HttpRequestImpl.Dispose = function(__handle)
        {
        };

        Experimental.Net.Http.Implementation.HttpRequestImpl.SetTimeout = function(__handle, __timeoutInMilliseconds)
        {
            __handle.timeout = __timeoutInMilliseconds;
        };

        Experimental.Net.Http.Implementation.HttpRequestImpl.SetResponseType = function(__handle, __responseType)
        {
            __handle.responseType = ['text', 'arraybuffer'][__responseType];
        };

        Experimental.Net.Http.Implementation.HttpRequestImpl.GetState = function(__handle)
        {
            return (__handle.readyState < 2) ? __handle.readyState : __handle.readyState + 1;
        };

        Experimental.Net.Http.Implementation.HttpRequestImpl.SendByteArrayAsync = function(__handle, __data)
        {
            __handle.send(__data);
        };

        Experimental.Net.Http.Implementation.HttpRequestImpl.SendStringAsync = function(__handle, __data)
        {
            __handle.send(__data);
        };

        Experimental.Net.Http.Implementation.HttpRequestImpl.SendAsync_2 = function(__handle)
        {
            __handle.send();
        };

        Experimental.Net.Http.Implementation.HttpRequestImpl.GetResponseStatus = function(__handle)
        {
            return __handle.status;
        };

        Experimental.Net.Http.Implementation.HttpRequestImpl.GetResponseHeaders = function(__handle)
        {
            return __handle.getAllResponseHeaders();
        };

        Experimental.Net.Http.Implementation.HttpRequestImpl.GetResponseContentByteArray = function(__handle)
        {
            return new Uint8Array(__handle.response);
        };

    });
