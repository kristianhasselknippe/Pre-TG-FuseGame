Experimental.Net.Http.HttpBufferContent = $CreateClass(
    function() {
        Experimental.Net.Http.HttpContent.call(this);
    },
    function(S) {
        var I = S.prototype = new Experimental.Net.Http.HttpContent;

        I.GetType = function()
        {
            return 546;
        };

        I.ReadAsBufferAsync = function(callback)
        {
            callback.Invoke(Uno.Buffer.New_2(this._messageRequest.GetResponseContentByteArray()));
        };

        I._ObjInit_1 = function()
        {
            Experimental.Net.Http.HttpContent.prototype._ObjInit.call(this);
        };

        Experimental.Net.Http.HttpBufferContent.New_1 = function()
        {
            var inst = new Experimental.Net.Http.HttpBufferContent;
            inst._ObjInit_1();
            return inst;
        };

    });
