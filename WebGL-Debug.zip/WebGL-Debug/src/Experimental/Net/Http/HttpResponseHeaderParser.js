Experimental.Net.Http.HttpResponseHeaderParser = $CreateClass(
    function() {
    },
    function(S) {
        var I = S.prototype;

        I.GetType = function()
        {
            return 531;
        };

        Experimental.Net.Http.HttpResponseHeaderParser.GetAll = function(headerString)
        {
            var array_123;
            var index_124;
            var length_125;
            var headers = Experimental.Net.Http.HttpResponseHeaders.New_3();

            for (array_123 = headerString.Split(Array.Init([10], 420)), index_124 = 0, length_125 = array_123.length; index_124 < length_125; ++index_124)
            {
                var header = array_123[index_124];
                var index = header.IndexOf(58, 0);

                if (index < 0)
                {
                    headers.Add(header, $DownCast(Uno.Collections.List__string.New_1(), 32825));
                }
                else
                {
                    var key = header.Substring(0, index);
                    var value = header.Substring(index + 1, (header.length - index) - 1);
                    headers.Add(key, Experimental.Net.Http.HttpResponseHeaderParser.ToIEnumerable__string(value.Split(Array.Init([44], 420))));
                }
            }

            return headers;
        };

        Experimental.Net.Http.HttpResponseHeaderParser.ToIEnumerable__string = function(array)
        {
            var array_123;
            var index_124;
            var length_125;
            var list = Uno.Collections.List__string.New_1();

            for (array_123 = array, index_124 = 0, length_125 = array_123.length; index_124 < length_125; ++index_124)
            {
                var item = array_123[index_124];
                list.Add(item);
            }

            return $DownCast(list, 32825);
        };

    });
