Experimental.Net.Http.ObjectDisposedException = $CreateClass(
    function() {
        Uno.Exception.call(this);
    },
    function(S) {
        var I = S.prototype = new Uno.Exception;

        I.GetType = function()
        {
            return 537;
        };

        I._ObjInit_3 = function(objectname)
        {
            Uno.Exception.prototype._ObjInit.call(this, (Uno.String.op_Inequality(Uno.String.op_Addition("Cannot access a disposed object.", objectname), null) && Uno.String.op_Inequality(objectname, "")) ? Uno.String.op_Addition("Object name: ", objectname) : "");
        };

        Experimental.Net.Http.ObjectDisposedException.New_4 = function(objectname)
        {
            var inst = new Experimental.Net.Http.ObjectDisposedException;
            inst._ObjInit_3(objectname);
            return inst;
        };

    });
