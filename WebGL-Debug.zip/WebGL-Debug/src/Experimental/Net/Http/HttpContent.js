Experimental.Net.Http.HttpContent = $CreateClass(
    function() {
        this._messageRequest = null;
    },
    function(S) {
        var I = S.prototype;

        I.GetType = function()
        {
            return 544;
        };

        I.SetResponseHandle = function(handle)
        {
            this._messageRequest = handle;
        };

        I._ObjInit = function()
        {
        };

    });
