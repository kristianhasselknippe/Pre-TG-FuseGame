Experimental.Net.Http.HttpResponseHeaders = $CreateClass(
    function() {
        Experimental.Net.Http.HttpHeaders.call(this);
    },
    function(S) {
        var I = S.prototype = new Experimental.Net.Http.HttpHeaders;

        I.GetType = function()
        {
            return 534;
        };

        I._ObjInit_2 = function()
        {
            Experimental.Net.Http.HttpHeaders.prototype._ObjInit.call(this);
        };

        Experimental.Net.Http.HttpResponseHeaders.New_3 = function()
        {
            var inst = new Experimental.Net.Http.HttpResponseHeaders;
            inst._ObjInit_2();
            return inst;
        };

    });
