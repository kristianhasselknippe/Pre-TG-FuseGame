Experimental.Net.Http.HttpHeaders = $CreateClass(
    function() {
        this._headers = null;
    },
    function(S) {
        var I = S.prototype;

        I.GetType = function()
        {
            return 532;
        };

        I.Item = function(name, value)
        {
            if (value !== undefined)
            {
                this._headers["Uno.Collections.IDictionary__string__Uno_Collections_IEnumerable_string_.Item"](name, value);
            }
            else
            {
                return this._headers["Uno.Collections.IDictionary__string__Uno_Collections_IEnumerable_string_.Item"](name);
            }
        };

        I.Add = function(name, value)
        {
            this._headers["Uno.Collections.IDictionary__string__Uno_Collections_IEnumerable_string_.Add"](name, value);
        };

        I.Contains = function(name)
        {
            return this._headers["Uno.Collections.IDictionary__string__Uno_Collections_IEnumerable_string_.ContainsKey"](name);
        };

        I._ObjInit = function()
        {
            this._ObjInit_1($DownCast(Uno.Collections.Dictionary__string__Uno_Collections_IEnumerable_string_.New_1(), 32871));
        };

        I._ObjInit_1 = function(headers)
        {
            this._headers = headers;
        };

    });
