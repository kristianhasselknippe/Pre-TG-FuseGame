Experimental.Net.Http.InvalidStateException = $CreateClass(
    function() {
        Uno.Exception.call(this);
    },
    function(S) {
        var I = S.prototype = new Uno.Exception;

        I.GetType = function()
        {
            return 539;
        };

        I._ObjInit_2 = function()
        {
            Uno.Exception.prototype._ObjInit.call(this, "The object is in an invalid state.");
        };

        Experimental.Net.Http.InvalidStateException.New_3 = function()
        {
            var inst = new Experimental.Net.Http.InvalidStateException;
            inst._ObjInit_2();
            return inst;
        };

        I._ObjInit_3 = function(message)
        {
            Uno.Exception.prototype._ObjInit.call(this, message);
        };

        Experimental.Net.Http.InvalidStateException.New_4 = function(message)
        {
            var inst = new Experimental.Net.Http.InvalidStateException;
            inst._ObjInit_3(message);
            return inst;
        };

    });
