Experimental.Net.Http.HttpMessageInvoker = $CreateClass(
    function() {
        this._handler = null;
        this.OnError = null;
    },
    function(S) {
        var I = S.prototype;

        I.GetType = function()
        {
            return 540;
        };

        I.RegisterContentHandler = function(httpContentHandler)
        {
            this._handler.RegisterContentHandler(httpContentHandler);
        };

        I.SendAsync__Experimental_Net_Http_HttpBufferContent = function(request, callback)
        {
            if (Uno.Delegate.op_Inequality(this.OnError, null))
            {
                this._handler.OnError = this.OnError;
            }

            return this._handler.SendAsync__Experimental_Net_Http_HttpBufferContent(request, callback);
        };

        I._ObjInit = function(handler)
        {
            this._handler = handler;
        };

        I.add_OnError = function(value)
        {
            this.OnError = $DownCast(Uno.Delegate.Combine(this.OnError, value), 470);
        };

    });
