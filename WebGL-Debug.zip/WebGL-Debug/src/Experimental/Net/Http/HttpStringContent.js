Experimental.Net.Http.HttpStringContent = $CreateClass(
    function() {
        Experimental.Net.Http.HttpContent.call(this);
    },
    function(S) {
        var I = S.prototype = new Experimental.Net.Http.HttpContent;

        I.GetType = function()
        {
            return 545;
        };

        I._ObjInit_1 = function()
        {
            Experimental.Net.Http.HttpContent.prototype._ObjInit.call(this);
        };

        Experimental.Net.Http.HttpStringContent.New_1 = function()
        {
            var inst = new Experimental.Net.Http.HttpStringContent;
            inst._ObjInit_1();
            return inst;
        };

    });
