Experimental.Net.Http.HttpMessageHandler = $CreateClass(
    function() {
        this._isDisposed = false;
        this._pendingRequests = null;
        this._clientHandle = null;
    },
    function(S) {
        var I = S.prototype;

        I.GetType = function()
        {
            return 535;
        };

        I.$II = function(id)
        {
            return [418].indexOf(id) != -1;
        };

        I.SubscribeToEvents = function()
        {
            Uno.Application.Current().Window().add_Updating($CreateDelegate(this, Experimental.Net.Http.HttpMessageHandler.prototype.Update, 445));
            Experimental.Net.Http.Implementation.HttpRequestCallbacks.add_Aborted($CreateDelegate(this, Experimental.Net.Http.HttpMessageHandler.prototype.OnAbortedCallback, 472));
            Experimental.Net.Http.Implementation.HttpRequestCallbacks.add_Error($CreateDelegate(this, Experimental.Net.Http.HttpMessageHandler.prototype.OnErrorCallback, 486));
            Experimental.Net.Http.Implementation.HttpRequestCallbacks.add_Timeout($CreateDelegate(this, Experimental.Net.Http.HttpMessageHandler.prototype.OnTimeoutCallback, 472));
            Experimental.Net.Http.Implementation.HttpRequestCallbacks.add_Done($CreateDelegate(this, Experimental.Net.Http.HttpMessageHandler.prototype.OnDoneCallback, 472));
            Experimental.Net.Http.Implementation.HttpRequestCallbacks.add_StateChanged($CreateDelegate(this, Experimental.Net.Http.HttpMessageHandler.prototype.OnStateChangedCallback, 472));
            Experimental.Net.Http.Implementation.HttpRequestCallbacks.add_Progress($CreateDelegate(this, Experimental.Net.Http.HttpMessageHandler.prototype.OnProgressCallback, 490));
        };

        I.UnsubscribeFromEvents = function()
        {
            Uno.Application.Current().Window().remove_Updating($CreateDelegate(this, Experimental.Net.Http.HttpMessageHandler.prototype.Update, 445));
            Experimental.Net.Http.Implementation.HttpRequestCallbacks.remove_Aborted($CreateDelegate(this, Experimental.Net.Http.HttpMessageHandler.prototype.OnAbortedCallback, 472));
            Experimental.Net.Http.Implementation.HttpRequestCallbacks.remove_Error($CreateDelegate(this, Experimental.Net.Http.HttpMessageHandler.prototype.OnErrorCallback, 486));
            Experimental.Net.Http.Implementation.HttpRequestCallbacks.remove_Timeout($CreateDelegate(this, Experimental.Net.Http.HttpMessageHandler.prototype.OnTimeoutCallback, 472));
            Experimental.Net.Http.Implementation.HttpRequestCallbacks.remove_Done($CreateDelegate(this, Experimental.Net.Http.HttpMessageHandler.prototype.OnDoneCallback, 472));
            Experimental.Net.Http.Implementation.HttpRequestCallbacks.remove_StateChanged($CreateDelegate(this, Experimental.Net.Http.HttpMessageHandler.prototype.OnStateChangedCallback, 472));
            Experimental.Net.Http.Implementation.HttpRequestCallbacks.remove_Progress($CreateDelegate(this, Experimental.Net.Http.HttpMessageHandler.prototype.OnProgressCallback, 490));
        };

        I.OnAbortedCallback = function(eventArgs)
        {
            var eventArgs_124 = new Experimental.Net.Http.Implementation.HttpRequestEventArgs;
            eventArgs_124.op_Assign(eventArgs);
            var pendingRequest = this.TryGetCorrespondingRequest(eventArgs_124.Handle);

            if (pendingRequest != null)
            {
                pendingRequest.OnAborted();
                this._pendingRequests.Remove(pendingRequest);
            }
        };

        I.OnErrorCallback = function(eventArgs, platformspesificErrorMessage)
        {
            var eventArgs_125 = new Experimental.Net.Http.Implementation.HttpRequestEventArgs;
            eventArgs_125.op_Assign(eventArgs);
            var pendingRequest = this.TryGetCorrespondingRequest(eventArgs_125.Handle);

            if (pendingRequest != null)
            {
                pendingRequest.OnError(platformspesificErrorMessage);
                this._pendingRequests.Remove(pendingRequest);
            }
        };

        I.OnTimeoutCallback = function(eventArgs)
        {
            var eventArgs_126 = new Experimental.Net.Http.Implementation.HttpRequestEventArgs;
            eventArgs_126.op_Assign(eventArgs);
            var pendingRequest = this.TryGetCorrespondingRequest(eventArgs_126.Handle);

            if (pendingRequest != null)
            {
                pendingRequest.OnTimeout();
                this._pendingRequests.Remove(pendingRequest);
            }
        };

        I.OnDoneCallback = function(eventArgs)
        {
            var eventArgs_127 = new Experimental.Net.Http.Implementation.HttpRequestEventArgs;
            eventArgs_127.op_Assign(eventArgs);
            var pendingRequest = this.TryGetCorrespondingRequest(eventArgs_127.Handle);

            if (pendingRequest != null)
            {
                pendingRequest.OnDone();
                this._pendingRequests.Remove(pendingRequest);
            }
        };

        I.OnStateChangedCallback = function(eventArgs)
        {
            var eventArgs_128 = new Experimental.Net.Http.Implementation.HttpRequestEventArgs;
            eventArgs_128.op_Assign(eventArgs);
            var pendingRequest = this.TryGetCorrespondingRequest(eventArgs_128.Handle);

            if (pendingRequest != null)
            {
                pendingRequest.OnStateChanged();
            }
        };

        I.OnProgressCallback = function(eventArgs, current, total, hasTotal)
        {
            var eventArgs_129 = new Experimental.Net.Http.Implementation.HttpRequestEventArgs;
            eventArgs_129.op_Assign(eventArgs);
            var pendingRequest = this.TryGetCorrespondingRequest(eventArgs_129.Handle);

            if (pendingRequest != null)
            {
                pendingRequest.OnProgress(current, total, hasTotal);
            }
        };

        I.TryGetCorrespondingRequest = function(handle)
        {
            for (var i = 0; i < this._pendingRequests.Count(); i++)
            {
                if (this._pendingRequests.Item(i).Handle() == handle)
                {
                    return this._pendingRequests.Item(i);
                }
            }

            return null;
        };

        I.CreateRequest = function(method, url)
        {
            var httpMessageHandlerRequest = Experimental.Net.Http.HttpMessageHandlerRequest.New_1(this._clientHandle, method, url);
            this._pendingRequests.Add(httpMessageHandlerRequest);
            return httpMessageHandlerRequest;
        };

        I.Update = function(sender, args)
        {
            Experimental.Net.Http.Implementation.HttpClientImpl.Update(this._clientHandle);
        };

        I.Dispose = function()
        {
            for (var enum_123 = this._pendingRequests.GetEnumerator(); enum_123.MoveNext(); )
            {
                var request = enum_123.Current();
                request.Dispose();
            }

            Experimental.Net.Http.Implementation.HttpClientImpl.Dispose(this._clientHandle);
            this.UnsubscribeFromEvents();
            this._isDisposed = true;
        };

        Experimental.Net.Http.HttpMessageHandler._TypeInit = function()
        {
            Experimental.Net.Http.Implementation.HttpRequestCallbacks.ClearState();
        };

        I._ObjInit = function()
        {
            this._pendingRequests = Uno.Collections.List__Experimental_Net_Http_HttpMessageHandlerRequest.New_1();
            this._clientHandle = Experimental.Net.Http.Implementation.HttpClientImpl.Create();
            this.SubscribeToEvents();
        };

        Experimental.Net.Http.HttpMessageHandler.New_1 = function()
        {
            var inst = new Experimental.Net.Http.HttpMessageHandler;
            inst._ObjInit();
            return inst;
        };

        I["Uno.IDisposable.Dispose"] = I.Dispose;

    });
