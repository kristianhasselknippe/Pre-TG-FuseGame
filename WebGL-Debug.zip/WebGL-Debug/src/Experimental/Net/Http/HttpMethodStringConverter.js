Experimental.Net.Http.HttpMethodStringConverter = $CreateClass(
    function() {
    },
    function(S) {
        Experimental.Net.Http.HttpMethodStringConverter.StringMethods = null;

        Experimental.Net.Http.HttpMethodStringConverter.ToString = function(httpMethod)
        {
            var v = httpMethod;

            if ((v < 0) && (v > Experimental.Net.Http.HttpMethodStringConverter.StringMethods.length))
            {
                throw new $Error(Uno.ArgumentException.New_4("HttpMethod not valid", "httpMethod"));
            }

            return Experimental.Net.Http.HttpMethodStringConverter.StringMethods[v];
        };

        Experimental.Net.Http.HttpMethodStringConverter._TypeInit = function()
        {
            Experimental.Net.Http.HttpMethodStringConverter.StringMethods = Array.Init(["GET", "POST", "PUT", "DELETE", "OPTIONS", "HEAD", "TRACE", "CONNECT", "PATCH"], 414);
        };

    });
