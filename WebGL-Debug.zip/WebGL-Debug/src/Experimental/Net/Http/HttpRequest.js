Experimental.Net.Http.HttpRequest = $CreateClass(
    function() {
        this.Url = null;
        this.Method = 0;
        this.Headers = null;
        this.Content = null;
        this.Raw = null;
        this._Timeout = 0;
    },
    function(S) {
        var I = S.prototype;

        I.GetType = function()
        {
            return 543;
        };

        I.Timeout = function(value)
        {
            if (value !== undefined)
            {
                this._Timeout = value;
            }
            else
            {
                return this._Timeout;
            }
        };

        I._ObjInit = function()
        {
            this.Headers = Experimental.Net.Http.HttpRequestHeaders.New_3();
            this.Timeout(5000);
            this.Content = "";
        };

        I._ObjInit_1 = function(method, url)
        {
            this._ObjInit();
            this.Method = method;
            this.Url = url;
        };

        Experimental.Net.Http.HttpRequest.New_2 = function(method, url)
        {
            var inst = new Experimental.Net.Http.HttpRequest;
            inst._ObjInit_1(method, url);
            return inst;
        };

    });
