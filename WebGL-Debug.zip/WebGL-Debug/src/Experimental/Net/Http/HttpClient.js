Experimental.Net.Http.HttpClient = $CreateClass(
    function() {
        Experimental.Net.Http.HttpMessageInvoker.call(this);
    },
    function(S) {
        var I = S.prototype = new Experimental.Net.Http.HttpMessageInvoker;

        I.GetType = function()
        {
            return 529;
        };

        I._ObjInit_1 = function()
        {
            Experimental.Net.Http.HttpMessageInvoker.prototype._ObjInit.call(this, Experimental.Net.Http.HttpMessageHandler2.New_1());
            this.RegisterContentHandler(Experimental.Net.Http.HttpStringContent.New_1());
            this.RegisterContentHandler(Experimental.Net.Http.HttpBufferContent.New_1());
        };

        Experimental.Net.Http.HttpClient.New_2 = function()
        {
            var inst = new Experimental.Net.Http.HttpClient;
            inst._ObjInit_1();
            return inst;
        };

    });
