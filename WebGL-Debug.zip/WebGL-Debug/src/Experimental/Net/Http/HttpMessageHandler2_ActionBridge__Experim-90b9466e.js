Experimental.Net.Http.HttpMessageHandler2_ActionBridge__Experimental_Net_Http_HttpBufferContent = $CreateClass(
    function() {
        this._requestCallback = null;
        this._response = null;
        this._contentHandlers = null;
    },
    function(S) {
        var I = S.prototype;

        I.GetType = function()
        {
            return 550;
        };

        I.ExecuteCallback = function(eventArgs)
        {
            this._response = this.CreateResponse(eventArgs);
            this.Method(this._response);
        };

        I.Method = function(response)
        {
            this._requestCallback.Invoke(response);
        };

        I.CreateResponse = function(req)
        {
            var r = Experimental.Net.Http.HttpResponse__Experimental_Net_Http_HttpBufferContent.New_1();
            r.StatusCode(req.GetResponseStatus());
            r.Headers(Experimental.Net.Http.HttpResponseHeaderParser.GetAll(req.GetResponseHeaders()));
            r.Content(this.CreateResponseContent(req));
            return r;
        };

        I.CreateResponseContent = function(r)
        {
            for (var enum_123 = this._contentHandlers["Uno.Collections.IEnumerable__Experimental_Net_Http_HttpContent.GetEnumerator"](); enum_123["Uno.Collections.IEnumerator.MoveNext"](); )
            {
                var contentHandler = enum_123["Uno.Collections.IEnumerator__Experimental_Net_Http_HttpContent.Current"]();

                if ($IsOp(contentHandler, 546))
                {
                    contentHandler.SetResponseHandle(r);
                    return $DownCast(contentHandler, 546);
                }
            }

            return null;
        };

        I._ObjInit = function(callback, contentHandlers)
        {
            this._requestCallback = callback;
            this._contentHandlers = contentHandlers;
        };

        Experimental.Net.Http.HttpMessageHandler2_ActionBridge__Experimental_Net_Http_HttpBufferContent.New_1 = function(callback, contentHandlers)
        {
            var inst = new Experimental.Net.Http.HttpMessageHandler2_ActionBridge__Experimental_Net_Http_HttpBufferContent;
            inst._ObjInit(callback, contentHandlers);
            return inst;
        };

    });
