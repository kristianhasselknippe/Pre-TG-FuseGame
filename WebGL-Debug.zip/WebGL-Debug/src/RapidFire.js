RapidFire = $CreateClass(
    function() {
        Powerup.call(this);
    },
    function(S) {
        var I = S.prototype = new Powerup;

        I.GetType = function()
        {
            return 1040;
        };

        I.GetAppearance = function()
        {
            var ind_125;
            var collection_123;
            var panel = Fuse.Controls.Panel.New_2();
            panel.Children()["Uno.Collections.ICollection__Fuse_Element.Add"]((collection_123 = Fuse.Shapes.Rectangle.New_1(), ind_125 = Fuse.Drawing.SolidColor.New_2(Uno.Float4.New_2(1.0, 0.0, 0.0, 1.0)), collection_123.Fill(ind_125), ind_125, collection_123));
            return panel;
        };

        I._ObjInit_6 = function(pos)
        {
            Powerup.prototype._ObjInit_5.call(this, pos);
            this.Width(30.0);
            this.Height(30.0);
            this.Duration = 5.0;
        };

        RapidFire.New_5 = function(pos)
        {
            var inst = new RapidFire;
            inst._ObjInit_6(pos);
            return inst;
        };

    });
